Mode: **REBUILD** | Phase: **tokens** | Route: **type_system_recommendation**
Loaded skills: `type-system-expert`, `accessibility-feedback-expert`

---

### **Reading Context**
- **Marketing site**: long-form, editorial, trust-building
- **Web app dashboard**: dense tables, KPIs, filters, real-time updates
- **Mobile**: small screens, touch targets, variable ambient light
- **Fintech trust posture**: clarity > speed, precision > playfulness

---

### **Scale & Role Map**
| Role               | Desktop (px) | Mobile (px) | Weight | Line height | Use case                          |
|--------------------|--------------|-------------|--------|-------------|-----------------------------------|
| Display            | 48–64        | 32–40       | 700    | 1.1         | Hero headlines, trust badges     |
| Heading 1          | 32           | 24          | 600    | 1.2         | Section titles, onboarding        |
| Heading 2          | 24           | 20          | 500    | 1.3         | Sub-sections, dashboard cards    |
| Heading 3          | 20           | 18          | 500    | 1.4         | Widget titles, table headers      |
| Body               | 16           | 16          | 400    | 1.5         | Long-form, tooltips, disclaimers  |
| Data (tables)      | 14           | 14          | 400    | 1.4         | Financial figures, labels         |
| Meta               | 12           | 12          | 400    | 1.4         | Timestamps, legal footnotes       |
| Button/Action      | 16           | 16          | 500    | 1.3         | CTAs, primary actions              |

**Notes**:
- **Data role**: Monospace fallback (e.g., `ui-monospace`) for tabular numbers to enforce alignment.
- **Mobile**: No size reduction for body/data roles to preserve readability.
- **Weights**: 400 (regular), 500 (medium), 600 (semibold), 700 (bold) — avoid 300/200 to maintain clarity in dense tables.

---

### **Typeface Recommendations**
#### **Primary System: Inter + IBM Plex Mono**
- **Inter** (sans-serif):
  - **Why**: Designed for screens, high x-height, neutral fintech tone, supports variable weights (400–700).
  - **Roles**: Display, headings, body, buttons.
  - **Fallback**: `system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`.
  - **Variable font**: `Inter.var` (opsz 14–48) for responsive optical sizing.

- **IBM Plex Mono** (monospace):
  - **Why**: Clean, modern, and trustworthy (IBM’s brand equity). Aligns numbers in tables without feeling "code-y."
  - **Roles**: Data tables, financial figures, input fields.
  - **Fallback**: `SF Mono, Menlo, Consolas, monospace`.

#### **Alternative: Figtree + JetBrains Mono**
- **Figtree** (sans-serif):
  - **Why**: Rounded terminals feel approachable but professional; good for marketing-heavy fintech.
  - **Roles**: Headings, body (avoid for dense tables).
- **JetBrains Mono** (monospace):
  - **Why**: More open apertures than IBM Plex Mono; better for long-form disclaimers.

**Avoid**:
- **Geometric sans** (e.g., Futura, Avenir): Can feel cold or impersonal for trust-sensitive fintech.
- **Humanist sans** (e.g., Frutiger, Myriad): Too generic; lacks fintech-specific credibility.

---

### **Readability Rules**
1. **Line length**:
   - Body: 45–75 characters (marketing) / 35–50 characters (tables).
   - Mobile: 100% width with 16px margins.
2. **Contrast**:
   - Text: **≥4.5:1** (WCAG AA) against backgrounds.
   - Data tables: **≥7:1** (WCAG AAA) for critical figures.
   - Use [APCA](https://www.myndex.com/APCA/) for dark mode (e.g., `#2D3748` on `#1A202C`).
3. **Spacing**:
   - Body: `line-height: 1.5` (16px base → 24px).
   - Tables: `line-height: 1.4` (14px base → 19.6px) to reduce vertical density.
4. **Emphasis**:
   - **Bold (700)**: Trust badges, KPIs, primary actions.
   - **Medium (500)**: Headings, secondary actions.
   - **Regular (400)**: Body, disclaimers (avoid italics for legal text).

---

### **Adoption Guidance**
1. **Phase 1 (Tokens)**:
   - Define CSS variables for roles (e.g., `--text-body`, `--text-data-mono`).
   - Use `clamp()` for responsive sizing (e.g., `clamp(16px, 1vw, 20px)` for body).
2. **Phase 2 (Components)**:
   - Replace hardcoded sizes in buttons, tables, and cards.
   - Add `font-variant-numeric: tabular-nums` to data tables for alignment.
3. **Phase 3 (Dark Mode)**:
   - Test APCA contrast for all roles (e.g., [APCA Contrast Calculator](https://www.myndex.com/APCA/)).
   - Adjust weights: Use 500 for body in dark mode to reduce "glow."

---

### **Why This Reads as Trustworthy**
- **Precision**: Monospace for financial data signals accuracy.
- **Neutrality**: Inter’s neutrality avoids "salesy" associations.
- **Hierarchy**: Clear weight progression guides attention without shouting.
- **Accessibility**: Meets WCAG AA/AAA for contrast; avoids italics for legal text.

**Tradeoff**: Slightly larger mobile footprint (no size reduction for body/data) prioritizes clarity over space.

---
**Next steps**:
1. Generate CSS variables for the role map.
2. Audit tables with `font-variant-numeric: tabular-nums`.
3. Test dark mode with APCA contrast.