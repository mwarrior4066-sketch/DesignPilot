Here’s the **API Reliability and Security Review** for `POST /exports`, structured under the governing route `api_reliability_security_review` with supporting evidence classes and required decisions:

---

### **Failure Semantics and Error Contract**
**Problem**: The endpoint uses HTTP 200 for *all* responses (success, validation errors, timeouts, internal failures), violating [RFC 9457 (Problem Details)](https://datatracker.ietf.org/doc/html/rfc9457). This forces clients to parse opaque payloads to distinguish outcomes, increasing coupling and fragility. Internal enum values in errors (e.g., `ERROR_CODE_INVALID_TEMPLATE`) expose implementation details, aiding attackers and complicating client-side error handling.

**Required Decisions**:
1. **Problem Details Contract**:
   - Adopt `application/problem+json` with mandatory fields: `type` (URI reference), `title` (human-readable), `status` (HTTP code), `detail` (specific error), and `instance` (request ID).
   - Example for timeout:
     ```json
     {
       "type": "https://api.example.com/errors/export-timeout",
       "title": "Export generation timed out",
       "status": 504,
       "detail": "PDF generation exceeded 180s limit for report_id=123",
       "instance": "/exports/req_abc123"
     }
     ```
   - *Tradeoff*: Clients must update error-handling logic, but gain explicit failure semantics.

2. **Error Envelope Separation**:
   - **Success (200)**: Return only the PDF binary with `Content-Disposition: attachment`.
   - **Validation (400/422)**: Use `400 Bad Request` for malformed input (e.g., missing `report_id`) and `422 Unprocessable Entity` for business-logic violations (e.g., invalid template).
   - **Server Errors (5xx)**: Use `500` for internal failures, `503` for maintenance, and `504` for timeouts.
   - *Evidence Class*: `failure_semantics_rule` (RFC 9457 compliance).

---

### **Authorization and Resource Protection**
**Problem**: The endpoint lacks explicit resource protection, risking **BOLA (Broken Object Level Authorization)** and **BFLA (Broken Function Level Authorization)**. Any authenticated user can trigger exports, and there’s no validation of:
- Whether the user owns the `report_id`.
- Whether the report’s data is accessible to the user’s role/tenant.
- Rate limits or quotas to prevent abuse (e.g., DoS via expensive PDF generation).

**Required Decisions**:
1. **Authorization Perimeter**:
   - Enforce **object-level permissions** (e.g., `can_export(report_id, user_id)`).
   - Use **deny-by-default** with explicit allowlists (e.g., RBAC/ABAC policies).
   - Example policy:
     ```text
     ALLOW export IF:
       - report.owner_id == user.id OR
       - user.role IN ["admin", "analyst"] AND report.tenant_id == user.tenant_id
     ```
   - *Evidence Class*: `permission_rule` (BOLA/BFLA mitigation).

2. **Resource Controls**:
   - Add **rate limiting** (e.g., 5 exports/minute/user) and **quotas** (e.g., 50 exports/month).
   - Log all export attempts with `user_id`, `report_id`, and timestamp for audit trails.
   - *Tradeoff*: Increased latency for permission checks, but critical for security.

---

### **Idempotency and Async Lifecycle**
**Problem**: The endpoint is **synchronous** (blocks for 3 minutes) and **non-idempotent**, violating retry safety. Clients cannot safely retry failed requests (e.g., network timeouts) without risking duplicate exports. The lack of an async lifecycle forces clients to poll or wait, degrading UX.

**Required Decisions**:
1. **Idempotency Contract**:
   - Add an `Idempotency-Key` header (client-generated UUID) with a **24-hour TTL**.
   - Return `409 Conflict` for duplicate keys (with the original response).
   - Example:
     ```http
     POST /exports
     Idempotency-Key: abc123
     ```
   - *Evidence Class*: `async_lifecycle_rule` (retry safety).

2. **Async Job Model**:
   - **Immediate Response (202 Accepted)**:
     ```json
     {
       "status_url": "/exports/status/req_abc123",
       "expires_in": 86400
     }
     ```
   - **Status Endpoint**:
     - `GET /exports/status/{request_id}` returns:
       ```json
       {
         "status": "queued|running|completed|failed",
         "result_url": "/exports/result/req_abc123",  // if completed
         "error": { ... }  // if failed (Problem Details)
       }
       ```
   - **Webhook Option**: Allow clients to register a callback URL for terminal states.
   - *Tradeoff*: Clients must handle async flows, but gain resilience and scalability.

---

### **Resilience and Observability**
**Problem**: The endpoint has no **circuit breakers**, **load shedding**, or **observability** for long-running jobs. A surge in requests could exhaust resources (e.g., memory for PDF generation), and failures are invisible to operators.

**Required Decisions**:
1. **Resilience Strategy**:
   - **Circuit Breaker**: Trip after 3 consecutive failures; reject new requests for 60s.
   - **Load Shedding**: Reject requests with `503 Service Unavailable` if queue depth > 100.
   - **Timeouts**: Enforce a **120s server-side timeout** (with `504 Gateway Timeout`).
   - *Evidence Class*: `resilience_rule`.

2. **Observability Tax**:
   - **Metrics**:
     - `exports_requests_total` (counter, labeled by `status`, `user_id`, `report_id`).
     - `exports_duration_seconds` (histogram).
     - `exports_queue_depth` (gauge).
   - **Tracing**: Propagate `trace_id` across async jobs (e.g., OpenTelemetry).
   - **Logs**: Structured logs for all terminal states (e.g., `{"event": "export_completed", "request_id": "abc123", "duration_ms": 45000}`).
   - *Tradeoff*: Operational overhead, but critical for debugging.

---

### **Verification Checkpoints**
| **Check**               | **How to Verify**                                                                 |
|--------------------------|------------------------------------------------------------------------------------|
| Problem Details          | Test with invalid `report_id` → confirm `422 Unprocessable Entity` with `type`/`detail`. |
| Authorization            | Attempt export with unauthorized `report_id` → confirm `403 Forbidden`.            |
| Idempotency              | Retry with same `Idempotency-Key` → confirm `409 Conflict` with original response.  |
| Async Lifecycle          | Trigger export → confirm `202 Accepted` with `status_url`.                         |
| Resilience               | Simulate 3 failures → confirm circuit breaker trips (503 responses).               |
| Observability            | Check metrics/traces for `exports_duration_seconds` and `trace_id` propagation.    |

---

### **Rebuild Sequence**
1. **Phase 1 (Critical Fixes)**:
   - Implement **Problem Details** (RFC 9457) and separate error codes.
   - Add **object-level authorization** (e.g., `can_export` policy).
   - Enforce **120s timeout** and return `504` for timeouts.

2. **Phase 2 (Resilience)**:
   - Add **idempotency keys** and `409 Conflict` handling.
   - Implement **async job model** (202 + status endpoint).
   - Add **circuit breakers** and **load shedding**.

3. **Phase 3 (Observability)**:
   - Instrument **metrics** (Prometheus/OpenTelemetry).
   - Add **structured logs** and **tracing**.

---

### **Evidence Classes Cited**
- `failure_semantics_rule`: RFC 9457 compliance.
- `permission_rule`: BOLA/BFLA mitigation.
- `async_lifecycle_rule`: Idempotency and async job model.
- `resilience_rule`: Circuit breakers, load shedding, observability.

---

### **Forbidden Shortcuts Avoided**
- ❌ **"Retry theater"**: Added idempotency keys to enable safe retries.
- ❌ **"Success envelope failure"**: Separated HTTP codes for success/errors.
- ❌ **"Security by identifier"**: Enforced object-level permissions, not just `report_id` validation.

---

### **Tradeoffs**
| **Preserved**               | **Sacrificed**                          |
|------------------------------|-----------------------------------------|
| Backward compatibility       |