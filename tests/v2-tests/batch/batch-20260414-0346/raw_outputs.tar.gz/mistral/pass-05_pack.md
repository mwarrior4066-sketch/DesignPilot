Here’s a **PDF Remediation Plan** that preserves the document’s visual integrity while fixing accessibility and reading-order issues. This follows the `pdf_remediation_plan` output contract and is governed by the `document-accessibility-expert` route.

---

### **Current Failure State**
1. **Reading order & extraction**: Pull quotes and decorative images interrupt the logical flow; copy-paste yields garbled text.
2. **Semantic structure**: Untagged content (e.g., headings, lists, tables) breaks screen-reader navigation.
3. **Broken TOC links**: Hyperlinks in the table of contents point to incorrect anchors.
4. **Decorative images**: Visual-only elements are not marked as artifacts, cluttering the accessibility tree.

---

### **Remediation Sequence**
*(Ordered to preserve semantics and avoid destructive edits)*

1. **Tagging Pass**
   - **Headers**: Apply `<H1>`–`<H6>` tags to all headings (match visual hierarchy).
   - **Body text**: Tag primary content as `<P>`; ensure two-column text flows left-to-right, top-to-bottom.
   - **Pull quotes**: Tag as `<Quote>` and **reposition in the reading order** *after* the paragraph they reference (not mid-flow).
   - **Tables**: Tag with `<Table>`, `<TH>`, `<TD>`; add `<Caption>` if missing.
   - **Decorative images**: Tag as `<Artifact>` (excludes them from screen-reader output).

2. **Reading Order Repair**
   - Use Adobe Acrobat’s **Order Tool** to:
     - Drag pull quotes *after* their source paragraphs.
     - Ensure columns flow left-to-right (not zigzag).
     - Group related elements (e.g., figure + caption).

3. **TOC Link Fixes**
   - Rebuild bookmarks/hyperlinks in InDesign:
     - Verify anchors match target headings.
     - Test links in Acrobat’s **Bookmarks Panel**.

4. **Unicode & Text Layer**
   - **OCR check**: Confirm text is selectable (not image-based).
   - **Ligatures/fonts**: Replace non-Unicode glyphs (e.g., "fi" ligatures) with standard characters.

5. **Verification Checks**
   - **Screen-reader test**: Navigate with NVDA/VoiceOver to confirm logical flow.
   - **Copy-paste test**: Extract text to plaintext; verify no garbled content.
   - **Acrobat Accessibility Checker**: Fix flagged issues (e.g., contrast, alt text).

---

### **Risk Controls**
- **Preserve original layout**: Do not flatten or rasterize the PDF.
- **Avoid OCR-first**: Only use OCR if the text layer is missing (last resort).
- **Backup**: Save a copy before editing tags (InDesign/PDF).

---

### **Why This Works**
- **Semantic tags** enable screen readers to navigate by structure (e.g., "Jump to next heading").
- **Reading-order fixes** ensure exported text matches the visual flow.
- **Artifact tags** remove decorative noise from the accessibility tree.
- **TOC repairs** restore critical navigation for all users.

**Next Step**: Use Adobe Acrobat Pro’s **Tags Panel** to start the tagging pass. For complex layouts, consider exporting tagged content from InDesign with proper paragraph styles.

---
*Mode: REBUILD | Phase: implementation | Route: `pdf_remediation_plan`*
*Supporting skills: `document-accessibility-expert`, `pdf-layout-expert`*