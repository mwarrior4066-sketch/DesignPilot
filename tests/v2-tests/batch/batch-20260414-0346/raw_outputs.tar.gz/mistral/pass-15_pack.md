```text
Mode: STRUCTURE | Phase: specs | Route: backend_architecture_spec
```

# Backend Architecture Spec: Multi-Tenant Scheduling Platform

## System Framing
**Actors & Resources**
- Tenants (organizations) own workspaces, schedules, and approval policies
- Users (team members) act within tenant workspaces with role-based permissions
- External systems receive webhooks for schedule changes and approvals

**Why Architecture is Needed**
The current REST/relational stack lacks:
- Consistent eventing for activity feeds and webhooks
- Regional data residency boundaries
- Audit trails beyond basic CRUD
- Scalable background job processing
- Foundation for customer-defined automation

---

## Core Model & Authority Boundaries

### Tenant Isolation Model
- **Source of Truth**: `tenant_id` on all records (enforced at DB level via row-level security)
- **Authorization**: ReBAC (Relationship-Based Access Control) with:
  - Tenant memberships (`user_tenant_roles`)
  - Workspace-level roles (`workspace_members`)
  - Approval policy rules (`approval_policies`)
- **Data Residency**: Regional sharding by `tenant.region` with:
  - Separate DB instances per region
  - Cross-region queries prohibited (enforced via middleware)
  - Tenant migration process with data copy + verification

### Key Resources & Ownership
| Resource          | Owner          | Key Actions                          | Authorization Boundary          |
|-------------------|----------------|--------------------------------------|---------------------------------|
| Schedules         | Workspace      | create, update, delete, approve      | Workspace member role           |
| Approval Policies | Tenant Admin   | define, modify                       | Tenant admin role               |
| Activity Feed     | System         | generate, filter                     | Tenant membership               |
| Webhooks          | Tenant Admin   | register, test, disable              | Tenant admin role               |
| Audit Logs        | System         | write-only (immutable)               | System service account          |

---

## Data, Consistency & Delivery Design

### Activity Feed (Cursor-Based)
- **Delivery Pattern**:
  - Cursor = `(event_id, timestamp)` for pagination
  - Events stored in `activity_feed_events` table with:
    ```sql
    event_id UUID,
    tenant_id UUID,
    workspace_id UUID,
    event_type VARCHAR,  -- 'schedule_created', 'approval_requested', etc.
    payload JSONB,       -- Event-specific data
    cursor_position BIGINT GENERATED ALWAYS AS (extract(epoch from created_at)*1000) STORED,
    created_at TIMESTAMPTZ
    ```
- **Consistency**: Read-your-writes via cursor position
- **Filtering**: Client provides `tenant_id`, `workspace_id`, and optional `event_type` filters

### Approval Workflows
- **State Machine**:
  ```mermaid
  stateDiagram-v2
    [*] --> Draft
    Draft --> Submitted: submit()
    Submitted --> Approved: approve()
    Submitted --> Rejected: reject()
    Approved --> Published: publish()
    Rejected --> Draft: resubmit()
  ```
- **Authority**: `approval_policies` table defines:
  - Required approvers (by role or user)
  - Timeout rules
  - Escalation paths
- **Consistency**: Linearizable within tenant/workspace

### Webhooks
- **Async Lifecycle**:
  - `202 Accepted` on event receipt
  - Status URL: `/webhooks/status/{delivery_id}`
  - Terminal states: `delivered`, `failed`, `retrying`
  - Webhook registry:
    ```sql
    webhook_id UUID,
    tenant_id UUID,
    url VARCHAR,
    event_types VARCHAR[],  -- e.g., ['schedule_published', 'approval_requested']
    secret VARCHAR,         -- For HMAC signature
    is_active BOOLEAN,
    created_at TIMESTAMPTZ
    ```
- **Resilience**:
  - Circuit breaker (5 consecutive failures → disable)
  - Exponential backoff (max 5 retries)
  - Dead-letter queue for failed deliveries

### Background Jobs
- **Queue Design**:
  - Regional queues (e.g., `jobs_eu`, `jobs_us`)
  - Priority lanes:
    - High: Approval timeouts, webhook deliveries
    - Medium: Activity feed generation
    - Low: Analytics, data cleanup
- **Observability**:
  - `jobs` table with:
    ```sql
    job_id UUID,
    queue VARCHAR,
    priority INT,
    status VARCHAR,  -- 'queued', 'running', 'completed', 'failed'
    payload JSONB,
    attempts INT,
    trace_id VARCHAR,  -- For distributed tracing
    created_at TIMESTAMPTZ,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
    ```

---

## Observability & Failure Posture

### Audit Trails
- **Immutable Logs**:
  - `audit_logs` table (append-only):
    ```sql
    log_id UUID,
    tenant_id UUID,
    user_id UUID,
    action VARCHAR,  -- 'schedule_created', 'approval_granted', etc.
    resource_type VARCHAR,
    resource_id UUID,
    metadata JSONB,  -- Old/new values for updates
    ip_address VARCHAR,
    user_agent VARCHAR,
    created_at TIMESTAMPTZ
    ```
  - Retention: 7 years (legal requirement)
  - Access: Read-only via admin API with tenant-scoped queries

### Metrics & Tracing
- **Key Metrics**:
  - Approval latency (P99 < 5s)
  - Webhook delivery success rate (> 99.9%)
  - Activity feed generation time (P95 < 200ms)
  - Job queue saturation (alert if > 80% capacity)
- **Distributed Tracing**:
  - Trace ID propagated through:
    - API requests
    - Background jobs
    - Webhook deliveries
  - Sampling: 100% for errors, 10% for successes

### Degraded Modes
| Failure Scenario               | Degraded Behavior                                                                 |
|--------------------------------|-----------------------------------------------------------------------------------|
| Webhook delivery failure       | Retry with backoff; notify tenant admin after 3 failures                          |
| Approval timeout               | Escalate to next approver (per policy); notify workspace owner                    |
| Activity feed generation slow  | Serve stale feed (max 5 minutes old); prioritize high-priority events             |
| Regional DB outage             | Failover to read-only replica (if available); queue writes for later replay       |

---

## Service Boundaries & Contracts

### Core Services
1. **Tenant Service**
   - Manages tenants, regions, and memberships
   - Enforces data residency rules
   - Handles tenant migrations

2. **Schedule Service**
   - CRUD for schedules
   - Approval workflow orchestration
   - Emits events to `event_bus`

3. **Activity Feed Service**
   - Generates and filters activity feed events
   - Manages cursor-based pagination
   - Handles event deduplication

4. **Webhook Service**
   - Manages webhook registry
   - Delivers events asynchronously
   - Handles retries and dead-lettering

5. **Job Service**
   - Manages background job queues
   - Handles job prioritization
   - Provides observability into job status

6. **Audit Service**
   - Writes to immutable audit logs
   - Provides read-only access to logs
   - Handles log retention

### Event Bus Contracts
| Event Type               | Producer          | Consumers                          | Payload Example                                                                 |
|--------------------------|-------------------|------------------------------------|---------------------------------------------------------------------------------|
| `schedule_created`       | Schedule Service  | Activity Feed, Webhook, Audit      | `{ "schedule_id": "uuid", "workspace_id": "uuid", "created_by": "uuid" }`       |
| `approval_requested`     | Schedule Service  | Activity Feed, Webhook, Job        | `{ "schedule_id": "uuid", "requested_by": "uuid", "approvers": ["uuid"] }`      |
| `approval_granted`       | Schedule Service  | Activity Feed, Webhook, Audit      | `{ "schedule_id": "uuid", "approved_by": "uuid" }`                              |
| `webhook_delivery_failed`| Webhook Service   | Job, Audit                         | `{ "delivery_id": "uuid", "webhook_id": "uuid", "attempt": 3, "error": "..." }`  |

---

## Operational Concerns

### Regional Deployment
- **Sharding Strategy**:
  - One DB instance per region (e.g., `eu-central-1`, `us-east-1`)
  - Tenant data never leaves its region
  - Cross-region reads prohibited (enforced via middleware)
- **Migration Process**:
  1. Copy tenant data to new region
  2. Verify data integrity (checksums)
  3. Update `tenant.region` in source DB
  4. Route new requests to new region
  5. Archive old data after 30 days

### Automation Foundation
