Here’s a structured critique of the poster design, following the **Graphic Critique** output contract:

---

### **Communication Goal**
The poster must first establish **what the event is** (a design conference) and **why it matters** (audience, theme, or unique value) before emphasizing the title. Currently, the title dominates without context, which may confuse viewers at a glance.

---

### **Composition Failures**
1. **Hierarchy Misalignment**
   - The **title is the focal point**, but it lacks supporting context (e.g., "Design Conference 2025" or a tagline). Viewers must work to connect the title to the event.
   - The **logo and date are secondary** but compete for attention due to placement (logo centered, date buried in a corner). The date should be more prominent for actionability.

2. **Distance Legibility Issues**
   - The **small gray date** is likely unreadable from a distance (e.g., on a hallway wall or digital screen).
   - The **decorative title typeface** may sacrifice clarity at smaller sizes or when viewed quickly.

3. **Background Photo Overpowering**
   - The **full-bleed city skyline** creates visual noise, making it harder to focus on critical information. The photo’s details (e.g., buildings) compete with text.
   - The **white logo overlay** lacks contrast against bright or complex parts of the skyline, risking illegibility.

---

### **Rebuild Moves**
1. **Reorder Hierarchy**
   - **Lead with context**: Place "Design Conference [Year]" or a short tagline (e.g., "Exploring the Future of Design") *above or alongside* the title to frame it.
   - **Demote the title’s dominance**: Reduce its size or weight slightly to balance with supporting info.

2. **Improve Distance Legibility**
   - **Enlarge the date** and place it near the top or bottom in a high-contrast color (e.g., white on dark or vice versa).
   - **Simplify the title typeface**: Use a decorative font for *part* of the title (e.g., one word) but pair it with a clean, readable sans-serif for the rest.

3. **Control the Background**
   - **Darken or blur the skyline** to create a consistent "text box" effect behind critical info.
   - **Reposition the logo**: Move it to a corner (e.g., bottom left) or integrate it into the title as a lockup.

4. **Add Emphasis Tradeoffs**
   - **Sacrifice visual drama** (e.g., full-bleed photo) to **preserve clarity**. For example:
     - Crop the skyline to a smaller, less detailed section.
     - Use a gradient overlay to mute the background where text sits.

---

### **Distance and Emphasis Tradeoff**
- **What should dominate**: The event’s identity (name + context) and actionable details (date, location).
- **What can recede**: The decorative title flourishes and background photo complexity. These elements should support—not compete with—the message.

---

### **Evidence Classes Cited**
- **Visual structure rule**: Hierarchy and legibility principles (e.g., "title should follow context, not lead it").
- **Comparison artifact**: Contrast with effective conference posters (e.g., [AIGA Design Conference](https://www.aiga.org/)) where context precedes title.
- **Implementation constraint**: Distance legibility (e.g., "gray text on complex backgrounds fails at 3+ meters").

---

### **Why This Matters**
A poster’s job is to **communicate quickly and clearly**. The current design prioritizes aesthetics over function, risking missed opportunities to attract attendees. By rebalancing hierarchy and legibility, the poster can retain visual appeal while ensuring the message is instantly understood.

---

### **Next Steps**
1. **Test legibility**: Print a small version or view it from across a room to verify text clarity.
2. **A/B test hierarchy**: Try swapping the title and context placement to see which version communicates faster.
3. **Simplify the background**: Use a tool like Photoshop to darken/blur the skyline behind text areas.