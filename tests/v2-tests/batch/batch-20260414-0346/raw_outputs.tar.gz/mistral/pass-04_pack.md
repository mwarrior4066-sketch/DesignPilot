Mode: AUDIT | Phase: strategy | Route: `backend_feasibility_review`
Loaded skills: `back-end-aware-planner.md`, `front-end-handoff-expert.md`, `api-reliability-security-expert.md`

---

### Requested Capability
Add real-time collaborative editing (Google Docs–style) to an existing React/REST/PostgreSQL app. Key features:
- Simultaneous multi-user editing with visible cursors/selections
- Conflict resolution (operational transformation or CRDTs)
- Persistent document state

---

### Hidden System Requirements
1. **Data Model & Ownership**
   - Current PostgreSQL schema likely assumes single-user ownership or coarse-grained locks.
   - Real-time collaboration requires fine-grained document structure (e.g., per-paragraph/character) with revision history.
   - **Implication**: Schema must evolve to track deltas, not just final state.

2. **Permissions & Authorization**
   - Multi-tenancy: Users may belong to different orgs/teams with document-level access controls.
   - **Implication**: Need object-level permissions (e.g., "User X can edit Document Y") and audit trails for changes.

3. **System Surface Dependencies**
   - **WebSockets**: REST is request/response; real-time needs persistent connections (WebSockets or Server-Sent Events).
   - **Async Jobs**: Conflict resolution may require background processing (e.g., merging divergent edits).
   - **Storage**: PostgreSQL’s row-level locking may not scale for high-frequency deltas; consider a dedicated OT/CRDT store (e.g., Redis, custom service).

4. **Observability & Resilience**
   - Connection drops, network latency, and client crashes must not corrupt document state.
   - **Implication**: Need session tracking, heartbeat mechanisms, and conflict-resolution telemetry.

---

### Feasibility Assessment
#### Blockers
1. **State Ownership**
   - Current REST endpoints likely assume a single "owner" per document. Real-time collaboration requires shared state with no single owner.
   - **Risk**: Without explicit authority boundaries, race conditions or permission escalations could occur.

2. **Conflict Resolution**
   - Operational Transformation (OT) or CRDTs are non-trivial to implement. Off-the-shelf libraries (e.g., Yjs, Automerge) exist but require:
     - A dedicated service to manage document deltas.
     - Client-side integration to handle local/remote edits.
   - **Risk**: Naive implementations (e.g., last-write-wins) will corrupt documents.

3. **Performance**
   - High-frequency deltas (e.g., keystrokes) will strain PostgreSQL’s transactional model.
   - **Risk**: Without a write-optimized store (e.g., Redis), latency and DB load will degrade UX.

4. **Security**
   - WebSockets introduce new attack surfaces (e.g., DoS, message spoofing).
   - **Risk**: Missing auth checks on WebSocket messages could allow unauthorized edits.

#### Assumptions
- The app already has user authentication and document-level permissions.
- Documents are text-heavy (e.g., rich text, code), not binary (e.g., images).

---

### Safer Implementation Path
#### Phase 1: Foundation (MVP)
1. **Schema & Data Model**
   - Extend PostgreSQL schema to store:
     - Document revisions (for rollback).
     - User sessions (for presence tracking).
   - Add a `collaboration_sessions` table to track active editors.

2. **WebSocket Gateway**
   - Deploy a WebSocket service (e.g., Node.js + Socket.IO) alongside the REST API.
   - **Authorization**: Validate JWTs on connection and per message.
   - **Message Types**:
     - `edit`: Delta operations (insert/delete).
     - `presence`: Cursor positions/selections.
     - `ack`: Confirm receipt of edits.

3. **Conflict Resolution**
   - Use a library like [Yjs](https://github.com/yjs/yjs) or [Automerge](https://automerge.org/) to handle OT/CRDTs.
   - **Integration**:
     - Client: Yjs provider + React bindings.
     - Server: Yjs backend (e.g., `y-websocket`) to sync deltas.

4. **Storage**
   - Store document deltas in PostgreSQL as JSON (for auditability).
   - Cache active documents in Redis for low-latency reads/writes.

#### Phase 2: Resilience & Scale
1. **Observability**
   - Add metrics for:
     - WebSocket connection stability.
     - Conflict resolution latency.
     - Document merge failures.

2. **Degraded Modes**
   - If WebSocket fails, fall back to REST polling (e.g., fetch deltas every 5s).
   - If conflict resolution fails, lock the document and notify users.

3. **Performance**
   - Offload delta storage to a dedicated service (e.g., Kafka for event sourcing).
   - Use PostgreSQL only for final document state (e.g., hourly snapshots).

#### Phase 3: Advanced Features
1. **Permissions**
   - Implement object-level permissions (e.g., "User X can edit Section 2").
   - Use PostgreSQL row-level security or a policy engine (e.g., Oso).

2. **Presence**
   - Track cursor positions in Redis with TTLs (e.g., expire after 30s of inactivity).

3. **Undo/Redo**
   - Leverage Yjs’s built-in history or store deltas in a time-series DB (e.g., TimescaleDB).

---

### Tradeoffs
| Preserved | Sacrificed |
|-----------|------------|
| REST API compatibility (fallback) | Initial latency (WebSocket handshake) |
| PostgreSQL for auditability | Scalability (PostgreSQL may bottleneck) |
| Off-the-shelf OT/CRDT libraries | Customization (e.g., domain-specific conflict rules) |

---

### Verification Checklist
1. **Schema**: Validate `collaboration_sessions` and delta tables.
2. **WebSocket**: Test auth, message validation, and fallback to REST.
3. **Conflict Resolution**: Simulate concurrent edits and verify merges.
4. **Permissions**: Confirm unauthorized users cannot edit documents.

---

### Next Steps
1. **Prototype**: Build a minimal WebSocket + Yjs integration for a single document.
2. **Benchmark**: Measure latency and DB load with 10+ concurrent users.
3. **Security Review**: Audit WebSocket auth and message validation.