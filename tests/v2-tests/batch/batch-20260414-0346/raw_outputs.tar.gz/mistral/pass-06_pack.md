Mode: **STRATEGY** | Phase: **brand** | Route: **brand_positioning_pass**
Loaded skills: brand-strategy-expert, content-and-case-study-expert

---

### **Audience & Problem**
Freelancers—especially solopreneurs and micro-businesses—need financial tools that feel *built for them*, not repurposed from corporate banking. Traditional banks treat them as an afterthought (clunky UX, opaque fees, slow support), while Stripe/Mercury/Relay are optimized for *scaling* businesses, not the day-to-day chaos of freelancing (e.g., irregular income, tax headaches, client payments).

**Core pain**: Freelancers want a partner that *gets* their workflow—one that’s reliable but doesn’t talk down to them. They’re tired of feeling like a "small fish" in a system designed for whales.

---

### **Positioning Frame**
**Against**: Traditional banks (slow, impersonal) *and* "scaler-first" fintechs (Stripe/Mercury/Relay, which prioritize growth-stage businesses over solo operators).
**Territory to own**: *"The freelancer’s financial co-pilot"*—a tool that’s as agile as they are, with guardrails for stability.

**Wedge**:
- **Trust**: Built for *their* reality (irregular income, tax season panic, client payment delays).
- **Approachability**: No jargon, no corporate tone. Feels like a peer, not a bank.
- **Proactive**: Anticipates their needs (e.g., "We’ll auto-reserve 30% for taxes when you get paid").

**Why it works**:
- Stripe/Mercury/Relay focus on *businesses that want to grow*. This targets *freelancers who want to thrive*—a subtle but critical difference.
- Traditional banks are *institutions*. This is a *tool with a personality*.

---

### **Trust & Proof Burden**
Freelancers are skeptical of "too good to be true" promises. To earn trust:
1. **Transparency**: No hidden fees, no "gotcha" clauses. Example: "We’ll never charge you for moving your own money."
2. **Proof points**:
   - *"10,000 freelancers use us to auto-save for taxes"* (social proof).
   - *"Get paid 2 days faster than Stripe"* (quantifiable win).
   - *"Our support team are freelancers too"* (shared identity).
3. **Convention-busting**: Use humor or relatable language (e.g., "No more ‘banker’s hours’—we’re open when you are").

---

### **Messaging Consequences**
**Tone**: Warm but direct. Like a savvy friend who’s also a CPA.
- **Do**: *"We’ll handle the boring stuff so you can focus on the work you love."*
- **Don’t**: *"Revolutionizing freelance finance"* (overpromising).

**Visuals**: Less "corporate blue," more "human-scale" (e.g., warm gradients, illustrations of freelancers in their element—coffee shops, home offices).

**Product cues**:
- **Naming**: Avoid "bank" (e.g., "Pulse" instead of "Pulse Bank").
- **Features**: Highlight "freelancer-first" tools (e.g., "Tax Vault," "Client Payment Reminders").

---

### **Tradeoffs**
| **Preserve**               | **Sacrifice**                     |
|----------------------------|-----------------------------------|
| Trust (no gimmicks)        | "Bank-like" gravitas              |
| Approachability            | Corporate polish                  |
| Freelancer-specific tools  | Enterprise features (e.g., payroll) |

**Why**: Adding enterprise features later is easier than regaining trust after overpromising.

---

### **Next Steps**
1. **Validate**: Test positioning with freelancers (e.g., "Does this resonate more than ‘a bank for freelancers’?").
2. **Prototype**: Design a landing page with the "co-pilot" metaphor and freelancer-centric proof points.
3. **Differentiate**: Audit Stripe/Mercury/Relay’s messaging to sharpen the wedge (e.g., "They say ‘scale’; we say ‘stability’").

---
**Evidence classes cited**:
- `comparison_artifact` (Stripe/Mercury/Relay as alternatives).
- `implementation_constraint` (freelancer-specific tools vs. enterprise features).
- `file_backed_receipt` (social proof, quantifiable wins).