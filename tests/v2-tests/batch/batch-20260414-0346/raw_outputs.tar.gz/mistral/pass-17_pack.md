Here’s how the **front-end architecture decision**—*whether to use a global state manager like Redux or local component state with context*—would be explained across **Functional**, **Integrative**, and **Strategic** tiers, following DesignPilot’s adaptive explanation protocol. Each tier preserves the same governing evidence but adjusts scaffolding, jargon, and rationale depth.

---

### **Functional Tier**
*(Guided execution, explicit scaffolding, next-step direction)*

#### **What’s the job of state in this app?**
State is the "memory" of your app—it holds data that changes over time (like user inputs, API responses, or UI toggles). Right now, you’re deciding *where* to store that memory:
- **Local state + Context**: Keep state close to where it’s used (e.g., a form’s input values in the form component). Use React’s built-in `useState` or `useReducer`, and share it with `Context` only when needed.
- **Global state manager (Redux)**: Store *all* state in a central "store" that any component can access. Redux adds tools like time-travel debugging and middleware (e.g., for logging or async actions).

#### **Why does this choice matter?**
1. **Complexity**: Global state (Redux) adds setup work—actions, reducers, selectors—even for simple data. Local state is faster to write but harder to share across distant components.
2. **Performance**: Redux can slow down your app if you overuse it (e.g., storing *everything* globally). Local state is lighter but may cause "prop drilling" (passing data through many layers).
3. **Teamwork**: Redux forces a clear structure, which helps large teams. Local state is flexible but can get messy if everyone writes state differently.

#### **What’s the real problem here?**
- If your app is **small** (e.g., a single form, a dashboard with 2–3 screens), local state + Context is *simpler and safer*. You’ll avoid over-engineering.
- If your app is **large** (e.g., many screens sharing data, complex workflows, or frequent state updates), Redux *prevents chaos* by centralizing logic.
- If you’re unsure, start with **local state + Context** and *only add Redux when you hit pain points* (e.g., prop drilling, hard-to-debug state changes).

#### **What’s the tradeoff?**
- **Preserve**: Simplicity and speed for small apps.
- **Sacrifice**: Redux’s structure (which helps big apps) to avoid unnecessary complexity.

#### **How do you verify this works?**
- For local state: Check if components can access the data they need without passing props through 5+ layers.
- For Redux: Check if the store is organized by *domain* (e.g., `userSlice`, `cartSlice`) and not just dumping everything in one place.

#### **Next step**
Start with **local state + Context** for this app. If you later need to share state across many screens or debug complex updates, *then* add Redux—but only for the parts that need it.

---
**Governing recommendation (Functional tier):**
*"Use local component state with Context for this app now, and only add Redux later if you hit specific pain points like prop drilling or hard-to-debug state changes."*

---

### **Integrative Tier**
*(Cross-functional rationale, moderate scaffolding, tradeoffs included)*

#### **State management: Local vs. global**
The choice between **local component state + Context** and a **global state manager like Redux** hinges on three axes:
1. **Scope**: How widely is the state needed?
   - Local state is scoped to a component or subtree (e.g., a form’s input values). Context lets you share it without prop drilling, but it’s still "local" in that it’s opt-in.
   - Redux is *global by default*—any component can access any part of the store, which can lead to overuse.
2. **Complexity**: How much structure do you need?
   - Local state is unopinionated: `useState` for simple values, `useReducer` for complex logic. Context adds a layer of indirection but keeps things flexible.
   - Redux enforces a pattern (actions → reducers → selectors) that scales well for large apps but adds boilerplate for small ones.
3. **Performance**: How does state affect rendering?
   - Local state re-renders only the components that use it. Context re-renders *all* consumers when the value changes (unless you memoize or split contexts).
   - Redux’s `connect` or `useSelector` lets you subscribe to *slices* of state, avoiding unnecessary re-renders—but only if you structure selectors carefully.

#### **When to choose local state + Context**
- **Small apps or isolated features**: A single form, a dashboard with 2–3 screens, or a feature with minimal shared state.
- **Rapid prototyping**: You need to move fast and don’t want to set up Redux’s boilerplate.
- **Performance-sensitive UIs**: Local state minimizes re-renders by default. Context can be optimized with memoization or split into smaller contexts.

#### **When to choose Redux**
- **Large apps with shared state**: Many screens need access to the same data (e.g., user auth, cart, notifications).
- **Complex state logic**: Frequent updates, derived data, or async workflows (e.g., a multi-step checkout).
- **Team collaboration**: Redux’s structure makes it easier for multiple developers to work on state without conflicts.
- **Debugging needs**: Time-travel debugging, logging, or middleware for analytics.

#### **Key tradeoffs**
| **Factor**               | **Local State + Context**                          | **Redux**                                      |
|--------------------------|----------------------------------------------------|------------------------------------------------|
| **Setup time**           | Fast (built into React)                            | Slow (boilerplate, tooling)                    |
| **Scalability**          | Harder to scale (prop drilling, context bloat)     | Scales well (centralized logic)                |
| **Performance**          | Optimized by default (local re-renders)            | Requires careful selector design               |
| **Team alignment**       | Flexible but can get messy                         | Enforces consistency                           |
| **Debugging**            | Limited (no time-travel)                           | Advanced (Redux DevTools)                      |

#### **Implementation constraints**
- **Local state + Context**:
  - Split contexts by domain (e.g., `AuthContext`, `CartContext`) to avoid unnecessary re-renders.
  - Use `useReducer` for complex local state logic (e.g., form validation).
- **Redux**:
  - Structure the store by *domain* (e.g., `userSlice`, `cartSlice`), not by UI.
  - Use `createSelector` for derived data to avoid recalculating values on every render.
  - Consider Redux Toolkit (RTK) to reduce boilerplate.

#### **Verification**
- For local state: Test if components can access the data they need without prop drilling. Use React DevTools to check re-renders.
- For Redux: Verify that selectors are memoized and that the store is organized by domain. Use Redux DevTools to inspect state changes.

---
**Governing recommendation (Integrative tier):**
*"Use local component state with Context for this app’s current scope, but structure the code to allow Redux to be added later if the app grows or state-sharing needs become complex—prioritizing simplicity now while avoiding lock-in."*

---

### **Strategic Tier**
*(Compressed synthesis, minimal scaffolding, direct tradeoffs)*

#### **State management: Local vs. global**
The decision reduces to **scope, structure, and cost**:
- **Local state + Context** is optimal for *isolated or small-scale* state needs. It minimizes overhead but scales poorly for shared state (prop drilling, context bloat).
- **Redux** is a *global solution* that enforces structure and scales well but introduces complexity and performance tax (selector design, middleware).

#### **Governing constraints**
1. **Scope**: If state is needed by >3 screens or involves complex async workflows, Redux’s structure justifies its cost.
2. **Performance**: Local state is lighter by default; Redux requires careful selector design to avoid over-rendering.
3. **Team**: Redux’s opinionated pattern reduces drift in large teams; local state is flexible but risks inconsistency.

#### **Tradeoff resolution**
- **Preserve**: Development speed and simplicity for the app’s current scale.
- **Sacrifice**: Redux’s scalability and debugging tools to avoid premature complexity.

#### **Implementation path**
1. Start with **local state + Context**, split by domain (e.g., `AuthContext`, `CartContext`).
2. If state-sharing needs emerge, *migrate incrementally* to Redux, starting with the most shared domain (e.g., user auth).
3. Use **Redux Toolkit (RTK)** to reduce boilerplate and enforce best practices.

#### **Verification**
- Local state: Check for prop drilling or context re-renders in React DevTools.
- Redux: Verify domain-based store structure and memoized selectors in Redux DevTools.

---
**Governing recommendation (Strategic