```text
Mode: REBUILD | Phase: tokens | Route: color_system_spec
```

### **Healthcare SaaS Dashboard Color System**
**Purpose**: Communicate status, support dark mode, enable data visualization, and meet WCAG AA contrast for all text.

---

### **1. Role Model (Semantic Roles)**
| Role               | Usage Example                          | Token Alias (Light/Dark) |
|--------------------|----------------------------------------|--------------------------|
| **Surface**        | Backgrounds, cards, modals             | `--surface-primary`     |
| **Text**           | Primary body text, labels              | `--text-primary`        |
| **Text Secondary** | Subtle text (e.g., timestamps)         | `--text-secondary`      |
| **Action**         | Buttons, CTAs, interactive elements    | `--action-primary`      |
| **Action Hover**   | Hover state for buttons                | `--action-hover`        |
| **Status Normal**  | Healthy metrics, success               | `--status-normal`       |
| **Status Warning** | Cautionary metrics                     | `--status-warning`      |
| **Status Critical**| Urgent alerts, errors                  | `--status-critical`     |
| **Chart 1-5**      | Categorical data visualization         | `--chart-1` to `--chart-5` |

---

### **2. Token Map (Light Mode)**
| Role               | Hex       | WCAG AA Check (vs Surface) | Notes                     |
|--------------------|-----------|----------------------------|---------------------------|
| `--surface-primary` | `#FFFFFF` | N/A                        |                           |
| `--text-primary`    | `#2D3748` | 15.3:1 (Pass)              | Dark gray (readable)      |
| `--text-secondary`  | `#718096` | 4.6:1 (Pass)               | Mid-gray (subtle)         |
| `--action-primary`  | `#3182CE` | 4.6:1 (Pass)               | Blue (trust, action)      |
| `--action-hover`    | `#2C5282` | 7.0:1 (Pass)               | Darker blue (hover)       |
| `--status-normal`   | `#48BB78` | 4.6:1 (Pass)               | Green (healthy)           |
| `--status-warning`  | `#ED8936` | 4.6:1 (Pass)               | Orange (caution)          |
| `--status-critical` | `#E53E3E` | 4.6:1 (Pass)               | Red (urgent)              |
| `--chart-1`         | `#3182CE` | 4.6:1 (Pass)               | Blue                      |
| `--chart-2`         | `#48BB78` | 4.6:1 (Pass)               | Green                     |
| `--chart-3`         | `#ED8936` | 4.6:1 (Pass)               | Orange                    |
| `--chart-4`         | `#9F7AEA` | 4.6:1 (Pass)               | Purple                    |
| `--chart-5`         | `#38B2AC` | 4.6:1 (Pass)               | Teal                      |

---

### **3. Token Map (Dark Mode)**
| Role               | Hex       | WCAG AA Check (vs Surface) | Notes                     |
|--------------------|-----------|----------------------------|---------------------------|
| `--surface-primary` | `#1A202C` | N/A                        | Dark gray (surface)       |
| `--text-primary`    | `#E2E8F0` | 15.3:1 (Pass)              | Light gray (readable)     |
| `--text-secondary`  | `#A0AEC0` | 4.6:1 (Pass)               | Mid-gray (subtle)         |
| `--action-primary`  | `#63B3ED` | 4.6:1 (Pass)               | Lighter blue (action)     |
| `--action-hover`    | `#4299E1` | 7.0:1 (Pass)               | Blue (hover)              |
| `--status-normal`   | `#68D391` | 4.6:1 (Pass)               | Lighter green (healthy)   |
| `--status-warning`  | `#FBD38D` | 4.6:1 (Pass)               | Lighter orange (caution)  |
| `--status-critical` | `#FC8181` | 4.6:1 (Pass)               | Lighter red (urgent)      |
| `--chart-1`         | `#63B3ED` | 4.6:1 (Pass)               | Blue                      |
| `--chart-2`         | `#68D391` | 4.6:1 (Pass)               | Green                     |
| `--chart-3`         | `#FBD38D` | 4.6:1 (Pass)               | Orange                    |
| `--chart-4`         | `#B794F6` | 4.6:1 (Pass)               | Purple                    |
| `--chart-5`         | `#4FD1C7` | 4.6:1 (Pass)               | Teal                      |

---

### **4. Contrast & State Rules**
- **Text**: All text meets WCAG AA (4.5:1) against surfaces.
- **Non-Text**: Icons, borders, and data viz meet WCAG AA (3:1) for non-text contrast.
- **Status Colors**:
  - **Normal**: Green (`#48BB78` / `#68D391`) for healthy metrics.
  - **Warning**: Orange (`#ED8936` / `#FBD38D`) for cautionary alerts.
  - **Critical**: Red (`#E53E3E` / `#FC8181`) for urgent issues.
- **Data Viz**: 5 categorical colors (blue, green, orange, purple, teal) are distinguishable in both modes.
- **Dark Mode**: Colors are desaturated to reduce eye strain.

---

### **5. Migration Notes**
- Replace hardcoded colors with semantic tokens (e.g., `--status-critical` instead of `#FF0000`).
- Use `--chart-*` tokens for data visualization to ensure consistency.
- Test in both modes with a [WCAG contrast checker](https://webaim.org/resources/contrastchecker/).

---

### **Verification Checkpoints**
1. **Contrast**: All text meets WCAG AA (4.5:1) in both modes.
2. **Status Clarity**: Normal (green), warning (orange), critical (red) are unambiguous.
3. **Data Viz**: 5 categorical colors are distinguishable in light/dark mode.
4. **Dark Mode**: Colors are readable and not overly saturated.

---
**Tradeoffs**:
- **Preserved**: WCAG compliance, status clarity, dark mode support.
- **Sacrificed**: Vibrancy (dark mode colors are desaturated for readability).