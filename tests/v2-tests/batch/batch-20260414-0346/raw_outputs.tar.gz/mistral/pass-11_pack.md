Mode: REBUILD | Phase: structure | Route: `layout_reconstruction_plan`

---

### **Source Constraints (What Must Be Preserved)**
From the 2018 PDF, we’ll treat these as *non-negotiable* geometry:
- **Grid diagrams**: Baseline grid increment (e.g., 4px, 8px), column count (e.g., 12-column), gutter width, and margin values (e.g., 24px left/right, 32px top/bottom).
- **Margin specifications**: Explicit values for print/digital (e.g., "bleed: 3mm" or "safe zone: 10px from edge").
- **Column examples**: Real-world layouts showing span logic (e.g., "headline spans 8 columns, body spans 6").
- **Breakpoint cues**: If the PDF includes responsive hints (e.g., "mobile: 6 columns"), we’ll infer a breakpoint scale.

*Confidence note*: We’ll label inferred values (e.g., "likely 8px baseline") and flag mismatches between diagrams and example layouts.

---

### **Reconstruction Assumptions**
1. **Grid model**:
   - If the PDF shows a *manuscript grid* (fixed margins, single column), we’ll preserve it for long-form docs.
   - If it’s a *modular grid* (columns + rows), we’ll extend it to modern frameworks (e.g., CSS Grid/Flexbox).
   - *Inferred*: If no baseline grid is visible, we’ll assume 4px or 8px increments for digital alignment.

2. **Responsive translation**:
   - Print margins → Digital safe zones (e.g., "24px margin" → `padding: 1.5rem`).
   - Fixed columns → Fluid columns (e.g., "12 columns at 1200px" → `repeat(12, 1fr)` with `minmax()`).
   - *Unverified*: Breakpoint logic (e.g., "stack columns at 768px") will need validation against modern device widths.

3. **Legacy quirks**:
   - If the PDF uses *optical corrections* (e.g., "headlines align to 3rd baseline"), we’ll document them as exceptions.
   - *Destructive shortcuts rejected*: No flattening, rasterizing, or OCR-only extraction—preserve vector paths and text layers.

---

### **Rebuild Sequence**
1. **Extract geometry**:
   - Measure margins, gutters, and column widths from the PDF (using tools like Adobe Acrobat’s ruler or Figma’s import).
   - Record values in a *token map* (e.g., `--grid-margin: 24px; --grid-gutter: 16px`).

2. **Normalize to modern units**:
   - Convert print units (mm/inches) to rem/px for digital.
   - Example: `3mm bleed → 12px` (assuming 96dpi).

3. **Define the grid system**:
   - **For digital**:
     ```css
     .container {
       display: grid;
       grid-template-columns: repeat(12, 1fr);
       gap: var(--grid-gutter);
       padding: var(--grid-margin);
     }
     ```
   - **For print**:
     - Recreate the grid in InDesign/Illustrator using the original measurements.
     - Preserve bleed/safe zones as guides.

4. **Span logic**:
   - Translate column spans into CSS classes or design tokens:
     ```css
     .span-8 { grid-column: span 8; }
     .span-6 { grid-column: span 6; }
     ```

5. **Breakpoints (if inferred)**:
   - Propose a modern scale (e.g., mobile: 6 columns, tablet: 8, desktop: 12) and validate against the PDF’s examples.

6. **Verification checkpoints**:
   - Overlay the reconstructed grid on the original PDF to check alignment.
   - Test responsive behavior with real content (e.g., "Does the headline still span 8 columns at 768px?").

---

### **Risk Controls**
- **Drift guard**: Lock core geometry (margins, gutters) as *immutable tokens* in the new system.
- **Legacy-preservation rule**: Document optical corrections as exceptions (e.g., "Headlines align to 3rd baseline for optical balance").
- **Tolerance rule**: Allow ±2px deviation for inferred values (e.g., "gutter: 16px (inferred from 15px in PDF)").

---

### **Output Artifacts**
1. **Token map** (for developers):
   ```json
   {
     "grid": {
       "margin": "24px",
       "gutter": "16px",
       "columns": 12,
       "baseline": "8px"
     }
   }
   ```
2. **Grid template** (for designers):
   - Figma/Adobe XD file with the reconstructed grid as a reusable component.
3. **Verification guide**:
   - Checklist to validate new layouts against the original (e.g., "Headline spans 8 columns at 1200px width").

---

### **Next Steps**
1. **Upload the PDF** for a visual pre-pass to confirm measurements.
2. **Flag mismatches**: If the PDF’s diagrams and examples conflict, we’ll prioritize the examples (real-world usage).
3. **Propose breakpoints**: If none exist, we’ll suggest a modern scale (e.g., 600px, 900px, 1200px).