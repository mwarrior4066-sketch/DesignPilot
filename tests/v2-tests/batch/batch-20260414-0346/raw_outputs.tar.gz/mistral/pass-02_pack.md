```text
Mode: SPEC | Phase: UI | Route: component_spec
Loaded skills: component-systems-expert, accessibility-feedback-expert, front-end-handoff-expert
```

# Split Button – Component Specification

## Purpose & Scope
A split button combines a primary action (`Save`) with a dropdown trigger for secondary actions (`Save as draft`, `Save and close`). It must:
- Clearly separate the primary action from the dropdown trigger.
- Support keyboard navigation, disabled states, and loading states.
- Meet touch-target size requirements on mobile.
- Maintain accessibility compliance (WCAG 2.1 AA).

This component **does not** handle:
- The logic of the actions themselves (e.g., form submission, API calls).
- Custom dropdown positioning (assume native browser dropdown behavior).

---

## Anatomy
| Part | Role | Notes |
|------|------|-------|
| **Primary Button** | Executes the default action (`Save`). | Must be visually distinct from the dropdown trigger. |
| **Dropdown Trigger** | Opens the secondary actions menu. | Must use a clear affordance (e.g., chevron icon). |
| **Dropdown Menu** | Lists secondary actions (`Save as draft`, `Save and close`). | Must support keyboard navigation and touch. |
| **Loading Indicator** | Replaces the primary button label during async operations. | Must not break layout or touch targets. |

---

## State Matrix
| State | Primary Button | Dropdown Trigger | Dropdown Menu | Notes |
|-------|----------------|------------------|---------------|-------|
| **Default** | Enabled | Enabled | Closed | Ready for interaction. |
| **Hover (Primary)** | Visual feedback (e.g., background change) | – | – | Indicates interactivity. |
| **Hover (Dropdown)** | – | Visual feedback (e.g., background change) | – | Indicates interactivity. |
| **Focus (Primary)** | Focus ring | – | – | Keyboard navigation support. |
| **Focus (Dropdown)** | – | Focus ring | – | Keyboard navigation support. |
| **Active (Primary)** | Pressed state | – | – | Visual feedback on click/tap. |
| **Active (Dropdown)** | – | Pressed state | – | Visual feedback on click/tap. |
| **Disabled** | Disabled (grayed out) | Disabled (grayed out) | – | Prevents interaction. |
| **Loading** | Loading spinner + "Saving..." | Disabled | – | Prevents duplicate submissions. |
| **Menu Open** | – | Active state | Visible | Secondary actions are accessible. |

---

## Accessibility & Implementation Notes
### Keyboard Support
- **Tab**: Moves focus between the primary button and dropdown trigger.
- **Enter/Space**: Executes the focused action (primary button or dropdown item).
- **Arrow Keys**: Navigates dropdown menu items when open.
- **Escape**: Closes the dropdown menu.

### ARIA Attributes
- Primary button: `aria-label="Save"` (or dynamic label in loading state).
- Dropdown trigger: `aria-haspopup="true"`, `aria-expanded="false"` (toggles to `true` when menu is open).
- Dropdown menu: `role="menu"`, `aria-labelledby="[trigger-id]"`.
- Menu items: `role="menuitem"`.

### Touch Targets
- Minimum **48x48px** for both primary button and dropdown trigger (WCAG 2.5.5).
- Ensure spacing between the primary button and dropdown trigger to prevent accidental taps.

### Loading State
- Replace the primary button label with a spinner + "Saving..." (or similar).
- Disable the dropdown trigger during loading to prevent race conditions.

### Disabled State
- Use `aria-disabled="true"` (not `disabled` attribute) to allow focus for screen readers.
- Gray out both the primary button and dropdown trigger.

---

## Token Map
| Token | Role | Example Value |
|-------|------|---------------|
| `--split-button-primary-bg` | Primary button background | `#0066cc` |
| `--split-button-primary-text` | Primary button text color | `#ffffff` |
| `--split-button-dropdown-bg` | Dropdown trigger background | `#f0f0f0` |
| `--split-button-dropdown-icon` | Dropdown icon color | `#333333` |
| `--split-button-disabled-opacity` | Disabled state opacity | `0.5` |
| `--split-button-loading-spinner` | Spinner color | `#ffffff` |

---

## Migration Notes
- Replace existing standalone "Save" buttons with this component where secondary actions are needed.
- Ensure dropdown items are **semantically related** to the primary action (e.g., "Save" variants).
- Test keyboard navigation and touch targets in mobile viewports.

---

## Verification Checklist
1. **Keyboard**: Tab, Enter, Space, and arrow keys work as expected.
2. **Touch**: Primary button and dropdown trigger meet 48x48px minimum.
3. **Screen Reader**: Announces "Save, button" and "Dropdown menu, collapsed" (or "expanded").
4. **Loading State**: Primary button shows spinner, dropdown is disabled.
5. **Disabled State**: Both parts are grayed out and non-interactive.