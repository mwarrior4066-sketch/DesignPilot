**Governing route:** `rt_frontend_implementation_review`  
**Supporting skills:** `front-end-architecture-expert`, `accessibility-feedback-expert`, `back-end-aware-planner`  
**Task weight:** compound (architecture, accessibility, and state safety are central)  
**Evidence classes cited:** rendering_model, state_ownership, boundary_placement, semantic_contract, cost_or_degraded_path  

---

## Architecture risks in the current proposal

1. **Large client-rendered page**  
   - **Problem:** A fully client-rendered dashboard with role‑based visibility and table‑heavy screens will ship unnecessary JavaScript, delay initial render, and hurt Core Web Vitals.  
   - **Impact:** Slow time‑to‑interactive for users on slower networks or devices; poor SEO for logged‑out views; higher client‑side hydration cost.

2. **Separate boolean loading/error state**  
   - **Problem:** `isLoading` and `isError` booleans can enter invalid states (e.g., both true) and don’t model mutually exclusive UI states cleanly.  
   - **Impact:** Bug‑prone conditional rendering; harder to add intermediate states (refreshing, retrying, stale‑while‑revalidate).

3. **Custom `<div>` buttons for filter chips**  
   - **Problem:** Non‑semantic buttons break keyboard navigation, focus management, and screen‑reader announcements.  
   - **Impact:** WCAG 4.1.2 (name, role, value) failure; users cannot operate filters via keyboard or switch/voice input.

4. **Optimistic updates for recurring edits**  
   - **Problem:** Recurring edits often involve server‑side validation (conflicts, role permissions, business rules). Blind optimism can leave the UI out of sync or show succeeded‑then‑reverted changes.  
   - **Impact:** User confusion; integrity errors when the server rejects the optimistic change.

5. **Missing degraded‑path planning**  
   - **Problem:** No fallback if the client‑side JavaScript fails or the session expires during an edit.  
   - **Impact:** Dead UI; users cannot recover without a full page refresh.

---

## Safer architecture recommendations

### 1. Rendering and mutation strategy
**Use server‑side rendering (SSR) with partial client hydration.**

- **Why:** The dashboard is permission‑heavy and table‑heavy — initial HTML should contain the visible data for the current role.  
- **How:**  
  - Render the dashboard shell, filter controls, and first page of table data on the server.  
  - Attach client‑side behavior only to interactive islands: filter chips, pagination controls, edit buttons.  
  - This preserves time‑to‑content, works without JavaScript, and reduces hydration cost.

**State machine over separate booleans**

- **Why:** A finite state machine ensures only valid UI states are possible.  
- **How:**  
  ```ts
  type DataState = 
    | { status: 'idle' }
    | { status: 'loading', staleData?: TableData }
    | { status: 'success', data: TableData }
    | { status: 'error', error: Error, staleData?: TableData };
  ```
  - `staleData` enables stale‑while‑revalidate patterns.  
  - One variable drives the UI; impossible to be both loading and error.

### 2. Semantic and accessibility contract
**Filter chips must be `<button>` elements.**

- **Required attributes:**  
  ```html
  <button
    type="button"
    role="switch" or role="checkbox"
    aria-pressed="true/false"
    aria-label="Filter: Upcoming appointments"
    data-filter-value="upcoming"
  >
    Upcoming
  </button>
  ```
- **Keyboard:** Space/Enter toggles; focus ring visible in high‑contrast mode.  
- **Screen reader:** Announces “filter, button, pressed” or “not pressed”.

**Table accessibility**

- **Scope:** Add `<th scope="col">` / `<th scope="row">`.  
- **Caption:** `<caption>` or `aria-labelledby` for table purpose.  
- **Row selection:** Use `<input type="checkbox">` with proper labels, not custom divs.

### 3. Optimistic updates with rollback safety
**Use a three‑phase pattern for recurring edits:**

1. **Local optimistic update** — UI reflects the change immediately.  
2. **Mutation request** — send to server with a unique `clientMutationId`.  
3. **Reconciliation** — on server response:  
   - **Success:** keep the optimistic state, update any server‑generated fields (timestamps, IDs).  
   - **Failure:** revert the optimistic change, show error with the `clientMutationId` for debugging.

**Guard:** Only allow optimistic updates for actions that have a high success rate under current permissions. For role‑dependent edits, first verify permissions via a lightweight endpoint before showing the editable UI.

### 4. State ownership and boundaries
**Where state lives:**

| State | Owner | Reasoning |
|-------|-------|-----------|
| Filter values | URL query params | Shareable links, server‑side pre‑filtering, back/forward navigation. |
| Pagination | URL query params | Same as above. |
| Table data | Server‑generated HTML + client cache | SSR provides first render; client cache (SWR) handles subsequent fetches. |
| UI state (modal open, loading) | Client component state | No need to serialize; purely presentational. |
| Permissions | Server‑side session + HTTP‑only cookie | Never trust client‑side role checks for security. |

**Boundary placement:**  
- **Server‑client boundary** at the data‑fetching function.  
- **Permissions boundary** at the API route — each endpoint validates the session role before returning data.  
- **Accessibility boundary** at the component level — every interactive control must meet the semantic contract before merging.

### 5. Cost and degraded path
**The cost of this approach:**

- **Bundle overhead:** Adds a few KB for a state‑machine library and focus‑management utilities.  
- **Complexity:** Requires disciplined API design (filter/pagination in URL, permission‑aware endpoints).  
- **Testing surface:** Need to verify server‑client hydration matches, keyboard navigation works, and optimistic rollback handles conflicts.

**Degraded paths:**

1. **JavaScript fails** → filters and pagination fall back to full‑page reloads via native form submits.  
2. **Session expires during edit** → server returns 401, client shows login modal, preserves unsaved changes in draft storage.  
3. **Server‑side rendering fails** → static error page with “Retry” button; no broken half‑UI.

---

## Required decisions for this task

| Decision | This answer’s resolution |
|----------|---------------------------|
| **rendering_model** | SSR with partial hydration (interactive islands). |
| **state_ownership** | Filters/pagination in URL; table data from server + client cache; UI state local. |
| **boundary_placement** | Server‑client boundary at data fetch; permissions at API route; a11y at component. |
| **semantic_contract** | Filter chips are `<button>` with ARIA roles; tables use scope and captions. |
| **cost_or_degraded_path** | Bundle overhead for state‑machine and focus utilities; fallbacks to full reloads and static error pages. |

---

## What is preserved vs. sacrificed

**Preserved:**
- Role‑based visibility (enforced server‑side).
- Real‑time filter/pagination interactivity.
- Optimistic‑update feel for high‑confidence actions.

**Sacrificed:**
- Fully client‑side SPA fluidity (some interactions cause a full‑page reload if JavaScript fails).
- Simplicity of boolean state flags (adopting a state machine adds upfront discipline).
- Arbitrary optimistic updates (now gated by permission pre‑checks and conflict awareness).

---

## Next steps

1. **Update the implementation plan** to reflect SSR + partial hydration.
2. **Add the semantic contract** to the component spec — filter chips as `<button>`, table accessibility attributes.
3. **Implement the state‑machine pattern** for loading/error/success states.
4. **Design the degraded paths** — what happens when JavaScript is blocked or the session expires.
5. **Run an accessibility audit** on the first interactive prototype using keyboard‑only and screen‑reader testing.

---

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: SSR with partial hydration",
    "state_ownership: filters/pagination in URL, table data from server + client cache, UI state local",
    "boundary_placement: server‑client at data fetch, permissions at API route, a11y at component",
    "semantic_contract: filter chips as <button> with ARIA, tables use scope and captions",
    "cost_or_degraded_path: bundle overhead for state‑machine/focus utilities, fallbacks to full reloads and static error pages"
  ],
  "evidence_classes_cited": ["rendering_model", "state_ownership", "boundary_placement", "semantic_contract", "cost_or_degraded_path"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]