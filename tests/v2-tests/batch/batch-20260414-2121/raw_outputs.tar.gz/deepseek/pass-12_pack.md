I’ll recommend a type system for a fintech product that works across marketing site, web app dashboard, and mobile—balancing modern trustworthiness, tabular data clarity, and hierarchy.

---

## Type system recommendation

**Primary typeface: Inter**  
- Open-source, widely available, designed for UI screens.  
- Excellent readability at small sizes, strong x‑height, clear numerals (tabular figures available).  
- Multiple weights (Thin to Black) support clear hierarchy.  
- Works well in both marketing prose and dense dashboards.  
- Trustworthy, neutral, and modern without being trendy.

**Secondary/display option: Source Serif Pro** (for marketing headlines, premium touch)  
- Open-source serif that pairs elegantly with Inter.  
- Adds warmth and credibility for brand/marketing moments.  
- Use sparingly in the app—only for high-level section titles or onboarding hero text.

**Fallback stack:**  
`Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif`

---

## Scale and usage

### Marketing site
- **Headlines:** Source Serif Pro (Semibold) for hero/title; Inter (Bold) for subheads.  
- **Body:** Inter Regular, 18–20px on desktop, 1.5–1.6 line height.  
- **Small text:** Inter Regular, 16px.

### Web app dashboard
- **Page titles:** Inter Bold, 24px.  
- **Section headings:** Inter Semibold, 18px.  
- **Body UI:** Inter Regular, 16px, line height 1.5.  
- **Table numbers:** Inter **tabular figures** (monospaced numerals) in Regular or Medium, 15px.  
- **Labels, helpers:** Inter Regular, 14px, lighter color (#666).

### Mobile
- Scale down proportionally:  
  - Dashboard titles: 20px  
  - Body: 15–16px  
  - Labels: 13–14px  
- Keep line heights slightly tighter (1.4–1.5) for vertical space.

---

## Tabular data specifics
- Use **Inter’s tabular figures** (OpenType feature `tnum`) for all financial numbers—ensures decimal alignment in tables.  
- In data tables, set numbers in Medium weight, labels in Regular.  
- Background: subtle zebra striping (#f9f9f9) for long rows.  
- Right-align numbers, left-align labels.

---

## Hierarchy weights
- **Light (300):** rarely, maybe for large marketing subtitles.  
- **Regular (400):** body text, labels.  
- **Medium (500):** table numbers, interactive elements.  
- **Semibold (600):** section headings, buttons.  
- **Bold (700):** page titles, important metrics.  
- Avoid Black (900) in UI—can feel heavy.

---

## Color and contrast
- Primary text: `#111` or `#222` on white.  
- Secondary: `#555`.  
- Tertiary (hints, disabled): `#777`.  
- Ensure contrast ratios meet WCAG AA (≥ 4.5:1 for normal text, 3:1 for large text).

---

## Implementation notes
- Load Inter from Google Fonts or self-host with variable font if possible (smaller bundle).  
- Enable tabular figures via CSS:  
  ```css
  font-feature-settings: "tnum";
  font-variant-numeric: tabular-nums;
  ```
- For Source Serif Pro, use only Regular and Semibold weights.  
- Test rendering on Windows (ClearType) and macOS.

---

## Rationale
Inter was chosen because it’s free, highly legible, and designed for interfaces—critical for dense financial data.  
Tabular figures ensure numeric alignment, a must for trust in fintech.  
Source Serif Pro adds a touch of credibility in marketing without breaking the system.  
The scale works across contexts without redesigning hierarchy per platform.

---

## Tradeoffs
- **You gain:** consistency, readability, tabular precision, no licensing cost.  
- **You sacrifice:** some brand distinctiveness (Inter is popular) and serif/display flair inside the app.

---

Let me know if you’d like to see a sample scale in pixels/pts, CSS variable definitions, or a comparison with a paid alternative (e.g., Graphik, DIN).