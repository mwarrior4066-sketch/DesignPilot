I'll analyze this PDF accessibility remediation request and provide a structured plan.

## Visual pre‑pass
**Artifact type:** PDF exported from InDesign  
**Layout type:** Two‑column with pull quotes, decorative images, broken TOC links  
**Visible components:** Columns, pull quotes, images, table of contents  
**Confidence level:** High (user description matches typical InDesign export issues)  
**Mismatch check:** None – description aligns with known InDesign accessibility pitfalls

## Governing route: PDF remediation (`rt_pdf_remediation`)
This task centers on document semantics, reading order, and extraction fidelity – the core contract of PDF remediation.

**Supporting skills:**
- `document-accessibility-expert.md` (primary support – tagging, reading order, artifacts)
- `layout-reconstruction-expert.md` (secondary – to infer column structure if visual analysis is needed)

## PDF Remediation Plan

### 1. Semantic failures identified
- **Broken reading order:** Two‑column layout not tagged as articles/regions, causing linearization to jump between columns
- **Pull‑quote interruption:** Decorative or content‑pull quotes breaking flow without `Alt` or `ActualText`
- **Untagged decorative images:** Images marked as artifacts or with empty `Alt`
- **Broken TOC links:** Destination anchors missing or incorrectly named
- **Likely missing document structure tree:** No `TagTree` or minimal tagging

### 2. Reading order & extraction priority
**Correct reading order:**  
1. Document title (H1)  
2. Table of contents (TOC) with working links  
3. Left column content (tagged as continuous article)  
4. Right column content (tagged as separate article or continuation with `Next` attribute)  
5. Pull quotes tagged as `Aside` or `BlockQuote` with `Alt` describing their role  
6. Decorative images marked as artifacts (`Artifact` property)  
7. Footnotes/endnotes in logical position

**Extraction fidelity:**  
- Screen readers should follow visual column order (left then right, not zig‑zag)  
- Pull quotes should be skippable but available if user navigates to them  
- TOC links must resolve to correct heading IDs  
- All text must be extractable for search, copy‑paste, and assistive tech

### 3. Verification method
- **Adobe Acrobat Pro:** Accessibility Checker (WCAG 2.1/PDF/UA‑1)  
- **PAC 2024:** PDF/UA compliance report  
- **Screen‑reader testing:** NVDA, JAWS, VoiceOver with PDF  
- **Extraction test:** Select all text → paste into plain‑text editor to verify order

### 4. Step‑by‑step remediation

#### A. Pre‑work in InDesign (if source available)
1. **Layer cleanup:** Delete hidden/print‑only layers  
2. **Article panel:** Define reading order with Articles panel (left column → right column)  
3. **Image export options:** Set decorative images to “Ignore” or assign empty `Alt`  
4. **TOC styles:** Use hyperlink destinations, not page‑number references  
5. **Export to PDF:** Choose “PDF/X‑4” or “PDF/UA” preset with “Create Tagged PDF” enabled

#### B. Acrobat Pro repair (if only PDF exists)
1. **Add tags:** `Tools → Accessibility → Add Tags to Document`  
2. **Reading order:** `Touch‑Up Reading Order` tool to define columns as separate regions  
3. **Pull quotes:** Tag as `Aside` or `BlockQuote` with `Alt=”Pull quote: [text]”`  
4. **Decorative images:** Right‑click → `Properties → Tag` → check “Artifact”  
5. **TOC links:** `Tools → Content → Links` → edit each link destination to correct heading  
6. **Headings:** Ensure H1‑H6 hierarchy exists (use `Tags` panel)  
7. **Language:** Set document language in `File → Properties → Advanced`

#### C. Output verification checklist
- [ ] Tags tree exists and is logical  
- [ ] Reading order passes Acrobat Checker  
- [ ] All images have appropriate `Alt` or artifact marking  
- [ ] TOC links navigate correctly  
- [ ] Color contrast ≥ 4.5:1 for text  
- [ ] No content marked as “background” incorrectly  
- [ ] Document title set in metadata  
- [ ] Language attribute present

### 5. Destructive shortcuts rejected
**Do not:**
- Flatten to single column (destroys layout integrity)  
- Remove pull quotes entirely (loses design intent)  
- Delete decorative images without artifact marking (may leave ghost content)  
- Use “Make Accessible” wizard without manual review (often creates poor reading order)

### 6. Tradeoffs
**Preserved:** Visual two‑column design, pull‑quote styling, image placement  
**Sacrificed:** Some automated export convenience (requires manual tagging/order review)  
**Accepting:** That screen‑reader users will experience columns sequentially, not simultaneously

## What you need from the user
1. **Source files:** InDesign `.indd` or PDF only?  
2. **Screen‑reader priority:** Any specific AT to test?  
3. **Compliance standard:** WCAG 2.1, PDF/UA‑1, or internal requirements?  
4. **Timeframe:** Quick fix vs. full remediation?

## Next steps
1. Apply the InDesign pre‑work if source exists  
2. Run Acrobat Pro repair steps  
3. Verify with PAC 2024 and screen‑reader test  
4. Deliver repaired PDF with accessibility report

Would you like me to generate the exact Acrobat Pro steps with screenshots, or do you need the InDesign Article panel workflow?