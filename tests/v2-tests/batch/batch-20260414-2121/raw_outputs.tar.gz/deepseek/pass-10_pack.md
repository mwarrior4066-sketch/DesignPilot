**Hierarchy failure:** The decorative title is the largest visual element, but it’s meaningless without context. A viewer scanning the poster won’t know *what* the event is until they find the smaller logo or date—which defeats the purpose of a poster’s top-level communication job.

**What’s preserved:** The bold, atmospheric photo and decorative typeface can still drive visual impact and tone.

**What’s sacrificed:** Immediate clarity and audience relevance. Without context, the title is just decorative type—it doesn’t tell anyone why they should care.

**Rebuild move:**  
1. **Lead with the conference name/logo**—make it the largest or second-largest element so the event is identifiable at a glance.  
2. **Reposition the decorative title** as a thematic tagline or secondary headline, keeping its style but smaller.  
3. **Pull key details (date, location, call-to-action) out of the bottom corner** and group them prominently, using size, color, or placement to create a clear information hierarchy:  
   - Conference name  
   - Tagline/title  
   - Date + location  
   - URL or registration cue  

**Verification method:** Apply the “5‑second test”—cover the logo and ask: “What is this for?” If the answer isn’t obvious, the hierarchy is still broken.