**Route:** `rt_api_reliability_security_review`  
**Escalation level:** `compound`  
**Evidence classes cited:** `async_job_model`, `idempotency_contract`, `authorization_perimeter`, `resilience_strategy`, `problem_details_contract`  

---

## 1. Failure semantics and error contract

**Current failure model:**  
- **HTTP 200 for all responses** — This violates RFC 9110 (HTTP Semantics) and breaks client/consumer expectations. A 200 status means success; errors must be signaled via 4xx/5xx status codes.  
- **Internal enum values leaked** — Error messages expose implementation details (e.g., `"Invalid export_type: INTERNAL_REPORT"`), which can aid attackers in probing the system.  
- **No structured error payload** — Without a standard error format (RFC 9457), clients cannot reliably distinguish between transient failures, user errors, and system faults.

**Required contract:**  
- **Adopt RFC 9457 (Problem Details for HTTP APIs)** for all error responses.  
- **Map failures to appropriate HTTP statuses:**  
  - `400 Bad Request` — Invalid parameters, missing required fields.  
  - `401 Unauthorized` / `403 Forbidden` — Authorization failures.  
  - `409 Conflict` — Duplicate request (when idempotency is added).  
  - `422 Unprocessable Content` — Semantic validation errors (e.g., report data inconsistent).  
  - `429 Too Many Requests` — Rate limit exceeded.  
  - `500 Internal Server Error` — Unexpected server-side failures.  
  - `503 Service Unavailable` — Downstream dependency failure or system overload.  
- **Sanitize error messages** — Never expose internal enums, stack traces, or file paths. Use opaque error codes logged server-side for debugging.

**Example compliant error response:**  
```json
{
  "type": "https://example.com/errors/invalid-parameter",
  "title": "Invalid parameter",
  "status": 400,
  "detail": "The export_type parameter is not recognized.",
  "instance": "/exports/12345"
}
```

---

## 2. Authorization and resource protection

**Current gaps:**  
- **No explicit authorization check** — It’s unclear whether the endpoint validates that the user can access the data being exported.  
- **No object‑level authorization (BOLA)** — Even if the user is authenticated, they may be able to export another user’s data by guessing an ID.  
- **No rate limiting** — A synchronous 3‑minute endpoint is a trivial denial‑of‑service vector.

**Required protections:**  
- **Authentication required** — The endpoint must require a valid session or API token.  
- **Object‑level authorization** — Before generating the report, verify that the requesting user has read access to every resource included in the export. Use a centralized authorization service or policy engine; do not embed ad‑hoc checks in the export logic.  
- **Rate limiting** — Apply a per‑user quota (e.g., 5 exports per hour) and a global burst limit to prevent system overload. Return `429 Too Many Requests` with a `Retry‑After` header when limits are exceeded.  
- **Audit logging** — Log every export request with user ID, timestamp, resource scope, and success/failure outcome for compliance and forensics.

---

## 3. Idempotency and async lifecycle

**Current anti‑pattern:**  
- **Synchronous 3‑minute blocking** — This ties up server resources, risks timeouts, and makes clients brittle. HTTP connections may drop, leaving the client unsure whether the export succeeded.  
- **No idempotency key** — Duplicate requests (e.g., from a user double‑clicking) will trigger duplicate work, wasting resources and potentially causing inconsistent state.

**Required redesign:**  

**A. Move to async job model**  
- **Change the endpoint to `POST /exports` → `202 Accepted`** with a `Location` header pointing to a job‑status endpoint (e.g., `/exports/{jobId}`).  
- **Job lifecycle states:** `queued` → `processing` → `completed` | `failed`.  
- **On completion,** the status endpoint returns a `303 See Other` redirect to the downloadable PDF, or a `200` with a signed, time‑limited download URL.  
- **On failure,** the status endpoint returns a structured error (RFC 9457) with a retry recommendation.

**B. Add idempotency contract**  
- **Require an `Idempotency‑Key` header** (or `X‑Idempotency‑Key`) on the initial `POST /exports`.  
- **Store the key with the job**; duplicate requests with the same key return `409 Conflict` and a link to the existing job’s status endpoint.  
- **Key expiration** — Idempotency guarantees should last at least as long as the job’s retention period (e.g., 24 hours).  

**C. Client‑side resilience**  
- Provide a **polling interval recommendation** (e.g., 5–10 seconds) and a **max polling duration** (e.g., 10 minutes).  
- Support **webhook callbacks** as an alternative to polling for high‑volume integrations.

---

## 4. Resilience and observability

**Current risks:**  
- **No retry safety** — Without idempotency, retries can cause duplicate exports.  
- **No timeout protection** — A 3‑minute synchronous call can exhaust connection pools, thread pools, or memory.  
- **No degradation path** — If PDF generation fails, the whole request fails; there’s no fallback (e.g., CSV export) or partial success.  
- **Poor observability** — No distributed tracing, no structured logs, no metrics on job duration, failure rates, or queue depth.

**Required improvements:**  

**A. Resilience patterns**  
- **Circuit breaker** on downstream dependencies (e.g., database, file storage, templating engine).  
- **Exponential backoff with jitter** for any retries inside the export pipeline.  
- **Graceful degradation** — If PDF generation fails after retries, consider falling back to a simpler format (CSV) or returning a “try again later” message with an estimated wait time.  

**B. Observability tax**  
- **Assign a `trace_id` to every request** and propagate it through all downstream calls.  
- **Structured logging** — Log job lifecycle events (queued, started, completed, failed) with duration, user ID, resource scope, and error codes.  
- **Metrics to expose:**  
  - Export job queue length  
  - Average job processing time (p50, p95, p99)  
  - Failure rate by error type  
  - Rate‑limit hits  
- **Alerting** on queue saturation, elevated failure rates, or latency spikes.

**C. Deployment safeguards**  
- **Resource limits** — Set CPU/memory limits on the export worker pods/containers.  
- **Health checks** — A `/health` endpoint that verifies connectivity to required dependencies (DB, storage, etc.).  
- **Load shedding** — When the system is under high load, reject new export requests with `503 Service Unavailable` and a `Retry‑After` header rather than queueing them indefinitely.

---

## 5. Summary of required changes

| Area | Current flaw | Required fix |
|------|--------------|--------------|
| **Error contract** | HTTP 200 for errors; leaks enums | Adopt RFC 9457; map errors to correct statuses; sanitize messages |
| **Authorization** | Missing object‑level checks; no rate limits | Add BOLA; enforce per‑user quotas; audit log every request |
| **Idempotency** | No idempotency key; synchronous blocking | Move to async job model (`202 Accepted` + status URL); require `Idempotency‑Key` header |
| **Resilience** | No retry safety; no timeouts; poor observability | Add circuit breakers, backoff, graceful degradation; instrument with tracing, logs, metrics |
| **Operational safety** | Denial‑of‑service risk; no health checks | Add rate limits, resource quotas, load shedding, health endpoints |

**Tradeoff:**  
You **sacrifice** the simplicity of a synchronous request‑response cycle and the quick‑to‑implement error‑handling model.  
You **gain** a production‑grade API that is resilient under load, safe for retries, observable, and secure against authorization bypass and denial‑of‑service attacks.

**Next step:**  
If you want a concrete implementation sketch—including the updated OpenAPI spec, job‑status endpoint design, and example idempotency‑key handling—I can provide a rebuild plan.

---

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "problem_details_contract: RFC 9457",
    "authorization_perimeter: object-level authorization + rate limits",
    "idempotency_contract: async job model + idempotency-key header",
    "async_job_model: 202 Accepted + status URL",
    "resilience_strategy: circuit breaker + backoff + observability tax"
  ],
  "evidence_classes_cited": ["async_job_model", "idempotency_contract", "authorization_perimeter", "resilience_strategy", "problem_details_contract"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]