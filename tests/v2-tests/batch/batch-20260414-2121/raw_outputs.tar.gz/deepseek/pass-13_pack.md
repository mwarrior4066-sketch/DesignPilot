I’ll map the research gaps for your B2B project management tool redesign.

---

## Research Gaps Map

**Current evidence in hand:**
- 3 stakeholder interviews (internal or client stakeholders—needs clarity)
- 2 usability tests on the current product
- Analytics: 60% drop-off in project creation flow

**Known unknowns (gaps):**

| Gap | Why it matters | Priority | Recommended method |
|------|----------------|----------|---------------------|
| **Why users abandon project creation** | The 60% drop-off is a symptom, not a diagnosis. Without knowing whether it’s complexity, missing features, confusion, or perceived risk, redesign may solve the wrong problem. | High | **Moderated usability tests** on the current creation flow with think-aloud; **session replay + heatmaps** if available; **exit-intent survey** for leavers. |
| **Power user workflows & unmet needs** | B2B PM tools often have a “power user” segment that drives adoption and dictates feature depth. Missing their needs risks building a shallow tool. | High | **Semi-structured interviews** with 5–7 identified power users; **diary study** for a week of their actual project setup/management tasks. |
| **Competitive landscape & differentiators** | Without knowing what competitors do well/where they fail, you may reinvent common patterns or miss a positioning opportunity. | Medium | **Competitive usability audit** (heuristic evaluation of 3–4 key competitors on project creation); **feature comparison matrix**; **switcher interviews** (users who moved from another tool). |
| **User segmentation beyond “power users”** | Likely there are multiple roles (project managers, team members, execs, clients) with different goals and permissions needs. | Medium | **Survey** to map roles, goals, and permissions expectations; follow up with **role-based interviews**. |
| **Context of use & integration needs** | How does this tool fit into existing workflows? Is it used alongside other tools (Slack, Jira, Google Docs, etc.)? | Medium | **Contextual inquiry** or **workflow mapping interviews**; review of existing tool stacks via survey. |
| **Trust & onboarding barriers** | B2B users need confidence in data security, reliability, and team adoption. Unknown trust hurdles may explain abandonment. | Medium | **Interview questions** focused on risk perception, security concerns, and “what would make you comfortable creating a project?” |
| **Quantitative baseline for success metrics** | Beyond drop-off, what are the target metrics for success (time to create, satisfaction, error rates)? | Low-Medium | **Define KPIs** with stakeholders; **benchmark current performance**; set target thresholds for redesign validation. |

---

## Recommended research sequence

1. **Diagnose the 60% drop-off**  
   - Run 5–7 moderated usability sessions on the current project creation flow.  
   - Add an exit survey for users who abandon (if feasible).  
   *Outcome: Clear problem statements for redesign.*

2. **Interview power users**  
   - Recruit from your existing user base (high activity, many projects).  
   - Focus on advanced needs, customization, and pain points in current tool.  
   *Outcome: Depth requirements and loyalty drivers.*

3. **Competitive audit**  
   - Evaluate 3 direct competitors on project creation, onboarding, and key workflows.  
   - Note where they succeed/fail.  
   *Outcome: Avoid reinventing the wheel; identify differentiators.*

4. **Role-based survey + interviews**  
   - Survey to segment users by role/goals.  
   - Follow-up interviews with 2–3 per key segment.  
   *Outcome: Role-tailored design requirements.*

---

## What you can do now with existing data
- **Re-analyze stakeholder interviews** for implied needs vs. stated wants.
- **Re-watch usability tests** and note where confusion or hesitation appears in project creation.
- **Map the drop-off analytics** to specific steps in the flow (which step loses the most?).

---

## Risk if gaps aren’t filled
- Redesign may optimize for the wrong problem (e.g., making UI prettier while the real issue is missing permissions model).
- Power users may reject the new design as “dumbed down.”
- You might miss a chance to leapfrog competitors on a key unmet need.

---

**Next step:** Prioritize gap #1 (why users abandon) and gap #2 (power users) before moving into solution ideation.