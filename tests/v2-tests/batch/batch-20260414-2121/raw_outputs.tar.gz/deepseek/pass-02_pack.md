I'll write a component spec for a split button with primary action, dropdown, and full state coverage.

**Component spec: Split button**

**Component boundary**
- A split button combines a primary action button with a dropdown trigger that reveals secondary actions.
- The primary action is the default (Save), the dropdown contains related secondary actions (Save as draft, Save and close).
- This is a compound component, not a simple button variant.

**State coverage**
- **Default**: Primary button and dropdown trigger both enabled
- **Hover**: Visual feedback on both segments independently
- **Focus**: Keyboard focus ring on active segment, tab sequence: primary → dropdown → dropdown items
- **Active/pressed**: Depressed visual state during click/tap
- **Disabled**: Both segments disabled with appropriate semantics (aria-disabled="true")
- **Loading**: Primary action shows spinner, dropdown remains disabled during async operation
- **Dropdown open**: Dropdown panel visible, primary action remains actionable
- **Dropdown item hover/focus**: Visual feedback on individual menu items

**Accessibility behavior**
- **Keyboard navigation**:
  - Tab to primary button (Enter/Space activates)
  - Tab to dropdown trigger (Enter/Space opens menu, ArrowDown also opens)
  - When menu open: ArrowUp/Down navigates items, Enter selects, Escape closes
  - Tab away from open menu closes it
- **Screen reader**:
  - Primary button: "Save, button"
  - Dropdown trigger: "More save options, button, collapsed" (opens to "expanded")
  - Menu items: "Save as draft, menu item", "Save and close, menu item"
  - Use aria-haspopup="menu", aria-expanded="true/false"
- **Touch targets**: Minimum 44×44px for both segments on mobile
- **Focus management**: Focus returns to dropdown trigger after menu closes unless user tabs away

**Implementation boundary**
- **HTML structure**:
  ```html
  <div class="split-button" role="group" aria-label="Save options">
    <button class="split-button__primary" aria-label="Save">
      <span class="split-button__label">Save</span>
      <span class="split-button__loading" hidden aria-hidden="true">Loading...</span>
    </button>
    <button class="split-button__trigger" aria-haspopup="menu" aria-expanded="false">
      <span class="visually-hidden">More save options</span>
      <svg>▼</svg>
    </button>
    <ul class="split-button__menu" role="menu" hidden>
      <li role="none">
        <button class="split-button__item" role="menuitem">Save as draft</button>
      </li>
      <li role="none">
        <button class="split-button__item" role="menuitem">Save and close</button>
      </li>
    </ul>
  </div>
  ```
- **CSS considerations**:
  - Flex container with two button children
  - Remove border-radius between segments
  - Shared height, typography, and color tokens
  - Dropdown panel positioned absolutely below trigger
  - High contrast focus states
- **JavaScript requirements**:
  - Toggle menu on trigger click/Enter/Space/ArrowDown
  - Close menu on Escape, click outside, or tab away
  - Handle async loading state (disable primary, show spinner)
  - Emit events: primary-click, item-select, menu-toggle

**Visual design tokens**
- **Height**: 40px (desktop), 44px (mobile)
- **Spacing**: 8px padding horizontal, 4px gap between segments
- **Typography**: System UI font, 14px/1.2, medium weight
- **Colors**:
  - Primary: Brand primary color
  - Hover: 10% darker
  - Active: 20% darker
  - Disabled: 40% opacity, cursor not-allowed
- **Border**: 1px solid border color, shared between segments
- **Focus ring**: 2px outline, offset 2px, high contrast color

**Interaction contracts**
1. **Primary click**: Immediately executes Save action
2. **Dropdown open**: Shows secondary options without executing
3. **Item selection**: Executes chosen secondary action, closes menu
4. **Loading state**: Primary button shows spinner, ignores clicks
5. **Disabled state**: All interactions ignored, aria-disabled="true"

**Edge cases**
- Very long labels (truncate with ellipsis, maintain min width)
- Many secondary items (scrollable menu, max-height 300px)
- Nested split buttons (not supported - use separate component)
- Right-to-left languages (flip dropdown direction, mirror chevron)

**Testing requirements**
- Keyboard navigation flows
- Screen reader announcement sequence
- Touch target size verification
- Loading state interruption handling
- Menu closure on external interaction
- High contrast mode visibility

**Tradeoff resolution**
- **Rather than** a single button with a long dropdown that includes the primary action, **we preserve** immediate access to the default action while **sacrificing** some visual simplicity.
- **Rather than** making both segments equal width, **we preserve** clear primary/secondary hierarchy while **accepting** slightly uneven visual weight.
- **Because** split buttons require precise pointer coordination, **we add** generous touch targets and keyboard fallbacks **to ensure** accessibility isn't compromised.

**Confidence boundary**
This spec assumes:
- The component lives in a form or editor context where Save is the dominant action
- Secondary actions are closely related variants of the primary action
- No more than 4-5 secondary actions (beyond which a regular dropdown button is better)

The implementation preserves the semantic distinction between primary action execution and secondary action discovery while maintaining full keyboard and screen reader accessibility across all states.