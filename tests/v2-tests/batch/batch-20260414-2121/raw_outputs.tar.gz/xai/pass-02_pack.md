## Split Button Component Spec

### Overview
A split button combines a primary action with a secondary dropdown menu for related actions. This component is designed for scenarios where a user needs quick access to a default action while having the option to choose alternatives. Here, the primary action is "Save," with secondary actions "Save as draft" and "Save and close" accessible via a dropdown trigger.

### Component Boundary
- **Primary Action**: A button labeled "Save" that executes the default save operation.
- **Dropdown Trigger**: A separate, visually adjacent button with a downward arrow icon that reveals a menu with secondary actions.
- **Dropdown Menu**: A list containing "Save as draft" and "Save and close," appearing below the trigger on activation.
- **Scope Limitation**: This spec covers the split button's structure, states, and interactions. Backend save logic, routing, or data handling is out of scope and owned by the consuming application.

### Visual Design
- **Layout**: The primary button and dropdown trigger are horizontally aligned, with a subtle visual separator (e.g., a 1px border or color shift) to distinguish them. The primary button takes up approximately 70-80% of the total width to emphasize its importance.
- **Icon**: The dropdown trigger uses a downward chevron icon (e.g., from a standard icon set like Material Icons or FontAwesome).
- **Size**: Minimum touch target of 44x44px for both primary and trigger buttons to meet mobile accessibility standards (WCAG 2.1). Default height of 36px for desktop contexts, scaling to 48px on touch devices.
- **Typography**: Button text uses a 16px font size for readability, with a medium or semi-bold weight to ensure hierarchy.
- **Color**: Primary action uses a filled style with a brand primary color (e.g., blue-600, #2563eb) and white text for contrast. Trigger uses a lighter variant (e.g., blue-500, #3b82f6) or an outline style to de-emphasize it. Menu items use a neutral background (e.g., white or gray-50) with dark text (e.g., gray-900).

### State Coverage
- **Default**: Both primary and trigger buttons are interactive, with hover states (e.g., slight darkening of background, like blue-700 for primary). Dropdown is hidden.
- **Active (Dropdown Open)**: Trigger button shows a pressed state (e.g., blue-700 or inset shadow), and the dropdown menu is visible below the button pair, aligned to the trigger's right or left edge based on viewport space. Menu items have hover states (e.g., gray-100 background).
- **Disabled**: Both buttons are non-interactive, with reduced opacity (e.g., 40%) and a grayed-out appearance (e.g., gray-300 background or border). No hover effects. Dropdown remains hidden.
- **Loading (Primary Action)**: Primary button shows a spinner icon replacing the "Save" text, maintaining the button's dimensions to prevent layout shift. Trigger remains interactive unless the entire component is in a loading context. Text may be replaced with "Saving..." if space allows.
- **Loading (Secondary Action)**: If a secondary action is triggered, the dropdown closes, and the primary button enters a loading state to reflect the ongoing operation, as the primary button visually owns the action feedback.
- **Error**: If an action fails, an error state may be shown via a temporary red outline or icon (e.g., exclamation mark) on the primary button, with a tooltip or adjacent error message if provided by the consuming app. This state is transient and not a persistent button mode.

### Accessibility Behavior
- **ARIA Roles and Attributes**:
  - Primary button: `role="button"` with `aria-label="Save"` if text alone is insufficient.
  - Dropdown trigger: `role="button"` with `aria-expanded="true"` when open, `false` when closed, and `aria-controls` pointing to the dropdown menu ID.
  - Dropdown menu: `role="menu"` with each item as `role="menuitem"`.
- **Keyboard Support**:
  - `Tab` focuses the primary button first, then the dropdown trigger. Dropdown menu is not in the tab order until opened.
  - `Enter` or `Space` on the primary button triggers the save action.
  - `Enter`, `Space`, or `Arrow Down` on the trigger opens the dropdown, focusing the first menu item.
  - Inside the dropdown: `Arrow Up/Down` navigates menu items, `Enter` or `Space` selects an item and closes the menu, `Escape` closes the menu and returns focus to the trigger.
  - `Shift + Tab` from the trigger moves focus backward without opening the dropdown.
- **Focus Indicators**: Visible focus rings (e.g., 2px blue outline, offset by 2px) on both buttons and menu items when focused via keyboard, meeting WCAG 2.1 contrast requirements (minimum 3:1 ratio against background).
- **Touch Targets**: Minimum 44x44px targets ensure compliance with WCAG 2.1 for mobile and touch users.
- **Screen Reader**: Announces primary as "Save, button," trigger as "More save options, button, collapsed/expanded," and menu items as "Save as draft, menu item" and "Save and close, menu item."
- **Reduced Motion**: Dropdown open/close animation (if any) respects `prefers-reduced-motion` by using a fade without slide or transform effects when reduced motion is preferred.

### Interaction Design
- **Click/Tap**:
  - Primary button: Triggers "Save" action immediately.
  - Trigger button: Toggles dropdown visibility. If already open, clicking closes it.
  - Menu items: Selecting an item (e.g., "Save as draft") triggers the action and closes the dropdown.
- **Mobile Behavior**: On touch devices, the component scales up (e.g., 48px height) to ensure tappable targets. Dropdown menu width matches the split button width or expands to a minimum of 200px for readability, preventing cramped touch targets.
- **Click Outside**: Clicking outside the dropdown closes it, returning focus to the trigger if it was keyboard-initiated.
- **Viewport Awareness**: Dropdown positions itself below the trigger by default, flipping above if viewport bottom is constrained, and aligns left or right if horizontal space is limited.

### Implementation Boundary
- **HTML Structure**:
  - Container: `<div class="split-button">` for layout and state scoping.
  - Primary: `<button type="button" class="split-button-primary">Save</button>`.
  - Trigger: `<button type="button" class="split-button-trigger" aria-expanded="false">` with an icon or SVG for the chevron.
  - Dropdown: `<ul class="split-button-dropdown" role="menu" hidden>` with `<li role="menuitem">` for each action.
- **CSS**:
  - Use CSS custom properties for theming (e.g., `--split-button-primary-bg: #2563eb;`).
  - Flexbox for button alignment (e.g., `display: flex; gap: 0;` with a separator pseudo-element if needed).
  - Positioning for dropdown (e.g., `position: absolute; top: 100%;` with dynamic flipping logic).
  - Transitions for dropdown visibility (e.g., `opacity` fade over 200ms, respecting reduced motion).
- **JavaScript**:
  - Toggle `aria-expanded` and dropdown visibility on trigger click.
  - Handle keyboard navigation for menu items (Arrow keys, Enter, Escape).
  - Close dropdown on outside click using event delegation.
  - Manage focus return after menu interaction.
  - Optionally, handle loading state by toggling a class or attribute (e.g., `data-state="loading"`) to show spinner.
- **Framework Notes**:
  - If using React, manage state with `useState` for dropdown visibility and `useRef` for focus management.
  - If using Vue, use `v-model` or reactive state for toggling and `ref` for DOM focus.
  - Ensure event listeners clean up on unmount to prevent memory leaks.
- **Dependencies**: No external libraries required beyond a standard icon set if SVGs are not inline. If using a UI library (e.g., Material-UI, shadcn/ui), adapt to their button and menu primitives while preserving accessibility and state logic.
- **Performance**: Avoid layout thrashing during dropdown toggle by using `transform` or `opacity` for animations rather than `height` or `display`. Ensure loading spinner does not cause reflow by reserving space in the DOM.
- **Testing**:
  - Unit tests for state transitions (default, open, disabled, loading).
  - Accessibility tests with axe-core or similar to verify ARIA and keyboard navigation.
  - Visual regression tests for hover/focus/loading states across breakpoints.
  - Touch tests on mobile emulators to confirm target size and dropdown positioning.

### Tradeoffs and Rationale
- **Separate Buttons vs Unified**: Using two distinct buttons (primary and trigger) rather than a single button with a split hit area improves accessibility by providing clear focus targets and ARIA roles. This sacrifices a small amount of visual compactness but gains explicit interaction clarity.
- **Primary Emphasis**: Allocating more width to the primary button (70-80%) prioritizes the main action over secondary options, aligning with user expectation for "Save" as the default. This means the trigger is visually smaller, which could reduce discoverability for secondary actions on first use.
- **Loading on Primary**: Showing loading feedback on the primary button even for secondary actions centralizes feedback in one visible spot, at the cost of potentially confusing users who expect feedback tied to the clicked menu item. This is mitigated by closing the dropdown during loading to reduce visual noise.
- **Dynamic Dropdown Positioning**: Adjusting dropdown placement based on viewport prevents clipping and ensures usability, sacrificing simplicity in CSS for better UX on constrained screens.

This spec provides a robust foundation for a split button that balances functionality, accessibility, and implementation feasibility across desktop and mobile contexts. If you need adjustments for a specific design system or additional states, let me know.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: primary action and dropdown trigger", "state_coverage: default, active, disabled, loading, error", "accessibility_behavior: ARIA roles, keyboard support, focus indicators, touch targets", "implementation_boundary: HTML structure, CSS, JS, framework notes"],
  "evidence_classes_cited": ["accessibility_standard", "touch_target_threshold"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]