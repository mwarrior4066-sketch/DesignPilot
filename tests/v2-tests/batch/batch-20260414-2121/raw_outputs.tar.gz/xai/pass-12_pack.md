I’ll recommend a type system for your fintech product that works across a marketing site, web app dashboard, and mobile platforms. The goal is a modern, trustworthy look with strong support for tabular financial data and clear hierarchy through multiple weights.

### Recommendation: Inter
**Primary Typeface**: Inter, designed by Rasmus Andersson, is a sans-serif typeface optimized for digital interfaces. It’s my top choice for your fintech product due to its balance of modernity, readability, and versatility.

- **Why Inter Fits**: Inter was specifically crafted for screen use, with a focus on UI and data-dense environments. Its clean, neutral design conveys trust and professionalism—key for fintech—while avoiding overly decorative or dated aesthetics. It offers a wide range of weights (from Thin to Black, 9 total), which supports strong typographic hierarchy across marketing, dashboard, and mobile contexts.
- **Tabular Data Strength**: Inter includes a dedicated set of figures optimized for tables, with consistent width across weights to prevent alignment issues in financial data displays. This ensures numbers in dashboards don’t jitter or misalign when weights change (e.g., bolding a total).
- **Cross-Platform Performance**: Inter renders exceptionally well on web and mobile, with high legibility at small sizes due to its large x-height and open apertures. It’s available as a variable font, which reduces file size and simplifies responsive scaling across breakpoints—critical for mobile apps and web dashboards.
- **Modern and Trustworthy**: Its geometric foundation with subtle humanist touches (like slightly curved terminals) gives a contemporary feel without sacrificing approachability. This avoids the coldness of pure geometric sans-serifs or the informality of overly rounded designs.
- **Licensing**: Inter is open-source under the SIL Open Font License, making it free to use across all your platforms without cost or legal concerns.

### Type System Configuration
Here’s how to deploy Inter across your contexts with specific roles, sizes, and weights for hierarchy:

#### Marketing Site
- **Purpose**: Capture attention, communicate trust, and guide users to conversion.
- **Headline (Display)**: Inter Bold or Extra Bold, 48px–72px (desktop), 32px–48px (mobile). Use for hero sections and major calls-to-action. Tighten letter-spacing slightly (-0.02em) for polish.
- **Subhead**: Inter Medium, 24px–32px (desktop), 18px–24px (mobile). Use for section intros or secondary emphasis.
- **Body**: Inter Regular, 16px–18px (desktop), 14px–16px (mobile). Line height of 1.5–1.6 for readability in longer content like blog posts or feature descriptions.
- **Caption/Accent**: Inter Regular or Italic, 14px (desktop), 12px (mobile). Use for footnotes, disclaimers, or subtle emphasis.
- **Line Length**: Target 50–75 characters per line on desktop for body text to maintain readability.

#### Web App Dashboard
- **Purpose**: Prioritize clarity and scanability for dense financial data and UI elements.
- **Dashboard Title**: Inter SemiBold, 20px–24px. Use for page headers or major section titles.
- **Widget Labels/KPI Headings**: Inter Medium, 14px–16px. Use for chart titles, filter labels, or key metrics.
- **Tabular Data**: Inter Regular, 12px–14px. Use monospaced figures (enable `tnum` OpenType feature) for alignment in tables and ledgers. Line height of 1.4–1.5 to keep rows scannable.
- **Secondary Text**: Inter Regular, 12px. Use for tooltips, timestamps, or status indicators.
- **Micro Text**: Inter Regular, 10px–11px. Use for subtle metadata or compact disclaimers in tight spaces.
- **Density Focus**: Keep leading tight in data tables (1.3–1.4) to maximize information density without sacrificing legibility.

#### Mobile App
- **Purpose**: Optimize for smaller screens with touch-friendly hierarchy and readability.
- **Headline/Title**: Inter Bold, 20px–24px. Use for screen headers or primary actions.
- **Navigation Labels**: Inter Medium, 14px–16px. Use for tab bars, menu items, or card titles.
- **Body/Content**: Inter Regular, 14px–16px. Line height of 1.5 for short paragraphs or transactional details.
- **Data Points**: Inter Regular, 12px–14px. Use for list items or compact financial summaries, with `tnum` for alignment.
- **Captions**: Inter Regular, 11px–12px. Use for secondary info or disclaimers.
- **Touch Target Note**: Ensure text elements meet minimum touch target sizes (44px height per WCAG) by pairing smaller text with adequate padding.

### Hierarchy Through Weights
- **Primary Emphasis**: Bold or Extra Bold for top-level headlines or critical CTAs. This draws attention on marketing pages and mobile screens.
- **Secondary Emphasis**: SemiBold or Medium for subheads, widget titles, or navigation. This differentiates without overpowering.
- **Neutral/Base**: Regular for body text, data, and UI labels. This is the workhorse weight for most content.
- **De-emphasized**: Light or Thin for captions, placeholders, or inactive states (use sparingly and ensure contrast meets WCAG 4.5:1 for normal text).

### Implementation Notes
- **Variable Font Usage**: Use Inter’s variable font format (Inter.var.woff2) to minimize load times and enable fine-grained weight adjustments via CSS (`font-weight: 450;`). This is especially useful for responsive designs across web and mobile.
- **Fallback Stack**: If Inter fails to load or isn’t supported, use a system font stack for resilience: `font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;`. This ensures a comparable sans-serif experience.
- **Contrast and Accessibility**: Ensure text meets WCAG AA contrast ratios (4.5:1 for normal text, 3:1 for large text) against your background colors, especially for financial data on dashboards. Test small sizes (12px) on mobile for legibility.
- **Licensing Safety**: Since Inter is open-source, embed it in your app bundles or host it on your CDN without worrying about per-user or per-device fees.

### Tradeoff
By choosing Inter, you gain a modern, data-friendly typeface with excellent cross-platform support at no cost. The sacrifice is that it’s widely used in tech and fintech (e.g., by Stripe and Coinbase), so it won’t feel uniquely branded. If differentiation becomes a priority later, you could pair it with a custom display font for marketing headlines—but for now, Inter’s reliability and neutrality prioritize trust over distinctiveness.

### Next Step
If this works for your vision, I can refine the scale further with exact breakpoints or generate a CSS snippet for implementation. Let me know if you’d like an alternative typeface with a different tone or if branding uniqueness is a bigger concern than I’ve assumed.