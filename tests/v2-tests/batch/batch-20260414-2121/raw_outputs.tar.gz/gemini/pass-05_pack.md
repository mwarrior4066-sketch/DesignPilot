I can help fix your PDF report to ensure it's accessible for screen readers and has a logical reading order for export. This involves a **PDF remediation plan** with a focus on document accessibility and layout integrity.

**Governing Route:** `rt_pdf_remediation_plan`
**Supporting Skills:** `document-accessibility-expert.md`, `pdf-layout-expert.md`

Here's a plan to address the issues you've identified:

### PDF Remediation Plan for Accessibility and Reading Order

Your PDF, exported from InDesign, presents several common challenges for accessibility, particularly with complex layouts and interactive elements. The core problem is a **semantic_failure** where the visual presentation does not accurately reflect the underlying logical structure needed by assistive technologies.

**1. Re-establish Logical Reading Order and Structure**
The two-column layout and pull quotes are key areas for reading order challenges.
*   **Action:** We will manually correct the reading order within the PDF's tag tree. This **requires** identifying the main content flow, then correctly nesting or sequencing elements like headings, paragraphs, lists, and tables.
*   **Two-column Layout:** For a two-column layout, the **reading_order_or_extraction** must prioritize continuous flow across columns, typically top-left to top-right, then down to the next row's left column. This often means correcting the tag order to interleave content from the left column with the corresponding content from the right column, rather than reading one entire column before moving to the next.
*   **Pull Quotes:** Pull quotes that interrupt the main flow will be tagged as `<Aside>` elements and placed logically within the tag tree so they are encountered at a relevant point, but do not break the continuity of the main paragraph flow for screen readers. This ensures they are accessible without being disruptive.

**2. Address Decorative Images**
*   **Action:** All purely decorative images will be marked as "Artifact" in the PDF tag structure. This signals to screen readers that these images should be ignored **because** they do not convey information essential for comprehension.
*   **Consideration:** If any decorative images *do* convey subtle but important branding or context (e.g., a header graphic with a logo and report title), we'd need to add appropriate alternative text. Based on your description, "decorative" means no alt text is needed.

**3. Repair Broken Table of Contents Links**
*   **Action:** The table of contents (TOC) entries will be re-linked to their corresponding headings within the PDF. This **requires** ensuring that all target headings are correctly tagged with appropriate heading levels (e.g., `<H1>`, `<H2>`) to create a robust navigation structure. The TOC itself will be tagged as a navigation list (`<L>`) with list items (`<LI>`) containing links (`<Link>`).

**4. Reject Destructive Shortcuts**
*   **Decision:** `destructive_shortcut_rejected` - We will **reject** any approach that rasterizes pages or flattens the PDF to "fix" layout issues. Such methods would destroy the underlying text, vector graphics, and semantic structure, making the document completely inaccessible and unexportable as text.
*   **Tradeoff:** This manual, detailed remediation will be more time-consuming and require specialized PDF editing tools compared to simply re-exporting or flattening. However, it is necessary to achieve true accessibility and maintain the document's integrity and future usability.

**5. Verification Method**
*   **Action:** After remediation, the PDF will be verified using a combination of automated accessibility checkers (e.g., Adobe Acrobat Pro's Accessibility Checker, PAC 2021) and manual inspection with a screen reader (e.g., NVDA, JAWS, VoiceOver).
*   **Specific Checks:** We will confirm:
    *   No major accessibility errors are flagged by automated tools.
    *   The reading order matches the logical flow when navigated by a screen reader.
    *   All content is selectable as text and can be extracted accurately.
    *   TOC links function correctly.
    *   Decorative images are correctly artifacted.
    *   Language is correctly identified.

This plan focuses on restoring the semantic integrity and usability of your PDF report for all users.