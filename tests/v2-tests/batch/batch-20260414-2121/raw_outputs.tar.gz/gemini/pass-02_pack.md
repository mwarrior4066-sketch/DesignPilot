Here is a component specification for a split button, covering its behavior, states, accessibility, and implementation considerations.

## Split Button Component Specification: Save and Secondary Actions

This specification defines a split button component featuring a primary "Save" action and an integrated dropdown for secondary save-related actions like "Save as draft" and "Save and close." The design prioritizes robust accessibility, clear state feedback, and mobile touch usability.

### 1. Component Boundary

The **component_boundary** for the split button consists of two distinct, yet visually grouped, interactive elements:

1.  **Primary Action Button:** A standard button element responsible for the most common action (e.g., "Save"). This part is visually dominant and occupies the majority of the component's width. It acts as a standard button when clicked or activated.
2.  **Dropdown Trigger Button:** A smaller button, typically visually separated by a subtle divider or border, containing a visual indicator (e.g., a down arrow icon). When activated, this button reveals a menu of secondary actions.

These two parts must be treated as a single logical component for layout and grouping, but as separate interactive elements for focus, events, and semantic roles.

### 2. Interaction Design

*   **Primary Action (Save):**
    *   A single click or keyboard activation (Enter/Space) on this segment performs the "Save" action directly.
    *   This action should typically be immediate, without opening a menu.
*   **Dropdown Trigger:**
    *   A single click or keyboard activation (Enter/Space) on this segment toggles the visibility of the dropdown menu.
    *   The menu should appear directly below or adjacent to the split button.
    *   Clicking outside the menu (or pressing Escape) closes the menu.
*   **Dropdown Menu Items:**
    *   The menu contains secondary actions (e.g., "Save as draft", "Save and close").
    *   Clicking or activating a menu item performs its respective action and closes the menu.

### 3. State Coverage

Robust **state_coverage** is critical for clarity and feedback. All states must apply to both the primary action button and the dropdown trigger, or specifically to the entire component where noted.

*   **Default:** Standard visual appearance, ready for interaction.
*   **Hover:** Visual feedback when the mouse cursor is over either the primary action button or the dropdown trigger. (e.g., background color change).
*   **Focus:** Distinct visual indicator when either part of the button receives keyboard focus. This must be a clear outline or glow, not just a background change, because it's essential for keyboard users.
*   **Active (Pressed):** Visual feedback when either part of the button is being pressed (e.g., darker background, slight depression).
*   **Dropdown Open:** The dropdown trigger visually indicates it is active (e.g., background highlight, arrow icon rotation) and the menu is visible.
*   **Disabled:** Both the primary action button and the dropdown trigger are visually muted, non-interactive, and do not receive focus or respond to clicks. This state applies when the save action is currently unavailable (e.g., form validation failed, content unchanged).
*   **Loading:**
    *   When the primary "Save" action is triggered: The primary button segment may display a spinner or loading indicator, and both button segments should become `disabled` to prevent re-submission.
    *   When a dropdown action is triggered: The specific menu item may display a loading indicator, and the entire split button component should become `disabled` to prevent conflicting actions.
    *   Loading states should be brief and provide clear feedback on completion or error.

### 4. Accessibility Behavior

**Accessibility_behavior** must be carefully engineered for keyboard, screen reader, and touch users.

*   **Keyboard Support:**
    *   **Tab:** Tabbing to the split button should focus the primary "Save" button. Pressing Tab again moves focus to the dropdown trigger, then to the next interactive element on the page.
    *   **Enter/Space (on Primary Button):** Activates the primary "Save" action.
    *   **Enter/Space (on Dropdown Trigger):** Toggles the dropdown menu visibility. When the menu opens, focus should move to the *first item* in the dropdown list because direct access is more efficient than forcing users to tab through.
    *   **Arrow Keys (within Dropdown Menu):** Up/Down arrow keys navigate between menu items.
    *   **Home/End (within Dropdown Menu):** Move focus to the first/last menu item respectively.
    *   **Escape (within Dropdown Menu or on Dropdown Trigger):** Closes the dropdown menu and returns focus to the dropdown trigger button.
*   **Screen Reader Support (ARIA):**
    *   The primary button should use `role="button"`.
    *   The dropdown trigger should use `role="button"` and `aria-haspopup="menu"`.
    *   When the dropdown menu is open, the dropdown trigger should have `aria-expanded="true"`. When closed, `aria-expanded="false"`.
    *   The dropdown menu itself should use `role="menu"`, with each menu item using `role="menuitem"`.
    *   Each menu item should be clearly labeled, either by its visible text content or an `aria-label`.
*   **Disabled State:** Elements in a disabled state must have `aria-disabled="true"` and be removed from the tab order (`tabindex="-1"`) to prevent accidental focus.
*   **Mobile Touch Targets:** Both the primary action button and the dropdown trigger must meet a minimum target size of 44x44 CSS pixels as per WCAG guidelines. This ensures comfortable and accurate interaction for users on touch devices, preventing mis-taps. The internal spacing and padding should contribute to this minimum size.

### 5. Implementation Boundary

The **implementation_boundary** for the split button should prioritize semantic HTML and progressive enhancement.

*   **Semantic Structure:**
    *   The primary button and dropdown trigger should ideally be `<button>` elements.
    *   The dropdown menu should be a `<ul>` with `<li>` for menu items, or another semantic list structure appropriate for menus.
    *   The overall component can be wrapped in a `<div>` or `<span class="split-button-container">` for styling and layout purposes, but it must not interfere with the semantic roles of its children.
*   **CSS:** Visual separation and grouping should be achieved using CSS (borders, padding, background colors). The disabled and loading states must have clear visual cues.
*   **JavaScript:** Manages the dropdown menu's visibility, keyboard navigation, and focus management.
*   **Token Contracts:** Ensure any design tokens (color, spacing, typography, border-radius) used for the button match the established design system, simplifying handoff and ensuring consistency.

### 6. Tradeoffs and Considerations

One key **tradeoff_resolution** for split buttons is balancing visual simplicity with functional discoverability. While they offer a compact way to group related actions, the secondary actions in the dropdown are less discoverable than always-visible buttons. We accept this by prioritizing a clean primary action flow, **rather than** cluttering the interface with all possible save options. This means accepting that users might need a moment to discover the dropdown if they are looking for "Save as draft," but we gain a cleaner primary interface for the most common "Save" action.