Here is a color system for a healthcare SaaS dashboard, designed to meet your requirements for status communication, dark mode support, data visualization, and WCAG AA accessibility.

The system is built on semantic roles, ensuring that colors communicate meaning rather than just appearance.

## Semantic Roles and Palette Definition

### Core UI & Text Colors
These colors form the foundation of the interface for backgrounds, text, and basic components.

**Light Mode:**
*   **Backgrounds:**
    *   `bg-canvas`: `#FFFFFF` (Page background)
    *   `bg-surface`: `#F5F7FA` (Card, modal, and panel backgrounds)
*   **Text & Icons:**
    *   `text-primary`: `#1E293B` (Main body text, headings)
    *   `text-secondary`: `#475569` (Helper text, secondary labels)
    *   `text-disabled`: `#CBD5E1` (Disabled elements, subtle separators)
    *   `border-default`: `#E2E8F0` (Borders, dividers)

**Dark Mode:**
*   **Backgrounds:**
    *   `bg-canvas-dark`: `#1A202C` (Page background)
    *   `bg-surface-dark`: `#2D3748` (Card, modal, and panel backgrounds)
*   **Text & Icons:**
    *   `text-primary-dark`: `#F7FAFC` (Main body text, headings)
    *   `text-secondary-dark`: `#E2E8F0` (Helper text, secondary labels)
    *   `text-disabled-dark`: `#A0AEC0` (Disabled elements, subtle separators)
    *   `border-default-dark`: `#4A5568` (Borders, dividers)

### Brand & Accent Color
A single, consistent brand color for interactive elements and primary accents.

**Light Mode:**
*   `brand-primary`: `#3B82F6` (e.g., primary buttons, active states, main links)

**Dark Mode:**
*   `brand-primary-dark`: `#60A5FA` (Lighter shade of blue for dark backgrounds)

## State Mapping: Status and Data Visualization

This section defines the colors for communicating status and for distinguishing data categories.

### Status Colors (Normal, Warning, Critical)
These communicate system health, alerts, and critical issues. Each has a dedicated shade for light and dark modes to ensure clarity and contrast.

**Light Mode:**
*   `status-normal`: `#10B981` (Green for success, healthy, complete)
*   `status-warning`: `#F59E0B` (Amber for caution, pending, review needed)
*   `status-critical`: `#EF4444` (Red for error, alert, urgent action)

**Dark Mode:**
*   `status-normal-dark`: `#34D399` (Lighter green)
*   `status-warning-dark`: `#FBBF24` (Brighter amber)
*   `status-critical-dark`: `#F87171` (Lighter red)

### Categorical Data Visualization Colors
A set of 6 distinct colors for charts and graphs, designed to be perceptually different and work across modes.

**Light Mode:**
*   `data-category-1`: `#3B82F6` (Blue - also acts as `brand-primary`)
*   `data-category-2`: `#F97316` (Orange)
*   `data-category-3`: `#10B981` (Green)
*   `data-category-4`: `#8B5CF6` (Purple)
*   `data-category-5`: `#EC4899` (Pink)
*   `data-category-6`: `#06B6D4` (Cyan)

**Dark Mode:**
*   `data-category-1-dark`: `#60A5FA` (Blue)
*   `data-category-2-dark`: `#FB923C` (Orange)
*   `data-category-3-dark`: `#6EE7B7` (Green)
*   `data-category-4-dark`: `#A78BFA` (Purple)
*   `data-category-5-dark`: `#F472B6` (Pink)
*   `data-category-6-dark`: `#22D3EE` (Cyan)

**Tradeoff Resolution**: The selection of `data-category-1` as the same hue as `brand-primary` reduces the total distinct hues but leverages brand recognition. To provide 6 categories, other hues are chosen carefully to ensure distinctness while aiming for color-blind friendly options where possible (avoiding direct red/green adjacent for primary data categories).

## Contrast Boundary: WCAG AA Compliance

All text and essential UI elements must meet WCAG AA contrast ratios.

*   **Normal text (14pt/18.66px and smaller):** Minimum 4.5:1 contrast ratio against its background.
*   **Large text (14pt/18.66px bold or 18pt/24px and larger):** Minimum 3:1 contrast ratio against its background.
*   **Non-text contrast (UI components and graphical objects):** Minimum 3:1 contrast ratio against adjacent colors.

**Verification Method**:
*   **Light Mode Text:**
    *   `text-primary` (`#1E293B`) on `bg-canvas` (`#FFFFFF`): **12.2:1** (Passes AA)
    *   `text-secondary` (`#475569`) on `bg-canvas` (`#FFFFFF`): **6.2:1** (Passes AA)
*   **Dark Mode Text:**
    *   `text-primary-dark` (`#F7FAFC`) on `bg-canvas-dark` (`#1A202C`): **13.8:1** (Passes AA)
    *   `text-secondary-dark` (`#E2E8F0`) on `bg-canvas-dark` (`#1A202C`): **8.0:1** (Passes AA)

**Data Visualization Labels**:
While the categorical colors are intended for visual elements (bars, lines, chart segments), if they are used as text labels, their contrast against the background must also pass WCAG AA. For example:
*   `data-category-1` (`#3B82F6`) on `bg-canvas` (`#FFFFFF`) is **4.0:1**, which is below 4.5:1.
*   **Recommendation:** For data labels, prioritize `text-primary` or `text-secondary`. If a categorical color *must* be used for text, use a darker shade for light mode backgrounds (or lighter for dark mode backgrounds) that achieves the 4.5:1 ratio, or ensure the text is large (>=18pt) to meet the 3:1 ratio.

## Migration Strategy

The implementation of this color system should follow a phased approach:

1.  **Tokenization**: Map all defined colors to CSS variables (e.g., `--color-bg-canvas`, `--color-status-critical`). Implement separate token sets for light and dark modes.
2.  **Global Styles**: Update global styles to use these new color tokens for backgrounds, text, and borders.
3.  **Component Integration**: Integrate color tokens into existing components, starting with core elements like buttons, inputs, and cards.
4.  **Data Visualization Update**: Apply the new categorical and status colors to all dashboard charts and data displays. Pay special attention to label contrast.
5.  **Audit & Refine**: Conduct a thorough accessibility audit (automated and manual) across both light and dark modes to verify WCAG AA compliance for all text and UI elements. Address any identified `contrast_boundary` failures.
6.  **Documentation**: Create clear documentation for designers and developers on how to use the new color tokens, their semantic roles, and accessibility considerations.

**Tradeoff Resolution**: Implementing a robust token system adds initial setup overhead (`cost_or_degraded_path`) but vastly improves long-term maintainability, consistency, and the ease of future palette adjustments (such as adding more data categories or adjusting for brand changes).