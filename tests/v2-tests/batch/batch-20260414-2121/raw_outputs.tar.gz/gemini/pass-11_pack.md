To reconstruct your layout system from the 2018 brand guidelines PDF for new templates, I would follow a structured process of extraction, inference, and translation. This approach prioritizes understanding the original intent while modernizing the implementation.

**Governing Route:** `rt_layout_reconstruction_plan`
**Supporting Skills:** `layout-reconstruction-expert`, `pdf-layout-expert`, `grid-system-expert`, `type-system-expert`, `ui-system-expert`

---

## Layout System Reconstruction Plan

My goal is to extract the functional rules and semantic intent of your existing layout system, then translate these into a flexible, maintainable system suitable for modern digital and potentially print templates.

### 1. Visual Pre-Pass and Extraction (Observed & Inferred Evidence)

I will perform a detailed visual analysis of your PDF, separating directly **observed evidence** from **inferred structure**.

**Observed Evidence (High Confidence):**
These are facts directly visible or explicitly stated in the PDF.
*   **Page Dimensions:** Exact width and height of standard pages (e.g., A4, US Letter, specific digital artboards) from technical specifications or clear visual boundaries.
*   **Outer Margins:** Precise top, bottom, left, and right margins from grid diagrams or explicit measurements.
*   **Column System:**
    *   **Number of Columns:** The count of columns used in various layout examples.
    *   **Gutter Widths:** Explicit or consistently measurable spacing between columns.
    *   **Column Span Examples:** How different content blocks occupy 1, 2, 3, or more columns.
*   **Baseline Grid:** If present, the vertical rhythm unit (e.g., 8px, 12px) from alignment guides or consistent vertical spacing.
*   **Key Grid Components:** Explicitly named modules, zones, or regions if defined in the diagrams (e.g., "header zone," "sidebar module").
*   **Typography Hierarchy:** Font families, sizes, line heights (leading), and paragraph spacing as applied within the layout examples, especially for body text, headings, and captions.
*   **Component-level Spacing:** Visible padding and margin around recurring elements (e.g., headings, list items, image captions) that imply a micro-spacing system.

**Inferred Structure (Medium to Low Confidence):**
These are patterns or values I would deduce from visual consistency, requiring verification.
*   **Implicit Alignment Rules:** Objects aligning to specific grid lines, baselines, or column edges even if not explicitly stated as rules.
*   **Underlying Grid Math:** If only visual examples are provided, I will infer the mathematical basis of the grid (e.g., total width minus gutters, divided by columns).
*   **Module Sizing:** Consistent height or width ratios for recurring content blocks not explicitly defined.
*   **Responsive Intent (if any):** If different page sizes or "context" examples are shown, I would infer early ideas of adaptive behavior, though this is less common in 2018 print guidelines.
*   **Confidence Level:** For all inferred elements, I will name the confidence level (medium to low) and highlight assumptions.

**Mismatch Detection:** I will explicitly flag any instances where your description of the PDF's contents (e.g., "grid diagrams") does not align with what is visually present or is ambiguous.

### 2. Translation to a Modern Layout System

The extracted information will then be translated into a flexible and tokenized layout system, designed for adaptability across various media (web, app, print, digital documents).

**a. Preserved Elements (`preserved_elements`):**
The core visual identity, hierarchical intent, and proven spatial relationships from your 2018 guidelines will be preserved. This includes:
*   The general visual rhythm and balance established by the original margins and column structures.
*   The intended reading experience and content density.
*   The functional hierarchy communicated through typography and major content zones.

**b. Modernization Strategy:**

*   **Fixed Values to Design Tokens & Responsive Units:**
    *   **Margins & Padding:** Convert fixed pixel/point values into a semantic design token system (e.g., `spacing-02`, `spacing-04`, `spacing-xl`) or responsive `rem`/`em` units. Define semantic roles for these tokens (e.g., `$layout-margin-page`, `$component-padding-button`).
    *   **Page Dimensions:** Translate into `max-width` constraints for content containers and define explicit breakpoints for different viewport sizes (e.g., mobile, tablet, desktop) rather than fixed page sizes.
*   **Column System to Flexible Grid:**
    *   **CSS Grid / Flexbox Model:** Re-articulate the column logic using modern CSS Grid (preferred for multi-axis layouts) or Flexbox for more linear arrangements.
    *   **Flexible Columns:** Instead of fixed-width columns, use `fr` units (fractional units) or percentage-based columns to allow the layout to scale.
    *   **Semantic Gutters:** Define gutters using CSS `gap` properties or dynamic `margin` values, controlled by design tokens.
    *   **Layout Primitives:** Introduce generic layout components (e.g., `Grid`, `Stack`, `Columns`) that encapsulate these rules, promoting reuse and consistency.
*   **Baseline Grid to Vertical Rhythm:**
    *   **Line-Height and Spacing Tokens:** Translate the baseline grid concept into a consistent vertical rhythm using calculated `line-height` values and vertical spacing design tokens that ensure elements align cleanly. The strictness of the baseline grid may be softened for digital contexts to allow for more flexible content, while maintaining a clear rhythm.
*   **Typography System:**
    *   **Responsive Type Scale:** Convert specific point sizes to a responsive type scale using `rem` units, with adjustments for different breakpoints.
    *   **Semantic Roles:** Map the original usage of type (e.g., H1, body, caption) to semantic roles that are independent of specific font choices.
    *   **Variable Fonts:** Recommend incorporating variable fonts for greater control over weight, width, and optical sizing if not already in use, to optimize for legibility across contexts.
*   **Component-level Spacing:** Extract these micro-spacing rules and codify them into a dedicated spacing scale, applied through design tokens at the component level.

### 3. Reconstruction Order (`reconstruction_order`)

1.  **Extract Core Layout System:** Focus first on margins, columns, gutters, and primary content areas.
2.  **Detail Typography System:** Map font families, sizes, line heights, and hierarchy.
3.  **Identify Micro-spacing:** Catalog padding/margins within and around smaller elements.
4.  **Codify Grid Logic:** Write down the mathematical and structural rules.
5.  **Translate to Tokens/Responsive Units:** Convert all static values into a modern, flexible system.
6.  **Create Documentation Schema:** Outline how these new rules will be documented for templates.

### 4. Verification Method (`verification_method`)

To ensure the reconstructed system accurately reflects the original intent while being modern and robust, I would propose the following verification steps:
*   **Visual Comparison:** Create mockups or simple prototypes using the new system and compare them side-by-side with key layouts from the original PDF.
*   **Rule Set Review:** Cross-reference the extracted rules with your team to confirm accuracy and intent.
*   **Scalability Test:** Apply the new system to various content lengths, screen sizes, and device types to ensure it remains coherent and legible.
*   **Accessibility Check:** Briefly ensure the new system supports basic accessibility principles (e.g., logical reading order, sufficient contrast if color decisions implicitly affect layout).

---
[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: core visual identity and hierarchy",
    "inference_boundary: separation of observed facts from inferred patterns",
    "reconstruction_order: systematic extraction and translation steps",
    "verification_method: visual comparison, rule review, scalability test, accessibility check"
  ],
  "evidence_classes_cited": ["observed", "inferred", "confidence_level"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]