Here's a type system recommendation for your fintech product, designed to balance modern aesthetics, trustworthiness, data legibility, and cross-platform consistency.

### Type System Recommendation for Fintech Product

A well-chosen type system is critical for a fintech product, as it directly underpins both user trust and the efficient display of complex financial data. This recommendation prioritizes legibility, hierarchy, and a modern yet grounded aesthetic across your marketing site, web app dashboard, and mobile interfaces.

#### Font Family Selection

I recommend a versatile **humanist or geometric sans-serif superfamily** as the primary typeface for all contexts. This choice is critical because it directly impacts readability and the product's perceived professionalism. Such families typically offer:

*   **Modern and Trustworthy Feel:** Clean lines, clear letterforms, and a lack of overly decorative elements contribute to a contemporary and reliable impression.
*   **Excellent Legibility:** High x-heights, open apertures, and good character differentiation ensure text is easily readable at various sizes, a non-negotiable for financial data.
*   **Robust Weight Range:** Essential for creating clear hierarchy and visual distinction, from light body text to bold headlines and UI elements.
*   **Tabular Figures (Monospaced Numbers):** A key requirement for fintech is precise tabular figure alignment; without this, financial data becomes difficult to scan and compare accurately across rows and columns. Ensure the chosen family supports this feature natively.

**Recommended Example:**
*   **Inter:** (Google Fonts) A highly functional and modern typeface specifically designed for user interfaces. It boasts a large x-height, excellent legibility, a wide range of weights, and includes dedicated tabular figures. It excels in both small text environments (like dashboards and mobile lists) and larger marketing contexts. Its variable font capabilities also offer granular control for responsive adjustments.

#### Reading Context (`reading_context`)

The chosen typeface should seamlessly adapt to three distinct reading contexts:

1.  **Marketing Site:**
    *   **Role:** Brand expression, conveying clarity, and inviting engagement.
    *   **Behavior:** Larger display sizes for headlines, clear calls to action, and accessible body text for conveying product benefits. The modern feel supports a forward-thinking brand.
    *   **Priority:** Brand alignment and engaging readability.

2.  **Web App Dashboard:**
    *   **Role:** Information density, data readability, and rapid scanning.
    *   **Behavior:** Efficient use of space, clear hierarchy for KPIs and metrics, highly legible small text, and precise tabular figure alignment for financial tables. This requires strong contrast and distinct weight differentiation.
    *   **Priority:** Data integrity, efficiency, and functional clarity.

3.  **Mobile Interface:**
    *   **Role:** On-the-go comprehension, touch-target clarity, and accessibility in varied environments.
    *   **Behavior:** Optimized for small screen sizes, single-column layouts, and minimal eye strain. Touch targets must remain legible even when fonts are scaled.
    *   **Priority:** Legibility at small sizes, minimal cognitive load, and accessibility.

#### Scale Decision (`scale_decision`)

A responsive, semantic type scale is essential to manage consistency and legibility across all mediums.

*   **Base Size:** Establish a comfortable base font size for body text (e.g., 16px or 1rem) for optimal readability.
*   **Modular Scale for Headings:** Use a consistent modular scale (e.g., a ratio of 1.250 – Major Third or 1.333 – Perfect Fourth) to generate heading sizes (H1-H6). This creates natural, harmonious steps in hierarchy.
*   **Data-Specific Sizes:** For tabular financial data, a slightly smaller yet highly legible size (e.g., 12-14px) may be used, prioritizing density and scanning ease, without which critical information might be spread too thin or become unreadable.
*   **Responsive Adjustments:** Implement breakpoints where the type scale adjusts to optimize for larger screens (marketing, desktop dashboard) and smaller screens (mobile). This means accepting fluid or step-based scaling for certain elements.
*   **Variable Fonts:** If using a typeface like Inter (with variable font capabilities), explore using its optical sizing axis to dynamically adjust weight and width for optimal legibility at very small or very large sizes.

#### Pairing Rationale (`pairing_rationale`)

For a fintech product, simplicity and consistency are paramount. I recommend using a **single, robust sans-serif superfamily** rather than a pairing of multiple typefaces.

*   **Consistency:** A single family ensures a unified visual language across all touchpoints, reinforcing trustworthiness and brand coherence.
*   **Performance:** Reduces font file requests and load times, directly impacting performance and user experience, especially on mobile. This approach sacrifices the potential for a more distinct brand voice that a highly specialized display typeface might offer, but gains efficiency.
*   **Implementation Simplicity:** Easier to manage font stacks, responsive behavior, and accessibility across different development teams and platforms.

If a subtle distinction is desired for marketing headlines, consider using a different weight or style (e.g., a bolder or slightly more condensed cut) from within the *same* superfamily, rather than introducing a second font.

#### Adoption Sequence (`adoption_sequence`)

A phased approach to type system adoption will ensure a smooth transition and allow for refinement.

1.  **Define Type Tokens:** Translate the chosen font family, weights, and scale into design tokens (e.g., `--font-family-base`, `--font-size-h1`, `--font-weight-bold`). This is required for implementation consistency.
2.  **Establish Semantic Roles:** Map specific font styles (e.g., `heading-1`, `body-default`, `data-small`) to their functional uses across the marketing site, dashboard, and mobile app. This ensures designers and developers use the type system correctly.
3.  **Pilot Implementation:** Apply the new type system to a contained section or a new feature first. This allows for real-world testing and feedback without disrupting core experiences.
4.  **Accessibility Audit:** Conduct a thorough accessibility audit (WCAG AA minimum) focusing on contrast, reading order, and resize behavior across all platforms. Without this, compliance risks are high.
5.  **Documentation and Training:** Create clear documentation for designers and developers, including usage guidelines, common pitfalls, and examples.
6.  **Phased Rollout:** Gradually roll out the type system across your existing products, prioritizing high-impact areas like dashboards and critical user flows first. This approach ensures a controlled rollout and allows for iteration, without which system-wide adoption risks inconsistency.

---
[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing_site_web_app_dashboard_mobile",
    "scale_decision: responsive_semantic_scale_data_specific_sizes_variable_font_potential",
    "pairing_rationale: single_sans_serif_superfamily_for_consistency_performance",
    "adoption_sequence: define_tokens_semantic_roles_pilot_audit_docs_phased_rollout"
  ],
  "evidence_classes_cited": [
    "trust requires",
    "a key requirement is",
    "without which",
    "this requires",
    "this means accepting",
    "at the cost of",
    "this ensures"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]