Here’s a **PDF remediation plan** that preserves the two-column layout while fixing screen-reader accessibility, reading order, and export fidelity. The plan follows the governing route `rt_pdf_remediation_plan` with supporting skills `document-accessibility-expert.md` and `layout-reconstruction-expert.md`.

---

### **1. Semantic Structure Repair**
**Problem**: Pull quotes and decorative images are untagged, breaking reading order.
**Fix**:
- **Tag pull quotes** as `<Quote>` with `Role="PullQuote"` and `Placement="Block"` to separate them from body text.
- **Tag decorative images** as `<Artifact>` (not `<Figure>`) to exclude them from the reading order.
- **Verify reading order** in Adobe Acrobat’s *Tags* panel: Body text → Pull quote → Body text (not pull quotes interrupting paragraphs).
- **Confidence**: High (observed in InDesign-exported PDFs).

**Evidence class cited**: `semantic_failure` (missing tags), `reading_order_or_extraction` (interrupted flow).

---

### **2. Table of Contents (TOC) Links**
**Problem**: Broken links in the TOC.
**Fix**:
- **Re-link TOC entries** to corresponding bookmarks/page anchors in Acrobat:
  1. Open *Bookmarks* panel → Recreate or verify bookmarks for each section.
  2. In *Tags* panel, select each TOC entry → *Properties* → Set `Link` action to the correct bookmark.
- **Test**: Use *Read Out Loud* (View → Read Out Loud) to confirm links navigate correctly.
- **Confidence**: High (InDesign TOCs often lose links during export).

**Evidence class cited**: `semantic_failure` (broken links), `verification_method` (Read Out Loud test).

---

### **3. Two-Column Layout Preservation**
**Problem**: Screen readers may linearize columns incorrectly.
**Fix**:
- **Tag columns** as `<Sect>` with `Role="Column"` and `Placement="Block"` to group content by column.
- **Set reading order** to "Left-to-right, top-to-bottom" in Acrobat’s *Order* panel.
- **Add `ReadingOrder` attribute** to `<Sect>` tags to enforce column sequence.
- **Confidence**: Medium (requires manual verification; InDesign’s auto-tagging may misorder columns).

**Evidence class cited**: `inference_boundary` (column order may vary by PDF viewer).

---

### **4. Decorative Images**
**Problem**: Decorative images are untagged or mislabeled as `<Figure>`.
**Fix**:
- **Retag decorative images** as `<Artifact>` with `Type="Background"` or `Type="Decoration"`.
- **Remove alt text** (decorative images should have empty `Alt=""`).
- **Verify**: Use *Tags* panel to confirm images are excluded from the reading order.
- **Confidence**: High (observed in InDesign exports).

**Evidence class cited**: `semantic_failure` (misleading tags).

---

### **5. Validation and Verification**
**Required checks**:
1. **WCAG 2.1 AA Compliance**:
   - Run *Accessibility Check* in Acrobat (Full Check → WCAG 2.1 AA).
   - Fix errors for:
     - **Tagged PDF**: All content must be tagged.
     - **Logical reading order**: Use *Order* panel to verify.
     - **Link purpose**: TOC links must navigate correctly.
2. **Screen Reader Test**:
   - Use NVDA or VoiceOver to read the document aloud. Confirm:
     - Pull quotes are announced as "pull quote."
     - Decorative images are skipped.
     - Columns are read left-to-right, top-to-bottom.
3. **Export Test**:
   - Export text via *File → Export → Text* to confirm reading order is preserved.

**Evidence class cited**: `verification_method` (WCAG check + screen reader test).

---

### **6. Destructive Shortcuts Rejected**
**Avoided pitfalls**:
- **Do not flatten the layout**: Converting to a single column would sacrifice design intent.
- **Do not remove pull quotes**: They are semantically meaningful; tagging is sufficient.
- **Do not delete decorative images**: Retagging as `<Artifact>` preserves visuals while excluding them from the reading order.

**Tradeoff**: Preserves visual design at the cost of manual tagging effort.

---

### **7. Implementation Steps**
1. **Open in Adobe Acrobat Pro** (required for tagging).
2. **Run *Accessibility Check*** → Fix errors for untagged content.
3. **Retag pull quotes** as `<Quote>` and decorative images as `<Artifact>`.
4. **Re-link TOC** to bookmarks.
5. **Set column reading order** in *Order* panel.
6. **Test with screen reader** and export text to verify.

---

### **8. Tools and Outputs**
- **Tools**: Adobe Acrobat Pro (for tagging), NVDA/VoiceOver (for testing).
- **Outputs**:
  - Remediated PDF with:
    - Correct reading order.
    - Functional TOC links.
    - Decorative images excluded from screen-reader flow.
  - **Validation report**: WCAG 2.1 AA compliance summary.

**Evidence class cited**: `verification_method` (tools used).

---

### **Governing Decisions (Contract Index)**
| Decision ID               | Value                                                                 |
|---------------------------|-----------------------------------------------------------------------|
| `semantic_failure`        | Pull quotes untagged, decorative images mislabeled, TOC links broken |
| `reading_order_or_extraction` | Columns linearized incorrectly, pull quotes interrupt flow        |
| `verification_method`     | WCAG 2.1 AA check + screen reader test + text export                 |
| `destructive_shortcut_rejected` | Layout flattening, pull quote removal, image deletion avoided    |