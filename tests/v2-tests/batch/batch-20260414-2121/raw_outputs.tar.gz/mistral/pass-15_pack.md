Here’s a **backend architecture spec** for your multi-tenant scheduling platform, structured to address scalability, data residency, auditability, and extensibility while preserving existing REST APIs and relational database investments. The design prioritizes **consistency boundaries**, **eventual automation support**, and **operational clarity** over speculative polish.

---

## **1. Core Services & Boundaries**
### **Service Decomposition**
| Service               | Responsibility                                                                 | Data Ownership                                                                 | Key Contracts                                                                 |
|-----------------------|-------------------------------------------------------------------------------|--------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| **Tenant Service**    | Tenant provisioning, regional residency, quota enforcement                   | Tenant metadata, residency rules, subscription tiers                          | `TenantCreated`, `ResidencyChanged`, `QuotaExceeded`                        |
| **Workspace Service** | Team workspaces, member roles, access control                                | Workspace hierarchy, role assignments, invitation flows                       | `WorkspaceCreated`, `MemberAdded`, `RoleUpdated`                            |
| **Scheduling Service**| Core scheduling (events, availability, conflicts), approval workflows        | Events, availability slots, approval states, recurrence rules                 | `EventCreated`, `ApprovalRequested`, `EventRescheduled`                      |
| **Activity Service**  | Cursor-based activity feeds (per workspace/user)                             | Activity logs, cursor state, feed composition rules                           | `ActivityLogged`, `FeedRequested` (cursor-based pagination)                 |
| **Webhook Service**   | Outbound webhooks to customer systems, retry/backoff, delivery guarantees    | Webhook subscriptions, delivery attempts, payload history                     | `WebhookSubscribed`, `WebhookDeliveryFailed`, `WebhookPayloadSent`          |
| **Automation Service**| (Future) Customer-defined rules (e.g., "auto-approve if <X conditions")      | Rule definitions, execution state, sandboxed execution context                | `RuleCreated`, `RuleTriggered`, `RuleExecutionFailed`                        |
| **Audit Service**     | Immutable audit trails for all tenant/workspace actions                      | Audit logs (append-only), retention policies, export compliance               | `AuditLogged`, `AuditExported`                                              |
| **Job Service**       | Background jobs (e.g., reminders, cleanup, async exports)                    | Job queues, execution state, retry policies                                   | `JobScheduled`, `JobCompleted`, `JobFailed`                                  |

---

## **2. Data Boundaries & Residency**
### **Multi-Tenancy Model**
- **Tenant Isolation**: Each tenant’s data is logically isolated (schema-per-tenant or row-level security). Residency rules are enforced at the **Tenant Service** layer.
- **Regional Residency**:
  - Tenants are assigned a **home region** (e.g., `us-east-1`, `eu-west-1`) at creation.
  - All tenant data (including backups) must reside in the home region.
  - Cross-region reads are **blocked by default**; exceptions require explicit opt-in (e.g., for global admins).
- **Data Classification**:
  | Data Type               | Residency Enforcement | Replication Strategy          | Retention Policy               |
  |-------------------------|-----------------------|--------------------------------|--------------------------------|
  | Tenant metadata         | Global (single region)| Async to read replicas         | 7 years (compliance)           |
  | Workspace data          | Home region           | None                           | 5 years post-deletion          |
  | Event data              | Home region           | None                           | 3 years post-event             |
  | Activity feeds          | Home region           | None                           | 1 year (rolling window)        |
  | Audit logs              | Home region           | Async to cold storage          | 7 years (immutable)            |
  | Webhook payloads        | Home region           | None                           | 30 days (delivery history)     |
  | Background jobs         | Home region           | None                           | 90 days (execution history)    |

---

## **3. Key Contracts & APIs**
### **3.1. Event Contracts (Async)**
All services emit events to a **tenant-scoped event bus** (e.g., AWS EventBridge, Kafka with tenant partitioning). Events are **immutable** and **idempotent**.

#### **Example Events**
```json
// TenantCreated (Tenant Service)
{
  "eventId": "evt_123",
  "tenantId": "tn_456",
  "homeRegion": "eu-west-1",
  "createdAt": "2024-01-01T00:00:00Z",
  "metadata": { "subscriptionTier": "pro" }
}

// ApprovalRequested (Scheduling Service)
{
  "eventId": "evt_789",
  "tenantId": "tn_456",
  "workspaceId": "ws_101",
  "eventId": "evt_abc",
  "requestedBy": "user_xyz",
  "approvers": ["user_123", "user_456"],
  "deadline": "2024-01-10T00:00:00Z"
}

// WebhookPayloadSent (Webhook Service)
{
  "eventId": "evt_def",
  "tenantId": "tn_456",
  "webhookId": "wh_789",
  "payload": { "eventId": "evt_abc", "status": "approved" },
  "attempt": 1,
  "status": "delivered"
}
```

### **3.2. REST API Contracts**
#### **Scheduling Service**
```http
POST /tenants/{tenantId}/workspaces/{workspaceId}/events
{
  "title": "Team Sync",
  "startTime": "2024-01-15T09:00:00Z",
  "endTime": "2024-01-15T10:00:00Z",
  "recurrence": { "rule": "weekly", "endDate": "2024-12-31" },
  "approvalRequired": true,
  "attendees": ["user_xyz"]
}
```
**Response**:
```json
{
  "eventId": "evt_abc",
  "status": "pending_approval",
  "approvalUrl": "/approvals/evt_abc"
}
```

#### **Activity Service (Cursor-Based Feed)**
```http
GET /tenants/{tenantId}/workspaces/{workspaceId}/activity?cursor=abc123&limit=20
```
**Response**:
```json
{
  "items": [
    {
      "activityId": "act_123",
      "type": "event_created",
      "timestamp": "2024-01-01T00:00:00Z",
      "actor": "user_xyz",
      "metadata": { "eventId": "evt_abc" }
    }
  ],
  "nextCursor": "def456",
  "hasMore": true
}
```

#### **Webhook Service**
```http
POST /tenants/{tenantId}/webhooks
{
  "url": "https://customer.com/webhook",
  "events": ["event_created", "approval_requested"],
  "secret": "whsec_123"  // For HMAC signature
}
```
**Response**:
```json
{
  "webhookId": "wh_789",
  "status": "active"
}
```

---

## **4. Operational Concerns**
### **4.1. Background Jobs**
- **Job Service** owns all async work (e.g., reminders, cleanup, exports).
- **Job Types**:
  | Job Type               | Trigger                          | Retry Policy               | Idempotency Key          |
  |------------------------|----------------------------------|----------------------------|--------------------------|
  | Event reminder         | `EventCreated` event             | Exponential backoff (5x)   | `eventId`                |
  | Webhook delivery       | `WebhookSubscribed` + event      | Exponential backoff (3x)   | `webhookId + eventId`    |
  | Audit log export       | Manual request                   | None                       | `exportId`               |
  | Recurring event sync   | Cron (daily)                     | None                       | `tenantId + date`        |

- **Storage**: Jobs stored in a relational table with `status` (`pending`, `running`, `completed`, `failed`), `attempts`, and `nextRunAt`.

### **4.2. Webhooks**
- **Delivery Guarantees**:
  - At-least-once delivery (deduplication handled by customer via `eventId`).
  - Retry with exponential backoff (3 attempts, max 24h delay).
  - Dead-letter queue for failed deliveries (retryable via API).
- **Security**:
  - HMAC signatures for all payloads (shared secret per webhook).
  - Rate limiting (e.g., 100 requests/minute per tenant).
- **Payloads**:
  - Include `tenantId`, `eventId`, `timestamp`, and event-specific data.
  - Example:
    ```json
    {
      "tenantId": "tn_456",
      "eventId": "evt_abc",
      "type": "approval_requested",
      "timestamp": "2024-01-01T00:00:00Z",
      "data": { "eventTitle": "Team Sync", "requestedBy": "user_xyz" }
    }
    ```

### **4.3. Audit Trails**
- **Immutable Logs**: All tenant/workspace actions logged to an append-only table.
- **Schema**:
  ```sql
  CREATE TABLE audit_logs (
    auditId UUID PRIMARY KEY,
    tenantId UUID NOT NULL,
    workspaceId UUID,
    actorId UUID NOT NULL,  -- User or system
    action VARCHAR(50) NOT NULL,  -- e.g., "event_created", "member_removed"
    entityType VARCHAR(50) NOT NULL,  -- e.g., "event", "workspace"
    entityId UUID NOT NULL,
    metadata JSONB,  -- Action-specific data (e.g., event title, role changes)
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ipAddress INET,
    userAgent TEXT
  );
  ```
- **Retention**: 7 years (compliance). Older logs archived to cold storage.
- **Export**: API endpoint to export logs (CSV/JSON) with filters (e.g., date range, action type).

### **4.4. Regional Residency Enforcement**
- **Tenant Service** validates all requests against the tenant’s `homeRegion`.
- **Cross-Region Reads**: Blocked by default. Global admins can override with a header:
  ```http
  GET /tenants/tn_456/workspaces/ws_101/events
  X-Allow-Cross-Region: true
  ```
- **Data Replication**:
  - Tenant metadata replicated to all regions (for auth/routing).
  - Workspace/event data **never** leaves the home region.

### **4.5. Automation Rules (Future)**
- **Sandboxed Execution**:
  - Rules run in isolated containers (e.g., AWS Lambda, Kubernetes pods).
  - No direct DB access; rules interact via APIs.
- **Rule Definition**:
  ```json
  {
    "ruleId": "rule_123",
    "tenantId": "tn_456",
    "name": "Auto-approve team syncs",
    "trigger": { "eventType": "approval_requested" },
    "condition": "event.attendees.length < 5 && event.title.includes('Team Sync')",
    "action": { "type": "approve_event", "comment": "Auto-approved by rule" }
  }
  ```
- **Execution**:
  - Rules triggered by events (e.g., `ApprovalRequested`).
  - Actions emit events (e.g., `EventApproved`).

---

## **5. Cross-Cutting Concerns**
### **5.1. Authorization**
- **Role-Based Access Control (RBAC)**:
  | Role          | Permissions                                                                 |
  |---------------|-----------------------------------------------------------------------------|
  | Admin         | Full access to all workspaces, tenant settings                              |
  | Workspace Admin| Manage workspace members, events, approvals                                |
  | Member        | Create/edit own events, view workspace activity                             |
  | Guest         | View events (read-only)                                                     |

- **Object-Level Checks**:
  - All requests validate `tenantId` + `workspaceId` + `userId` against the **Workspace Service**.
  - Example: `GET /tenants/{tenantId}/workspaces/{workspaceId}/events` checks if the user is a member of the workspace.

### **5.2. Consistency Model**
- **Strong Consistency**:
  - Tenant/workspace metadata (e.g., roles, residency rules).
  - Event approvals (avoid double-booking).
- **Eventual Consistency**:
  - Activity feeds (cursor-based, may lag by seconds).
  - Webhook deliveries (retries may delay).
  - Audit logs (asynchronous writes).

### **5.3. Observability**
- **Metrics**:
  - Per-tenant: `events_created`, `approvals_requested`, `webhook_deliveries`, `job_failures`.
  - Latency: P99 for API endpoints, job execution time.
- **Logging**:
  - Structured logs with `tenantId`, `workspaceId`, `userId`, `requestId`.
  - Audit logs (immutable) + operational logs (30-day retention).
- **Tracing**:
  - Distributed tracing (e.g., OpenTelemetry) for cross-service flows (e.g., `EventCreated` → `WebhookPayloadSent`).

### **5.4. Security**
- **Data Encryption**:
  - At rest: AES-256 (tenant data) + TLS 1.2+ (in transit).
  - Webhook secrets encrypted with tenant-specific keys.
- **API Security**:
  - OAuth 2.0 (JWT) for user authentication.
  - Rate limiting (e.g., 1000 requests/minute per tenant).
- **Webhook Security**:
  - HMAC signatures for payloads.
  - IP allowlisting (optional).

---

## **6. Migration Strategy**
### **6.1. Phase 1: Stabilize Eventing**
- Replace ad-hoc background jobs with the **Job Service**.
- Introduce the **tenant-scoped event bus** (e.g., AWS EventBridge).
- Migrate existing REST APIs to emit events (e.g., `EventCreated`).

### **6.2. Phase 2: Multi-Tenancy & Residency**
- Add `homeRegion` to tenant metadata.
- Enforce residency rules in the **Tenant Service**.
- Replicate tenant metadata to all regions.

### **6.3. Phase 3: Webhooks & Automation**
- Build the **Webhook Service** (start with core events).
- Design the **Automation Service** sandbox (no execution yet).

### **6.4. Phase 4: Customer Automation**
- Enable rule creation via API.
- Add UI for rule management.
- Monitor rule execution for performance/safety.

---

## **7. Risks & Mitigations**
| Risk                                      | Mitigation                                                                 |
|-------------------------------------------|----------------------------------------------------------------------------|
| Cross-region latency for global admins    | Cache tenant metadata in all regions; use read replicas for auth.         |
| Webhook delivery failures                 | Dead-letter queue + manual retry API.                                      |
| Audit log explosion                       | Partition by `tenantId` + `date`; archive old logs.                        |
| Automation rule abuse                     | Rate limiting + sandboxed execution + manual approval for high-risk rules. |
| Eventual consistency gaps                 | Use `eventId` for idempotency; document consistency windows.               |

---

## **8. Open Questions**
1. **Automation Rules**:
   - Should rules support complex conditions (e.g., "if event is in the next 24h AND attendee is a manager")?
   - How to handle rule conflicts (e.g., two rules approving/rejecting the same event)?
2. **Webhooks**:
   - Should customers be able to subscribe to **all** events (e.g., for auditing)?
   - How to handle payload size limits (e.g., large event metadata)?
3. **Residency**:
   - Should tenants be able to **move** regions (e.g., `eu-west-1` → `us-east-1`)? If so, how to handle data migration?
4. **Audit Logs**:
   - Should logs include **read** operations (e.g., "user viewed event")? This could bloat storage.

---

## **9. Next Steps**
1. **Implement the Job Service** to replace ad-hoc background jobs.
2. **Add tenant-scoped event bus** (e.g., AWS EventBridge) and emit core events.
3. **Enforce residency rules** in the Tenant Service.
4. **Build the Webhook Service** with retry/backoff logic.
5. **Design the Automation Service sandbox** (no execution yet).
6. **Add audit logging** to all services.