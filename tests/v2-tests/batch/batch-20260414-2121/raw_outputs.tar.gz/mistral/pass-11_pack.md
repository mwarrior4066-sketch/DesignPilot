### **Governing Route**
`rt_layout_reconstruction_plan` (Layout Reconstruction Expert)
**Supporting Skills**
- `grid-system-expert.md` (Grid normalization & modern translation)
- `type-system-expert.md` (Typography hierarchy & scale)
- `pdf-layout-expert.md` (PDF frame logic & baseline integrity)
**Evidence Classes Cited**
- `observed` (directly visible in PDF)
- `inferred` (assumed from spacing/alignment)
- `unverified` (requires validation)

---

### **Layout Reconstruction Plan**
#### **1. Extract Observed Evidence (High Confidence)**
From the **2018 PDF brand guidelines**, extract:
- **Grid diagrams**
  - Column count (e.g., 12-column, 6-column)
  - Gutter width (e.g., 20px)
  - Margin width (e.g., 80px left/right, 60px top/bottom)
  - Baseline grid increment (e.g., 8px, 12px)
  - Breakpoint behavior (if specified, e.g., "collapses to 8 columns at tablet")
- **Margin specifications**
  - Page margins (e.g., "1.5in for print, 80px for digital")
  - Safe zones (if marked, e.g., "no text/logos within 20px of edge")
- **Column layout examples**
  - Span logic (e.g., "headlines span 8 columns, body spans 6")
  - Alignment rules (e.g., "all text aligns to baseline grid")
  - Max-width constraints (e.g., "content container never exceeds 1200px")

#### **2. Infer Structure (Medium Confidence)**
- **Probable manuscript model**
  - If the PDF uses a **fixed-page layout** (e.g., A4, Letter), infer whether it was designed for print-first or digital adaptation.
  - Example: *"The 12-column grid suggests a digital-first system, but the fixed 1.5in margins imply print constraints."*
- **Typography scale**
  - Extract font sizes (e.g., H1 = 48px, Body = 16px) and line-height ratios (e.g., 1.5×).
  - Infer whether a **modular scale** (e.g., 1.25×, 1.5×) was used.
- **Spacing system**
  - Identify whether spacing follows the baseline grid (e.g., "all padding = 1× baseline increment").
  - Example: *"Gutters are 20px, which is 2.5× the 8px baseline—likely intentional for rhythm."*

#### **3. Flag Unverified Assumptions (Low Confidence)**
- **Interaction logic**
  - *"The PDF shows static layouts—interactive behavior (e.g., hover states, responsive breakpoints) cannot be confirmed."*
- **Accessibility compliance**
  - *"Contrast ratios, touch targets, and keyboard navigation are not visible in the PDF and must be validated separately."*
- **Color roles**
  - *"The PDF specifies color swatches, but their semantic roles (e.g., primary action, background) are inferred from usage examples."*

---

### **4. Translate to a Modern Layout System**
#### **A. Grid Normalization**
| **Legacy Spec**               | **Modern Equivalent**                          | **Rationale**                                  |
|-------------------------------|-----------------------------------------------|-----------------------------------------------|
| 12-column grid                | 12-column CSS Grid + 8px baseline             | Maintains flexibility for complex layouts.   |
| 80px margins                  | `clamp(60px, 5vw, 100px)`                      | Fluid margins for responsive design.          |
| 20px gutters                  | `gap: 1.25rem` (20px)                          | Uses `rem` for scalability.                   |
| Fixed 1200px max-width        | `max-width: 80rem` (1280px)                    | Aligns to modern viewport standards.         |

#### **B. Typography Hierarchy**
- **Legacy:** H1 = 48px, Body = 16px, Line-height = 1.5×
- **Modern:**
  ```css
  :root {
    --font-scale: 1.25; /* Modular scale */
    --base-size: 1rem; /* 16px */
  }
  h1 { font-size: calc(var(--base-size) * 3)); } /* 48px */
  p { font-size: var(--base-size); line-height: 1.5; }
  ```
- **Additions:**
  - Variable font support (e.g., `font-variation-settings: "opsz" 14`).
  - Fluid typography (e.g., `clamp(1rem, 2vw, 1.25rem)` for body text).

#### **C. Spacing System**
- **Legacy:** 8px baseline grid
- **Modern:**
  ```css
  :root {
    --space-unit: 1rem; /* 16px */
    --space-xxs: calc(0.25 * var(--space-unit)); /* 4px */
    --space-xs: calc(0.5 * var(--space-unit));  /* 8px */
    --space-s: calc(1 * var(--space-unit));     /* 16px */
    --space-m: calc(1.5 * var(--space-unit));   /* 24px */
  }
  .container { padding: var(--space-m); }
  ```
- **Rationale:** Uses CSS custom properties for consistency and theming.

#### **D. Breakpoint Behavior**
- **Legacy:** "Collapses to 8 columns at tablet"
- **Modern:**
  ```css
  @media (min-width: 768px) {
    .grid { grid-template-columns: repeat(8, 1fr); }
  }
  @media (min-width: 1024px) {
    .grid { grid-template-columns: repeat(12, 1fr); }
  }
  ```
- **Additions:**
  - Mobile-first approach (e.g., `min-width` instead of `max-width`).
  - Container queries for component-level responsiveness.

---

### **5. Validation & Next Steps**
#### **A. Verification Methods**
1. **Grid Overlay Test**
   - Apply the reconstructed grid to a new template and check alignment with legacy examples.
2. **Baseline Grid Check**
   - Use a browser extension (e.g., "Grid Inspector") to verify text aligns to the baseline.
3. **Responsive Audit**
   - Test breakpoints on devices/simulators to confirm column behavior.

#### **B. Tradeoffs Named**
- **Preserved:**
  - Column count and gutter width (maintains visual rhythm).
  - Typography scale (preserves hierarchy).
- **Sacrificed:**
  - Fixed margins (replaced with fluid `clamp()` for responsiveness).
  - Print-specific constraints (e.g., bleed zones, CMYK color).

#### **C. Next Steps**
1. **Generate a CSS/SCSS Template**
   - Output a ready-to-use stylesheet with the reconstructed grid, typography, and spacing.
2. **Create a Figma/Adobe XD Grid Template**
   - Translate the system into a design tool for team alignment.
3. **Document Exceptions**
   - Note where modern standards (e.g., accessibility, fluid typography) override legacy specs.

---

### **Example Output Artifact**
#### **Reconstructed Grid CSS**
```css
/* Modern 12-column grid with 8px baseline */
:root {
  --grid-columns: 12;
  --gutter-width: 1.25rem; /* 20px */
  --margin-width: clamp(1.5rem, 5vw, 2.5rem); /* 24px–40px */
  --max-width: 80rem; /* 1280px */
}

.grid {
  display: grid;
  grid-template-columns: repeat(var(--grid-columns), 1fr);
  gap: var(--gutter-width);
  margin: 0 var(--margin-width);
  max-width: var(--max-width);
}

/* Typography */
h1 { font-size: 3rem; line-height: 1.2; }
p { font-size: 1rem; line-height: 1.5; }

/* Spacing */
.container { padding: 1.5rem; }
```

#### **Figma Grid Template Specs**
- **Columns:** 12
- **Gutters:** 20px
- **Margins:** 40px (fluid)
- **Baseline:** 8px
- **Breakpoints:**
  - Mobile: 4 columns
  - Tablet: 8 columns
  - Desktop: 12 columns

---

### **Key Decisions (Contract Index)**
| **Decision**               | **Value**                                  | **Rationale**                                  |
|----------------------------|-------------------------------------------|-----------------------------------------------|
| `preserved_elements`       | Column count, gutter width, typography    | Maintains visual consistency with legacy.    |
| `inference_boundary`       | Fluid margins, responsive breakpoints     | Adapts to modern viewport standards.         |
| `reconstruction_order`     | Grid → Typography → Spacing → Breakpoints | Logical dependency chain.                    |
| `verification_method`      | Grid overlay test + responsive audit      | Ensures alignment and functionality.         |