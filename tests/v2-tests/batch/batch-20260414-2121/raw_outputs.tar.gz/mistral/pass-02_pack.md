Here’s a **component spec** for the **Split Button** that meets your requirements. The spec follows the `component_spec` contract, covering boundary, states, accessibility, and implementation constraints.

---

# **Split Button – Component Spec**
**Component ID**: `split-button`
**Purpose**: A composite button with a primary action and a dropdown for secondary actions, supporting keyboard, touch, disabled, and loading states.

---

## **1. Component Boundary**
- **Primary action**: Triggered by the left/main button segment (e.g., "Save").
- **Dropdown trigger**: Right segment (chevron) opens a menu of secondary actions (e.g., "Save as draft", "Save and close").
- **Menu**: A floating popover anchored to the dropdown trigger, with keyboard-navigable items.
- **Scope**: Does *not* include form submission logic, API calls, or async state management (handled by parent).

---

## **2. States**
### **2.1. Base States**
| State               | Visual Cues                                                                 | Behavior                                                                                     |
|---------------------|-----------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|
| **Default**         | Primary button: filled; dropdown: outlined with chevron.                   | Primary button triggers `onPrimaryAction`. Dropdown opens menu on click/tap.               |
| **Hover**           | Primary button: background darkens; dropdown: background lightens.         | Visual feedback only.                                                                       |
| **Active**          | Primary button: pressed down; dropdown: pressed down.                       | Visual feedback only.                                                                       |
| **Focus**           | Primary button: focus ring; dropdown: focus ring.                           | Keyboard navigation support (see [Accessibility](#4-accessibility)).                        |
| **Disabled**        | Both segments: grayed out, no pointer events.                               | Prevents all interactions.                                                                  |
| **Loading**         | Primary button: spinner replaces text; dropdown: disabled.                  | Primary action is blocked; dropdown remains closed.                                         |

### **2.2. Menu States**
| State               | Visual Cues                                                                 | Behavior                                                                                     |
|---------------------|-----------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|
| **Closed**          | Menu hidden.                                                                | Default state.                                                                              |
| **Open**            | Menu visible, anchored to dropdown trigger.                                 | Keyboard navigation enabled (see [Accessibility](#4-accessibility)).                        |
| **Item Hover**      | Menu item: background highlight.                                            | Visual feedback only.                                                                       |
| **Item Focus**      | Menu item: focus ring.                                                      | Keyboard navigation support.                                                                |

---

## **3. Accessibility Behavior**
### **3.1. Keyboard Support**
| Key                 | Action                                                                                     |
|---------------------|--------------------------------------------------------------------------------------------|
| **Tab**             | Moves focus to the split button (primary button first, then dropdown).                     |
| **Space/Enter**     | Triggers the focused segment (primary action or opens dropdown).                           |
| **↓ (Down Arrow)**  | Opens dropdown (if closed) and moves focus to first menu item.                             |
| **↑/↓ (Arrow Keys)**| Navigates menu items.                                                                      |
| **Esc**             | Closes dropdown and returns focus to the dropdown trigger.                                 |
| **Tab (in menu)**   | Closes dropdown and moves focus to next focusable element.                                 |

### **3.2. ARIA Attributes**
| Element             | ARIA Attributes                                                                           |
|---------------------|-------------------------------------------------------------------------------------------|
| **Primary Button**  | `role="button"`, `aria-label="Save"` (or dynamic label).                                  |
| **Dropdown Trigger**| `role="button"`, `aria-haspopup="true"`, `aria-expanded="false"` (toggles on open/close). |
| **Menu**            | `role="menu"`, `aria-labelledby="[dropdown-trigger-id]"`.                                 |
| **Menu Items**      | `role="menuitem"`, `aria-disabled="true"` (if disabled).                                   |

### **3.3. Touch Targets**
- **Minimum size**: 48×48px for both segments (WCAG 2.5.5).
- **Spacing**: 2px gap between segments to prevent accidental taps.
- **Long press**: Opens dropdown (optional, but recommended for mobile).

---

## **4. Implementation Boundary**
### **4.1. Props**
| Prop                | Type                     | Required | Description                                                                                     |
|---------------------|--------------------------|----------|-------------------------------------------------------------------------------------------------|
| `primaryAction`     | `{ label: string, onClick: () => void }` | Yes      | Primary action configuration.                                                                  |
| `secondaryActions`  | `Array<{ label: string, onClick: () => void, disabled?: boolean }>` | Yes      | Secondary actions in the dropdown.                                                             |
| `disabled`          | `boolean`                | No       | Disables both segments.                                                                         |
| `loading`           | `boolean`                | No       | Shows loading state on primary button.                                                          |
| `size`              | `"small" \| "medium" \| "large"` | No       | Default: `"medium"`.                                                                            |
| `ariaLabel`         | `string`                 | No       | Overrides default ARIA labels (e.g., for i18n).                                                |

### **4.2. Events**
| Event               | Payload                     | Description                                                                                     |
|---------------------|-----------------------------|-------------------------------------------------------------------------------------------------|
| `onPrimaryAction`   | None                        | Fired when primary button is clicked.                                                          |
| `onSecondaryAction` | `{ action: string }`        | Fired when a secondary action is selected.                                                     |
| `onMenuOpen`        | None                        | Fired when dropdown opens.                                                                     |
| `onMenuClose`       | None                        | Fired when dropdown closes.                                                                    |

### **4.3. Styling Tokens**
| Token               | Purpose                                                                                     |
|---------------------|---------------------------------------------------------------------------------------------|
| `--split-button-bg` | Background color (primary button).                                                          |
| `--split-button-text-color` | Text color (primary button).                                                               |
| `--split-button-border` | Border color (dropdown segment).                                                            |
| `--split-button-hover-bg` | Hover background (both segments).                                                           |
| `--split-button-disabled-opacity` | Opacity for disabled state.                                                                 |
| `--split-button-loading-spinner-color` | Color of loading spinner.                                                                   |

---

## **5. Mobile-Specific Considerations**
- **Viewport Adaptation**:
  - On narrow screens (< 360px), stack segments vertically (primary button above dropdown).
  - Ensure menu items are scrollable if they exceed viewport height.
- **Touch Feedback**:
  - Add a subtle "ripple" effect on tap (optional but recommended).
  - Prevent accidental taps by requiring a minimum drag distance (2px) to open the dropdown.

---

## **6. Validation Rules**
- **Hard Rules**:
  - Primary action must always be visible and triggerable.
  - Dropdown must close on `Esc` or outside click.
  - Disabled state must block all interactions.
  - Loading state must disable the primary button.
- **Semantic Rules**:
  - Menu items must have unique, descriptive labels.
  - Keyboard navigation must follow a logical order (top-to-bottom).
- **Evidence Classes**:
  - WCAG 2.1 AA compliance (contrast, focus states, touch targets).
  - Mobile touch target size (48×48px).

---

## **7. Tradeoffs**
- **Preserved**:
  - Compact footprint (single button with dropdown).
  - Clear primary/secondary action hierarchy.
  - Full keyboard and touch support.
- **Sacrificed**:
  - Slightly higher cognitive load than a single button (users must learn the split interaction).
  - Mobile adaptation requires additional viewport logic.

---

## **8. Example Usage**
```tsx
<SplitButton
  primaryAction={{ label: "Save", onClick: handleSave }}
  secondaryActions={[
    { label: "Save as draft", onClick: handleSaveDraft },
    { label: "Save and close", onClick: handleSaveAndClose },
  ]}
  disabled={isSaving}
  loading={isLoading}
/>
```

---

## **9. Next Steps**
1. **Implementation**: Build the component with the above props/states.
2. **Testing**:
   - Keyboard navigation (Tab, Space, Enter, Esc).
   - Touch targets (48×48px minimum).
   - Disabled/loading states.
3. **Documentation**: Add usage examples and accessibility notes.