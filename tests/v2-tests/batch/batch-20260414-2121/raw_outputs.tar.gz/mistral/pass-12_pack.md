Here’s a **type system recommendation** for your fintech product that balances **modern trustworthiness**, **hierarchy clarity**, **tabular data readability**, and **cross-platform consistency** (marketing site, web app dashboard, mobile).

---

### **Type System: "Fintech Trust Stack"**
**Core Goals**:
1. **Trustworthy**: Clean, professional, and authoritative without feeling cold.
2. **Hierarchy**: Clear scale for headings, body, and data tables.
3. **Tabular Data**: Optimized for dense financial tables (e.g., transactions, statements).
4. **Cross-Platform**: Works on marketing sites (large screens), dashboards (dense data), and mobile (small screens).
5. **Modern**: Contemporary but not trendy; avoids gimmicks.

---

### **1. Primary Typeface: "Inter" (Variable)**
**Why Inter?**
- **Designed for UI**: Built for screens, with excellent legibility at small sizes.
- **Variable Font**: Supports `wght` (weights) and `opsz` (optical sizing) for responsive hierarchy.
- **Trustworthy**: Neutral and professional, but warmer than Helvetica or Arial.
- **Tabular Data**: Numeric characters are monospaced (e.g., `tnum` feature) for alignment in tables.
- **Open-Source**: Free for commercial use (MIT license).

**Weights & Usage**:
| Weight       | Use Case                          | Example                     |
|--------------|-----------------------------------|-----------------------------|
| **400**      | Body text, captions, tooltips     | Dashboard body, marketing paragraphs |
| **500**      | Subheadings, buttons, labels      | Section titles, form labels |
| **600**      | Primary headings (H2, H3)         | Marketing headlines, dashboard sections |
| **700**      | Hero headings (H1)                | Marketing landing pages     |
| **300**      | Secondary/tertiary text           | Disclaimers, footnotes      |

**Optical Sizing (`opsz`)**:
- Use `opsz=14` for body text (optimized for small screens).
- Use `opsz=48` for large headings (optimized for marketing hero sections).

**Tabular Numbers (`tnum`)**:
- Enable `tnum` for all financial data (e.g., transaction amounts, balances) to ensure alignment in tables.

---

### **2. Secondary Typeface: "IBM Plex Mono" (Monospace)**
**Why IBM Plex Mono?**
- **Trustworthy Monospace**: Designed for code and data, but feels more human than Courier.
- **Fintech Aesthetic**: Used by banks (e.g., Stripe, Revolut) for a "tech-forward" but professional look.
- **Tabular Data**: Perfect for aligning numbers in tables, logs, or transaction histories.

**Usage**:
- **Financial Tables**: Transaction amounts, account numbers, timestamps.
- **Code/Logs**: API responses, error messages, or technical details.
- **Input Fields**: For numeric input (e.g., amounts, PINs).

**Weights**:
- **400**: Default for data tables.
- **500**: For emphasis in tables (e.g., negative balances).

---

### **3. Fallback Stack**
**Web/Mobile**:
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
```
**Monospace**:
```css
font-family: 'IBM Plex Mono', 'SF Mono', 'Menlo', monospace;
```

---

### **4. Scale & Spacing**
#### **Marketing Site (Large Screens)**
| Element          | Font Size (rem) | Line Height | Weight | Letter Spacing |
|------------------|-----------------|-------------|--------|----------------|
| H1 (Hero)        | 3.5–4.5         | 1.1         | 700    | -0.02em        |
| H2               | 2.5–3.0         | 1.2         | 600    | -0.01em        |
| H3               | 1.75–2.0        | 1.3         | 600    | 0              |
| Body             | 1.0–1.125       | 1.5         | 400    | 0              |
| Captions         | 0.875           | 1.4         | 300    | 0.01em         |

#### **Dashboard (Dense Data)**
| Element          | Font Size (rem) | Line Height | Weight | Letter Spacing |
|------------------|-----------------|-------------|--------|----------------|
| H1               | 1.75–2.0        | 1.2         | 600    | 0              |
| H2               | 1.5             | 1.3         | 600    | 0              |
| H3               | 1.25            | 1.4         | 500    | 0              |
| Body             | 0.875–1.0       | 1.5         | 400    | 0              |
| Data Tables      | 0.875           | 1.4         | 400    | 0 (tnum)       |
| Captions         | 0.75            | 1.3         | 300    | 0.01em         |

#### **Mobile (Small Screens)**
| Element          | Font Size (rem) | Line Height | Weight | Letter Spacing |
|------------------|-----------------|-------------|--------|----------------|
| H1               | 2.0–2.5         | 1.2         | 600    | 0              |
| H2               | 1.5–1.75        | 1.3         | 600    | 0              |
| Body             | 1.0             | 1.5         | 400    | 0              |
| Data Tables      | 0.875           | 1.4         | 400    | 0 (tnum)       |

---

### **5. Color & Contrast**
- **Primary Text**: `#1A1A1A` (near-black for trustworthiness).
- **Secondary Text**: `#555555` (for captions, disclaimers).
- **Data Tables**:
  - Positive values: `#2E7D32` (green).
  - Negative values: `#C62828` (red).
  - Neutral: `#1A1A1A`.
- **WCAG Compliance**: Ensure all text meets **AA contrast** (4.5:1 for body, 3:1 for large text).

---

### **6. Tabular Data Optimization**
- **Alignment**:
  - Right-align numbers (e.g., amounts, balances).
  - Left-align text (e.g., transaction descriptions).
- **Spacing**:
  - Use `padding: 0.5rem 0.75rem` for table cells.
  - Add subtle zebra striping (`#F9F9F9` background) for readability.
- **Typography**:
  - Enable `tnum` (tabular numbers) in Inter for alignment.
  - Use `IBM Plex Mono` for numeric-heavy tables (e.g., transaction IDs).

---

### **7. Implementation Notes**
#### **Web (CSS)**
```css
/* Base typography */
:root {
  --font-primary: 'Inter', sans-serif;
  --font-mono: 'IBM Plex Mono', monospace;
  --text-primary: #1A1A1A;
  --text-secondary: #555555;
}

/* Enable tabular numbers for financial data */
.financial-data {
  font-variant-numeric: tabular-nums;
}

/* Responsive typography */
@media (max-width: 768px) {
  h1 { font-size: 2rem; }
  body { font-size: 1rem; }
}
```

#### **Mobile (React Native)**
```jsx
// Use `react-native-svg` for custom fonts
<Text style={{ fontFamily: 'Inter_400Regular', fontSize: 16 }}>
  Your balance: $1,234.56
</Text>
<Text style={{ fontFamily: 'IBMPlexMono_400Regular', fontSize: 14 }}>
  Transaction ID: 1234567890
</Text>
```

#### **Figma/Design Tokens**
- Use **Inter Variable** (download from [rsms.me/inter](https://rsms.me/inter/)).
- Set up **text styles** for:
  - `Heading/H1` (700, 3.5rem).
  - `Heading/H2` (600, 2.5rem).
  - `Body/Regular` (400, 1rem).
  - `Data/Table` (400, 0.875rem, `tnum` enabled).

---

### **8. Why This Works for Fintech**
| Requirement               | How This System Meets It                          |
|---------------------------|---------------------------------------------------|
| **Trustworthy**           | Inter’s neutrality + IBM Plex Mono’s "tech" feel. |
| **Hierarchy**             | Variable weights + optical sizing (`opsz`).       |
| **Tabular Data**          | `tnum` in Inter + IBM Plex Mono for alignment.    |
| **Cross-Platform**        | Responsive scale + fallback stack.                |
| **Modern**                | Clean, contemporary, but not trendy.              |

---

### **9. Alternatives Considered**
| Typeface          | Pros                          | Cons                          |
|-------------------|-------------------------------|-------------------------------|
| **Roboto**        | Free, widely available.       | Less refined for UI/data.     |
| **San Francisco** | Apple’s system font.          | Limited to Apple ecosystem.   |
| **Helvetica**     | Classic, neutral.             | Overused, cold, no `tnum`.    |
| **GT Walsheim**   | Modern, geometric.            | Expensive, less tabular support. |
| **Satoshi**       | Clean, modern.                | No variable font (yet).       |

---

### **10. Next Steps**
1. **Test in Context**:
   - Apply this system to a **marketing landing page**, **dashboard table**, and **mobile transaction screen**.
   - Check for **readability** (especially small text on mobile) and **trustworthiness** (does it feel "bank-like"?).
2. **Refine Weights**:
   - Adjust `wght` values if headings feel too heavy/light.
3. **Optimize for Dark Mode**:
   - Use `#E0E0E0` for light text on dark backgrounds.
4. **Localization**:
   - Test with non-Latin scripts (e.g., Arabic, Chinese) if needed.

---

### **Example Outputs**
#### **Marketing Site (Hero Section)**
![Marketing Hero Example](https://via.placeholder.com/800x400/FFFFFF/1A1A1A?text=H1:+Secure+Banking+for+Everyone+(Inter+700,+4rem)+|+Body:+Your+trusted+partner+in+finance+(Inter+400,+1.125rem))

#### **Dashboard (Transaction Table)**
| Date       | Description          | Amount       |
|------------|----------------------|--------------|
| 2023-10-01 | Coffee Shop          | **$5.20**    |
| 2023-10-02 | Salary Deposit       | **+$3,200.00** |
| 2023-10-03 | Utility Bill         | **-$85.50**  |

*(Inter 400, `tnum` enabled, right-aligned amounts)*

#### **Mobile (Account Summary)**
![Mobile Example](https://via.placeholder.com/300x600/FFFFFF/1A1A1A?text=H2:+Your+Accounts+(Inter+600,+1.5rem)+|+Body:+Checking:+$1,234.56+(Inter+400,+1rem))

---

### **Tradeoffs**
| Preserved                          | Sacrificed                          |
|------------------------------------|-------------------------------------|
| Trustworthiness and professionalism | Trendy or experimental aesthetics.  |
| Tabular data readability           | Some personality (e.g., quirky fonts). |
| Cross-platform consistency         | Perfect pixel-perfection on every OS. |