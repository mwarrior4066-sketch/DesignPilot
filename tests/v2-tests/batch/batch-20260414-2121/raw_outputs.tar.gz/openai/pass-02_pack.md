## Split Button Component Spec

### Component Boundary

**Component Name:** SplitButton

**Purpose:**  
Combines a primary action button (“Save”) with an attached secondary dropdown trigger. The primary button executes the main action, while the dropdown toggle reveals a menu of alternate save options (“Save as draft”, “Save and close”).

**Component Structure:**  
- Main button (Save) — primary action  
- Dropdown trigger — chevron or caret (adjoins right side)  
- Dropdown menu (hidden by default) — contains secondary actions

**State Coverage**

- **Default:** Primary button and dropdown are enabled.
- **Disabled:** Entire split button and dropdown are non-interactive (greyed out, non-focusable).
- **Loading:** Primary action shows loading indicator, disables interaction until complete; dropdown trigger may remain enabled or be disabled based on implementation preference (see tradeoffs below).
- **Open:** Dropdown trigger and menu are in “open” state; menu is visible and navigable.

**Variants:**
- Icon-only mode (optional, if needed for dense UIs)
- Full width (if used in mobile flows)
- Custom menu item rendering (if alternative action text/logic needed)
- Right-to-left support for languages/regions as needed

---

### Accessibility & Keyboard Behavior

#### Focus Order & Keyboard Navigation

- **Tab**: Moves focus from primary button to split (dropdown) trigger to next element.
- **Enter/Space (focus on primary button)**: Executes Save (primary action), unless disabled or loading.
- **Enter/Space (focus on dropdown trigger)**: Opens dropdown menu (shows alternate actions).
- **Down Arrow (focus on dropdown trigger):** Opens menu and places focus on first menu item.
- **Down/Up Arrows (inside menu):** Moves focus between menu items.
- **Escape:** Closes dropdown menu and returns focus to dropdown trigger.
- **Enter/Space (focus on menu item):** Selects alternate action.

#### Accessible Structure

- **Button group**: Ensure each sub-control is a <button> element for native behavior.
- **Dropdown menu**: Use ARIA `role="menu"` on menu container; each secondary action uses `role="menuitem"`.
- **Dropdown trigger**: Use `aria-haspopup="menu"` and `aria-expanded` for open state.  
- **Disabled state**: Use both native `disabled` attribute **and** `aria-disabled="true"` for all controls.

#### Screen Reader Announcements

- Announce primary as “Save, button.”
- Announce split trigger as “Show more actions, button, opens menu.”
- On menu open: “Menu, 2 items.”
- On menu item focus: “Save as draft, menu item,” etc.

#### Touch Targets (Mobile)

- Minimum target size: **44x44 px** for both main button and split/chevron trigger
- Padding and spacing: Ensure 8–16 px separation between main button and split trigger; maintain safe tapable zone
- Hit area may extend beyond the visible chevron for usability

#### Visual States

- **Loading**:  
  - Main button displays spinner or progress alongside “Save” text
  - Main button and split trigger remain focusable but are blocked from submitting additional actions until complete (to prevent duplicate submissions)
- **Disabled**:  
  - Reduces contrast, prevents focus, blocks pointer/touch events

---

### Implementation Boundary

- The SplitButton is self-contained: manages its own open/close menu state, focus handling, and keyboard/touch interactions.
- Does not own data mutation logic: parent component wires actions to onClick handlers.
- Manages loading and disabled states via props or bound context.
- Must be accessible in both light & dark themes, and respect high-contrast mode.
- Must not assume any global focus traps or overlays: handles its own menu positioning and accessibility.
- Responsiveness: Stacks vertically or reflows as needed for mobile breakpoints.

---

### Tradeoff Highlight

- **Dropdown Trigger Disabled during Loading:**  
  - _Option A_: Disable only the primary action button during loading; dropdown remains openable (but any alternate actions are also disabled to prevent parallel submissions).
    - _Preserves discoverability but may cause confusion if alternate actions are not available in this state._
  - _Option B_: Entire SplitButton disables or blocks interaction during loading.
    - _Simpler, prevents any action, avoids parallel triggers._
    - **RECOMMENDED**: Disable all interaction during loading to ensure a clean transactional boundary.

- **Menu Positioning:**  
  - For mobile, prefer full-width or bottom-sheet dropdown for easier tap targets, as classic menu drop aligns can be hard to reach on small screens.

---

### Output Contract Decisions

- **component_boundary:** SplitButton owns the button, dropdown, and local menu; does not dictate what parent does with actions.
- **state_coverage:** All states specified: default, disabled, loading, open.
- **accessibility_behavior:** Compliant with keyboard, screen reader, ARIA, and mobile touch requirements.
- **implementation_boundary:** Does not own mutation/business logic; only local UI/menu state and event handling.

---

**References/Resources:**  
- [WAI-ARIA Authoring Practices – Button Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/button/)
- [WAI-ARIA Authoring Practices – Menu Button Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/menubutton/)

---

**Summary:**  
This split button exhibits accessibility, responsive, and interaction best practices. By owning its internal states, keyboard, and screen-reader logic, and exposing a clear, disabled boundary during loading, it ensures user and implementation safety across platforms.

---

**What is preserved:**  
- Usability and accessibility for all input types.
- Clear transactional safety during mutating actions.

**What is sacrificed:**  
- In loading states, no alternate actions may be triggered (favoring system safety over continuous secondary interaction).  
- Classic desktop menu styling may give way to mobile-friendly patterns on small screens, at the cost of strict visual consistency.

---

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: SplitButton owns button, dropdown, and menu; event handlers supplied by parent",
    "state_coverage: default, disabled, loading, open are covered",
    "accessibility_behavior: full keyboard, touch, ARIA, and focus compliance",
    "implementation_boundary: only UI/menu state, not business logic"
  ],
  "evidence_classes_cited": ["component_boundary", "state_coverage", "accessibility_behavior", "touch_target_threshold", "disabled-loading-ui"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]
