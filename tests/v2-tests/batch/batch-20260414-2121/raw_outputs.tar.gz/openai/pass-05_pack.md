To make your InDesign-exported, two-column PDF report accessible for screen readers and usable for accessible export, you’ll need to address several specific issues:

---

## 1. **Set Up Proper Tag Structure**
- **Open the PDF in Adobe Acrobat Pro (or equivalent PDF remediator).**
- **Use the Accessibility Checker** (Tools > Accessibility > Full Check).
- If tags are missing entirely, use "Add Tags to Document" first, but be aware this is only a starting point and almost always requires manual repair.
- **Navigate to the Tags Panel** (View > Show/Hide > Navigation Panes > Tags) and verify that:  
  - Headings (`<H1>`, `<H2>`, etc.) exist in logical order.
  - Paragraphs use `<P>`.
  - Lists and tables use `<L>`, `<LI>`, `<Table>`, etc.

---

## 2. **Fix Reading Order for Columns and Interruptions**
- **The default tag order may follow the visual layout (left column, right column) rather than logical reading order.**
- **Manually adjust the reading order in Acrobat’s Reading Order tool (Tools > Accessibility > Reading Order):**
  - Use the "Order" panel (View > Show/Hide > Navigation Panes > Order).
  - Click and drag to resequence items so that the text flows correctly: left-to-right, top-to-bottom, skipping decorative content, and ensuring pull quotes and sidebars appear in the correct place (not as random interrupts).
  - For pull quotes: Tag these as separate `<Artifact>` (see below) or place in reading order only if critical to understanding.

---

## 3. **Tag Decorative Images as Artifacts**
- **Decorative images should NOT be tagged as informative.**
- In the Reading Order tool, select each decorative image.
- Mark as "Background/Artifact" or right-click in the Tags panel and set as Artifact.
- This ensures screen readers will skip them.

---

## 4. **Properly Tag Pull Quotes**
- **If pull quotes are purely decorative or redundant:**  
  - Mark as Artifact, so they are skipped by assistive technology.
- **If they provide crucial content:**  
  - Tag as `<BlockQuote>` or `<P>`, and position logically in the reading order at the best interpretive spot (often before/after the referenced paragraph), not wherever the layout placed them.

---

## 5. **Repair Table of Contents (TOC) Links**
- **Broken TOC links reduce both navigation and accessibility.**
- In Acrobat, use the "Edit PDF" tool to select each TOC entry.
- Right-click and select "Create Link" (Link > Add/Edit Web or Document Link), then set the destination to the correct heading or page.
- In the Tags panel, ensure each link is inside an `<Link>` tag, nested within a list or paragraph as appropriate.
- Test all links with keyboard navigation (Tab, Enter).

---

## 6. **Verify with Screen Reader and Accessibility Checker**
- Use NVDA or JAWS (Windows) or VoiceOver (Mac) to test the PDF for logical reading order and navigation.
- Re-run Acrobat’s Accessibility Checker. Address any flagged issues:
  - Missing alt text (should not be needed if artifacts are set correctly for decorative images).
  - Heading levels and logical structure.
  - List and table tagging.

---

## 7. **Export Recommendations for Future InDesign Exports**
- In future, in InDesign’s export settings, use "Create Tagged PDF," properly structure your document with styles (Headings, Body, TOC), and set images as decorative or informative in Object Export Options.
- But always expect to check and remediate after export, because no export is perfect for complex layouts.

---

### **Tradeoff & Rationale**

- **You preserve:** The report’s visual design and column flow for sighted users.
- **You sacrifice:** Some absolute spatial fidelity for a reading order that makes sense for non-visual readers. Pull quotes may not always land where they appear visually, but will never interrupt context nonsensically.
- **Why:** Because PDF semantics and accessibility tools prioritize logical information flow and navigability over visual fidelity for assistive technologies.

---

## **Summary:**
1. **Tag structure:** Ensure tags are present and logical.
2. **Reading order:** Manually sequence content for columns and quotes.
3. **Decorative images:** Tag as Artifact to hide from screen readers.
4. **TOC links:** Repair so keyboard and AT users can navigate.
5. **Test:** Always check with a screen reader and accessibility checker.

By following this process, your PDF report will export with logical, screen-reader friendly order, skip decorative and pull-quote noise, and provide working navigation for all users.

If you want step-by-step or tool-specific instructions for a part of this process, let me know.