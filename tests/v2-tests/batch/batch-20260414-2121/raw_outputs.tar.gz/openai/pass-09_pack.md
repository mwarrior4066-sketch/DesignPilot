## Color System Spec: Healthcare SaaS Dashboard

**Contract checkpoint:**  
- Semantic roles for status (normal, warning, critical)  
- Categorical data-vis palette (≥5 roles)  
- WCAG AA contrast for all text/background  
- Dark mode support  
- Roles and contrast boundaries named explicitly

---

### 1. **Semantic Color Roles**

| Role         | Usage                                                      | Light Mode            | Dark Mode             | Contrast (min.) |
|--------------|------------------------------------------------------------|-----------------------|-----------------------|-----------------|
| Background   | Main dashboard surface                                     | #FFFFFF               | #181C21               | -               |
| Card/Panel   | Widget/Panel containers                                    | #F5F7FA               | #23272E               | -               |
| Primary Text | Default text (headings, labels)                            | #151A1D               | #F9FBFC               | 8.7:1           |
| Secondary Text | Subtext, labels                                          | #5B6B77               | #B7C3CC               | 4.5:1           |
| Divider      | Borders, separators                                        | #E2E8EF               | #343942               | -               |
| Interactive  | Buttons, links, actionable icons                           | #1565C0               | #4DA3FF               | 4.5:1           |
| Normal       | Success/steady state indicators (badges, icons, graphs)    | #03773A               | #20C77D               | 4.5:1           |
| Warning      | Caution, needs attention                                   | #E5B100               | #FFD94D               | 4.8:1           |
| Critical     | Errors, blocking issues                                    | #C6342A               | #FF6B5B               | 5.2:1           |
| Disabled     | Disabled state (text, input bg)                            | #C6CDD2               | #59616A               | -               |

*Contrast checks assume pairing with background or card.*

---

### 2. **Data Visualization Palette (Categorical, 5+ colors)**

All colors are distinguishable against both light and dark backgrounds and each other (colorblind-safe as much as practical):

| Data Color | Light Mode | Dark Mode |
|------------|------------|-----------|
| Data 1     | #2D82BF    | #63AFFF   |
| Data 2     | #35A7FF    | #6BE6E6   |
| Data 3     | #F96167    | #FF9B8A   |
| Data 4     | #FFBC42    | #FFE066   |
| Data 5     | #52B788    | #24D294   |
| Data 6     | #5E548E    | #BBB2E3   |

- All categorical colors offer ≥3:1 contrast against dashboard backgrounds; do **not** use for text, only for graphical elements (lines, bars, fills).
- For labels or direct text on colored swatches, use **primary text** color for darks, **background** for lights.

---

### 3. **Dark Mode Conversion Rules**

- Backgrounds shift from white and pale neutrals to deep blue-gray or near-black.
- All role tokens have direct dark mode pairs.
- Status roles "invert" chroma and tweak brightness (not simply invert colors) to maintain semantic identity and contrast.
- Data-vis colors elevate chroma and brightness for pop on dark, with perceptual uniformity (test with simulated low-vision filters).

---

### 4. **Contrast & Accessibility Policy**

- All semantic **text/background** and **status indicator** pairs meet or exceed **WCAG AA**:  
  - **Normal text:** 4.5:1+ contrast  
  - **Large/bold text at status colors:** 3:1+ minimum
- Do not use red/green status without icon or label—color is a cue, not the sole signifier (“critical” includes icon and accessible label).
- Do not place text on data chart segments unless you have 4.5:1 contrast or use an overlay label style.
- Links and interactive elements always meet 4.5:1 against background and card.

**Reference:**  
[WCAG 2.1 AA contrast checker](https://webaim.org/resources/contrastchecker/)

---

### 5. **Example Token Names & Usage Suggestions**

```css
:root {
  --color-bg: #FFFFFF;
  --color-bg-dark: #181C21;
  --color-card: #F5F7FA;
  --color-card-dark: #23272E;
  --color-text-primary: #151A1D;
  --color-text-primary-dark: #F9FBFC;

  --color-status-normal: #03773A;
  --color-status-normal-dark: #20C77D;
  --color-status-warning: #E5B100;
  --color-status-warning-dark: #FFD94D;
  --color-status-critical: #C6342A;
  --color-status-critical-dark: #FF6B5B;

  --color-data-1: #2D82BF;
  --color-data-1-dark: #63AFFF;
  --color-data-2: #35A7FF;
  --color-data-2-dark: #6BE6E6;
  --color-data-3: #F96167;
  --color-data-3-dark: #FF9B8A;
  --color-data-4: #FFBC42;
  --color-data-4-dark: #FFE066;
  --color-data-5: #52B788;
  --color-data-5-dark: #24D294;
}
```

---

### 6. **Migration & Maintenance Notes**

- **Dark mode**: deploy using CSS variables or a design token system, switch at root/parent container.
- **Token contract**: use semantic names, not color literals, so that contrast or hue can be tuned at system level.
- **Testing**: use automated and manual tools to check contrast in both modes, and check data-vis with colorblind sim filters.
- **Extendibility**: for additional data categories, add more data* roles ensuring unique hue and ≥3:1 contrast.

---

**Tradeoff**:  
Data visualization colors are chosen for distinction and aesthetic pop, which means some may be less high-contrast for thin lines on extremely pale/dark backgrounds. For all text, semantic tokens are strictly WCAG-compliant. Where vibrancy and accessibility are in tension, status clarity and text legibility are preserved; data-vis color variety is the adjustable layer.

---

If you need a direct handoff in Figma tokens, CSS, or want in-app swatches, request the preferred format!