## Poster Critique for Design Conference

### Structural Failure
The current hierarchy leads with a prominent decorative title before establishing context for the event. This means viewers see an attention-grabbing headline, but may not immediately know what the poster represents. Presenting a title before essential context can cause audience confusion—particularly for new or out-of-context viewers—because it assumes prior knowledge. In public environments, where posters compete for quick attention, functional clarity should precede stylization.

### Visual Hierarchy and Legibility
- **Title at the Top, Decorative Typeface**: While this draws the eye, a highly stylized title can sacrifice readability, especially from a distance. Without contextual framing (what, when, where, for whom), a decorative heading risks becoming empty emphasis.
- **Small Gray Date in Corner**: Time-sensitive information, like the event date, is visually minimized both by position (bottom corner) and color (low-contrast gray). Important details risk being overlooked, especially against a complex background photo.
- **Full-Bleed City Skyline Photo**: This provides a sense of place and atmosphere, but strong visual content can compete with text, potentially lowering legibility if not handled with overlays or contrast zones.
- **White Conference Logo, Centered**: Overlaying a white logo in the center may create tension between focal points (logo vs. title). If the logo lacks the name or functional description of the event, it may further confuse uninitiated viewers.

### Accessibility Concerns
- Decorative typefaces and low-contrast information (small gray text) both violate best practices for legibility and accessibility. The date, likely critical for action, fails WCAG AA minimum contrast when placed in gray over a potentially variable photo background.
- The city skyline can create busy or low-contrast zones, further reducing clarity for key details.
- Information that matters for attendance (what the event is, who should care, when and where) is visually de-prioritized.

### Intervention Order
To address these, intervene in this priority:
1. **Contextual Labeling**: Add a subtitle or framing line (e.g., "International Design Conference 2024") directly above or below the main title, using clear, accessible typography.
2. **Date & Details Prominence**: Move the date (and, if missing, the location) into the main content area, using larger text and increased contrast (e.g., white or black text on a color-block overlay, depending on background).
3. **Type & Color Contrast Audit**: Reconsider decorative type for the title—if legibility drops at poster-reading distances, switch to a bold but readable face. Audit all poster text for WCAG 2.1 AA contrast minimums, especially those layered over photos.
4. **Background Management**: Add overlays, gradients, or blurs behind text to guarantee readability against the full-bleed skyline, rather than placing light text directly over high-variance images.

### Tradeoff Resolution
- **Preserved**: Visual impact of a large decorative title and dramatic photography; sense of city/place for the event.
- **Sacrificed**: Immediate clarity, actionable context, and accessibility for all viewers.

One downside is the poster looks visually striking, but requires viewers to hunt for critical information, which can lead to missed engagement for the event—particularly from a broader or unfamiliar audience.

### Rationale
This intervention prioritizes legibility and cognitive clarity because a poster's main job is to quickly inform and motivate action. Aesthetics and branding are important, but they do not outweigh the risk of users missing the most basic facts about the event. This requires:
- Raising the prominence and clarity of "what, when, where"
- Auditing type and color for accessibility
- Structuring content so anyone, regardless of prior knowledge, immediately understands what is being promoted

**Because** the poster will reach viewers who may have zero context, the information hierarchy must work at a glance: what is this, when and where, what should I do, and then, only after those questions, does mood and style earn more visual surface.

---

**Summary**:  
Prioritize event context, boost contrast/legibility for key details, and rebalance text over image for accessibility. The current design sacrifices clarity for impact—restore informational order to serve the poster’s real job.

---

**Route**: graphic_critique  
**Hierarchy failure**: message unclear at a glance—title dominates before event context  
**Tradeoff named**: visual drama vs. clarity/actionability  
**Verification method**: audit at viewing distance; check contrast ratios; run comprehension with users not already familiar with the event