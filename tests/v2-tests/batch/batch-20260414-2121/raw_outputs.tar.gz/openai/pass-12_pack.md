A well-chosen type system for a fintech product must balance trust, precision, clarity, and versatility across diverse surfaces—marketing site, web app dashboard, and mobile. Financial products demand exceptional readability for data tables, clear hierarchy, and a feeling of credibility.

## Type System Recommendation

**Primary Typeface:** [Inter](https://rsms.me/inter/)  
- Open-source, widely supported, and robust across digital platforms.
- Designed for digital interfaces, with excellent clarity at small sizes—ideal for dashboards and data-heavy UIs.
- Modern sans-serif appearance that feels approachable yet professional.
- Supports a broad range of weights (100–900), so you can establish strong typographic hierarchy.
- Good numeral design (tabular and proportional options), perfect for financial tables.
- Excellent hinting and variable-font support, maximizing performance on web and mobile.

**Alternate Options:**  
- **Roboto** (ubiquitous, especially on Android, but less distinctive than Inter)
- **IBM Plex Sans** (more “tech” or “enterprise” in feel, also strong on numerals)
- **SF Pro** (if you are targeting Apple ecosystems heavily; proprietary)

### Hierarchy & Role Assignment

- **Headings & Callouts:**  
  Use Inter Medium (500) or SemiBold (600). Headings should be sized for clear scan paths on both web and mobile.
- **Body Text:**  
  Inter Regular (400), 15–16px (web), 16sp (mobile). This maintains readability and a generous x-height.
- **Data Tables & Numeric Content:**  
  Always enable [tabular numerals](https://rsms.me/inter/#features) (font-feature-settings: 'tnum' 1). Use Inter Medium (500) for totals or highlights, Regular (400) for supporting data.
- **Navigation/Menu/Label:**  
  Inter Medium (500) or SemiBold (600), small caps (if available) for navigation and UI controls.

### Implementation Guidance

- **Web & Dashboard:**  
  - Use the variable font for optimal performance.  
  - Set default font-stack as:  
    `font-family: 'Inter var', Inter, system-ui, sans-serif;`
  - Ensure that you specify tabular numerals in CSS where financial data appears:
    ```css
    .fin-data { font-variant-numeric: tabular-nums; }
    ```
- **Mobile:**  
  - Inter is readily available via Google Fonts for Android and supported in iOS projects.  
  - If Inter is unavailable on a device, fall back to system UI fonts (`Roboto`, `SF Pro`).

### Color, Contrast, and Accessibility

- Inter was designed for screen and passes accessibility/readability requirements at WCAG AA/AAA contrast levels. Pair with a color system that guarantees at least 4.5:1 contrast for text.

### Tradeoffs

- **What is preserved:**  
  - Readability and trustworthiness—Inter feels modern without being trendy.  
  - Robust numeral rendering for financial data.  
  - Systemwide coherence; reduces the need for different fonts on marketing and product surfaces.
- **What is sacrificed:**  
  - Less decorative/brand-distinct than some custom or heavily branded typefaces.  
  - For print or highly editorial surfaces, you may need to introduce a serif for long-form reading.

### Adoption Sequence

1. Standardize Inter across all digital products (marketing, dashboard, mobile).
2. Audit all text components (headings, labels, tables, body) for styles/weights.
3. Replace ad-hoc styles with a centralized, token-driven typography system.
4. Test data tables for numeral alignment and ensure tabular numeral features are active everywhere financial data appears.

---

**Summary:**  
Adopt Inter as your primary typeface for all fintech product surfaces. It is a modern, trustworthy, variable sans-serif designed for clarity, excellent for tabular financial data, and offers strong support for typographic hierarchy. Use its full weight range to structure headings, body, and data. Activate tabular numerals for tables, and maintain color contrast for accessibility. This provides a coherent, scalable type system ideal for fintech’s hybrid demands.