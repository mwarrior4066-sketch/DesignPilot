# API Reliability and Security Audit: POST /exports

## Failure semantics and error contract

**Current state:** The endpoint returns HTTP 200 for all responses, including errors. This is a critical contract failure. Clients cannot distinguish success from failure without parsing the response body, which means automated retries, circuit breakers, and monitoring systems are all blind to failures by default.

**What it must do instead:** Every response must carry a semantically correct HTTP status code. Use RFC 9457 (Problem Details for HTTP APIs) as the error envelope. This requires because clients and infrastructure must be able to act on status codes without parsing bodies.

Required status codes:

- `202 Accepted` when the job is accepted and queued (see async section)
- `400 Bad Request` for invalid input
- `401 Unauthorized` for missing or invalid credentials
- `403 Forbidden` when the caller lacks permission for the requested resource
- `404 Not Found` for unknown export job IDs
- `409 Conflict` when a duplicate request is detected via idempotency key
- `429 Too Many Requests` for rate limit or quota exhaustion
- `500 Internal Server Error` for unexpected failures
- `503 Service Unavailable` when the rendering pipeline is at capacity

**Internal enum leakage:** Error responses currently leak internal enum values. This is an information disclosure risk because attackers can use internal state names to probe the system, infer business logic, and map out failure paths. Replace internal labels with stable, public-facing error type URIs. Use the RFC 9457 `type` field as a canonical identifier. Internal codes belong in logs with trace correlation, never in API responses.

Example of what must not appear in responses:
```
{ "error": "EXPORT_JOB_STATE_RENDERING_QUEUE_OVERFLOW" }
```

Example of the correct contract:
```json
{
  "type": "https://api.example.com/problems/export-capacity",
  "title": "Export service is at capacity",
  "status": 503,
  "detail": "The export queue is full. Retry after the indicated period.",
  "trace_id": "a3f2c1d9-...",
  "retry_after": 30
}
```

Every error response carries `trace_id` on all errors so support and observability tooling can correlate without exposing internals.

---

## Authorization and resource protection

**Current state:** The audit request does not describe any authorization checks. This is treated as an open gap: no confirmation that object-level authorization exists.

**The core risk:** POST /exports almost certainly operates on a resource owned by a specific tenant, user, or account. If the endpoint only checks that a caller is authenticated (valid session) but does not verify that the caller is authorized to export that specific resource, this is a BOLA (Broken Object-Level Authorization) vulnerability. An authenticated user from tenant A could trigger or poll exports belonging to tenant B.

**Required controls:**

*Authentication perimeter:* Every request must carry a valid credential. Unauthenticated requests must return `401` before any business logic executes.

*Object-level authorization:* Only the session owner or a caller with explicit delegation may trigger an export for a given resource. The check must be: does this caller have permission to read the source data that would populate this report? If not, `403` before any work begins. Deny by default.

*Scope of the authorization check:* The check must happen before the job is accepted. Do not queue a job and then discover the caller lacks permission mid-render. This wastes compute, makes quota enforcement unreliable, and complicates the async status model.

*Rate limiting per actor:* Exports are expensive. Without per-actor rate limits, a single authenticated caller can exhaust shared rendering capacity, degrading service for all tenants. Apply rate limit + quota controls at the actor level (user or tenant) before job acceptance. Return `429` with a `Retry-After` header when the limit is exceeded.

---

## Idempotency and async lifecycle

**Current state:** The endpoint runs synchronously, blocks for up to 3 minutes, and has no idempotency key. This combination is a reliability failure with no safe recovery path.

**Why synchronous blocking is untenable:** A 3-minute synchronous response means:
- Network timeouts will fire before the response arrives on many clients and proxies
- A dropped connection gives the client no way to know whether the job completed
- Retrying a synchronous request without idempotency protection risks generating duplicate exports
- One request per connection means concurrency is artificially capped
- The caller has no graceful degradation path when the response is slow

You sacrifice low implementation complexity to gain safe retries, timeout resilience, connection independence, and accurate job state.

**Required async model:** Migrate to the `202 Accepted + status URL` pattern. The job lifecycle must have terminal states: `queued -> running -> completed | failed`.

POST /exports accepts the request, validates inputs and authorization immediately, creates a job record, and returns:

```http
HTTP/1.1 202 Accepted
Location: /exports/jobs/job_9f3a2b1c
Retry-After: 10

{
  "job_id": "job_9f3a2b1c",
  "status": "queued",
  "status_url": "/exports/jobs/job_9f3a2b1c",
  "estimated_wait_seconds": 15
}
```

The client polls GET /exports/jobs/{job_id} with a polling interval guided by the `Retry-After` header until the job reaches a terminal state. On completion, the response includes a time-limited download URL. On failure, the response carries an RFC 9457 error body with the reason.

**Idempotency key:** Add an `Idempotency-Key` header requirement. The contract is: if a request arrives with the same `Idempotency-Key` and the job is still running or has completed within a deduplication window, return `409 on duplicate` rather than starting a second job. This means a client can safely retry a request after a dropped connection without risk of generating duplicate exports. The deduplication window should match your maximum expected job duration plus a safety margin.

```http
POST /exports
Idempotency-Key: client-generated-uuid-here
```

The server stores the key alongside the job record. Idempotency contract: same key, same caller, within window = return the existing job, not a new one.

---

## Resilience and observability

**Current state:** No retry-safe contract exists. Combined with the synchronous blocking model, there is no safe failure path for clients or infrastructure.

**Circuit breaker:** The rendering pipeline is a bounded resource. When it fails or degrades, requests should not pile up indefinitely. Apply a circuit breaker at the job acceptance boundary. When the pipeline is unhealthy (error rate exceeds threshold or queue depth exceeds limit), return `503 Service Unavailable` immediately rather than accepting more work into a degraded queue. This is graceful degradation: callers get a fast, actionable signal instead of a multi-minute timeout.

**Exponential backoff with jitter:** Document the expected retry contract for clients. After a `429` or `503`, clients must use exponential backoff with jitter rather than fixed-interval retries. Without jitter, retry storms amplify load spikes after a partial outage. The `Retry-After` header sets the floor; jitter spreads retries across the window.

**Observability requirements:** The async job model creates new observability obligations because job state transitions are now the primary signal of system health.

Instrument:
- Job acceptance rate vs. rejection rate (by reason)
- Queue depth and queue wait time
- Render duration by percentile (p50, p95, p99)
- Job terminal state breakdown (completed vs. failed, failure reasons by category)
- Per-actor quota consumption vs. limit
- `trace_id` carried through every log entry from job creation to terminal state, so any failure in the pipeline can be correlated end to end

Alert thresholds:
- p99 render time exceeds SLA threshold
- Failed job rate exceeds X% over rolling window
- Queue depth exceeds Y jobs (leading indicator before capacity is exhausted)

**Structured logging:** Every log entry for a job must carry `job_id` and `trace_id` as structured fields, not embedded in unstructured strings. This enables filtering, correlation, and automated alerting without log parsing.

---

## Summary of blocking constraints

| Constraint | Severity | Blocking? |
|---|---|---|
| HTTP 200 for all responses | Critical | Yes — monitoring, retries, and circuit breakers are blind |
| Internal enum leakage in errors | High | Yes — information disclosure, BOLA probe surface |
| No object-level authorization confirmed | Critical | Yes — BOLA risk if absent |
| No idempotency key | High | Yes — no safe retry path after connection drop |
| Synchronous 3-minute block | Critical | Yes — timeouts fire before response on most clients |
| No rate limiting per actor | High | Yes — single actor can exhaust shared rendering capacity |
| No retry contract for clients | Medium | No, but client behavior is unpredictable without it |
| No structured observability | Medium | No, but failure diagnosis is severely impaired |

No shipping decisions should be made until the three critical constraints are resolved. The high-severity items are blocking for correctness and safety even if they do not individually cause data loss.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "problem_details_contract: RFC 9457 with type URI, title, status, detail, trace_id",
    "authorization_perimeter: object-level check before job acceptance, deny by default",
    "idempotency_contract: Idempotency-Key header, 409 on duplicate within deduplication window",
    "async_job_model: 202 Accepted + status URL, terminal states queued → running → completed | failed",
    "resilience_strategy: circuit breaker at acceptance boundary, exponential backoff with jitter, Retry-After header"
  ],
  "evidence_classes_cited": [
    "RFC 9457 problem details contract",
    "BOLA authorization pattern",
    "202 async job lifecycle model",
    "idempotency-key header contract",
    "circuit breaker pattern",
    "exponential backoff with jitter",
    "structured observability with trace_id"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is object-level authorization currently implemented, or is only authentication checked?",
    "What is the expected deduplication window for idempotency keys?",
    "Are there existing SLA thresholds for render time that should anchor the observability alert levels?"
  ],
  "turn": 1
}
[/SESSION_STATE]