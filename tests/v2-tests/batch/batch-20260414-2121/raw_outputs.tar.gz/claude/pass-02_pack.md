## Split Button Component Spec

### Component boundary

A split button is a single logical control with two interactive zones: a primary action trigger and a secondary action menu trigger. These zones share visual grouping but have independent focus, state, and keyboard behavior. They are not two separate buttons placed side by side.

---

### Anatomy

```
┌─────────────────────────┬──────┐
│         Save            │  ▾   │
└─────────────────────────┴──────┘
  primary-action zone       menu trigger
```

**Segments:**
- `primary-action` — executes the default action directly
- `menu-trigger` — opens a dropdown containing secondary actions
- `dropdown-menu` — the overlay containing secondary action items
- `menu-item` — individual selectable actions within the dropdown

The visual divider between segments is decorative and must not be a focusable element.

---

### Variants

| Variant | Description |
|---|---|
| `default` | Normal interactive state |
| `disabled` | Both segments non-interactive |
| `primary-disabled` | Primary zone disabled, menu trigger still active |
| `loading` | Primary action in progress; both segments locked |
| `loading-menu` | A secondary action is in progress; both segments locked |
| `destructive` | Reserved for actions like delete — red semantic role, confirmation required before execution |

**Why separate `disabled` from `primary-disabled`:** a user may have already saved a draft and can no longer trigger Save, but secondary actions remain valid. These are meaningfully different states; collapsing them forces either incorrect affordance or hidden workarounds in consuming code.

---

### Sizes

| Size token | Min height | Primary min-width | Menu trigger min-width | Use context |
|---|---|---|---|---|
| `sm` | 32px | — | 32px | Dense tables, toolbars |
| `md` | 40px | — | 40px | Default UI |
| `lg` | 48px | — | 48px | Hero actions, mobile primary flows |

Touch targets must meet **48×48px minimum** for mobile contexts regardless of visual size. Achieve this with padding or an invisible tap area — not by enlarging the visual button. On mobile, `md` maps to `lg` behavior for touch targets.

---

### States

#### Primary action zone

| State | Visual treatment |
|---|---|
| Default | Brand fill, primary label |
| Hover | Lightened or darkened fill per theme |
| Focus-visible | 3px offset outline, brand-adjacent color, never hidden |
| Active/pressed | Depressed fill or scale transform |
| Disabled | 40% opacity, no pointer events, `aria-disabled="true"` |
| Loading | Spinner replaces or precedes label; zone locked |

#### Menu trigger zone

| State | Visual treatment |
|---|---|
| Default | Slightly narrower, same fill family as primary |
| Hover | Independent hover highlight |
| Focus-visible | 3px offset outline on trigger only, not bleeding to primary |
| Active | Depressed |
| Disabled | 40% opacity, `aria-disabled="true"` |
| Open | Pressed/active visual; `aria-expanded="true"` |

#### Loading state details

During `loading`, disable both segments and show a spinner in the primary zone because the underlying data contract is in flight — allowing a second trigger would produce a duplicate operation or race condition. Replace the spinner with a success or error indicator before re-enabling, or restore the default state with a toast if inline state is unavailable.

Do not use `disabled` attribute for loading — use `aria-disabled="true"` plus `pointer-events: none` so assistive technology can still read the button label and loading status rather than skipping the element entirely.

---

### Accessibility behavior

#### ARIA structure

```html
<div role="group" aria-label="Save options">
  <button
    type="button"
    id="split-primary"
    aria-disabled="false"
  >
    Save
  </button>

  <button
    type="button"
    id="split-trigger"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="split-menu"
    aria-label="More save options"
  >
    <svg aria-hidden="true"><!-- chevron --></svg>
  </button>

  <ul
    role="menu"
    id="split-menu"
    aria-labelledby="split-trigger"
    hidden
  >
    <li role="none">
      <button role="menuitem" type="button">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem" type="button">Save and close</button>
    </li>
  </ul>
</div>
```

**Why `role="group"` not `role="toolbar"`:** a toolbar implies multiple independent tools. This is one logical control with a primary path and an overflow path. Group communicates that without implying toolbar navigation semantics.

**Why explicit `aria-label` on the menu trigger:** the chevron icon carries no text. Without a label, screen readers announce only "button" with no context. "More save options" names the relationship without duplicating the primary label.

#### Keyboard contract

| Key | Context | Behavior |
|---|---|---|
| `Tab` | Any | Moves focus between primary zone and menu trigger; two sequential tab stops |
| `Enter` or `Space` | Primary zone focused | Fires primary action |
| `Enter` or `Space` | Menu trigger focused | Opens dropdown menu |
| `ArrowDown` | Menu trigger focused | Opens menu and moves focus to first item |
| `ArrowDown` / `ArrowUp` | Menu open | Moves between menu items |
| `Home` | Menu open | Moves to first menu item |
| `End` | Menu open | Moves to last menu item |
| `Enter` or `Space` | Menu item focused | Fires that action, closes menu |
| `Escape` | Menu open | Closes menu, returns focus to menu trigger |
| `Tab` | Menu open | Closes menu, moves focus forward — does not trap |

Focus must never become invisible during any state. The `loading` state should use `aria-live="polite"` on a status region to announce completion without interrupting reading flow.

---

### Dropdown menu behavior

- Menu opens below the split button by default; flips above if insufficient viewport space remains
- Menu width is at minimum the full width of the split button combined; grows to accommodate the longest label
- Menu is not a submenu structure — a flat list of actions, no nesting
- Menu closes on: action selection, `Escape`, click outside, scroll of a containing scrollable ancestor (not page scroll)
- Do not close on page scroll alone; this breaks mobile usage where scroll and tap interactions overlap

---

### Mobile touch behavior

- Both segments must meet 48×48px touch target minimum independently — a user must be able to tap either zone without risk of hitting the other
- The divider between zones should be at least 8px of visual or spatial separation to reduce mis-tap rate
- On small screens (below 360px width), consider collapsing the split button into a single button plus a bottom sheet for secondary actions rather than a tight two-segment control
- Long press on the primary zone must not trigger native browser context menus unless the implementation explicitly owns that interaction

---

### Disabled state rules

**Full disabled (`disabled` variant):**
- Both segments: `aria-disabled="true"`, `pointer-events: none`, `tabindex="-1"` is acceptable but avoid it if the button is meaningful — keeping it in tab order with disabled state announced is often better for discoverability
- Tooltip or helper text should explain why the action is unavailable when the reason is non-obvious

**Partial disabled (`primary-disabled` variant):**
- Primary zone: `aria-disabled="true"`, styled at 40% opacity, non-interactive
- Menu trigger: fully interactive, normal focus and keyboard behavior
- The menu must still open and secondary actions must function
- Consider adding a `aria-description` or tooltip on the primary zone explaining the locked state

Do not visually hide disabled zones. Hiding removes discoverability and breaks screen reader enumeration of available controls.

---

### Implementation boundary

This spec covers:
- ARIA structure
- State model
- Keyboard contract
- Touch target floor
- Menu positioning logic (open/close/flip)
- Disabled and loading state rules

This spec does not cover:
- Token definitions (colors, radii, spacing values) — owned by the design token system
- Animation timing for menu open/close — owned by the motion system
- Icon library for the chevron and spinner — owned by the icon system
- Confirmation dialog for destructive variant — owned by the dialog component spec
- Server-side action handling or debounce logic — owned by the implementing application

---

### Reuse and governance notes

- The split button is not a shortcut for two buttons placed side by side — if the actions are not logically related, use separate buttons
- Do not use split button for navigation actions — use it only for operations that modify or save state
- If the secondary actions list exceeds 5 items, reconsider the IA: the split button implies a clear primary path; a long secondary list signals the primary action is not actually primary
- Track usage: if the primary action is almost never used and the dropdown is the default path, invert the design — the real primary action should be in the primary zone

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: single logical control with two independent interactive zones",
    "state_coverage: default, disabled, primary-disabled, loading, loading-menu, destructive",
    "accessibility_behavior: role=group, aria-haspopup=menu, aria-expanded, aria-label on icon trigger, menuitem role on items",
    "implementation_boundary: tokens/animation/icons/dialog/server logic excluded from this spec"
  ],
  "evidence_classes_cited": [
    "wcag_touch_target_48x48",
    "aria_menu_pattern",
    "aria_disabled_vs_disabled_attribute",
    "keyboard_contract_explicit"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there an existing token system this component must consume, or is the spec greenfield?",
    "Should the destructive variant require an inline confirmation or always delegate to a modal?"
  ],
  "turn": 1
}
[/SESSION_STATE]