## Backend Feasibility Review: Real-Time Collaboration on a REST/PostgreSQL Stack

---

### Hidden System Requirements

Before any implementation decision, these are the dependencies your current architecture does not have and the feature silently requires all of them.

**Transport layer.** REST is request-response. Real-time collaboration requires a persistent bidirectional channel. You need WebSockets (or a managed equivalent like Ably, Liveblocks, or Pusher). This is not a REST endpoint you add — it is a second server process or a managed service sitting alongside your API.

**Operational transform or CRDT engine.** Simultaneous edits to the same document position produce conflicts that REST + optimistic locking cannot resolve correctly. You need either OT (used by Google Docs) or a CRDT library (used by Figma, Linear, and others). The difference matters for complexity: OT requires a central server to sequence transforms; CRDTs can resolve offline and merge without a coordinator. For a React/PostgreSQL stack starting from scratch, a CRDT approach (Yjs is the dominant open-source choice) is significantly lower operational risk than building OT.

**Ephemeral presence state.** Cursor positions, selections, and "user is typing" state are high-frequency, short-lived, and do not belong in PostgreSQL. They need an in-memory store with automatic expiry — Redis pub/sub or a dedicated presence channel in a managed service. Writing cursor positions to your relational database will produce write contention and bloat your transaction log.

**Document state authority.** With multiple clients writing simultaneously, you need a defined authority model: who owns the canonical document state, how often is it persisted from the in-memory CRDT state to PostgreSQL, and what happens if the server crashes mid-session. This is a persistence strategy decision, not just a schema change.

**Session and permission checks at the transport layer.** Your existing REST auth (cookies, JWTs, session tokens) does not automatically extend to WebSocket connections. You must re-authenticate at the WebSocket handshake and re-authorize on every message, not just at connection open. Object-level authorization — can this specific user edit this specific document — must be checked server-side on each operation, not trusted from the client payload.

**Concurrency and isolation model.** PostgreSQL row-level locking works for REST. It does not work for real-time because holding a row lock across a WebSocket session will deadlock under any real load. You need an append-only operation log or a separate document state table that uses optimistic writes from the CRDT layer, not pessimistic locking.

**Offline and reconnect behavior.** Even in "always online" web apps, users lose connectivity. The collaboration layer must handle: buffering local operations during disconnect, replaying missed operations on reconnect, and merging diverged state. Without this, a brief network drop causes silent data loss or corruption.

---

### Feasibility Assessment

**What works today:** PostgreSQL is a reasonable persistence target for snapshots and operation logs. React has mature CRDT bindings (Yjs + y-websocket + y-indexeddb). The ecosystem exists and is production-proven.

**What is blocked until resolved:**

| Blocker | Why it blocks |
|---|---|
| No WebSocket server | The feature cannot start without a persistent transport. REST alone cannot push updates to other clients. |
| No CRDT or OT layer | Without conflict resolution, simultaneous edits will produce last-write-wins corruption. PostgreSQL's `updated_at` timestamp is not a merge strategy. |
| No presence store | Writing cursor state to PostgreSQL is not safe under real-time write frequency. A 10-user session generating cursor updates at ~10Hz is 100 writes per second to your relational DB, before any actual document edits. |
| Auth not extended to WebSocket | Your current session or JWT validation does not run on WebSocket messages by default. Every message is unauthenticated until you explicitly add the check. |
| No operation log or snapshot model | Without a defined persistence strategy, a server restart loses in-flight work. PostgreSQL needs to receive a durable snapshot at defined intervals, not on every keystroke. |

**Not a blocker, but a significant decision point:** Managed services (Liveblocks, Ably, PartyKit) handle the WebSocket infrastructure, presence, and CRDT hosting for you. You pay for that with vendor dependency and data leaving your PostgreSQL boundary. Self-hosted Yjs + y-websocket + Redis keeps everything in your stack but adds operational complexity you do not currently have.

---

### Safer Implementation Path

Ship in phases. Each phase delivers real user value and does not require the next phase to be complete before it is useful.

---

**Phase 1 — Locking and awareness (2 to 4 weeks)**

Goal: prevent simultaneous editing without real merge capability yet.

- Add a `document_lock` table or a `locked_by` / `locked_at` column to your documents table in PostgreSQL.
- When a user opens a document for editing, claim a lock with a TTL (for example, 30 seconds, renewed on heartbeat).
- Other users see the document as read-only with a visible "being edited by [name]" indicator.
- Lock is released on close or on TTL expiry.

This is a REST-compatible change. It ships with your existing stack and eliminates the worst failure mode (silent data corruption) while you build the real system.

You sacrifice: simultaneous editing capability. You gain: zero corruption risk and a working presence signal before any WebSocket work.

---

**Phase 2 — WebSocket transport and presence (3 to 6 weeks)**

Goal: live cursor positions and awareness without document merging yet.

- Stand up a WebSocket server. Options: a Node process with `ws` or `socket.io`; `y-websocket` if you are pre-committing to Yjs; a managed service if you want to defer infrastructure. The decision here is: self-hosted (more control, more ops) vs managed (faster start, vendor dependency).
- Authenticate at the WebSocket handshake using your existing JWT or session token. Deny the connection if auth fails. Do not accept a document ID from the client as proof of authorization — check object-level permission server-side.
- Implement a presence channel: broadcast cursor position and user identity on a Redis pub/sub channel keyed by document ID. Do not write this to PostgreSQL.
- Remove Phase 1 locking once Phase 2 is stable — or keep locking as a fallback for offline/degraded states.

You sacrifice: operational simplicity (a second server process now exists). You gain: live presence and the transport layer needed for Phase 3.

---

**Phase 3 — CRDT-based collaborative editing (4 to 8 weeks)**

Goal: genuine simultaneous editing with conflict resolution.

- Integrate Yjs on both client and server. On the client, bind `y-websocket` (for real-time sync) and `y-indexeddb` (for local persistence during disconnect). On the server, use `y-websocket` server or the Hocuspocus server (a production-ready Yjs backend with PostgreSQL persistence built in).
- Define your persistence strategy: Yjs maintains the authoritative in-memory document state; the server snapshots the Yjs document binary to a `document_snapshots` table in PostgreSQL on a defined interval (every 30 seconds, or on every N operations, or on clean session close — choose one and make it explicit).
- Maintain an operation log in PostgreSQL for replay-on-reconnect: append each Yjs update as a binary blob row. Compact old updates into the snapshot periodically to control log growth.
- Re-run your object-level authorization check on every Yjs document update message, not just at connection open. A user whose permissions are revoked mid-session must be disconnected from that document's sync channel.
- Test explicitly: simultaneous edit by two users at the same position, reconnect after 60-second disconnect, server restart during active session, permission revocation mid-session.

You sacrifice: simplicity of the PostgreSQL-only architecture. You gain: real merge semantics, offline resilience, and a conflict model that does not corrupt data.

---

**Phase 4 — Hardening and scale (ongoing)**

Once Phase 3 is stable:

- Add circuit breaker behavior on the WebSocket server: if Redis pub/sub is unavailable, degrade gracefully to read-only mode rather than dropping connections silently.
- Add `trace_id` on all WebSocket error events so you can correlate client-side errors with server-side operation failures.
- Implement exponential backoff with jitter on the client reconnect logic to avoid thundering-herd reconnects after a server restart.
- Define a quota or rate limit on WebSocket message frequency per session to prevent a single client from flooding the presence or operation channels.
- If you expect more than a few hundred concurrent collaborative sessions, the WebSocket server will need horizontal scaling with sticky sessions or a shared coordination layer (Redis or a managed equivalent).

---

### Summary Decision

The request is feasible but not with your current stack alone. The minimum viable additions are a WebSocket transport, a CRDT engine, and an ephemeral presence store. PostgreSQL remains the persistence target and does not need to be replaced — it needs a defined snapshot and operation-log contract that keeps it from becoming the bottleneck.

The phased path above means you can ship visible progress every few weeks without waiting for the full collaboration stack to be complete. Phase 1 ships this sprint. Phase 3 is where the real engineering investment lives.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "data_dependency: CRDT or OT engine required for conflict resolution; Yjs recommended",
    "permissions_dependency: object-level authorization must be checked at WebSocket handshake and on every message",
    "system_surface_dependency: WebSocket server and Redis presence store required alongside existing REST/PostgreSQL stack",
    "blocking_constraint: no WebSocket transport, no CRDT layer, no presence store, no WebSocket auth extension"
  ],
  "evidence_classes_cited": [
    "system_surface_dependency",
    "authorization_perimeter",
    "async_job_model",
    "resilience_strategy",
    "idempotency_contract"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Self-hosted Yjs/y-websocket vs managed service (Liveblocks, Ably, PartyKit) — decision affects vendor dependency, ops complexity, and data residency",
    "Expected concurrent collaborative session count — affects whether WebSocket server needs horizontal scaling from Phase 3 onward",
    "Existing auth mechanism (JWT vs session cookie) — affects WebSocket handshake implementation detail"
  ],
  "turn": 1
}
[/SESSION_STATE]