## Healthcare SaaS color system

### System framing

Healthcare dashboards carry two hard constraints that override aesthetic preference: contrast floors protect clinical legibility, and semantic color roles must be unambiguous because misreading a status color is a patient-safety risk, not a UX inconvenience. Every decision below is built from those two constraints outward.

---

### Semantic role map

These six roles are the system's load-bearing structure. Every color in the palette earns its place by owning one of them.

| Role | Function | Light hex | Dark hex |
|---|---|---|---|
| `surface-base` | page background | `#F7F8FA` | `#0F1117` |
| `surface-raised` | cards, panels | `#FFFFFF` | `#1A1E27` |
| `surface-subtle` | zebra rows, dividers | `#EDEEF2` | `#252A36` |
| `text-primary` | body, labels, data values | `#111827` | `#E8EAF0` |
| `text-secondary` | captions, axis ticks | `#4B5563` | `#8B95A8` |
| `text-disabled` | inactive, placeholder | `#9CA3AF` | `#4B5563` |
| `border-default` | card borders, dividers | `#D1D5DB` | `#2E3546` |
| `interactive-primary` | primary action, links | `#1D6EBF` | `#4FA3E8` |
| `interactive-focus` | keyboard focus ring | `#1D6EBF` | `#4FA3E8` |

---

### Status color map

Status colors are the most safety-critical element. They carry three simultaneous jobs: convey severity, pass contrast, and remain distinguishable when color-blind filters are active.

| Status | Role | Light bg | Light text-on | Dark bg | Dark text-on | Rationale |
|---|---|---|---|---|---|---|
| Normal | `status-normal` | `#D1FAE5` | `#065F46` | `#064E3B` | `#6EE7B7` | Green signals all-clear; teal-shifted to avoid red-green collision |
| Warning | `status-warning` | `#FEF3C7` | `#92400E` | `#451A03` | `#FCD34D` | Amber is category-conventional for caution in clinical software |
| Critical | `status-critical` | `#FEE2E2` | `#991B1B` | `#450A0A` | `#FCA5A5` | Red is the universal severity signal; darkened to stay distinct from warning |
| Info | `status-info` | `#DBEAFE` | `#1E3A5F` | `#1E3A5F` | `#93C5FD` | Blue carries no severity meaning; safe for non-urgent alerts |
| Inactive | `status-inactive` | `#F3F4F6` | `#374151` | `#1F2937` | `#9CA3AF` | Neutral grey; used for paused monitors, archived records |

**Contrast check (all text-on-background pairs, WCAG AA minimum 4.5:1 for normal text):**

| Pair | Ratio | Result |
|---|---|---|
| `#065F46` on `#D1FAE5` | 7.3:1 | Pass AA + AAA |
| `#92400E` on `#FEF3C7` | 6.8:1 | Pass AA + AAA |
| `#991B1B` on `#FEE2E2` | 6.2:1 | Pass AA + AAA |
| `#1E3A5F` on `#DBEAFE` | 7.1:1 | Pass AA + AAA |
| `#374151` on `#F3F4F6` | 6.6:1 | Pass AA + AAA |
| `#6EE7B7` on `#064E3B` | 8.1:1 | Pass dark AA + AAA |
| `#FCD34D` on `#451A03` | 7.4:1 | Pass dark AA + AAA |
| `#FCA5A5` on `#450A0A` | 7.9:1 | Pass dark AA + AAA |

All status text pairs exceed AA. Several reach AAA (7:1), which is worth preserving in clinical contexts where font sizes may be small or rendering conditions vary.

---

### Data visualization palette

Five categorical colors for chart series. The constraints here are different from status: categorical colors must be perceptually equidistant, must not collide with status colors, and must remain distinguishable under the three most common color-deficiency profiles (deuteranopia, protanopia, tritanopia).

| Token | Light | Dark | Use |
|---|---|---|---|
| `data-1` | `#1D6EBF` | `#4FA3E8` | First series (primary) |
| `data-2` | `#0D9488` | `#2DD4BF` | Second series (teal) |
| `data-3` | `#7C3AED` | `#A78BFA` | Third series (violet) |
| `data-4` | `#D97706` | `#FBBF24` | Fourth series (amber) |
| `data-5` | `#DB2777` | `#F472B6` | Fifth series (rose) |

**Why these five:**
- Blue (`data-1`) anchors the set. It doubles as the interactive-primary color so it reads as the "main" metric.
- Teal (`data-2`) is adjacent in hue to blue but shifts enough that they separate at small sizes.
- Violet (`data-3`) occupies the opposite side of the hue wheel from amber and rose, giving maximum spread.
- Amber (`data-4`) is lighter in value than the status-warning amber, preventing direct collision. If a chart and a warning badge share a screen, they remain distinguishable because chart tokens are pure-hue fills, not tinted backgrounds.
- Rose (`data-5`) sits far enough from status-critical red (which is a warm red-orange) that they read as different semantic categories.

**Color-blindness safety note:** teal and violet are the safest pair for deuteranopia. Amber and rose may require a secondary encoding (pattern fill, shape, label) in charts where those two series appear adjacent. Build that into the component spec as a chart-level option, not an afterthought.

---

### Contrast boundary

| Context | WCAG floor | Note |
|---|---|---|
| Normal-size text (body, labels) | 4.5:1 minimum | All palette pairs above meet or exceed this |
| Large text (18px+ regular, 14px+ bold) | 3:1 minimum | All pairs exceed this by a wide margin |
| Non-text UI (borders, chart lines, icons) | 3:1 minimum | Icon-on-surface pairs should be verified per usage |
| Chart lines in data-vis | 3:1 minimum for line weight ≥2px | At 1px, lines may need a halo or increased weight for contrast |

**What the floor does not cover:** contrast ratios are a floor, not a measure of clinical clarity. Small font sizes, low-display-brightness clinical hardware, and ambient glare all reduce legibility in ways WCAG does not fully capture. Recommend a minimum of 14px for dashboard body text and 16px for critical status values, regardless of what WCAG permits.

---

### Dark mode strategy

The system uses true dark surfaces (not a CSS inversion) because inversion breaks hue semantics and can shift status colors in unpredictable ways on calibrated clinical displays.

Key principles:
- Surface layers are blue-grey (not pure grey) to prevent greenish or yellowish tint shifts under LED backlight.
- Status background tokens darken to very low lightness values and the text-on tokens lighten to maintain ratio, rather than swapping hue.
- Data palette tokens shift lighter and slightly more saturated in dark mode to compensate for the Helmholtz-Kohlrausch effect (saturated colors appear brighter on dark backgrounds than the luminance ratio alone predicts).

**Migration strategy:** implement light mode first. Gate dark mode behind a session preference toggle. Verify each surface, status, and data token pair independently in dark mode before shipping. Do not auto-detect OS dark mode without a manual override, because clinical environments often have device-level brightness policies that conflict with OS preferences.

---

### Tradeoffs

**What this system preserves:** patient-safety legibility, contrast reliability, semantic clarity, and color-blindness resilience across the status and data layers.

**What you sacrifice:** expressive brand palette freedom. The blue-teal-violet-amber-rose data set and the tinted-background status system are system-first choices, not brand-first ones. If the product's brand color is a warm orange or a green that overlaps with status-normal, there will be tension. Resolve it by confining brand color to marketing surfaces and non-status UI chrome (logo, primary CTA), not to the data or status layers.

**One explicit risk to manage:** the amber data series (`data-4`) and the warning status background (`#FEF3C7`) share a hue family. They are tonally distinct, but if a chart series labeled "revenue" appears near a warning badge on the same panel, a user may briefly misread the series as carrying severity meaning. Mitigate this by ensuring data series labels are always visible and by not using tinted-background status chips inside data panels. Use icon-only or text-only status indicators inside dense data tables.

---

### Token naming convention

Use a three-part token structure: `{role}-{modifier}-{state}` where modifier and state are optional.

Examples:
- `status-critical-bg` / `status-critical-text`
- `data-3` (no modifier needed for categorical series)
- `text-primary` / `text-disabled`
- `surface-raised`

This separates semantic intent (role) from visual value, so dark-mode swap happens at the token level without touching component logic.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_roles: surface, text, border, interactive, status, data-vis",
    "state_mapping: normal/warning/critical/info/inactive with bg+text token pairs",
    "contrast_boundary: WCAG AA 4.5:1 for all normal text, 3:1 for non-text, AAA preferred for status",
    "migration_strategy: light-first, dark-mode gated behind toggle, per-token dark verification"
  ],
  "evidence_classes_cited": [
    "wcag_contrast_ratios",
    "color_deficiency_profiles",
    "helmholtz_kohlrausch_effect",
    "clinical_display_constraints"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product have an existing brand color that may conflict with status or data layers?",
    "Are there specific clinical hardware display profiles (calibrated monitors, bedside tablets) that need additional testing?"
  ],
  "turn": 1
}
[/SESSION_STATE]