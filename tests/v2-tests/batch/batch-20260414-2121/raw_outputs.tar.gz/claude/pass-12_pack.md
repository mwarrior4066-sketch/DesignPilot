Tabular data is the real constraint here. It determines which typefaces can actually do the job versus which ones just look the part.

## Reading context

Three surfaces with different jobs:

- **Marketing site**: Display-scale headings, mid-length prose, moderate hierarchy depth. Emotional signal matters here.
- **Web app dashboard**: Dense data, small sizes, tabular figures, status labels, filter controls. Legibility at 12–14px governs every choice.
- **Mobile**: Small screens, variable rendering quality, touch-first interaction. Optical sizing and weight contrast matter more than personality.

The dashboard is the binding constraint. Any typeface that fails tabular financial data gets eliminated regardless of how well it performs on the marketing side.

## Core recommendation

**Primary: Inter**
**Display/Marketing accent: Plus Jakarta Sans or DM Sans**

---

### Inter (functional workhorse)

Use Inter across the dashboard, data tables, form fields, labels, and mobile body text.

Why it survives the fintech filter:

- `tnum` (tabular figures) available as an OpenType feature, keeping decimal points and currency amounts aligned across rows without manual kerning tricks
- Designed for screen legibility at small sizes, not optimized for print or large-scale display
- Regular, Medium, SemiBold, and Bold provide enough weight range for a four-level hierarchy inside dense UI
- Reliable cross-platform rendering on Windows (GDI), macOS, and Android without significant hinting artifacts
- Free, Google Fonts-hosted, and widely supported in Figma and major front-end stacks

Where it gives ground:

- At display sizes (40px+), it reads as utilitarian rather than distinctive. Fine for a B2B dashboard. Less ideal for a consumer marketing hero.
- Its personality is neutral to the point of being generic on marketing surfaces.

**Activate tabular figures explicitly.** Do not rely on the browser default.

```css
.data-table td,
.data-table th {
  font-variant-numeric: tabular-nums;
  font-feature-settings: "tnum" 1;
}
```

If you are using Inter Variable, also set `font-optical-sizing: auto` so the letterforms adjust at display versus body sizes.

---

### Plus Jakarta Sans (marketing display layer)

Use Plus Jakarta Sans for marketing site headings and hero copy where you want a touch more geometry and warmth than Inter provides.

Why it works alongside Inter:

- Geometric-humanist hybrid: structured enough to feel authoritative, rounded enough to avoid the sterile read some fintech products land on
- Shares enough of Inter's proportional DNA that the two typefaces do not fight each other when they appear on the same page or in a shared component
- Weight range covers Light through ExtraBold, giving you flexible display hierarchy
- Good Latin coverage; acceptable fallback stack options

Where it gives ground:

- Not a substitute for Inter in data-dense contexts. Do not use Plus Jakarta Sans for table cells, numeric fields, or UI labels at 12–14px.
- If your product has multi-script requirements beyond Latin, assess coverage before committing.

Substitute DM Sans if you want a slightly tighter, more understated feel, or if your visual language skews more toward restrained B2B over consumer-facing fintech.

---

## Scale decisions

### Marketing site

| Role | Typeface | Size | Weight | Leading |
|------|----------|------|--------|---------|
| Hero heading | Plus Jakarta Sans | 56–72px | Bold / ExtraBold | 1.1 |
| Section heading | Plus Jakarta Sans | 36–48px | SemiBold | 1.15 |
| Subheading | Inter | 20–24px | SemiBold | 1.3 |
| Body | Inter | 16–18px | Regular | 1.6 |
| Caption / label | Inter | 13–14px | Regular / Medium | 1.4 |

### Dashboard

| Role | Typeface | Size | Weight | Leading |
|------|----------|------|--------|---------|
| Page title | Inter | 20–24px | SemiBold | 1.3 |
| Card heading | Inter | 14–16px | SemiBold | 1.35 |
| Table header | Inter | 12–13px | Medium | 1.3 |
| Table body / data | Inter | 12–13px | Regular | 1.4 |
| Status label / tag | Inter | 11–12px | Medium | 1.2 |
| Numeric KPI | Inter | 28–40px | Bold / SemiBold | 1.15 |

Table header and body share a size intentionally. Weight contrast (Medium vs Regular) plus uppercase styling on headers provides enough differentiation without shrinking the data below reliable legibility.

### Mobile

| Role | Typeface | Size | Weight | Leading |
|------|----------|------|--------|---------|
| Screen title | Inter | 22–24px | Bold | 1.25 |
| Section header | Inter | 16–18px | SemiBold | 1.35 |
| Body / list item | Inter | 15–16px | Regular | 1.5 |
| Numeric figure | Inter | 15–16px | Medium | 1.4 |
| Caption | Inter | 12–13px | Regular | 1.4 |

Mobile body minimum is 15px. Below that, Inter's performance degrades on mid-tier Android hardware with default subpixel rendering.

---

## Hierarchy and weight structure

Keep weight decisions to four stops: Regular, Medium, SemiBold, Bold.

- **Regular**: body copy, table cells, descriptive text
- **Medium**: table headers, labels, supporting UI text, numeric figures that need mild emphasis
- **SemiBold**: card headings, navigation labels, section headers, KPI labels
- **Bold**: page titles, primary KPIs, marketing hero text (Inter), high-priority alerts

Using all eight available weights creates visual noise in dense UIs. Four weights is enough to express the full hierarchy without ambiguity, and it keeps the design system governable.

---

## Fallback stack

```css
/* Primary */
font-family: "Inter", "Inter Variable", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;

/* Display (marketing only) */
font-family: "Plus Jakarta Sans", "Inter", system-ui, -apple-system, sans-serif;
```

The system-ui chain catches cases where the font does not load. Segoe UI on Windows provides tabular figures natively. BlinkMacSystemFont covers older macOS. The stack degrades cleanly.

---

## Licensing and adoption

Inter: SIL Open Font License. Free for commercial use with no restrictions on distribution or embedding. No legal review required.

Plus Jakarta Sans: SIL Open Font License. Same conditions.

Both are available through Google Fonts (CDN) or self-hostable. Self-host for dashboard environments where CDN latency affects First Contentful Paint scores. Use `font-display: swap` with preloading for the two or three most-used weights.

```html
<link rel="preload" href="/fonts/inter-regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/fonts/inter-semibold.woff2" as="font" type="font/woff2" crossorigin>
```

---

## What you sacrifice

This system is deliberately not precious. Inter is neutral, which means the marketing site will need strong color, spacing, and layout work to feel premium. The typefaces alone will not carry the brand signal.

If your competitive position requires more typographic distinctiveness, the alternative is to replace Plus Jakarta Sans on the marketing layer with a licensed variable font (Söhne, Roc Grotesk, or ABC Favorit, all of which pair well with Inter's dashboard role). That adds licensing cost and font management overhead in exchange for a higher design ceiling on the marketing surface.

The two-typeface split here preserves the cost structure and development simplicity at the cost of some expressiveness. You gain reliability across all three surfaces, tabular data integrity, strong weight coverage, and a fallback chain that degrades gracefully on every target platform.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing site / web app dashboard / mobile",
    "scale_decision: four-weight system (Regular, Medium, SemiBold, Bold) across three surfaces",
    "pairing_rationale: Inter as functional workhorse with tabular figures; Plus Jakarta Sans as display layer for marketing",
    "adoption_sequence: self-host both fonts, preload two to three weights, activate tnum explicitly for data tables"
  ],
  "evidence_classes_cited": [
    "OpenType feature: tnum / tabular-nums for numeric alignment",
    "WCAG-adjacent: minimum 15px mobile body for mid-tier Android rendering",
    "SIL OFL licensing confirmed for both typefaces",
    "font-display: swap + preload pattern for performance",
    "CSS font-feature-settings and font-variant-numeric for tabular activation"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product have multi-script requirements beyond Latin?",
    "Is typographic distinctiveness on the marketing surface a competitive requirement, or is neutrality acceptable?",
    "Is there a preference for self-hosting versus Google Fonts CDN?"
  ],
  "turn": 1
}
[/SESSION_STATE]