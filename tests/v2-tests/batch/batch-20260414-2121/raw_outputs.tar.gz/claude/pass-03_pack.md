## Dashboard audit

### Dashboard role and scan failure

This is a monitoring dashboard — its job is to let users assess state at a glance and decide whether action is needed. The current layout fails that job at the first view in three distinct ways: the KPI row signals direction without giving users enough information to judge whether that direction is acceptable, the chart demands cognitive work before it can be read, and the navigation forces scanning instead of supporting routing.

These are hierarchy failures, not polish failures. The problems compound: a user lands on the view, sees a downward churn arrow, cannot tell if it is within target, looks to the chart for context, cannot read it because the legend is below the fold, and then cannot quickly navigate to a detail view because the sidebar offers no structure. The first view has three consecutive failures before any useful work begins.

---

### KPI row: missing reference values

**Failure.** DAU, MRR, and churn rate as standalone numbers with trend arrows are direction indicators, not status indicators. An arrow pointing up on MRR is meaningless without knowing whether $48k is on track, ahead, or behind a target of $55k. Churn rate is the highest-risk metric on this row and it has no threshold attached to it at all.

**What is missing.** Each KPI needs one reference value alongside the current number. This should be one of: target value, period-over-period comparison (vs. last 30 days), or a status threshold (e.g., churn flagged when above 3%). The trend arrow alone communicates change direction, not change meaning.

**Repair.** Add a secondary line under each KPI: `vs. target` or `vs. prior period`, with the delta expressed as both an absolute and percentage change. Color the delta, not just the arrow. For churn specifically, add a threshold band (acceptable / at risk / critical) because a trend arrow on a rate metric is the most misread pattern in SaaS dashboards. The cost is two lines of secondary text per KPI. You sacrifice visual minimalism and gain interpretable state, which is the actual job of this row.

**WCAG note.** If the trend arrows are the only signal of direction (no text alternative), they fail 1.4.1 Use of Color and 1.1.1 Non-text Content. Arrow icons need a text label or an accessible name that states the direction explicitly.

---

### Chart: unlabeled Y-axis and below-fold legend

These are two separate failures that combine into one unusable chart.

**Y-axis label missing.** Without a Y-axis label, the user must already know what is being measured to read the chart. On a dashboard with multiple possible units (counts, rates, revenue), this is an assumption the chart cannot safely make. A user who sees a line crossing 12,000 does not know if that is users, sessions, events, or dollars. Label the Y-axis with the unit and scale. This is a two-word fix that removes a class of misreading entirely.

**Legend below the fold.** Four lines with no visible legend means the user cannot decode the chart without scrolling. This is the most damaging of the three failures because it makes the chart actively misleading: users will assign their own meaning to the lines based on color alone, which varies by display calibration and color vision. If the legend cannot be placed inline (which it can), each line should be directly labeled at its rightmost endpoint with a short name. End-of-line labeling is more readable than a separate legend regardless of fold position, reduces the spatial distance between label and line, and removes the need for the user to track colors across the chart body.

**Compound repair.** Label the Y-axis. Move labels to line endpoints. If the segments have short names (under 12 characters), end-of-line labels are better than any legend placement because they eliminate color-matching entirely. You sacrifice a small amount of right-margin space and gain a chart that is immediately readable without interaction.

**Color note.** Four lines distinguished by hue alone will fail for approximately 8% of male users with red-green color vision deficiency. Add a secondary distinguishing variable: line weight, dash pattern, or marker shape at data points. This does not require changing the color palette.

---

### Sidebar: 12 ungrouped nav items

**Failure.** Twelve ungrouped items in a sidebar is not navigation, it is a flat list of features. It puts the user in charge of organizing the product mentally every time they want to route somewhere. Research on information scent shows that users cannot hold more than 5 to 7 unlabeled categories in working memory during task execution. At 12 flat items, users scan the whole list on every navigation event.

**Repair.** Group the 12 items into 3 to 4 named sections. Typical SaaS groupings that work: Overview / Acquisition / Retention / Settings, or Monitor / Analyze / Configure / Admin. The grouping should reflect the user's mental model of what they are doing, not the engineering team's feature list. If you cannot group the 12 items into fewer than 5 categories without forcing unnatural groupings, that is a product architecture signal: the nav may be exposing too many first-class features when some should be secondary pages.

Grouped navigation reduces per-navigation scan cost from 12 items to 3 to 4 group headers plus a subset of items. You sacrifice flat visual simplicity and gain structure that matches how users actually route through an analytics tool.

---

### Intervention order

Fix in this sequence:

1. **Legend to line endpoints** — chart is currently misleading, not just incomplete. A user who assigns their own meaning to an unlabeled line and acts on it has been given worse than no chart.
2. **KPI reference values** — the KPI row is the first thing users read. Without targets or comparisons, no status decision is possible from this row.
3. **Y-axis label** — low-effort, removes a class of misreading, should ship with the legend fix.
4. **Nav grouping** — high navigation cost, but does not corrupt data interpretation the way the first three failures do.
5. **Arrow accessibility** — WCAG repair, should be included in the KPI fix sprint.

---

### What is not addressed here

Color palette choice, chart line styling beyond the color-only failure, and sidebar visual design are not addressed because the failures above are structural. Fixing the structure first prevents the common failure mode where a dashboard is restyled and the underlying hierarchy problems survive into production.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_role: monitoring dashboard",
    "kpi_failure: missing reference values and threshold bands",
    "chart_failure: unlabeled Y-axis and below-fold legend",
    "density_or_navigation_decision: sidebar ungrouped at 12 items, repair to 3-4 named groups"
  ],
  "evidence_classes_cited": [
    "wcag_1_4_1_use_of_color",
    "wcag_1_1_1_nontext_content",
    "working_memory_threshold_5_to_7_items",
    "color_vision_deficiency_prevalence_8pct_male"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are segment names short enough for end-of-line labeling (under ~12 characters)?",
    "Does the product have defined targets or thresholds for each KPI that can be surfaced?",
    "Are the 12 nav items fixed or can items be promoted/demoted based on usage data?"
  ],
  "turn": 1
}
[/SESSION_STATE]