## API Review: POST /api/v1/projects/{id}/members

---

### 1. Status code on successful creation

**Governing decision:** Return `201 Created`, not `200 OK`, because this request creates a new resource (a membership), not an update to an existing one.

`200` signals a successful retrieval or update. Creating a membership is a discrete creation event. Returning `200` misrepresents the operation's semantics to any client parsing status codes for routing, logging, or retry logic — you sacrifice correct HTTP semantics to gain nothing.

---

### 2. Response body on success

**Governing decision:** Return the created membership resource, not the full updated member list, because the caller asked to add one member and needs confirmation that the specific membership was created.

Returning the full list couples the caller to a potentially large, paginated collection they did not ask for. It also makes idempotency confirmation harder: the caller cannot verify their specific operation succeeded without scanning the list. Return the new membership object with its `id`, `userId`, `role`, `createdAt`, and project reference. If the caller needs the full list, that is a separate `GET /api/v1/projects/{id}/members` request.

---

### 3. Idempotency

**Governing decision:** Require an `Idempotency-Key` header, because network retries on a non-idempotent write endpoint will create duplicate memberships.

Without an idempotency contract, a client that retries after a timeout cannot know whether the first request succeeded. The server must deduplicate: store the key with the result, return `409 Conflict` on a duplicate key with a different payload, and return the original response on a true retry. The idempotency contract is: `Idempotency-Key` header required, deduplication window of at least 24 hours, `409` on conflicting duplicate.

---

### 4. Error response format

**Governing decision:** Replace the plain string error response with RFC 9457 Problem Details, because structured errors are the only way clients can reliably parse failure reasons without scraping human-readable text.

A plain string requires the client to parse natural language to distinguish a missing user from a permission failure from a validation error. RFC 9457 gives you `type`, `title`, `status`, `detail`, and `instance` fields. This means accepting slightly more payload size to gain machine-parseable, loggable, traceable error responses. Every error response should also carry a `trace_id` so failures can be correlated across services.

Minimum structure:

```json
{
  "type": "https://api.example.com/errors/member-already-exists",
  "title": "Member already exists",
  "status": 409,
  "detail": "User 42 is already a member of project 7.",
  "instance": "/api/v1/projects/7/members",
  "trace_id": "abc-123"
}
```

---

### 5. Authorization

**Governing decision:** The authorization check must be an object-level authorization on the project, not just a session check, because a logged-in user with no project relationship must not be able to add members to any project they can hit by ID.

The current check confirms authentication (is this a real session?) but skips authorization (does this session owner have the right to modify this project?). This is a BOLA (Broken Object Level Authorization) vulnerability. The fix requires: verify the caller is authenticated, then perform an object-level authorization check that only the project admin or owner role may invoke this endpoint. The authorization perimeter is: `only [project admin or owner] may add members`. Deny by default for any other role, including authenticated-but-unrelated users.

The check sequence is:
1. Is the caller authenticated? If not, `401`.
2. Does the caller have the admin or owner role on project `{id}`? If not, `403`.
3. Does the target user exist? If not, `404`.
4. Is the target user already a member? If yes, `409` (or idempotent return if key matches).
5. Create the membership. Return `201`.

---

### Summary of required changes

| Concern | Current | Required |
|---|---|---|
| Success status | `200` | `201` |
| Response body | Full member list | Created membership object |
| Idempotency | None | `Idempotency-Key` header + dedup |
| Error format | Plain string | RFC 9457 + `trace_id` |
| Authorization | Auth check only | Object-level BOLA check on project |

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "status_code: 201 Created on membership creation",
    "response_body: created membership resource, not full list",
    "idempotency_contract: Idempotency-Key header required, 24h dedup window, 409 on conflict",
    "error_format: RFC 9457 Problem Details with trace_id",
    "authorization_perimeter: object-level BOLA check, only project admin or owner may add members, deny by default"
  ],
  "evidence_classes_cited": [
    "idempotency-key header",
    "409 on duplicate",
    "RFC 9457",
    "object-level authorization",
    "BOLA check",
    "deny by default",
    "only [role] may",
    "trace_id on all errors"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the API need a deduplication strategy for same-user re-add after removal, or should that be treated as a new membership event?",
    "Is there a role model beyond admin/owner that needs to be reflected in the authorization perimeter?"
  ],
  "turn": 1
}
[/SESSION_STATE]