## Brand Positioning Pass: Freelancer Fintech

### Audience frame

Freelancers are not small businesses pretending to be large ones. They are individuals managing income volatility, irregular pay cycles, client relationships, and personal financial anxiety inside one entity. The trust requirement is personal, not institutional. They need to feel like the product understands their actual work pattern, not that it has been graciously adapted to tolerate them.

This matters because Stripe, Mercury, and Relay all position toward business operators with operational complexity. That framing works for agencies, funded startups, and multi-person teams. It creates a gap for someone who speaks directly to the single-person income problem.

### Competitor audit

**Stripe** owns developer infrastructure trust. Its brand signals precision, completeness, and technical authority. It does not speak to financial anxiety or income rhythm. Freelancers use it as a payment rail, not a financial home.

**Mercury** owns the startup banking aesthetic: clean, modern, venture-friendly. It positions toward funded companies and signals sophistication to investors. The trust logic is: we are serious enough for your cap table. That framing is irrelevant to a freelancer without a co-founder.

**Relay** owns operational clarity for small teams: separate accounts, multi-user access, categorized spending. The trust logic is: we help you run the business properly. That framing requires the user to already think of themselves as a business owner, not a person doing their work.

None of them are competing for the position: I understand that your income is irregular and that financial stress is part of your working life, not a failure to be corrected.

### Positioning territory

Own **income clarity for working individuals**, not business banking for solo operators.

The distinction is not cosmetic. Business banking trust is built on institutional signals: FDIC language, enterprise features, security architecture, compliance vocabulary. That framing puts the product in a category the user already associates with friction and formality, which you then have to spend brand energy escaping.

Income clarity trust is built on a different set of signals: does this product understand how I actually get paid, does it help me make sense of what I have and what is coming, does it reduce the cognitive load of irregular income rather than add more categories and reports I have to maintain.

This means the positioning territory is: **the financial layer that works the way freelance income actually works**, rather than a bank adapted for freelancers.

### Trust logic

Trust requires demonstrating that you have correctly modeled the user's actual problem, not just their category. For a freelancer, the emotional core of the problem is: I do not always know what I will earn next month, and financial products make me feel like that is my fault.

A positioning that owns income clarity addresses this directly, because clarity implies: we show you what you have, what is pending, and what you probably need, without requiring you to behave like a business with predictable revenue.

The audience will not accept without some signal that the product actually handles irregular income, not just that it is friendly. Friendliness from a product that still assumes monthly salary behavior is a trust gap, not a trust bridge.

### Differentiation frame

The tension to resolve: approachable cannot mean simplified to the point of being inadequate. Freelancers deal with real financial complexity: self-employment tax, client payment timing, project-based income, business and personal expense overlap. A product that feels approachable but cannot handle that complexity earns distrust faster than a cold bank would, because the warmth created a false expectation.

The right framing is **clear, not simple**. Clear means: the product surfaces what matters and reduces noise. Simple means: the product hides things you still need to know. You want the former and should avoid the latter in both the product and the positioning language.

You sacrifice category legibility to gain audience specificity. Calling this income management rather than business banking means some users will not immediately recognize what it is, requiring slightly more explanation at the top of the funnel. That is the tradeoff worth accepting because it also means the users who do recognize it feel precisely addressed, which produces stronger initial trust than broad category recognition would.

### Messaging consequence

Avoid language that implies the user needs to organize themselves better. Words like financial control, take charge of your finances, and manage your business imply that the problem is user behavior. The positioning should place the burden on the financial environment being hard to navigate, not on the freelancer being disorganized.

Instead, use language that acknowledges the environment: irregular is normal, pending is real money, your work earns more than a paycheck. This framing positions the product as designed for the actual situation rather than adapted from a simpler one.

The brand voice should be direct and specific, not warm-and-vague. Warm-and-vague is what every challenger fintech defaults to when they want to feel unlike a bank. It has become a category convention that produces sameness, not differentiation. Specific language about real freelance financial problems is more distinctive and more trustworthy than tone alone.

### Open gap

Open gap: no data on which specific freelance personas carry the highest anxiety load and whether that maps to income level, career stage, or industry. The positioning above assumes the emotional core is income volatility stress, but if a segment study showed that the primary pain is actually tax confusion or client payment chasing, the territory anchor might shift. This is inferred from category behavior and competitor positioning, not from primary research on this user base.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: working individuals managing income volatility, not solo business operators",
    "differentiation_frame: income clarity, not business banking",
    "trust_logic: trust requires modeling the actual problem — irregular income is normal, not a failure",
    "messaging_consequence: avoid burden-on-user language; place burden on financial environment complexity"
  ],
  "evidence_classes_cited": [
    "competitor_positioning_audit",
    "category_convention_analysis",
    "trust_logic_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Which freelance persona carries the highest anxiety load — income volatility, tax confusion, or client payment chasing? Affects territory anchor."
  ],
  "turn": 1
}
[/SESSION_STATE]