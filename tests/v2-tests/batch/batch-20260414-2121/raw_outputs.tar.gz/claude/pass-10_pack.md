The structure has a sequencing problem before it has a visual one.

## Hierarchy failure

The title comes first, but it carries the least orientation value for a new viewer. Before someone can care about a name, they need to know the category: what kind of event, who it is for, when it is. The logo placed center-stage reinforces the name — it does not add context. The date, the one element that creates urgency and action, is smallest and lowest-contrast.

The scan order this poster produces: title (no context yet) → logo (reinforces the name you just read) → date (buried, barely legible against sky).

The scan order a useful event poster needs: category or tagline → title → date/location → secondary details.

## Typeface and photo conflict

Decorative typefaces work at poster scale when they have clear air around them. Against a full-bleed city skyline, the letterforms are competing with architectural edges, horizon lines, and tonal variation. The title either needs enough contrast mass to beat the photo, or the photo needs to be subdued enough to stop fighting it. Right now you likely have neither: a decorative face (lower stroke contrast tolerance) on a busy photographic background (high tonal variation).

The white center logo compounds this. White on sky reads differently depending on cloud cover, exposure, and time of day in the photo. If the logo has fine details or thin strokes, it will drop out in lighter sky areas.

## Date legibility

Small gray text in a corner against a photo background is a near-certain WCAG 1.4.3 failure. Gray on photography is not a predictable contrast relationship. You need either a text-protection layer (scrim, frosted band, solid field) or a repositioning of the date into a layout zone where the contrast is guaranteed and the size earns the urgency the date actually carries.

## What to fix and in what order

**Fix sequencing first.** Add a category line or event descriptor above or below the title in a secondary but readable weight. Something like "International Design Conference" or a short tagline. This gives the title meaning before the viewer reads it.

**Fix the date.** Move it out of the corner, increase its size, and give it contrast protection. A small date in a corner reads as fine print, not as a call to action.

**Resolve the photo conflict.** Either darken and desaturate the image enough to guarantee type legibility across all text zones, or treat the image as a background texture with a color overlay rather than a literal photograph. A full-bleed city skyline is a generic choice for a design conference; it does not communicate craft, creativity, or a specific editorial point of view.

**Reconsider the logo placement.** Center placement makes the logo the focal anchor, but the title is already doing naming work. The logo is more credible at a smaller size in a corner or within a lockup that pairs it with the event name, rather than competing with it at the same weight.

## Tradeoff to name

If you preserve the full-bleed photo as a primary visual element, you sacrifice typographic clarity and legibility confidence across all text layers. You gain atmosphere and production scale, but only if the layout protects the type at every zone. If you move toward a designed field with controlled color zones instead, you sacrifice the photographic drama, but you gain hierarchy control, contrast reliability, and the ability to let the typeface do real compositional work.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "communication_goal: orient viewer before naming event",
    "hierarchy_failure: title before context, date buried",
    "rebuild_move: add category line, protect date contrast, resolve photo conflict",
    "distance_tradeoff: full-bleed photo sacrifices type clarity and legibility confidence"
  ],
  "evidence_classes_cited": ["wcag_1_4_3_reference", "scan_order_analysis", "stroke_contrast_constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the photo a locked creative direction or open to replacement or treatment?",
    "Is there a tagline or event descriptor already written that could anchor hierarchy?"
  ],
  "turn": 1
}
[/SESSION_STATE]