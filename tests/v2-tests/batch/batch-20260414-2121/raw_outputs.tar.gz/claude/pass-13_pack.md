## Research gap map: B2B project management redesign

---

### What you actually know

Before mapping the gaps, it matters to be precise about what the existing evidence can and cannot support.

**3 stakeholder interviews**
These tell you business goals, internal pain points, and organizational priorities. They do not tell you what end users experience, because stakeholders and daily users are rarely the same people in B2B tools. Treat these as context, not as user evidence.

**2 usability tests on the current product**
These surface task-completion failures and friction moments visible during observation. With two sessions, you have early signal, not pattern confirmation. Any finding from two tests should be treated as a hypothesis, not a validated problem.

**60% drop-off on project creation**
This tells you where abandonment happens. It does not tell you why. The cause could be form complexity, a required field users don't have the answer to, permission confusion, a missing affordance, or a workflow mismatch between how the tool defines "project" and how users do.

---

### Gap map

Gaps are ordered by the risk they create if left unresolved before redesign decisions are locked.

---

#### Gap 1 — Why users abandon the project creation flow
**Priority: blocking**

This is the most dangerous unresolved gap. You have the where; you are missing the cause. Without it, any redesign of the creation flow is a guess. A simplified form might not be the fix if the real problem is that users lack required information at that moment, or that the permission model forces them to stop and get help.

**What to do:** Exit-intent microsurveys on the drop-off step (1 to 2 questions maximum), paired with 4 to 6 contextual sessions where you watch users attempt project creation in their actual work context rather than a test environment.

**Evidence needed:** Behavioral cause data, not just behavioral location data.

---

#### Gap 2 — End-user experience distinct from stakeholder perspective
**Priority: blocking**

Three stakeholder interviews are not a substitute for end-user research. In B2B tools, stakeholders describe the workflow they believe exists. Users describe the workflow they actually navigate. These diverge frequently, especially around workarounds, unofficial steps, and edge-case handling that never made it into requirements.

**What to do:** 6 to 8 directed interviews with active end users across at least two role types (project creators and project members, if that distinction exists in your product). Focus on mental models of what a "project" is, how they currently start one, and what they do when the tool doesn't match their expectation.

**Evidence needed:** First-person behavioral description from non-stakeholder users.

---

#### Gap 3 — Power user behavior and advanced workflow needs
**Priority: high**

Power users in B2B tools often represent the retention anchor: they are the people who pushed adoption internally and who will be most vocal if a redesign breaks their workflows. They also reveal the ceiling of what the tool needs to support, which shapes decisions about progressive disclosure, keyboard shortcuts, template systems, and bulk actions.

**What to do:** Identify 3 to 5 power users through analytics (high session frequency, high feature breadth) and run task-based interviews focused on what they've built, what they've worked around, and what would break for them in a redesign.

**Evidence needed:** Advanced workflow map, feature dependency list, workaround inventory.

---

#### Gap 4 — Competitive and market context
**Priority: high**

Without competitive analysis, you have no calibration for what users have learned to expect from other tools. In B2B project management, users frequently come in with mental models shaped by Asana, Jira, Monday, Linear, or Notion, depending on their background. A redesign that ignores learned interaction patterns creates unnecessary relearning cost.

**What to do:** Structured heuristic audit of 3 to 4 direct competitors focused specifically on the project creation flow, onboarding patterns, and permission models. This is not about copying UI; it is about understanding the interaction conventions your users already carry.

**Evidence needed:** Comparative interaction pattern map, convention inventory, differentiation rationale.

---

#### Gap 5 — Usability pattern confirmation across more users
**Priority: moderate**

Two usability sessions give you hypotheses, not patterns. Before committing redesign resources to fixes surfaced in those sessions, you need enough additional sessions to distinguish genuine systemic problems from individual user variability.

**What to do:** Extend usability testing to 5 to 7 additional participants before or in parallel with early redesign work. Run moderated sessions on the highest-risk flows: project creation, task assignment, and status tracking, since these are typically where B2B tools fail most.

**Evidence needed:** Pattern confirmation across sufficient sample for each identified friction point.

---

#### Gap 6 — Permission and role model comprehension
**Priority: moderate, rising to blocking if your redesign changes roles**

B2B tools fail frequently not at the UI layer but at the permission layer: users don't understand who can see what, why certain actions are unavailable, or how to configure access for external collaborators. None of your current evidence covers this directly.

**What to do:** Include role and permission scenarios in your usability sessions and contextual interviews. Ask users to describe their mental model of who can access a project and watch whether they can successfully complete a permission-related task without help.

**Evidence needed:** Permission comprehension model, error-recovery behavior, edge-case scenarios.

---

### Research sequence

Run these in roughly this order, adjusting based on what early sessions reveal.

1. Exit-intent survey on the creation drop-off (fast, low cost, unblocks Gap 1 partially)
2. End-user contextual interviews, 6 to 8 sessions (unblocks Gaps 1 and 2 together)
3. Power user interviews, 3 to 5 sessions (unblocks Gap 3 before architecture decisions are made)
4. Competitive heuristic audit (unblocks Gap 4, can run in parallel with interviews)
5. Extended usability testing, 5 to 7 sessions (confirms or revises Gap 5 findings)
6. Permission comprehension scenarios woven into sessions 2 and 5 (covers Gap 6 without extra cost)

---

### What you can and cannot decide right now

| Decision | Can you make it now? | What's missing |
|---|---|---|
| That the creation flow needs work | Yes | Nothing — the 60% drop-off is clear signal |
| What specifically to fix in the creation flow | No | Abandonment cause (Gap 1) |
| Whether to simplify or extend the creation form | No | End-user mental model (Gap 2) |
| How much complexity to support | No | Power user needs (Gap 3) |
| What interaction patterns to use | No | Competitive context (Gap 4) |
| That the current usability issues are systemic | Not yet | Pattern confirmation (Gap 5) |

---

### One explicit tradeoff

You could move directly to redesign using only what you have. That would save 3 to 5 weeks of research time and let you ship a prototype faster. The cost is that you would be solving for the wrong cause of the drop-off with reasonable probability, because "fix the form" is one of several plausible explanations and not the most common root cause in B2B creation flows. A faster prototype with wrong assumptions costs more to revise than a slightly later prototype built on cause data.

[SESSION_STATE]
{
  "route": "rt_ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": [
    "known_evidence: 3 stakeholder interviews, 2 usability tests, 60% creation flow drop-off",
    "gap_priority: abandonment cause > end-user voice > power users > competitive context > usability pattern confirmation > permission comprehension",
    "method_mapping: exit-intent survey, contextual interviews, power user interviews, heuristic audit, extended usability testing",
    "research_sequence: exit survey first, then contextual interviews, then power user interviews, then competitive audit, then extended usability"
  ],
  "evidence_classes_cited": ["behavioral_location_data", "stakeholder_perspective", "analytics_signal", "usability_session_findings"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are project creators and project members distinct roles in this product?",
    "Does the tool have an existing permission or role model that affects the creation flow?",
    "What is the timeline constraint for the redesign — does the research sequence need to compress?"
  ],
  "turn": 1
}
[/SESSION_STATE]