# Backend Architecture Spec: Multi-Tenant Scheduling Platform

---

## Governing Route

`rt_backend_architecture_spec` — authority model, consistency stance, data delivery, observability tax.

Supporting: `rt_api_reliability_security` for outbound webhook contracts and async job lifecycle; `rt_backend_feasibility` for regional residency constraints and audit trail sequencing.

---

## 1. Authority Model and Tenant Boundary

### Tenant isolation model

Every row in every service table carries a `tenant_id`. No query crosses that boundary without an explicit cross-tenant grant (platform-admin only, separately authorized).

Isolation is enforced at three layers:
1. **Application layer** — every service method receives a resolved `TenantContext` struct before touching data. No method accepts raw IDs without tenant scope.
2. **Database layer** — row-level security (RLS) policies enforce `tenant_id = current_setting('app.tenant_id')` on all tenant-scoped tables. This is a defense-in-depth backstop, not the primary gate.
3. **Network layer** — tenants mapped to regional deployments are pinned to that region's cluster. Cross-region reads require explicit replication topology, not accidental joins.

### Regional data residency

Residency is a property of the **tenant record**, not of individual users or requests.

```
tenant_regions table
  tenant_id       uuid PK FK
  home_region     enum('us-east', 'eu-west', 'ap-southeast', ...)
  pinned_at       timestamptz
  migration_state enum('stable', 'migrating', 'verifying')
```

The API gateway resolves `tenant_id -> home_region` from a lightweight global routing table (replication-safe, read-only, eventually consistent by 30s). Requests arriving at the wrong region receive `307 Temporary Redirect` to the correct regional endpoint, not a proxied response. This preserves data sovereignty: no tenant data transits a foreign region at rest.

Implication: background jobs, audit writers, and webhook dispatchers must be instantiated per region. There is no global job queue. The architecture tax here is operational duplication, but it is the only approach that satisfies residency without exception carve-outs.

---

## 2. Core Services and Boundaries

### 2.1 Identity and Authorization Service

**Owns:** tenant provisioning, user membership, role assignments, workspace membership, API key lifecycle.

**Does not own:** scheduling logic, audit emission, outbound delivery.

Authorization model: **RBAC with workspace scope.**

```
roles: platform_admin | tenant_admin | workspace_owner | member | viewer
permissions scoped to: (tenant_id, workspace_id, resource_type, action)
```

Every inbound request is resolved to a `Principal` before it reaches a domain service:

```
Principal {
  tenant_id:    uuid
  user_id:      uuid
  workspace_id: uuid | null
  roles:        Role[]
  api_key_id:   uuid | null
  region:       Region
}
```

Authorization checks are **object-level** throughout — not role-only. A user with `member` role may not read another member's private schedule even within the same workspace. Deny by default; explicit grants required.

---

### 2.2 Scheduling Service

**Owns:** events, slots, bookings, availability rules, recurrence expansion, conflict detection.

**Does not own:** approvals (separate service), user identity, notification dispatch.

Key design decisions:

**Slot expansion is lazy, not eager.** Recurring rule expansion happens at query time with a bounded lookahead window (default 90 days), not at creation time. Eager expansion into rows causes table bloat that degrades conflict detection at scale.

**Optimistic concurrency on bookings.** Slot rows carry a `version` integer. A booking write requires the version to match; on mismatch, the client retries. This prevents double-booking without a table-level lock.

**Conflict detection boundary:** The scheduling service owns conflict checking. The approval service may reject a booking, but it does not re-check slot availability. Availability locks must be held until approval resolves or released with a compensating event.

```
availability_lock table
  lock_id        uuid PK
  slot_id        uuid FK
  booking_id     uuid FK
  tenant_id      uuid
  held_until     timestamptz     -- TTL-based expiry
  state          enum('held', 'committed', 'released')
```

---

### 2.3 Workspace and Team Service

**Owns:** workspace CRUD, team membership, workspace-level settings, workspace feature flags.

**Does not own:** user identity, scheduling rules, audit emission.

Workspaces are the multi-tenancy subdivision unit — a single tenant may have many workspaces (departments, regions, product lines). Cross-workspace scheduling requires an explicit grant stored in the authorization service.

Activity feed cursors live here because the feed is workspace-scoped. The feed is **append-only**: no event is deleted or updated in place; corrections are new events. This is a necessary constraint, not a style choice, because the audit trail and the activity feed share the same event backbone.

---

### 2.4 Activity Feed Service

**Owns:** cursor-based feed delivery, workspace event stream, feed subscription state.

**Does not own:** event emission (that belongs to domain services), audit immutability guarantees (those belong to the audit service).

### Cursor model

The feed uses **keyset pagination**, not offset. The cursor encodes the last-seen `(event_id, created_at)` pair, opaque to the client.

```
GET /workspaces/{id}/feed?after=<cursor>&limit=50

Response:
{
  "events": [...],
  "next_cursor": "<opaque>",
  "has_more": true
}
```

Why keyset over offset: at high event volume, offset pagination requires counting rows the client will never read. Keyset pagination costs one index seek per page regardless of history depth. You sacrifice random-access jumps to gain stable, cheap pagination — an acceptable tradeoff because feed consumers nearly always want "what happened since I last checked."

**Feed events are immutable projections.** Domain services emit domain events; the feed service subscribes and projects them into `workspace_feed_events`. If a projection is wrong, emit a correction event rather than updating the original row.

```
workspace_feed_events table
  event_id        uuid PK
  tenant_id       uuid
  workspace_id    uuid
  actor_id        uuid
  event_type      varchar(64)    -- booking.created, approval.rejected, member.added, ...
  payload         jsonb
  created_at      timestamptz    -- indexed, used as cursor anchor
  idempotency_key varchar(128)   -- prevents duplicate projection
```

---

### 2.5 Approval Workflow Service

**Owns:** approval requests, reviewer assignment, approval state machine, escalation timers.

**Does not own:** booking availability, notification dispatch, audit emission.

### Approval state machine

```
PENDING_REVIEW
  -> APPROVED       (reviewer approves)
  -> REJECTED       (reviewer rejects)
  -> ESCALATED      (timer fires, no action taken)
  -> WITHDRAWN      (requestor cancels before decision)
  -> EXPIRED        (booking window passed while pending)

ESCALATED
  -> APPROVED
  -> REJECTED
```

Terminal states: `APPROVED`, `REJECTED`, `WITHDRAWN`, `EXPIRED`.

Every state transition emits a domain event. The scheduling service listens for `approval.approved` and commits the held availability lock. It listens for `approval.rejected` or `approval.expired` and releases the lock. These are the only legal ways to resolve a held lock from outside the scheduling service.

**Reviewer assignment rules** are stored per workspace and evaluated at request time, not at approval time. If rules change after a request is submitted, the original assignment is honored — you do not re-evaluate mid-flight because that would invalidate the audit trail.

**Escalation timers** are background jobs, not cron. Each approval request creates a scheduled job entry with a fire-at timestamp. The job worker claims jobs by `fire_at <= now() AND state = 'pending'` with an advisory lock to prevent double-fire.

---

### 2.6 Audit Trail Service

**Owns:** immutable audit log, compliance export, tamper-evidence chain.

**Does not own:** any domain logic, feed projection, outbound delivery.

The audit trail is **append-only** and **write-once**. No service may update or delete an audit row. Schema migrations may add columns; they may not remove or alter semantics of existing columns.

```
audit_events table
  audit_id        uuid PK
  tenant_id       uuid           -- indexed
  workspace_id    uuid           -- indexed
  actor_id        uuid
  actor_type      enum('user', 'system', 'api_key', 'automation')
  event_type      varchar(128)
  resource_type   varchar(64)
  resource_id     uuid
  before_state    jsonb          -- nullable for creates
  after_state     jsonb          -- nullable for deletes
  ip_address      inet
  user_agent      text
  region          varchar(32)
  created_at      timestamptz
  hash_chain      varchar(64)    -- SHA-256 of (prev_hash || this_row_content)
```

**Hash chain:** each row carries the SHA-256 of the previous row's hash concatenated with this row's canonicalized content. This allows offline verification that no rows were silently deleted or modified. You sacrifice write throughput for tamper evidence; the tradeoff is necessary for compliance use cases.

**Audit emission contract:** domain services do not write audit rows directly. They emit domain events; the audit service subscribes and writes. This means audit coverage cannot be bypassed by a service that forgets to call an audit function — it is structurally guaranteed by the event bus.

Audit events are **retained at minimum 7 years** in the tenant's home region. Deletion requires platform-admin action with a separate authorization step.

---

### 2.7 Outbound Webhook Service

**Owns:** webhook endpoint registry, delivery queue, retry lifecycle, signature generation, delivery receipts.

**Does not own:** event content, tenant data beyond delivery metadata.

### Delivery contract

```
POST <customer_endpoint>
Content-Type: application/json
X-Webhook-ID: <delivery_id>
X-Webhook-Timestamp: <unix_epoch_seconds>
X-Webhook-Signature: hmac-sha256=<sig>
Idempotency-Key: <delivery_id>

{
  "event_type": "booking.confirmed",
  "tenant_id": "<redacted or scoped>",
  "workspace_id": "...",
  "payload": { ... },
  "delivered_at": "<iso8601>"
}
```

**Signature:** `HMAC-SHA256(secret, delivery_id + "." + timestamp + "." + body)`. Customers verify by recomputing. Secret is per-endpoint, rotatable without downtime (grace window accepts both old and new secret during rotation).

### Retry lifecycle

```
delivery_attempts table
  delivery_id     uuid PK
  webhook_id      uuid FK
  tenant_id       uuid
  event_id        uuid
  state           enum('queued', 'in_flight', 'succeeded', 'failed', 'dead_lettered')
  attempt_count   int
  next_attempt_at timestamptz
  last_status     int            -- HTTP status of last attempt
  last_error      text
  created_at      timestamptz
  completed_at    timestamptz
```

Retry schedule: exponential backoff with jitter. Delays: 30s, 2m, 8m, 30m, 2h, 8h, 24h. After 7 failed attempts, move to `dead_lettered`. Dead-lettered deliveries are visible in the tenant dashboard and can be manually replayed.

**Circuit breaker:** if an endpoint returns 5xx on >50% of attempts over a 10-minute window, the circuit opens and deliveries are queued but not attempted. The circuit half-opens after 5 minutes to test. This protects the customer endpoint from thundering retry herds at the cost of delivery latency during outages.

**Customer-facing delivery log** is kept for 30 days. Platform-side retry state is kept until delivery or dead-letter resolution.

---

### 2.8 Background Job Infrastructure (Current Gap — Remediation Required)

The current stack has inconsistent background job behavior. This is a blocking constraint before eventing, webhooks, and escalation timers can be trusted.

**Required remediation before dependent features are released:**

1. **Durable job table** — all jobs are rows in a `background_jobs` table, not in-memory queues or ad-hoc cron. Jobs are claimed with `SELECT ... FOR UPDATE SKIP LOCKED` to prevent double-processing without a central lock manager.

```
background_jobs table
  job_id          uuid PK
  tenant_id       uuid
  region          varchar(32)    -- must match tenant home region
  job_type        varchar(64)
  payload         jsonb
  state           enum('pending', 'claimed', 'succeeded', 'failed', 'dead_lettered')
  attempt_count   int
  fire_at         timestamptz
  claimed_at      timestamptz
  claimed_by      varchar(128)   -- worker instance id
  next_retry_at   timestamptz
  created_at      timestamptz
```

2. **Per-region worker fleet** — each region runs its own worker pool. Workers only claim jobs where `region = <their_region>`. This satisfies data residency: job execution and data access stay in the tenant's home region.

3. **Dead-letter visibility** — dead-lettered jobs are surfaced in an internal ops dashboard. Runbooks are required before any job type goes to production.

4. **Idempotent job handlers** — every job handler must be safe to run twice. The job table prevents double-claim under normal conditions; network partitions can cause double-execution. Handlers check a `processed_at` marker or use a unique constraint on the side-effect row before acting.

---

## 3. Event Bus Design

### Topology

The event bus is **not a message broker in the traditional sense for this stack.** Given the existing relational database, the recommended approach is **transactional outbox** before committing to a managed broker.

```
outbox_events table
  event_id        uuid PK
  tenant_id       uuid
  region          varchar(32)
  aggregate_type  varchar(64)
  aggregate_id    uuid
  event_type      varchar(64)
  payload         jsonb
  created_at      timestamptz
  published_at    timestamptz    -- null until successfully delivered to broker
  publisher_id    varchar(128)   -- worker that published it
```

Domain services write the domain change **and** the outbox row in the same database transaction. A poller publishes unpublished rows to the broker (Kafka, NATS JetStream, or SQS+SNS depending on region). The `published_at` timestamp is set only after confirmed broker acknowledgment.

This solves the current inconsistency: a booking can no longer be committed without an audit event, because both are in the same transaction. You sacrifice broker independence (the DB is in the critical write path) to gain exactly-once-write semantics at the source.

### Event envelope

```json
{
  "event_id": "uuid",
  "tenant_id": "uuid",
  "workspace_id": "uuid",
  "region": "us-east",
  "event_type": "booking.confirmed",
  "schema_version": "1.0",
  "aggregate_type": "booking",
  "aggregate_id": "uuid",
  "actor": { "type": "user", "id": "uuid" },
  "occurred_at": "2025-01-15T10:30:00Z",
  "payload": { ... },
  "correlation_id": "uuid",
  "causation_id": "uuid"
}
```

`correlation_id` traces a business transaction across multiple events. `causation_id` points to the event that caused this one. Both are required for audit reconstruction and debugging distributed workflows.

### Consumer groups

| Consumer | Subscribes to | Behavior |
|---|---|---|
| Feed projector | all domain events | at-least-once, idempotent by `event_id` |
| Audit writer | all domain events | at-least-once, idempotent by `event_id` |
| Webhook dispatcher | configurable per webhook | at-least-once, delivers to outbound queue |
| Approval escalation | `timer.fired` | exactly-once via advisory lock |
| Scheduling lock resolver | `approval.*` | at-least-once, idempotent |

All consumers handle at-least-once delivery. Idempotency keys are `event_id` for projection consumers and `delivery_id` for outbound delivery.

---

## 4. Automation Rules (Future Surface — Architecture Must Not Block)

Customer-defined automation rules are not in scope for the current release, but the