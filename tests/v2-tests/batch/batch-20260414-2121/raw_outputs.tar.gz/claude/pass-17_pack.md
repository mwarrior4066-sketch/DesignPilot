## Functional tier

**What we're deciding:** Where should data "live" in your app -- in one central store, or inside the components that need it?

**The simple version:** React components can hold their own data (local state), or you can put shared data in a global store that any component can reach.

**When local state is enough:**
Your app probably doesn't need Redux if most data belongs to one screen, forms reset when you close them, and you're not trying to keep two distant parts of the UI perfectly synchronized at all times.

**When a global store helps:**
You need one when many unrelated components need the same data, when that data changes frequently from multiple places, or when you need to replay, undo, or audit what happened. The cost is real: you're adding a new mental layer -- actions, reducers, selectors -- that every contributor has to understand.

**Context as a middle option:**
React's built-in Context is useful for slow-moving shared data like the logged-in user, a theme, or a language setting. It's not well-suited for data that changes often, because every component that reads from a context re-renders when any part of that context changes.

**Governing recommendation:** Use local state by default, promote to Context only for slow-moving globals like auth or theme, and introduce a dedicated state manager only when you can name a specific coordination problem it solves -- not in anticipation of one.

---

## Integrative tier

**The real tension:** This decision is about rendering cost, mutation ownership, and where bugs are easy to trace -- not just "simple vs. scalable."

**Local state** keeps data close to where it's used. Components are self-contained, easier to test, and faster to reason about. The problem emerges when two sibling components need the same piece of data and neither owns the other. You start lifting state up the tree, and prop drilling begins. At some depth, this becomes a maintenance burden.

**Context** solves prop drilling without a library, but it carries a hidden rendering cost. When the context value changes, every subscribed component re-renders -- because Context uses reference equality, not structural diffing. You can split contexts by update frequency to mitigate this, but the discipline required often catches teams off guard.

**Redux (or Zustand, Jotai, Recoil)** solves the subscription problem properly. Components subscribe only to the slices they use, so a change in one slice doesn't re-render unrelated components. You also get time-travel debugging, predictable mutation flow, and a clear audit trail. The architecture tax is: you now have a separate data layer with its own conventions, and every new feature requires touching actions, reducers, and selectors in addition to the component.

**The real question to ask:** Is the data shared across distant components, does it change frequently, and does it need to stay consistent across simultaneous UI surfaces? If yes to all three, local state will cause real problems -- not hypothetical ones. If the answer is mostly no, Redux adds overhead without a corresponding payoff.

**Server state is a separate axis:** If your "global state" is really server-fetched data -- users, products, results -- a library like React Query or SWR owns that problem better than Redux does. Redux was never designed to be a cache for remote data. Mixing them creates two sources of truth for the same fact.

**Governing recommendation:** If your coordination problem is server data, adopt React Query or SWR and keep UI state local; if your coordination problem is genuinely shared client state that changes frequently across distant components, adopt a selector-based manager like Zustand before Redux because its architecture tax is lower for most team sizes.

---

## Strategic tier

**The architecture question underneath:** Where does state authority live, and who owns mutations?

Global state managers impose a single authority model: one store, explicit mutations, predictable read paths. That model earns its cost when multiple UI surfaces must stay consistent in real time, when mutation sequences need to be auditable, or when optimistic updates require reconciliation. Below that threshold, the model adds indirection without a corresponding reduction in bug surface.

**Rendering model is the constraint that most teams ignore:**

Context re-renders all subscribers on any value change -- reference equality, not structural diff. The performance ceiling is hit faster than teams expect, and the fix (splitting contexts, memoizing values, using `useMemo` on the provider value) requires deliberate discipline to enforce in a growing codebase. Selector-based managers -- Zustand, Jotai, Redux Toolkit with `useSelector` -- solve this structurally: components subscribe to slices, not the whole store, so the rendering boundary is owned by the data shape, not the team's memoization hygiene.

**The server-state boundary is where most Redux adoptions are wrong:**

Remote data has its own consistency requirements -- stale-while-revalidate, cache invalidation, background refetch, optimistic mutation rollback. Redux solves none of these natively. Teams that put server data in Redux end up writing thunks that partially duplicate what React Query or SWR give for free, then maintaining two mutation paths. The correct boundary: React Query or SWR owns server state; client-side UI state that does not derive from the server (modal open/closed, active tab, draft form state, multi-step wizard position) belongs in local state or a lightweight client store.

**Architecture tax is the real cost comparison:**

Redux Toolkit has reduced boilerplate significantly, but it still requires: a store setup, slice files per domain, selector definitions, and a team convention for where async logic lives. Zustand reduces that to a single hook file with explicit setters. For most product teams under ~15 engineers, Zustand's surface area is correct. Redux Toolkit's structure pays off when the team is larger, the domain is complex enough to need slice isolation, and DevTools traceability is a real debugging requirement -- not a theoretical one.

**Governing recommendation:** Adopt React Query for server state, default to local component state for UI state, and introduce Zustand if and only if you have a named client-state coordination problem that causes actual bugs -- defer Redux Toolkit until team size, domain complexity, or audit requirements make its architecture overhead worth carrying.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: selector-based subscription preferred over context for frequently-changing shared state",
    "state_ownership: server state owned by React Query or SWR; client UI state owned by local component state by default",
    "boundary_placement: global store introduced only when a named coordination problem causes real bugs",
    "cost_or_degraded_path: Redux Toolkit deferred until team size or audit requirements justify architecture tax"
  ],
  "evidence_classes_cited": [
    "rendering_cost_constraint",
    "reference_equality_behavior",
    "architecture_tax_comparison",
    "server_state_cache_requirements"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]