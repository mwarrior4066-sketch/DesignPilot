## PDF Remediation Plan

**Governing route:** `rt_pdf_remediation` with `document-accessibility-expert` as primary skill, `pdf-layout-expert` supporting frame and structure integrity.

---

### What this plan addresses

You have four distinct failure classes in one document. They need to be resolved in dependency order because fixing reading order before tagging is done correctly will undo the tagging work, and fixing TOC links before the tag tree is stable risks re-breaking the links on export.

---

### Failure audit

**Semantic failures (blocking)**

The decorative images currently have no tag treatment, which means a screen reader will either announce them as unlabeled figures or attempt to read them as content. Neither is acceptable. They need to be marked as `Artifact` so the accessibility tree ignores them entirely.

The tag tree from InDesign is almost certainly a flat or shallow `<P>` dump. Two-column InDesign documents export in frame order, not reading order, unless thread frames were carefully defined before export. If your text frames were independent rather than threaded, the tag tree reflects frame Z-order, not column flow. This is the root cause of the broken reading order.

Pull quotes are a structural ambiguity: if they are tagged as `<P>` inline with the body text, they interrupt the primary narrative at the wrong position. If they repeat text from the body, they may also create redundant announcement for screen reader users.

**Reading order and extraction failures**

Screen readers follow the tag tree, not the visual column order. For a two-column layout, the left column should be read completely before the right column begins. In InDesign, this is controlled by the Articles panel (which defines reading order for tagged export), not by visual position.

If the Articles panel was empty or unused, the PDF tag tree defaults to frame creation order or layer order, which rarely matches visual column flow.

**Navigation failure**

Broken TOC links in InDesign PDFs typically have one of two causes: the TOC style was not mapped to a paragraph style that persists through export, or the file used `Interactive` PDF export instead of `Print` PDF export with the Hyperlinks option checked. A third cause is that the TOC was built manually with tab leaders rather than using the `Layout > Table of Contents` feature, in which case there are no live links at all.

---

### Repair sequence

Correct order matters. Do not jump to step 4 before steps 1 and 2 are stable.

**Step 1 — Establish correct frame threading in InDesign (before re-export)**

If your body text frames are not threaded into a continuous story, thread them now: left column frame 1 to right column frame 1, then left column frame 2 to right column frame 2, continuing through the document. Pull quotes should be in separate, unthreaded frames so they sit outside the primary story thread.

This is the structural fix that makes everything downstream reliable. Without it, re-export will produce the same broken tag tree.

**Step 2 — Set the Articles panel reading order**

Open the Articles panel (`Window > Articles`). Add your primary story thread(s) as the first article. Add pull quote frames after the body text article, or omit them from the article entirely if they are pure visual decoration repeating content already in the body. Add any secondary content (sidebars, captions) in their correct narrative positions.

Check `Use for Reading Order in Tagged PDF` in the Articles panel options. This is the single most important toggle for two-column tagged export. Without it, the Articles panel has no effect on the tag tree.

**Step 3 — Mark decorative images as non-printing or artifact before export**

For images that carry no informational content, you have two options:

Option A (preferred, in InDesign): Set the image frame to `Object Export Options > Tagged PDF: Artifact`. This instructs the export engine to generate an `Artifact` tag, which screen readers skip. You do not need to do anything in Acrobat afterward for these elements.

Option B (in Acrobat Pro after export): Open the Tags panel, locate each decorative image tag (likely `<Figure>`), right-click and select `Change Tag to Artifact`. Alternatively, use `Accessibility > Reading Order Tool` to select the element and mark it as background.

Option A reduces post-export cleanup. Option B is the fallback if you cannot change InDesign export settings.

For images that do carry informational content but have no alt text, add alt text in InDesign under `Object > Object Export Options > Alt Text` before exporting. Do not leave meaningful figures untagged or with empty alt text.

**Step 4 — Fix the TOC before re-export**

If you used `Layout > Table of Contents` in InDesign:
- Confirm the TOC is built from a paragraph style, not manual tabs.
- Re-export as `Adobe PDF (Print)`, not `Adobe PDF (Interactive)`, and check `Hyperlinks` and `Bookmarks` in the export dialog under the General tab.
- After export, verify in Acrobat that the Bookmarks panel is populated. If the TOC entries appear as bookmarks, the link mechanism is intact.

If the TOC was built manually with tab leaders:
- It cannot produce live links. You need to rebuild it using `Layout > Table of Contents` with a proper TOC style, or repair the links manually in Acrobat Pro using `Edit > Links > Add or Edit`.

**Step 5 — Post-export verification in Acrobat Pro**

After re-export, run these checks in order:

1. `Accessibility > Accessibility Check` (full check). Confirm zero `Figure` elements with missing alt text, zero untagged content, and no reading order warnings.
2. Open the Tags panel and scan the tag tree manually for the first three pages. Confirm left column body text precedes right column body text in tag order. Confirm pull quote tags appear after the body paragraph they follow, not interrupting it mid-sentence.
3. Use `View > Read Out Loud` in Acrobat to do a real-time listen of the first page and one interior spread. This surfaces ordering problems that the automated check misses.
4. Click each TOC entry to confirm the link is live and resolves to the correct page.
5. Confirm decorative images are absent from the Tags panel or marked `Artifact` — they should produce no announcement in Read Out Loud mode.

**Step 6 — If full re-export is not possible**

If you cannot modify the InDesign source and must repair the exported PDF directly in Acrobat Pro:

- Use the `Reading Order` tool to manually drag and reorder content regions until the left-to-right, top-to-bottom column sequence is correct. This is slow and error-prone for long documents but is the only available fallback.
- Use the Tags panel to promote, demote, or reorder tags directly. Tag tree edits in Acrobat are persistent but are overwritten if you re-export from InDesign, so document which changes were made.
- Mark decorative figures as artifacts using `Change Tag to Artifact`.
- Add missing alt text directly in the Tags panel by selecting the `<Figure>` tag, opening Properties, and entering alt text in the `Alternate Text` field.
- Repair broken TOC links with `Edit > Links`. This is the correct fallback path if InDesign source is unavailable, but prefer re-exporting with correct hyperlink settings.

---

### Destructive shortcuts rejected

**Rejected: running the Acrobat auto-tag repair tool as the primary fix.** Auto-tagging on a complex two-column layout will re-sequence content by bounding-box geometry, not by story thread, and is likely to reintroduce the same column-order problem you are trying to fix. It also strips any manually set artifact tags.

**Rejected: flatten-to-single-column workaround.** Reflowing the layout into a single column to avoid the threading problem destroys the document's visual design integrity and is not an accessibility remediation strategy.

**Rejected: "tag all images as Figure with empty alt."** Empty alt text on a `<Figure>` tag causes some screen readers to announce the file name or a generic "graphic" label. Either provide meaningful alt text or tag the element as `Artifact`. There is no acceptable middle path for production documents.

---

### Verification method

The document passes remediation when:

- Acrobat Accessibility Check returns zero failures on Figure alt text, reading order, and tagged content
- Manual tag tree inspection confirms column-correct tag sequence for at least three spreads
- Read Out Loud completes a full page without announcing decorative elements or jumping columns mid-sentence
- Every TOC link resolves to the correct destination page
- NVDA or VoiceOver confirms the heading structure is navigable and pull quotes do not interrupt body text mid-paragraph

Spot-check with a real screen reader (NVDA on Windows or VoiceOver on Mac) at the end. Acrobat's own checker does not catch every reading-order failure in practice, and the Read Out Loud tool uses Acrobat's internal TTS engine, which can differ from third-party screen reader behavior on ambiguous tag structures.

---

### What you preserve vs. what you accept

You preserve the two-column visual layout entirely. The remediation happens at the tag tree and export settings layer, so the printed and screen appearance of the PDF does not change.

You accept that if the TOC was manually built without InDesign's TOC feature, rebuilding it is not a quick fix. That step requires going back into InDesign and establishing proper paragraph-style-based TOC generation before the link repair is reliable.

If InDesign source access is unavailable, you accept that Acrobat-only remediation is slower, more fragile, and will be overwritten on any future re-export. Document those manual Acrobat edits and store them as a repair log alongside the file.

[SESSION_STATE]
{
  "route": "rt_pdf_remediation",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_failure: decorative images must be tagged as Artifact, not left untagged or given empty alt text",
    "reading_order_or_extraction: reading order failure is caused by unthreaded frames and unused Articles panel; fix must happen in InDesign before re-export",
    "verification_method: Acrobat Accessibility Check + manual tag tree inspection + Read Out Loud + real screen reader spot-check",
    "destructive_shortcut_rejected: auto-tag repair, flatten-to-single-column, and empty alt text all rejected as primary fixes"
  ],
  "evidence_classes_cited": [
    "wcag_figure_alt_text_requirement",
    "indesign_articles_panel_reading_order_control",
    "acrobat_artifact_tag_behavior",
    "pdf_export_hyperlinks_dialog_requirement"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the InDesign source file available for re-export, or is Acrobat-only repair required?",
    "Was the TOC built using Layout > Table of Contents with paragraph styles, or manually with tab leaders?",
    "Are the pull quotes repeating body text verbatim, or carrying unique content?"
  ],
  "turn": 1
}
[/SESSION_STATE]