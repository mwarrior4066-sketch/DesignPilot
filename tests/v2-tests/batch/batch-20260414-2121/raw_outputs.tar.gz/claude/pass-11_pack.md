Layout reconstruction from a legacy brand PDF is a good fit for a structured extraction-then-translation process. Here is how I would approach it.

---

## What to extract from the PDF

### Grid structure
- Column count per layout type (editorial spread, single page, cover, etc.)
- Margin values: top, bottom, inside/outside or left/right
- Gutter width between columns
- Whether gutters are symmetric or asymmetric
- Any bleed or safe-zone specifications

### Measurement system
- Unit basis: millimeters, points, picas, or inches
- Whether there is an underlying baseline grid (usually stated in body text leading, e.g., 12pt or 14pt)
- Whether measurements are expressed as fixed values or as fractions of the page width

### Type scale references
- Body text size and leading from the diagrams or running text
- Heading sizes if shown at scale in examples
- Any stated minimum type sizes for captions or footnotes

### Column logic and span behavior
- How elements break across columns: full-width, half, two-thirds, etc.
- Whether images are allowed to bleed into margins
- Whether pull quotes or callouts use specific span rules

### Spatial relationships
- Consistent spacing increments between sections (often multiples of the baseline)
- Cap height alignment or optical margin alignment cues if diagrams show text starting points
- How columns relate to the binding edge on spreads

---

## What to treat as inferred vs. observed

### Observed (high confidence)
- Stated numeric values that appear in annotation layers or labeled diagrams
- Column count that is directly countable in the layout examples
- Margin values if annotated

### Inferred (medium confidence)
- Baseline grid increment if not stated but derivable from the body text leading
- Gutter width estimated from visual measurement relative to column width
- Type scale ratios estimated from visible size relationships

### Unverified (flag explicitly)
- Interaction or hierarchy rules that are implied by examples but never stated
- Whether the column system applies uniformly or varies by section type

---

## How to translate into a modern layout system

### Step 1: Normalize units
Convert all 2018 values to the unit system you are working in now. If the original is in millimeters and the new templates are web or app, establish a correspondence: the column proportions and margin-to-page-width ratios are what transfer, not the raw millimeter values.

### Step 2: Reconstruct the proportional grid
Express the original grid as ratios rather than fixed numbers. A 3-column layout with 20mm margins on a 210mm page gives you a margin ratio of roughly 9.5%. Apply that ratio to your new format rather than copying 20mm literally, because the output format almost certainly has different dimensions.

### Step 3: Establish a baseline increment
If the original used 12pt leading on body text, the baseline increment is 12pt. In a modern system this becomes your spacing scale anchor. All vertical spacing, section gaps, and heading margins should be multiples of that increment. If you are moving to a digital template (Figma, web, Keynote), map the baseline increment to an 8px or 4px grid and state explicitly which original values round to which grid step, because the conversion will not be lossless.

### Step 4: Define column behavior as named spans
Rather than raw column numbers, name the span types: `full`, `three-quarter`, `half`, `one-third`, `sidebar`. Pull these directly from the span patterns visible in the original layout examples. This gives future template users a vocabulary that matches the original design intent rather than forcing them to count columns manually.

### Step 5: Separate print-specific decisions from transferable ones
Some 2018 choices will not transfer. Bleed values, binding margins, CMYK color stops, and paper-specific optical corrections are print artifacts. Document them as reference, but exclude them from the modern template unless the new output is also print. What does transfer: the proportional column logic, the spatial rhythm, the margin hierarchy.

### Step 6: Document inference boundaries
Anything you measured rather than read from an annotation should be marked as an estimate with a tolerance note. For example: "Gutter inferred at approximately 5mm from visual inspection, ±1mm." This protects whoever inherits the system from treating inferred values as authoritative.

---

## Output artifacts to produce

- A grid specification sheet per layout type (page, spread, cover, interior)
- A named span reference with column span rules and examples
- A spacing scale anchored to the baseline increment
- An inference log noting which values were stated vs. estimated
- A migration note listing print-specific values excluded from the modern system

---

## Practical constraint

If the PDF is image-based rather than a live document with real annotation layers, all measurements will be inferred from pixel ratios, not read from embedded data. In that case, the confidence tier for every numeric value drops, and I would recommend cross-referencing at least one original printed artifact or the source Illustrator/InDesign files if they still exist, because a single pixel-ratio error compounds across the whole system.

Do you have the PDF available to share, or are you working from memory of the content? That changes whether I can run an actual extraction pass or whether this stays at the methodology level.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: proportional column ratios, baseline increment, named span vocabulary, spatial rhythm",
    "inference_boundary: gutter widths and type scale ratios treated as inferred unless annotated; image-based PDF drops all values to estimated",
    "reconstruction_order: normalize units → reconstruct proportional grid → establish baseline increment → define named spans → separate print-only decisions → document inference log",
    "verification_method: cross-reference with original printed artifact or source InDesign/Illustrator files when PDF is image-based"
  ],
  "evidence_classes_cited": ["layout_artifact", "inference_label", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the PDF image-based or does it have live annotation layers?",
    "What is the target output format for the new templates (print, web, presentation, digital doc)?",
    "Are the original source files (InDesign, Illustrator) still available?"
  ],
  "turn": 1
}
[/SESSION_STATE]