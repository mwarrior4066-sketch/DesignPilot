## Architecture review: permissions-heavy scheduling dashboard

The plan has four compounding problems. Each one is manageable alone, but together they create a system where role changes produce stale UI, error states go invisible, keyboard users cannot operate the filters, and optimistic edits to recurring events can corrupt data across the calendar. The fixes below address them in dependency order.

---

### Rendering model

**Current:** single large client-rendered page.

**Problem:** role-based visibility enforced only in the browser means a role change mid-session leaves stale data visible until a full reload. Server-rendering the permission-gated shell closes this window, because the role check runs at request time before any HTML reaches the client.

**Recommendation:** server-render the outer shell and the permission-gated layout using your framework's server component boundary. Table rows that need live filtering can hydrate as a client island at the table boundary, not at the page root. This limits hydration cost to the data surface that actually changes, rather than pulling the entire page into client-side rendering.

The cost is a slightly more complex component boundary and a stricter rule about what props cross the server/client line. You accept that constraint to gain: role enforcement at request time, a smaller hydration bundle, and correct behavior when session roles change.

---

### State ownership

**Current:** separate `isLoading` and `isError` booleans alongside data state.

**Problem:** boolean flags produce illegal state combinations. `isLoading: true` and `isError: true` can coexist. When they do, your UI has no reliable rule for what to render. As the number of async operations grows, the number of impossible states grows with it.

**Recommendation:** model async state as a discriminated union with exactly one active variant at a time.

```typescript
type AsyncState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T }
  | { status: 'error'; error: Error; retryable: boolean };
```

State lives in the server data layer (React Query, SWR, or equivalent). The component switches on `status` and renders exactly one branch. No combination of booleans, no defensive `&&` chains, no silent renders.

The cost of this model is that you cannot reuse generic boolean helpers you may already have. You accept that cost to gain: impossible states become compile-time errors, error boundaries receive typed context, and retry logic has a clean attachment point.

---

### Rendering and mutation strategy for recurring edits

**Current:** optimistic updates applied to recurring edits.

**Problem:** a recurring edit can mean "this occurrence," "this and following," or "all occurrences." The scope of the mutation is not known until the user confirms it, which means the scope of the rollback is also unknown at the time the optimistic update fires. If the server rejects the mutation partway through, you cannot reliably reconstruct which rows to undo.

**Recommendation:** do not apply optimistic updates to recurring event mutations. Use a confirmation modal that forces explicit scope selection before the request fires. The mutation is then a single committed write with a known rollback surface.

```
User edits recurring event
  -> modal: "Edit this event / this and following / all events"
  -> user confirms scope
  -> mutation fires with explicit scope parameter
  -> server responds with affected IDs
  -> cache invalidated for exactly those IDs
```

For single-occurrence edits with no recurrence implications, optimistic updates are safe and appropriate. The boundary is: optimistic updates for bounded, reversible writes only. Recurrence scope selection is unbounded until confirmed.

The cost is one extra modal step in the recurring edit path. You accept that cost to gain: no partial rollback ambiguity, correct cache invalidation, and data integrity across the calendar.

---

### Accessibility: filter chips

**Current:** custom `div` elements used as filter chip buttons.

**Problem:** `div` elements have no implicit role, no keyboard event handling, no focus behavior, and no announced state. A keyboard user cannot reach them. A screen reader user cannot determine whether a chip is selected or unselected.

**Recommendation:** replace every filter chip with a `<button>` element. Use `aria-pressed` for toggle-style chips (on/off) or a `<fieldset>` with `<input type="checkbox">` elements for multi-select filter groups. The `aria-pressed` approach is simpler and correct when each chip independently enables or disables a filter.

```tsx
<button
  type="button"
  aria-pressed={isActive}
  onClick={() => toggleFilter(id)}
  className={isActive ? 'chip chip--active' : 'chip'}
>
  {label}
</button>
```

Keyboard behavior this gives you for free: focusable in tab order, activatable with Space and Enter, announced as a button with pressed/not pressed state. You do not need to implement any of that manually.

The cost is replacing existing markup and any CSS selectors tied to the `div` structure. You gain WCAG 2.1 SC 4.1.2 compliance, correct screen reader announcement, and no custom keyboard handling to maintain.

---

### Server-driven filters

**Current plan context:** filters are server-driven.

**Recommendation:** keep filter state in the URL (query string), not in component-level state. Server-driven filters paired with URL state means the filter surface is shareable, bookmarkable, and survivable across refresh. A user can deep-link to a filtered view. A role change that triggers a server redirect lands on the correct filtered state rather than losing the filter context.

When a filter changes, push to the URL and let the server component re-render with the new params. The client island re-fetches or rehydrates from the updated URL. No filter state lives in React state.

---

### Permissions architecture summary

Role visibility is the most important constraint in this system, and it has to be enforced at the right layer.

| Layer | What it enforces | Why it matters |
|---|---|---|
| Server component shell | Role-gated layout and route access | Prevents stale visibility on role change |
| API responses | Row-level and field-level visibility | Correct even if client-side check fails |
| Client filter state | URL-based, not component state | Survives refresh, shareable, no drift |
| Mutations | Scope-confirmed before firing | No ambiguous rollback surface |

Do not rely on client-side conditional rendering as the primary permissions gate. It is a display convenience, not a security boundary. The API must enforce row-level and field-level visibility independently.

---

### Risks and safer path

The safer path is to implement these in the order they were diagnosed, because each fix reduces the blast radius of the next.

1. **Server/client boundary first.** Until the rendering model is right, all other fixes operate on a foundation that can produce stale permission states.
2. **Discriminated union state second.** This makes error boundaries and retry logic reliable before you add mutation complexity.
3. **Recurring edit confirmation third.** Once state handling is sound, the modal flow is straightforward to implement correctly.
4. **Accessibility last in sequence, but non-negotiable.** The `div`-to-`button` migration is low-risk and can run in parallel, but it cannot ship after the others as a "nice to have."

The main thing you sacrifice with this architecture is speed to a first working prototype. Client-rendering everything with boolean flags and `div` chips will run faster initially. What you gain is a system where role enforcement, state integrity, data correctness on recurring edits, and keyboard accessibility are all structurally guaranteed rather than defended by careful coding conventions.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: server-render permission-gated shell, hydrate table as client island",
    "state_ownership: discriminated union AsyncState<T> replacing boolean flags",
    "boundary_placement: server/client split at table boundary not page root",
    "semantic_contract: button with aria-pressed for filter chips, not div",
    "cost_or_degraded_path: optimistic updates scoped to single bounded writes only, not recurring edits"
  ],
  "evidence_classes_cited": [
    "wcag_sc_4_1_2",
    "discriminated_union_state_model",
    "server_component_boundary",
    "url_as_filter_state",
    "recurrence_scope_confirmation_pattern"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Which framework is in use? Next.js App Router, Remix, and SvelteKit each have different server/client boundary mechanics that affect implementation specifics.",
    "Is row-level visibility enforced at the API layer currently, or only in the client rendering logic?"
  ],
  "turn": 1
}
[/SESSION_STATE]