## What to extract from the PDF

Before any translation work, the extraction pass separates what the PDF actually shows from what must be inferred. These are different confidence classes and they drive different decisions downstream.

### Directly extractable (high confidence)

**Grid measurements**
Pull these as literal values where they appear labeled:
- margin values (top, bottom, left, right — they are often asymmetric in brand docs)
- column count per format
- gutter width
- column width, if explicit
- any baseline or cap-height references in type specimens

**Format definitions**
- named page formats (A4, letter, slide format, etc.)
- whether the system is print-only, screen-only, or both
- any stated bleeds or safe zones

**Layout examples**
- how many distinct column configurations appear (full-width, half, thirds, etc.)
- whether grids are fixed-width or proportional
- which layout zones are anchored (logo lockup, headline field, body field, footer band)

**Typography evidence**
- named typefaces in specimens
- approximate scale relationships between display and body (even if exact sizes are not labeled)
- column width as a constraint on line length

---

### Inferred from visual evidence (medium confidence — label these explicitly)

When the PDF was produced in a design application and exported as a non-tagged visual document, measurements not explicitly labeled must be inferred from proportional relationships. Flag these:

- **Inferred column count**: count the implied columns from diagram markers or text placement; note confidence level
- **Inferred gutter ratio**: if gutters are not labeled, estimate from column-width-to-gutter proportion; name the assumption
- **Inferred baseline grid**: look for consistent vertical spacing between text blocks; if you see it, it is almost certainly a 4 pt, 6 pt, or 8 pt increment — name which you are assuming
- **Proportional vs fixed intent**: 2018 brand guidelines were often print-first with fixed measurements; screen application may have been an afterthought or may not exist at all

---

### Not extractable from pixels alone

Be explicit about this boundary:
- you cannot confirm responsive breakpoint behavior from a print PDF
- you cannot confirm font licensing scope from a specimen
- you cannot confirm whether the grid was built in InDesign, Illustrator, or another tool (affects how to re-specify it)
- you cannot confirm intent for digital formats if the doc predates them

---

## Translation into a modern layout system

This is where the interesting tradeoffs live.

### Step 1 — Decide what you are preserving vs. modernizing

A 2018 brand doc likely assumed:
- fixed-width print or presentation formats
- one or two device contexts at most
- no token-based design system

You are accepting that some original specificity will not survive the translation. The tradeoff is: you sacrifice exact pixel fidelity to legacy templates in exchange for a system that is consistent across responsive contexts.

Name which elements are sacred (logo field proportions, headline margin ratios, characteristic column structure) versus which are negotiable (exact pixel values that made sense only for A4 letter-size print).

---

### Step 2 — Build a canonical spacing unit

If the original grid used a baseline increment (8 pt is common for print guides from this era), translate that to a base unit for the new system.

For a modern token-based system, you want:
- base unit: 8 px (maps well from 8 pt if the original was print at 96 dpi equivalence)
- spacing scale: 4, 8, 12, 16, 24, 32, 48, 64 — or a tighter subset if the brand was more restrained
- this unit then governs margins, padding, gutter widths, and component spacing consistently

The constraint is: the original gutter and margin proportions should survive as ratios, even if exact values shift. If the original had a 2:1 margin-to-gutter ratio, the new system should preserve that relationship.

---

### Step 3 — Reconstruct the column grid per format

For each format in the original (print, slide, web, if applicable):

| Original format | Inferred column count | Inferred margin | Gutter | Modern equivalent |
|---|---|---|---|---|
| A4 print | (from extraction) | (labeled or inferred) | (labeled or inferred) | Document / editorial template |
| Presentation slide | (from extraction) | (labeled or inferred) | (labeled or inferred) | 16:9 slide grid |
| (any web comps if present) | (from extraction) | (labeled or inferred) | (labeled or inferred) | Responsive breakpoint grid |

For web contexts that did not exist in the original, you will need to design the responsive behavior. The principle is to extrapolate from the proportional logic, not invent something new. If the original used a 12-column structure, the responsive cascade (12 → 8 → 4) is defensible as an extension of the same system. If the original was 9-column editorial, you have a judgment call about whether to keep the odd column count or normalize it.

---

### Step 4 — Translate margin intent, not just margin numbers

A common mistake is copying the raw margin number from a print spec into a web context. Print margins at 20mm have a different perceptual weight at 210mm page width than the same number in pixels at a 1440 px viewport.

The right move: translate the proportional relationship.
- if the original left margin was roughly 10% of page width, apply that ratio to your primary viewport width
- this preserves the original spatial feeling rather than forcing legacy print dimensions into an unrelated medium

---

### Step 5 — Document the confidence boundary in the new spec

The new layout system should carry a note on which values are confirmed from the original and which are inferred or adapted. This protects future contributors from treating your reconstruction as if it were the canonical original.

Something like:
- "Column count confirmed from labeled diagram on page 6 of the 2018 guidelines"
- "Gutter width inferred from proportional analysis; original measurement not explicitly labeled"
- "Baseline grid unit assumed to be 8 pt based on consistent vertical rhythm in body text specimens; not explicitly documented in original"

---

## What to do if the PDF is image-based

If the PDF is scanned or flattened to images rather than native vector/layout content, the extraction becomes harder:

- use a ruler or grid overlay tool to take proportional measurements from the diagram images
- note that pixel measurements from a screen view of a scanned page are unreliable unless you know the original page dimensions exactly
- label all values as inferred and note the measurement method
- treat the confidence level as medium at best for any numeric extraction

This matters because you do not want to build a new design system on measurements that are actually off by 15% because the original was scanned at a non-standard resolution.

---

## What you get out of this

After the extraction and translation pass you should have:

- a named spacing unit with a documented origin
- a column grid spec per format with confidence labels
- a margin-to-gutter ratio preserved from the original
- a set of canonical layout zones mapped from the original examples
- an explicit list of what was preserved, what was adapted, and what was invented

That last list is the thing that makes the new system honest. The tradeoff is transparency about reconstruction limits in exchange for a system that can actually scale to formats the original never anticipated.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: column proportions, margin-to-gutter ratios, baseline increment, layout zone structure",
    "inference_boundary: pixel measurements from image-based PDF flagged as medium confidence; gutter and baseline values labeled as inferred when not explicitly labeled",
    "reconstruction_order: extract confirmed values first, then infer proportional relationships, then translate to modern token-based system per format",
    "verification_method: confidence labels in new spec documenting confirmed vs inferred vs adapted values"
  ],
  "evidence_classes_cited": [
    "proportional_analysis",
    "confidence_boundary_labeling",
    "format_translation_rationale"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the PDF native vector/layout content or scanned/image-based? This changes measurement reliability significantly.",
    "Which formats need modern equivalents — web responsive, presentation, document, all three?",
    "Are the original typefaces still licensed and in use, or is the type system also being updated?"
  ],
  "turn": 1
}
[/SESSION_STATE]