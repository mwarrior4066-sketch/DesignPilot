## Backend Feasibility Review: Real-Time Collaboration

---

### Hidden System Requirements

Before a single line of collaboration code ships, these dependencies exist whether your design acknowledges them or not.

**Transport and connection infrastructure**

REST is request-response. Real-time collaboration requires a persistent connection. You need either WebSockets (lower latency, stateful) or Server-Sent Events (simpler, one-way). WebSockets are the correct choice here because you need bidirectional messaging: cursor broadcasts go server-to-client, edits go client-to-server, acknowledgments flow both ways. Your current REST infrastructure does not provide this. You need a WebSocket server, a connection registry (which user is connected to which document), and a process for cleaning up stale connections.

**Operational transformation or CRDT engine**

Concurrent edits on the same document cannot be resolved by "last write wins." If User A inserts a character at position 5 while User B deletes position 3, the positions themselves shift. You need a conflict resolution algorithm. The two main choices are:

- Operational Transformation (OT): transforms operations relative to each other before applying. Mature, well-understood, but complex to implement correctly. Libraries like ShareDB use this.
- CRDTs (Conflict-Free Replicated Data Types): data structures that merge automatically without coordination. Yjs and Automerge are the dominant options. Yjs in particular has strong editor integration (ProseMirror, TipTap, CodeMirror).

Without one of these, concurrent edits will corrupt document state silently.

**Presence and cursor state**

Cursor positions are not document state. They are ephemeral awareness data. Storing them in PostgreSQL creates unnecessary write amplification. Cursor positions change dozens of times per second per user. You need a separate ephemeral channel, typically a pub/sub layer. Redis with pub/sub or Redis Streams is the standard choice. Cursor state does not need persistence across sessions; it needs low-latency broadcast.

**Session and identity model**

Your REST API likely uses stateless JWT or session tokens. WebSocket connections are long-lived and stateful. You need to authenticate the initial WebSocket handshake, associate the connection with a user identity, handle token expiry gracefully during an open session, and reconnect without losing document state. If your current auth model is not designed for long-lived connections, this is a non-trivial migration.

**Persistence and durability contract**

With OT or CRDTs, your source of truth shifts. You cannot simply store the final document text after each keystroke. You must decide whether you store the operation log (so you can reconstruct history and replay), the CRDT state (a binary blob that merges correctly), or snapshots plus deltas. PostgreSQL can hold all of these, but your schema and write patterns change significantly. High-frequency small writes require batching or a write buffer. Unbatched per-keystroke writes to PostgreSQL will saturate your connection pool under real usage.

**Authorization at collaboration granularity**

Your current API likely authorizes at the document level: can this user access this document? Real-time collaboration requires object-level checks at connection time and potentially during editing: can this user edit this section, or only comment? Cursor visibility may also be permission-scoped. Deny by default is the correct posture; the collaboration layer must enforce it at the WebSocket handshake, not only at HTTP request time.

---

### Feasibility Assessment

**What works in your favor**

PostgreSQL handles the persistence requirements well. It supports binary blobs for CRDT state, JSONB for operation logs, and row-level locking. Your React frontend can integrate Yjs or ShareDB without replacing your existing component model. Mature libraries (Yjs, ShareDB, PartyKit, Liveblocks) have solved the hardest algorithmic problems so you do not need to write OT or CRDT logic from scratch.

**Explicit blockers**

| Blocker | Severity | Why it blocks |
|---|---|---|
| No persistent transport layer | Hard | REST cannot carry real-time sync. WebSocket infrastructure must be built or adopted before any collaboration feature ships. |
| No conflict resolution algorithm | Hard | Without OT or CRDT, concurrent edits will silently corrupt documents. This is not a polish concern, it is a correctness concern. |
| No ephemeral state channel | Hard | Cursor broadcasting at keystroke frequency over PostgreSQL writes will not scale. Redis pub/sub or equivalent is a prerequisite, not an optimization. |
| Auth model not designed for long-lived connections | Moderate | Token expiry mid-session will drop connections without a reconnection and re-auth strategy. This must be designed before launch, not patched after. |
| Write amplification to PostgreSQL | Moderate | Unbuffered per-keystroke persistence will exhaust your connection pool. Batching or a write buffer is required before any real traffic. |
| Undefined persistence contract | Moderate | Without a decision on operation log vs. CRDT state vs. snapshot-delta, your schema cannot be built. This decision must precede implementation. |

**What you are accepting by building this**

You are adding a stateful, long-lived infrastructure layer to a stateless REST application. This increases operational complexity permanently: WebSocket servers do not scale horizontally the same way REST servers do (sticky sessions or a shared connection registry is required), and your observability stack needs to cover connection counts, message latency, and sync lag, not just HTTP response times. This is the right tradeoff if real-time collaboration is a core product requirement. It is the wrong tradeoff if "live collaboration" means something lighter, like shared comments or turn-based locking.

---

### Safer Implementation Path: Phased Recommendations

**Phase 1: Resolve blockers before writing collaboration code**

- Decide on a conflict resolution approach. For most product teams building on top of an existing rich-text or structured editor, Yjs is the lower-risk choice because it integrates directly with TipTap and ProseMirror, handles merge logic automatically, and has an active ecosystem. ShareDB (OT-based) is appropriate if you need a server-authoritative model with strict operation history.
- Choose your transport layer. For most teams, adopting a managed real-time service (Liveblocks, PartyKit) in phase 1 is lower risk than building a raw WebSocket server, because connection management, presence, and scaling are handled for you. If you must self-host, use a dedicated Node.js WebSocket process separate from your REST API server.
- Decide on your persistence contract before writing schema migrations. If you choose Yjs, you will store the Yjs document state (binary, via `Y.encodeStateAsUpdate`) plus periodic snapshots. Define how long you retain operation history and what your snapshot interval will be.
- Add Redis before writing the cursor broadcast layer. Even if you defer cursors to phase 2, you need the pub/sub infrastructure in place before presence features land.

**Phase 2: Implement document sync with a single document as the proof of concept**

- Ship WebSocket connection handling with auth at the handshake. Validate the token before the connection is accepted, not after the first message. Only `session owner` or users with edit permission may open a sync connection; deny by default.
- Implement document load via the CRDT state stored in PostgreSQL, not by fetching the document text. The CRDT state is the source of truth from this point forward.
- Batch writes. Do not write to PostgreSQL on every operation. Buffer operations for 500ms to 2s, then flush. Use a background job or debounce mechanism. The blocking constraint here is connection pool saturation: without this you cannot proceed to multi-user load.
- Add `trace_id` on all sync errors. When a merge conflict surfaces or a connection drops mid-edit, you need to reconstruct what happened. Observability on the sync layer is not optional.

**Phase 3: Add presence and cursor state**

- Broadcast cursor positions through Redis pub/sub, not through the document sync channel. These are separate concerns: document mutations have a correctness requirement; cursor positions have a latency requirement. Mixing them couples two very different failure modes.
- Cursor state should not be persisted to PostgreSQL. It lives in Redis with a TTL. When the user disconnects, the cursor disappears automatically.
- Design the reconnection flow before shipping presence to users. A user who loses connectivity mid-session should rejoin and receive the current CRDT state without losing their own uncommitted changes (Yjs handles this with its offline-first merge model).

**Phase 4: Horizontal scaling and operational hardening**

- WebSocket servers require sticky sessions or a shared connection registry when you run multiple instances. Without sticky sessions, a user's WebSocket message may land on a server that does not hold their connection state. This is the cost of this approach: you sacrifice simple horizontal scaling in exchange for real-time sync. Address it with a Redis-backed connection registry or a managed layer before you hit this at production scale.
- Add monitoring for: active connection count per document, message delivery latency, sync lag (time between an edit on one client and its appearance on another), and reconnection rate. These are the four metrics that will tell you whether the system is healthy.
- Define your conflict audit trail. If two users produce a merge that results in unexpected output, can you reconstruct what happened? Operation logs stored in PostgreSQL answer this. Decide retention policy before launch.

---

**What this does not cover**

This review covers the backend system constraints. The UX of cursor rendering, user avatar display, offline indicators, and permission-based awareness visibility are front-end and product decisions that belong in a separate UI review once the system contract is settled.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "data_dependency: CRDT state (Yjs Y.encodeStateAsUpdate) as persistence source of truth over raw document text",
    "permissions_dependency: deny by default at WebSocket handshake; object-level authorization required",
    "system_surface_dependency: Redis pub/sub for ephemeral cursor state; PostgreSQL for CRDT state and snapshots",
    "blocking_constraint: no persistent transport layer, no conflict resolution algorithm, no ephemeral state channel"
  ],
  "evidence_classes_cited": [
    "system_surface_dependency",
    "permissions_dependency",
    "blocking_constraint",
    "data_dependency"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is rich-text editing the document model, or structured/JSON content? This affects the Yjs vs ShareDB recommendation.",
    "Is managed real-time infrastructure (Liveblocks, PartyKit) acceptable, or is self-hosted required?",
    "What is the expected concurrent-user count per document? This affects write buffer sizing and connection registry design."
  ],
  "turn": 1
}
[/SESSION_STATE]