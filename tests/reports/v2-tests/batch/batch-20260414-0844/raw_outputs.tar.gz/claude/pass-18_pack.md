## API Review: POST /api/v1/projects/{id}/members

---

### 1. Status code on successful creation

**Governing decision:** Return `201 Created`, not `200 OK`, because this operation creates a new resource (a membership record), not a mutation of an existing one.

`200` signals that something was updated. `201` signals that something was added to a collection. The distinction matters for downstream consumers, logging systems, and API clients that branch on status codes. Returning the created membership object in the response body is more useful than returning the full member list, because the caller's immediate interest is the outcome of their specific action, not a potentially large payload they didn't ask for.

---

### 2. Response payload

**Governing decision:** Return the created membership resource, not the full updated member list.

The full list is a read concern. Returning it on a write conflates two responsibilities and grows the payload unboundedly as the project scales. If a caller needs the updated list, they should `GET /api/v1/projects/{id}/members`. The write response should confirm exactly what was created, nothing more.

---

### 3. Idempotency

**Governing decision:** This endpoint requires an idempotency contract because the operation has real-world side effects that should not duplicate silently on retry.

Without an `Idempotency-Key` header, a network timeout that causes the client to retry will add the user twice if the first request succeeded but the response was lost. The correct contract: accept an `Idempotency-Key` header, return `409 Conflict` (or replay the original `201`) if the same key is replayed, and store the key with a TTL long enough to cover normal retry windows (24 hours is a reasonable default). The server bears the deduplication responsibility, not the caller.

---

### 4. Error response format

**Governing decision:** Structured error responses are required. Plain strings fail the machine-readability contract that API consumers depend on.

Replace the plain string with RFC 9457 Problem Details:

```json
{
  "type": "https://yourdomain.com/errors/member-already-exists",
  "title": "Member already exists",
  "status": 409,
  "detail": "User 42 is already a member of project 17.",
  "instance": "/api/v1/projects/17/members"
}
```

This gives clients a stable `type` URI they can branch on programmatically, a human-readable `title` they can surface in logs, and a `detail` field scoped to the specific request. It also carries a `trace_id` at the transport layer when your infrastructure injects it. Plain strings are only consumable by a human reading logs, not by an SDK, a monitoring pipeline, or a downstream service.

---

### 5. Authorization

**Governing decision:** Object-level authorization is required. Authentication (is the caller logged in?) is a necessary condition but not a sufficient one.

Checking only that the caller is authenticated is a BOLA (Broken Object-Level Authorization) vulnerability. Any authenticated user could add members to any project they do not own or administer. The correct check is: only a project admin or owner of `{id}` may invoke this endpoint. Deny by default. The authorization gate must run before any data mutation, not after. The recommended enforcement structure is:

1. Is the caller authenticated? If no, `401 Unauthorized`.
2. Does project `{id}` exist? If no, `404 Not Found` (do not leak existence to unauthenticated callers).
3. Is the caller a project admin or owner of `{id}`? If no, `403 Forbidden`.
4. Is the target user already a member? If yes, replay idempotent response or return `409`.
5. Create the membership.

Step 3 is the object-level authorization check. Skipping it means every authenticated user in your system is effectively a project admin.

---

### Summary table

| Concern | Current behavior | Required change |
|---|---|---|
| Status code | `200 OK` | `201 Created` |
| Response payload | Full member list | Created membership resource only |
| Idempotency | None | `Idempotency-Key` header + deduplication + `409` on replay |
| Error format | Plain string | RFC 9457 Problem Details with `type`, `title`, `status`, `detail` |
| Authorization | Authentication only | Object-level check: only project admin or owner may add members |

The authorization gap is the highest-severity issue. It should be treated as a security defect, not a backlog improvement.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "standard",
  "decisions_committed": [
    "status_code: 201 Created for resource creation",
    "response_payload: created membership resource, not full list",
    "idempotency_contract: Idempotency-Key header with 409 on replay",
    "error_format: RFC 9457 Problem Details",
    "authorization_perimeter: object-level check required, deny by default, BOLA remediation"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "idempotency-key header",
    "409 on duplicate",
    "BOLA check",
    "object-level authorization",
    "deny by default",
    "authorization perimeter",
    "only [role] may"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What TTL policy is acceptable for idempotency key storage in this system?",
    "Should project existence return 404 to unauthenticated callers, or is leaking existence acceptable in this threat model?"
  ],
  "turn": 1
}
[/SESSION_STATE]