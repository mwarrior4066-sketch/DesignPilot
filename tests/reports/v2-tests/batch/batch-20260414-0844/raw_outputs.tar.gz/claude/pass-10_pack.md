## What's working against this poster

The hierarchy problem you've named is real, but it's one symptom of a deeper structural issue: every element is competing at a different layer without a clear reading sequence.

### The hierarchy failure

The title firing first before identity context is established means the reader is processing a name without a frame. For a familiar conference brand, that can work. For anything where the audience needs orientation, the logo should anchor the piece before the title demands attention — not because convention says so, but because the reader's question at first glance is "what is this?" not "what is it called?"

The correction isn't necessarily to move the title down. It's to give the logo enough visual weight to land as the first anchor, then let the title follow. Right now the white center logo is competing with a full-bleed photo for visibility, which means it's probably losing the contrast battle even when it's geometrically centered.

### The photo isn't doing enough work

A city skyline as a background is a generic hospitality signal. It reads as "this event is in a city," which is true of most conferences. The photo earns its place only if it either:
- directly connects to the city or venue in a way the audience will recognize, or
- serves as a mood field with enough visual simplicity to subordinate itself to the type and logo

Full-bleed photography with complex tonal variation almost always fragments type legibility and fights the overlay elements. You're likely getting uneven contrast across the poster surface, which means the logo and title are readable in some regions of the print but not others.

### The date problem

Small gray text in the corner is the information most likely to be the deciding factor for attendance. If someone has context for what the conference is, the date is the thing they're scanning for. Burying it in low-contrast, small text at the corner treats the most action-relevant information as a footnote. It should be elevated — not to dominant size, but to a legible weight and position where it registers without effort.

### What to actually fix, in order

**1. Give the logo contrast independence from the photo.** White on photo almost never survives at distance. A contained zone — a translucent background panel, a geometric shape, a negative space region — lets the logo hold without fighting the image.

**2. Establish a reading sequence.** The intended order is probably: logo → title → date → location. The current layout doesn't enforce that. The title and logo are at competing scales without a clear winner, and the date is invisible.

**3. Earn the photo or replace it.** If the skyline is the host city and the audience will recognize it, keep it and commit — make it the emotional backdrop with deliberate darkening or a color treatment that subordinates it. If it's stock, replace it with a typographic or geometric treatment that gives the layout full tonal control.

**4. Reconsider the decorative typeface.** Decorative type at poster scale needs to survive reduced size (social share, print thumbnail, event listing). If the letterforms are complex at large size, they'll deteriorate fast at smaller reproduction sizes. A display cut of a strong typeface, used at confident scale, will outperform decorative type with many strokes or fine details.

### The tradeoff

Fixing the contrast and hierarchy means accepting that the photo will need to recede more than it does now — either through a heavier overlay, cropping, or replacement. The visual drama you gain from a full-bleed image comes at the cost of reliable typographic legibility across every viewing condition and print run. That's the central tension in photography-plus-type poster work, and the type has to win.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "communication_goal: establish event identity before event name",
    "hierarchy_failure: logo lacks contrast independence from photo; date is deprioritized",
    "rebuild_move: give logo a contained contrast zone; enforce logo → title → date reading sequence",
    "distance_tradeoff: full-bleed photo sacrifices typographic legibility to gain visual drama"
  ],
  "evidence_classes_cited": ["contrast_threshold", "reading_sequence", "reproduction_scale"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the city skyline photo the actual host city or stock imagery?",
    "What is the reproduction context — large-format print, digital, or both?"
  ],
  "turn": 1
}
[/SESSION_STATE]