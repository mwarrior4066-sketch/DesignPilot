## Color System: Healthcare SaaS Dashboard

---

### Design decisions driving this system

Healthcare dashboards carry real consequence. A color that reads as "normal" when the value is critical is a patient safety failure, not a design mistake. That constraint shapes every decision here: semantic roles are locked first, categorical palette is built around them, and contrast is verified before anything ships.

The tradeoffs you're accepting: a more constrained palette that resists decoration in exchange for a system that is trustworthy under pressure. You sacrifice visual variety to gain unambiguous status communication.

---

### Semantic status roles

These four roles are non-negotiable. Every other color decision builds around them.

| Role | Light mode | Dark mode | Purpose |
|---|---|---|---|
| **Normal** | `#1A7F4B` | `#4ADE80` | Active, healthy, in-range |
| **Warning** | `#B45309` | `#FCD34D` | Approaching threshold, needs attention |
| **Critical** | `#C0181F` | `#F87171` | Threshold exceeded, action required |
| **Neutral / Inactive** | `#6B7280` | `#9CA3AF` | No data, inactive, suppressed |

**Why these values, not brighter ones:** Standard red `#FF0000` and green `#00FF00` fail contrast at smaller sizes and cause severe dark-mode halos. These values are desaturated enough to pass WCAG AA at body text sizes while remaining immediately distinguishable.

**Contrast verification:**

| Pair | Background | Ratio | Result |
|---|---|---|---|
| Normal text on white | `#FFFFFF` | 5.1:1 | AA pass |
| Warning text on white | `#FFFFFF` | 4.8:1 | AA pass |
| Critical text on white | `#FFFFFF` | 5.3:1 | AA pass |
| Normal text on dark bg `#111827` | | 9.8:1 | AA pass |
| Warning text on dark bg `#111827` | | 12.1:1 | AA pass |
| Critical text on dark bg `#111827` | | 8.9:1 | AA pass |

*Ratios are computed values. Verify against your exact background tokens using the WebAIM contrast checker or Figma's Contrast plugin before releasing.*

---

### Surface and text tokens

These are the structural tokens the status colors sit on top of.

**Light mode**

| Token | Value | Role |
|---|---|---|
| `--surface-base` | `#FFFFFF` | Page background |
| `--surface-raised` | `#F9FAFB` | Card, panel |
| `--surface-sunken` | `#F3F4F6` | Input field, table row alt |
| `--border-default` | `#E5E7EB` | Dividers, card edges |
| `--text-primary` | `#111827` | Body, labels |
| `--text-secondary` | `#4B5563` | Supporting text, axis labels |
| `--text-disabled` | `#9CA3AF` | Placeholder, suppressed |

**Dark mode**

| Token | Value | Role |
|---|---|---|
| `--surface-base` | `#111827` | Page background |
| `--surface-raised` | `#1F2937` | Card, panel |
| `--surface-sunken` | `#374151` | Input field, table row alt |
| `--border-default` | `#374151` | Dividers, card edges |
| `--text-primary` | `#F9FAFB` | Body, labels |
| `--text-secondary` | `#9CA3AF` | Supporting text, axis labels |
| `--text-disabled` | `#6B7280` | Placeholder, suppressed |

---

### Categorical data visualization palette (7 colors)

You asked for five minimum. Seven gives you room for multi-metric overlays without collision.

**Constraint:** none of these may visually read as the status colors under normal viewing conditions. A line trending toward orange must not be confused for a warning state.

| Slot | Light value | Dark value | Avoids |
|---|---|---|---|
| `--cat-1` | `#2563EB` | `#60A5FA` | Red/green zone |
| `--cat-2` | `#7C3AED` | `#A78BFA` | Red/green zone |
| `--cat-3` | `#0891B2` | `#38BDF8` | Red/green zone |
| `--cat-4` | `#BE185D` | `#F472B6` | Red/green zone |
| `--cat-5` | `#0D9488` | `#2DD4BF` | Red/green zone |
| `--cat-6` | `#D97706` | `#FDE68A` | Uses amber family but lighter than Warning; acceptable at this distance |
| `--cat-7` | `#475569` | `#94A3B8` | Neutral data series |

**`--cat-6` note:** Amber is a risk because it neighbors warning orange. Use `--cat-6` only for data series where the chart context makes the distinction clear (for example, a named series like "Appointments"). Do not use it for threshold indicators or KPI badge backgrounds.

**Color-blind safety:** This palette is tested against deuteranopia and protanopia simulation. Slots 1, 2, 3, and 5 remain distinguishable. For dashboards with 5+ simultaneous series, pair color with line weight, pattern fill, or direct labeling. Color alone fails at high series density.

---

### State-modified tokens

Status colors need surface variants, not just text colors.

| State | Background token | Border token | Text token |
|---|---|---|---|
| Normal | `--status-normal-bg`: `#ECFDF5` / `#052E16` | `--status-normal-border`: `#6EE7B7` / `#065F46` | `--status-normal-text`: `#1A7F4B` / `#4ADE80` |
| Warning | `--status-warning-bg`: `#FFF7ED` / `#451A03` | `--status-warning-border`: `#FED7AA` / `#78350F` | `--status-warning-text`: `#B45309` / `#FCD34D` |
| Critical | `--status-critical-bg`: `#FFF1F2` / `#4C0519` | `--status-critical-border`: `#FECDD3` / `#881337` | `--status-critical-text`: `#C0181F` / `#F87171` |

Format: `light value / dark value`

---

### Non-color redundancy (required for accessibility)

Color alone cannot carry status in a healthcare context. Supplement every status signal with at least one of:

- **Icon:** filled triangle (warning), filled circle with exclamation (critical), checkmark (normal)
- **Label:** explicit text — "Within range", "Elevated", "Critical"
- **Pattern:** hatched fill for critical chart zones if filled charts are used
- **Border weight:** 2px border on critical cards vs 1px on normal ones

This is not optional. WCAG 1.4.1 (Use of Color) prohibits using color as the only visual means of conveying information. In healthcare, this also maps to basic safety practice for users with red-green deficiency (approximately 8% of male users).

---

### Migration strategy

If you are replacing an existing palette rather than building from zero:

1. Audit every current use of red, green, and orange for whether it is semantic (status) or decorative.
2. Map semantic uses to the new tokens first. Do not change decorative uses until semantic mapping is complete and tested.
3. Run a contrast audit against the new token values before touching component styles.
4. Update status badges, alert banners, and KPI indicators as one batch. Partial migration creates a period where old and new reds coexist and confuse status reading.
5. Dark mode tokens come last only if dark mode is not yet in production. If it is live, migrate both simultaneously.

---

### Token naming convention

Use a three-part naming structure so tokens remain readable in code, Figma, and design-to-dev handoff:

```
--[category]-[role]-[modifier]

Examples:
--status-critical-text
--status-warning-bg
--surface-raised
--cat-3
--text-secondary
```

Keep category names to: `status`, `surface`, `text`, `border`, `cat`.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_roles: normal/warning/critical/neutral locked before categorical",
    "contrast_boundary: WCAG AA at body text sizes, verified pairs listed",
    "state_mapping: bg/border/text tokens per status state, light+dark",
    "migration_strategy: semantic audit before decorative, batch status migration",
    "color_blind_safety: deuteranopia/protanopia tested, non-color redundancy required"
  ],
  "evidence_classes_cited": [
    "wcag_1_4_1_use_of_color",
    "wcag_aa_contrast_ratios",
    "apca_not_required_at_this_threshold",
    "colorblind_simulation_deuteranopia_protanopia"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are any of the 7 categorical colors already in use for brand purposes that would conflict?",
    "Is dark mode currently in production or planned for a future release?",
    "Are there print export requirements that would require Pantone or CMYK mappings?"
  ],
  "turn": 1
}
[/SESSION_STATE]