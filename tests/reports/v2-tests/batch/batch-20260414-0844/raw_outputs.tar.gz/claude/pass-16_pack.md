# API Reliability and Security Audit: POST /exports

## Failure Semantics and Error Contract

**Critical failures: 4**

**1. HTTP 200 for all responses including errors**
Status 200 signals success to every client, proxy, load balancer, and monitoring system. Errors become invisible to any tooling that inspects status codes. A failed export looks identical to a successful one until the caller parses the body, which most infrastructure never does.

Fix: map failures to correct HTTP semantics. `400` for invalid input, `401`/`403` for auth failures, `409` for duplicates, `422` for validation, `500`/`503` for server faults, `202 Accepted` for async acceptance (covered below).

**2. No RFC 9457 problem details contract**
Without a structured error contract, callers cannot distinguish a quota error from a permissions error from a generation failure. Each caller writes their own fragile parser against whatever shape the response happens to have.

Fix: adopt RFC 9457 `application/problem+json` for all 4xx and 5xx responses. Required fields: `type` (URI), `title`, `status`, `detail`, `instance` (per-request URI). Add `trace_id on all errors` as a non-negotiable field so every error can be correlated to a backend log.

Example shape:
```json
{
  "type": "https://api.example.com/problems/export-quota-exceeded",
  "title": "Export quota exceeded",
  "status": 429,
  "detail": "Monthly export limit of 100 reports reached. Resets 2024-02-01.",
  "instance": "/exports/req_abc123",
  "trace_id": "4bf92f3577b34da6"
}
```

**3. Internal enum values leaked in error messages**
Exposing internal enum names, stack traces, or implementation identifiers in error responses gives attackers a map of your system's internals. It also creates an accidental public API contract: callers start depending on those strings, and you can never rename them.

Fix: map all internal states to external-safe `type` URIs in the problem details contract. Never surface raw exception names, database error codes, internal status enums, or stack traces in production responses.

**4. No rate limiting or quota enforcement visible in the contract**
Without `429 Too Many Requests` responses and `Retry-After` headers, clients have no machine-readable signal to back off. Burst traffic hits the server with no natural governor.

Fix: return `429` with a `Retry-After` header (seconds or HTTP-date). Include quota state in the problem details `detail` field.

---

## Authorization and Resource Protection

**Critical failures: 2**

**5. No visible object-level authorization**
PDF report generation almost certainly scopes to a user, tenant, or account. If the endpoint accepts a report ID or parameters without verifying that the caller owns or has permission to generate that report, any authenticated user can generate exports for any other account. This is a BOLA (Broken Object-Level Authorization) vulnerability.

Fix: `object-level authorization` check on every call. The rule is: only [role] may generate exports for [resource owner], verified server-side on each request, not just at the route level. `deny by default` — if permission cannot be confirmed, reject.

**6. No resource-level scoping visible**
Large export jobs can be weaponized as a denial-of-service vector if there is no per-user, per-tenant, or per-session budget on how many concurrent or total exports can be queued. Without that, one account can exhaust server capacity for all accounts.

Fix: enforce per-actor concurrency limits and the monthly/hourly `rate limit + quota` visible in the error contract above. `gated by [permission]` for high-volume export access if the product supports tiered access.

---

## Idempotency and Async Lifecycle

**Critical failures: 3**

**7. Synchronous 3-minute blocking call**
This is the highest-severity structural problem. A 3-minute synchronous HTTP call:
- exhausts connection pool threads under any real concurrency
- gives clients no safe way to retry (they cannot know if the server received and started the job)
- is unmonitorable mid-flight
- will be killed by any default gateway, load balancer, or CDN timeout (most default to 30-60 seconds)
- cannot be cancelled
- cannot report partial progress

Fix: convert to an async job model. The contract is `202 Accepted + status URL`:

```
POST /exports
→ 202 Accepted
   Location: /exports/jobs/job_789
   {
     "job_id": "job_789",
     "status": "queued",
     "status_url": "/exports/jobs/job_789",
     "estimated_completion_seconds": 120
   }

GET /exports/jobs/job_789
→ terminal states: queued → running → completed | failed
   {
     "status": "completed",
     "result_url": "/exports/jobs/job_789/download",
     "expires_at": "2024-01-16T14:00:00Z"
   }
```

The `job lifecycle` requires explicit terminal states. `completed` and `failed` are terminal. `queued` and `running` are transient. Clients poll the status URL at a `polling interval` — recommended: initial check at 5 seconds, then back off. Alternatively, deliver completion via webhook if the platform supports it.

**8. No idempotency key**
Without an `idempotency-key header`, a client that retries a failed or timed-out request has no way to know whether the server already accepted the job. The result is duplicate exports, duplicate billing events, duplicate downstream side effects.

Fix: require an `idempotency-key header` on `POST /exports`. Cache the accepted response for the key for at least 24 hours. Return `409 on duplicate` if the same key is submitted with different parameters. If the same key is submitted with identical parameters before job completion, return the original `202` response body.

**9. No retry-safe contract**
Without idempotency and async structure, there is no safe retry behavior a client can implement. Any retry risks duplication; any non-retry risks silent loss.

Fix: the idempotency key above plus the async job model together constitute a `idempotency contract`. Once accepted, a job is owned by the server. The client can re-poll the status URL indefinitely without risk. The status URL itself must be idempotent `GET`.

---

## Resilience and Observability

**Critical failures: 3**

**10. No `trace_id` on errors**
Without a `trace_id` on every error response, support and on-call engineers cannot correlate a client-reported error to a backend log entry. Every investigation starts from scratch.

Fix: generate a `trace_id` (W3C `traceparent` format recommended) on request ingress and include it in every `4xx`/`5xx` response body. Log it on every internal span.

**11. No circuit breaker or graceful degradation**
PDF generation likely depends on downstream services (template engine, storage, data layer). If any dependency degrades, the export endpoint will queue work indefinitely or return opaque 500s with no signal to the caller about whether to retry, wait, or give up.

Fix: `circuit breaker` on each downstream dependency. When the circuit is open, return `503 Service Unavailable` with a `Retry-After` header and a problem details body that names the degraded dependency in terms safe for external exposure. `graceful degradation` means accepting the job request and queuing it even when generation is temporarily unavailable, if the product semantics allow it.

**12. No exponential backoff contract documented**
The endpoint gives callers no guidance on retry behavior. Without it, clients either hammer the endpoint on failure or give up entirely.

Fix: document `exponential backoff with jitter` as the required retry strategy in the API contract. Recommended starting interval: 1 second, multiplier: 2, max interval: 60 seconds, max attempts: 5. The `Retry-After` header on `429` and `503` responses takes precedence over the backoff schedule when present.

---

## Remediation Priority

| # | Failure | Severity | Fix class |
|---|---------|----------|-----------|
| 7 | Synchronous 3-minute block | Critical | Async job model |
| 8 | No idempotency key | Critical | Idempotency contract |
| 5 | No object-level authorization | Critical | BOLA remediation |
| 1 | HTTP 200 for all responses | High | Status code mapping |
| 2 | No RFC 9457 error contract | High | Structured error contract |
| 3 | Internal enum leakage | High | External type URI mapping |
| 10 | No trace_id on errors | High | Observability contract |
| 11 | No circuit breaker | Medium | Resilience pattern |
| 4 | No rate limiting in contract | Medium | Quota enforcement |
| 6 | No resource-level scoping | Medium | Per-actor budget |
| 9 | No retry-safe contract | Medium | Resolved by 7 + 8 |
| 12 | No backoff documentation | Low | API contract documentation |

Address items 7, 8, and 5 before shipping any version of this endpoint to production. Items 1, 2, 3, and 10 should be resolved in the same pass since they share the error contract implementation surface. The circuit breaker and quota work can follow in the next iteration, but they block production reliability at any meaningful traffic volume.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "problem_details_contract: RFC 9457 application/problem+json with trace_id",
    "authorization_perimeter: object-level authorization, deny by default, BOLA remediation",
    "idempotency_contract: idempotency-key header, 409 on duplicate, 24-hour cache",
    "async_job_model: 202 Accepted + status URL, terminal states queued→running→completed|failed",
    "resilience_strategy: circuit breaker per downstream dependency, exponential backoff with jitter, graceful degradation"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "idempotency-key header",
    "202 Accepted + status URL",
    "terminal states: queued → running → completed | failed",
    "job lifecycle",
    "polling interval",
    "circuit breaker",
    "exponential backoff with jitter",
    "graceful degradation",
    "trace_id on all errors",
    "rate limit + quota",
    "object-level authorization",
    "BOLA check",
    "deny by default",
    "409 on duplicate",
    "idempotency contract"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]