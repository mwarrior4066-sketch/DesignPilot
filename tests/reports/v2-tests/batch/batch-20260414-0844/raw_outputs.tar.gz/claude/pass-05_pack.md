The governing failure here is semantic integrity: the document has to produce a correct tag tree, logical reading order, and working navigation before any visual concerns matter. This is a document accessibility remediation task, with PDF layout supporting where frame logic affects tag placement.

---

## Failure inventory

**Reading order**
Two-column InDesign exports default to frame-by-frame order in the tag tree, which means Acrobat reads the left column frame, then jumps to the right column frame, rather than flowing column 1 top to bottom, then column 2. Pull quotes sitting inside the flow compound this: if they are tagged as `<P>` or `<H>` elements mid-column, a screen reader will read them as primary content at the point of interruption, not as supplementary callouts.

**Decorative images**
Untagged decorative images in Acrobat are ambiguous artifacts. Some PDF processors will surface them as unlabeled figures, generating empty or meaningless `<Figure>` announcements. They need to be explicitly marked as artifacts so assistive technology skips them entirely.

**Table of contents links**
Broken TOC links from InDesign exports almost always mean one of two things: the destination bookmarks were not exported with the InDesign PDF preset, or the link annotations were exported but the named destinations were not resolved. The fix is different depending on which failure is present, so you need to distinguish them before repairing.

---

## Repair sequence

Work in this order. Skipping ahead introduces tag conflicts.

### 1. Confirm the tag tree exists before touching anything

Open the Tags panel in Acrobat Pro. If the document is completely untagged, the fastest honest path is to re-export from InDesign with correct export settings rather than tagging a flat PDF by hand. Re-export costs less than manual remediation of a fully untagged document, and InDesign's tag-export behavior is more predictable than Acrobat's auto-tag engine.

If a tag tree exists but is malformed, continue with steps below.

### 2. Re-export from InDesign with correct settings (preferred if source is available)

In InDesign's PDF export dialog:

- Use **PDF/UA** or at minimum **PDF (Interactive)** rather than PDF/Print, because print presets suppress interactive elements including hyperlinks and bookmarks.
- Enable **Tagged PDF** under the General tab.
- Enable **Create Acrobat Layers** only if you need layer control; otherwise disable it to reduce tag complexity.
- Under **Interactive Elements**, set hyperlinks to **Include All**.
- Under **Bookmarks**, include the TOC bookmarks. This requires that your InDesign TOC was generated using **Layout > Table of Contents** with paragraph styles mapped to levels, not manually typed text with manual page references.
- Check **Export PDF Tags from Structure** if it is available in your InDesign version. This respects your Articles panel ordering.

**Articles panel** is the key to reading order. Before exporting, open the Articles panel in InDesign and confirm that all primary text frames appear in column-correct sequence: left-column article first, right-column article second, and that pull quotes are either excluded from articles entirely (making them artifacts) or placed after the body text they reference. Frames not added to Articles will still export, but their tag order defaults to frame-creation order, which is almost never the reading order you want.

### 3. Artifact decorative images

If you are working in Acrobat after export:

- Open the Tags panel and locate `<Figure>` elements that correspond to decorative images.
- Right-click the figure tag and select **Change Tag to Artifact**.
- Alternatively, use **Edit PDF > Edit** to select the image object, right-click, and choose **Create Artifact**.
- Confirm in the Tags panel that the image no longer appears as a tagged element.

If you are still in InDesign: select each decorative image, open the Object Export Options panel (Object menu), and under the **Tagged PDF** tab set it to **Artifact**. This prevents InDesign from tagging it on export.

### 4. Repair pull quote tagging

Pull quotes need one of two treatments depending on their role:

**Option A: Treat as artifact** (recommended when the pull quote duplicates body text)
If the pull quote literally repeats a sentence from the body, it adds no information. Tag it as an artifact so screen readers skip it. In Acrobat, use the TouchUp Reading Order tool or Tags panel to reassign the element. In InDesign, use Object Export Options to set it to Artifact before re-export.

**Option B: Tag as `<BlockQuote>` and place outside column flow** (use when the pull quote contains unique content)
If the pull quote contains content not found elsewhere, it must stay in the reading order but should be placed after the section it belongs to, not mid-paragraph. In the Tags panel, drag the `<BlockQuote>` or `<P>` tag to a position after the paragraph it references. Confirm that the visual position and the logical tag position are now distinct, which is valid and expected for pull quotes.

### 5. Fix reading order for two-column body text

In Acrobat Pro:

- Open **TouchUp Reading Order** (Accessibility > TouchUp Reading Order or via the Reading Order tool in the Accessibility panel).
- The tool shows numbered zones. The numbers reflect current reading order.
- Drag the order numbers to reflect: all of column 1 top to bottom, then all of column 2 top to bottom.
- For complex multi-frame pages, the Tags panel drag approach gives finer control: drag each `<P>` or `<H>` tag block so they sequence correctly under the parent `<Sect>` or `<Article>` container.

This step is the most labor-intensive part of post-export remediation, which is why fixing the Articles panel in InDesign before export is worth the time investment. One correct export eliminates dozens of manual Acrobat tag moves.

### 6. Diagnose and repair broken TOC links

**Diagnosis first:**

In Acrobat, go to **Edit PDF > Links** and select one of the broken TOC links. Open its properties. Check whether:

- The link annotation exists with a destination that says **Go to page view** and shows a page number, or
- The link annotation exists but the destination is a **Named Destination** that resolves to nothing

If the destination is a named destination with no target, the bookmarks were not exported. Re-export from InDesign with bookmarks enabled (see step 2 above).

If the link annotation does not exist at all, the export preset stripped hyperlinks. Re-export with **Include Hyperlinks** enabled, or in Acrobat go to **Edit PDF > Links > Add or Edit** and rebuild the link manually by drawing a link rectangle over the TOC entry and pointing it to the correct page.

If the destination is a page-view destination but goes to the wrong page, the TOC was out of sync with the document at export time. Update the TOC in InDesign (**Layout > Update Table of Contents**), re-export.

**After repair**: open the Bookmarks panel in Acrobat and confirm each TOC bookmark navigates correctly. Run the Accessibility Full Check (Accessibility > Accessibility Check) and confirm no broken links or destination errors appear.

---

## Verification method

Do not declare the document fixed until you have done all three of these:

1. **Full Accessibility Check in Acrobat Pro** (Accessibility > Accessibility Check > Full Check). Look specifically for: reading order failures, missing alt text on non-artifact figures, missing document title, missing language specification, and form field issues if any forms exist.

2. **Linear read with a screen reader.** Use NVDA + Chrome or JAWS + Acrobat and read the document from top to bottom in browse mode. Confirm that column 1 reads completely before column 2 begins, that pull quotes do not interrupt mid-sentence, and that decorative images are silent.

3. **TOC navigation test.** Click every TOC entry and confirm it lands on the correct section. If bookmarks exist, test those separately in the Bookmarks panel.

---

## Tradeoff this repair requires accepting

Re-exporting from InDesign source is faster and more reliable than manually remediating the exported PDF, but it requires access to the source file and correct export settings knowledge. If the source file is unavailable, you are accepting: higher manual labor in Acrobat, risk of introducing tag conflicts during drag-and-drop reordering, and the likelihood that future InDesign re-exports will overwrite your Acrobat repairs. The safer long-term path is to fix the export pipeline so every future export is clean, rather than treating Acrobat as the permanent remediation layer.

If only the exported PDF is available and the source is gone, the manual Acrobat path above is complete and valid, but plan for re-remediation if the document is ever updated.

[SESSION_STATE]
{
  "route": "rt_pdf_remediation",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_failure: tag tree malformation, broken reading order, untagged artifacts, broken TOC links",
    "reading_order_or_extraction: column-sequence repair via Articles panel (InDesign) or TouchUp Reading Order (Acrobat)",
    "verification_method: Acrobat Full Accessibility Check + screen reader linear read + TOC navigation test",
    "destructive_shortcut_rejected: auto-tag engine rejected as primary fix; manual Acrobat remediation accepted only when source unavailable"
  ],
  "evidence_classes_cited": [
    "wcag_rule",
    "pdf_ua_standard",
    "indesign_export_settings",
    "acrobat_tag_tree_behavior"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the InDesign source file available? This changes whether re-export or Acrobat-only remediation is the governing path.",
    "Are the TOC entries generated from an InDesign TOC style, or manually typed? This determines whether link repair requires re-export or manual Acrobat link annotation."
  ],
  "turn": 1
}
[/SESSION_STATE]