Tabular data is the constraint that governs everything else here. A typeface that looks modern on a marketing page but mangles financial figures in a table is the wrong choice regardless of how well it brands. So the selection logic runs: tabular figures first, then hierarchy range, then tonal fit, then cross-surface versatility.

---

## Reading contexts and what each surface demands

**Marketing site** needs display impact and brand voice at large sizes. Hierarchy is shallow: one or two headline levels, body copy, a CTA. Optical sizing matters at 48px and above.

**Web app dashboard** is the hardest surface. It needs a wide weight range for hierarchy (label, value, heading, caption), reliable tabular figures for number columns, small-size legibility at 11–13px captions, and enough x-height to survive low-contrast environments.

**Mobile** needs generous x-height, open apertures, and a tight enough letter-spacing default to survive variable rendering on lower-density screens. Tabular figures must carry into the native-web or React Native layer reliably.

---

## Primary recommendation: Inter (or Inter Variable)

**Why it governs the dashboard and mobile surfaces:**

Inter's tabular figures (`tnum`, `zero` for slashed zero) are production-grade. Its x-height is high enough to stay legible at 11–12px captions without compromising the display sizes. The variable font spans Thin through ExtraBold in one file, which eliminates weight-loading overhead and lets you run the full hierarchy from dashboard label (400) through KPI value (600) through page heading (700) through display headline (800) in one typeface.

The cost is that Inter at large display sizes reads as a product font, not a brand font. On a marketing hero at 72px, it signals "we built a tool" more than "we are the authoritative financial institution." Whether that is a problem or a feature depends on positioning.

---

## Pairing recommendation for the marketing site

Add a secondary display typeface for H1/H2 on the marketing surface only. Two options by positioning:

**DM Serif Display (free, Google Fonts)**
Serif contrast at large sizes communicates institutional authority and trust. Pair it with Inter for body and UI, so the marketing layer feels elevated while the product layer stays functional. The tradeoff: you accept a serif/sans split that requires a clear boundary rule (serif above the fold on marketing, Inter everywhere else), or the system feels inconsistent.

**Sohne or Söhne (commercial, Klim Type Foundry)**
If the budget supports a licensed typeface, Sohne gives you a single-family system with enough character variation across weights to handle both marketing display and dashboard UI without a secondary face. It reads as contemporary and serious without the startup-sans feel of Inter at large sizes. You sacrifice the free-tier option to gain brand distinctiveness.

---

## Scale decision

A practical type scale across all three surfaces:

| Role | Size | Weight | Notes |
|---|---|---|---|
| Display / Hero | 48–72px | 700–800 | Marketing only; use display face if paired |
| Section heading | 32–40px | 700 | Marketing + app page titles |
| Card / panel heading | 20–24px | 600 | Dashboard, app |
| Body copy | 16px | 400 | Marketing body, app descriptions |
| UI label | 14px | 500 | Dashboard labels, form labels |
| Table cell / value | 13–14px | 400 (data), 600 (KPI) | Tabular figures required |
| Caption / metadata | 11–12px | 400 | Timestamps, footnotes, tooltips |

Line-height ratios: 1.2 for display, 1.5 for body, 1.4 for UI labels, 1.3 for table cells.

---

## Tabular figure rules

Any number that appears in a column, a KPI card, or a comparison table must use `font-variant-numeric: tabular-nums`. Apply this via a utility class or a CSS custom property on the table element, not inline. If your design token layer handles typography, add a `--font-variant-numeric-tabular` token and apply it to the `data-display` component category.

For negative values and currency symbols: verify that the minus sign (`−`, U+2212) and the hyphen-minus (`-`, U+002D) render at consistent widths in your chosen typeface. Inter handles both correctly at the weights relevant to data display.

---

## Variable font and loading strategy

Use `Inter Variable` as a single `woff2` file. Declare it once in your font stack with a `font-display: swap` and a system-sans fallback:

```css
font-family: 'Inter Variable', 'Inter', system-ui, -apple-system, sans-serif;
```

For the marketing site display face, load only the weight range you actually use (typically Regular and Medium for body, Bold for headings). Subset to Latin plus any currency symbols your product supports.

Fallback stack for mobile / React Native: `system-ui` will cover most cases adequately when Inter fails to load, because the x-height and tabular figure behavior of system-ui on iOS and Android are acceptable for financial display. Explicitly test tabular rendering on both platforms before assuming parity.

---

## Adoption sequence

1. Lock Inter Variable as the primary face and confirm tabular figure rendering in your actual dashboard prototype, not a static mockup.
2. Decide on the marketing display face before building marketing templates (changing this later requires a headline audit across every page).
3. Define the type scale as design tokens before any component is built. Retrofitting a scale onto an existing component library is expensive.
4. Test the 11–12px caption range on the lowest-contrast surfaces in your dashboard (against mid-gray backgrounds, not white) before sign-off.
5. If native mobile is in scope, confirm that `tnum` applies correctly in the rendering layer being used. React Native requires explicit font variant handling; it does not inherit from CSS.

---

## What you're accepting

Using Inter means accepting that your product will read visually similar to a large number of other fintech and SaaS products. That is a real tradeoff. If brand distinctiveness at the typeface level matters to your positioning, the Sohne path costs more but earns more differentiation. If execution clarity and legibility at data-display sizes are the top constraint, Inter is the safer choice and the brand distinctiveness question should be answered through color, spacing, and component voice instead.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing site + web app dashboard + mobile",
    "scale_decision: Inter Variable across all product surfaces; optional display face for marketing",
    "pairing_rationale: DM Serif Display (free) or Sohne (licensed) for marketing layer only",
    "adoption_sequence: tabular figure validation first, then display face lock, then token-based scale, then caption contrast test, then native mobile tnum verification"
  ],
  "evidence_classes_cited": [
    "tabular_figure_rule",
    "font_variant_numeric_token",
    "line_height_ratio",
    "variable_font_loading",
    "fallback_stack"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is native mobile in scope (React Native / SwiftUI / Jetpack Compose)?",
    "Is a commercial typeface license within budget?",
    "Does the brand positioning favor distinctiveness at the typeface level, or is differentiation handled through color and component voice?"
  ],
  "turn": 1
}
[/SESSION_STATE]