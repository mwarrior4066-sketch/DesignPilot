## Brand Positioning Pass

### Audience frame

Freelancers are not small businesses pretending to be corporations. They are individuals managing income volatility, client relationships, and professional identity simultaneously — often without a finance team, an accountant on call, or institutional tolerance for complexity.

The core tension: freelancers want financial tools that respect their intelligence without requiring them to think like a CFO. They need reliability (rent depends on this), but they distrust anything that feels like it was designed for a company with 12 employees and an HR portal.

Trust for this audience is not built through gravitas. It is built through clarity, speed, and not making them feel like an afterthought.

### Competitive landscape

**Stripe** owns developer-first infrastructure. Its brand is technically confident to the point of being cold. It is built for builders, not for people who want to get paid and move on. Freelancers use it, but they do not feel seen by it.

**Mercury** owns startup-founder aesthetics: clean, modern, aspirational, and implicitly VC-adjacent. It signals "you are building something." That is a mismatch for a copywriter or photographer who is not raising a Series A and does not want to pretend otherwise.

**Relay** owns team-based cash flow — multiple users, spending cards by department, envelope budgeting for small ops. Its frame is organizational, not individual.

The gap: none of these three speak directly to the solo professional who earns irregularly, invoices clients, pays quarterly taxes, and wants a financial tool that maps to how their work actually flows, not how a startup's runway is managed.

### Positioning territory to own

**"Financial clarity for how you actually work."**

Own the territory of income-pattern-aware finance rather than business banking dressed down. This means:

- Irregular income is the default assumption, not the edge case
- The product anticipates tax season, dry months, and feast-or-famine cycles rather than requiring the user to manage around them
- Invoicing, payment tracking, and account separation feel native, not bolted on
- The tone treats freelance work as a legitimate, stable professional identity — not a transitional state before "real" employment or a business

This is trust built through competence and fit, not through institutional signals. The brand earns approachability by being genuinely designed for this person, not by adding warm colors to a banking template.

### Trust logic

Traditional bank trust is built on size, age, and regulatory signaling. That works for people who need institutional reassurance. Freelancers are not that audience.

For this audience, trust requires:

- Transparency about how money moves and where it sits
- Predictability: the product behaves the same way every time, with no surprise fees or opaque holds
- Proof of fit: the product clearly understands irregular income patterns, which signals it was built for them specifically rather than adapted from a corporate tool

The brand cannot claim trustworthiness through visual seriousness alone. Rounded corners and a friendly voice will not close the gap if the product's feature logic still assumes monthly salary income. Trust and approachability must be structural, not cosmetic.

### Messaging consequence

Avoid: "Banking built for freelancers" — this positions against banks but does not differentiate from competitors who say the same thing.

Avoid: "Your money, simplified" — this is category filler with no audience specificity.

Work toward framing that names the income pattern explicitly: slow months, client payments, tax reserves, project-based earning. The more specifically the brand names the freelancer's actual financial reality, the more trust it earns — because specificity is proof of understanding.

The differentiation frame is not "friendlier than a bank." It is "designed for income that does not arrive on the first of the month." That is a territory none of the three competitors own, and it is one that is both defensible and meaningful to the actual audience.

### Open gaps

- No data yet on whether freelancers prioritize invoicing integration, tax tooling, or income smoothing as the primary purchase trigger. That hierarchy changes which capability leads the positioning.
- The "approachable" brief needs a constraint check: approachable without trivializing. Some freelancers (lawyers, consultants, senior contractors) have high income and professional expectations. The brand needs to feel adult without reverting to corporate formality.
- Category convention for fintech still demands clear regulatory and security signals somewhere in the experience, even if they are not the lead message. Trust built on fit must not come at the cost of trust built on safety. The audience will not accept the former without the latter.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: solo freelancer managing income volatility, not small-business operator",
    "differentiation_frame: income-pattern-aware finance, not business banking with friendly tone",
    "trust_logic: trust built through product fit and transparency, not institutional signals or cosmetic warmth",
    "messaging_consequence: avoid generic banking-alternative framing; name irregular income patterns explicitly"
  ],
  "evidence_classes_cited": [
    "competitive_landscape_analysis",
    "audience_constraint_mapping",
    "category_convention_check"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Which capability leads positioning: invoicing integration, tax tooling, or income smoothing?",
    "What is the income and professional seniority range of the target freelancer segment?",
    "Where do regulatory/safety signals appear in the brand hierarchy without undermining the approachability frame?"
  ],
  "turn": 1
}
[/SESSION_STATE]