## Dashboard audit

### Dashboard role and scan failure

This is a **monitoring dashboard** — the user's first job is to detect anomalies and answer "is anything wrong right now." Every structural failure here works against that job.

The KPI row, chart, and nav all fail the same way: they show data without enough context to make the data meaningful. A number without a target is decoration. A line without a Y-axis label is a shape. A nav with 12 ungrouped items requires the user to read every item every time.

---

### KPI row failure

**Finding:** DAU, MRR, and churn rate appear as large numbers with trend arrows but no reference values, no targets, and no period context.

**Why this fails:** A trend arrow answers "which direction" but not "how much does that matter." Without a comparison value — prior period, target, or threshold — the user cannot determine whether the change is within normal variance or a genuine problem. The number is not actionable on its own.

**Repair:**

- Add a secondary line below each KPI: one comparison value (vs. last 30 days, vs. target, or vs. the same period prior year) and the delta as a percentage
- Use color and iconography only to signal status relative to a threshold, not just direction — green/yellow/red tied to an explicit rule, not to "up is good"
- Churn rate especially needs a target because the acceptable range differs radically by business model; without it, the number is uninterpretable

**Tradeoff:** Adding reference values increases visual density in the KPI row. You sacrifice visual simplicity to gain interpretive completeness. The simplicity of the current design is real, but it produces false clarity — the user sees a clean number and has no basis to act.

---

### Line chart failure

**Finding:** 30-day line chart, no Y-axis label, four colored lines, legend below the fold.

This has three distinct failures.

**Failure 1 — No Y-axis label.** The user cannot determine what unit is being charted. If this is DAU counts, MRR in dollars, and session length in minutes all on one axis, the chart is formally unreadable. Even if it is one metric, the unit is required for any comparison across time or context.

Repair: Add a Y-axis label with the metric name and unit. If the four lines use different scales, use dual axes or facet the chart — do not force incompatible scales onto one axis because the visual similarity implies comparability that does not exist.

**Failure 2 — Legend below the fold.** A legend that requires scrolling to reach makes the chart uninterpretable without that scroll. The user sees four lines with no key.

Repair: Move the legend to the top of the chart, inline with the chart title, or use direct labeling — label each line at its rightmost point with a short segment name. Direct labels remove the lookup entirely and work better for time-series lines than a detached legend.

**Failure 3 — Four-line density at the monitoring layer.** Four lines in one view is acceptable if the segments are the user's primary diagnostic tool. But for a first-view monitoring dashboard, the higher-value design shows an aggregate line with a clear status indicator, then allows drill-down into segments. If one segment is driving a problem, show that. Do not require the user to visually decompose four lines to discover it.

Repair: Consider a summary line with a band showing variance across segments. Show segment breakdown in a drill-down view rather than the first view.

**Tradeoff:** Simplifying to an aggregate line sacrifices segment visibility on the first view. You gain faster anomaly detection at the cost of immediate segment granularity. This is the right tradeoff for a monitoring dashboard; it is the wrong tradeoff for an analytical dashboard where segment comparison is the primary job.

---

### Navigation failure

**Finding:** 12 ungrouped nav items in the left sidebar.

**Why this fails:** Without grouping, the user must read all 12 items as a flat list every time they navigate. There is no visual shortcut to the area they need, and the nav does not communicate the structure of the product. Cognitive load scales with list length when there is no chunking.

**Repair:**

- Group items into 3 to 5 named categories (likely: Overview, Revenue, Users, Settings, and one product-specific group)
- Place the most frequently visited destinations first within each group
- Consider whether 12 items are all necessary in the primary nav or whether some belong in a secondary nav, a settings surface, or a contextual panel
- Visual separators and small group labels are sufficient; the structure does not need an accordion or nested hierarchy unless items genuinely require it

**Tradeoff:** Grouping requires a content inventory and a decision about product information architecture. You cannot group items without naming the groups, which forces an IA decision that may have been deliberately deferred. Deferring it further, however, means the current nav scales poorly as items are added.

---

### Intervention order

Fix in this sequence because each repair unblocks the next:

1. **KPI reference values** — highest interpretive payoff per effort; can be done in isolation without touching the chart or nav
2. **Legend and Y-axis label** — correctness repairs; the chart is formally broken without them
3. **Chart simplification** — structural decision requiring a conversation about whether this dashboard is monitoring-first or analysis-first
4. **Nav grouping** — requires IA work and team alignment; higher coordination cost, but longer-term payoff in all future nav additions

---

### What this dashboard currently does well

The layout order — KPIs above the chart — is correct for a monitoring dashboard. Scanning the most critical numbers first and then reaching for time-series context is the right hierarchy. The repair work here does not require restructuring that order; it requires adding interpretive scaffolding to each layer.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_role: monitoring",
    "kpi_failure: no reference values or targets",
    "chart_failure: missing Y-axis label, legend below fold, four-line density at monitoring layer",
    "density_or_navigation_decision: nav requires grouping into 3-5 named categories"
  ],
  "evidence_classes_cited": [
    "wcag_threshold",
    "monitoring_vs_analysis_dashboard_type",
    "kpi_interpretability_rule",
    "legend_placement_rule",
    "nav_chunking_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is this dashboard monitoring-first or analysis-first? The answer changes whether segment lines belong on the first view.",
    "What are the KPI targets or thresholds for DAU, MRR, and churn? Without them, status color cannot be implemented correctly."
  ],
  "turn": 1
}
[/SESSION_STATE]