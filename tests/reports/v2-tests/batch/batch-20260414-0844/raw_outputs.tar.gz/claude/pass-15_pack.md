# Backend Architecture Spec: Multi-Tenant Scheduling Platform

## Architecture overview

This spec defines the service model, data boundaries, authority decisions, and operational contracts for a scheduling platform that must support team workspaces, cursor-based activity feeds, approval workflows, outbound webhooks, regional data residency, audit trails, and eventual customer-defined automation rules.

The current stack has REST APIs and a relational database. Background jobs and eventing are inconsistent. That inconsistency is the first structural problem this spec must fix, because approval workflows, webhooks, and automation rules all depend on a reliable eventing spine. You cannot safely layer those features onto ad-hoc job dispatch.

The governing constraints in order:

1. **Tenant isolation** is non-negotiable before any of the other features ship. Multi-tenancy that leaks data between regions or workspaces invalidates every downstream feature.
2. **Eventing consistency** is the prerequisite for approval workflows, webhooks, and automation. Fixing this comes before adding new consumers.
3. **Audit trail correctness** must be append-only and tamper-resistant. It cannot be a side-effect of a regular write path.
4. **Automation rules** are deferred until the eventing and permission models are stable enough to serve as their execution substrate.

---

## Core services

### 1. Identity and tenancy service

**Responsibility:** owns the authority model for tenants, workspaces, members, and roles. Every other service delegates authorization decisions here.

**Key decisions:**

- Tenant is the top-level isolation boundary. A tenant owns one or more workspaces. Workspace membership and role assignments live here, not scattered across domain services.
- Authorization model: **deny by default**. Only explicitly granted permissions are valid. There is no ambient trust between workspaces within the same tenant.
- Role assignments are scoped: tenant-level roles, workspace-level roles, and resource-level grants are separate objects. A workspace admin cannot escalate to tenant-level access without an explicit tenant-admin grant.
- Object-level authorization checks (BOLA) are enforced by the tenancy service on every cross-service call. No service may assume workspace membership from a session token alone.
- Regional assignment is set at tenant provisioning and is immutable unless a formal data-migration workflow is triggered. The tenancy service owns the region-to-tenant mapping.

**Data boundary:** tenant registry, workspace registry, member-role assignments, permission grants. This data does not leave its home region.

**Contract surface:** synchronous read path for permission checks (low latency required); async event emission on membership changes, role changes, and workspace lifecycle events.

---

### 2. Scheduling domain service

**Responsibility:** owns the core scheduling objects: schedules, slots, bookings, and availability rules.

**Key decisions:**

- Scheduling objects are workspace-scoped. The tenancy service is called at the boundary of every mutation to verify workspace membership and permission.
- Optimistic concurrency on slot mutations using a version column. Double-bookings are prevented at the database layer with a conditional update, not application logic, because application logic loses under concurrent requests.
- State machine for bookings: `draft → pending_approval → confirmed | rejected | cancelled`. State transitions emit domain events. State is not inferred from timestamps.
- Approval workflows are triggered by a state transition event, not a direct service call from the scheduling service. This preserves the scheduling service's domain boundary.

**Data boundary:** all scheduling data is tenant-scoped and written to the region assigned at tenant provisioning. Cross-region reads are not supported; cross-region requests are rejected at the API gateway layer.

**Contract surface:** REST mutations on scheduling objects emit `schedule.*`, `slot.*`, and `booking.*` domain events on a durable event bus. Downstream consumers (approval, webhooks, audit, feeds) consume those events independently.

---

### 3. Approval workflow service

**Responsibility:** owns approval policy definitions, approval request lifecycle, and reviewer assignments.

**Key decisions:**

- Approval policies are workspace-level configuration objects. A policy defines: trigger conditions, reviewer roles or specific members, escalation rules, and timeout behavior.
- Approval requests are created by consuming `booking.pending_approval` events from the bus. The approval service does not receive direct calls from the scheduling service, because that would couple workflow logic to the scheduling domain.
- Approval request state machine: `created → assigned → approved | rejected | escalated | timed_out`. Every state transition is appended to the audit trail.
- Reviewer assignment is resolved at request creation time using the current workspace role assignments. Reassignment creates a new assignment record; it does not mutate the original.
- Timeout behavior uses a scheduled job that reads outstanding assignments, not a timer event, because timer events drift under load and produce duplicate-fire edge cases.
- When an approval completes, the approval service emits `approval.decided`. The scheduling service consumes this event and transitions the booking state. The scheduling service does not poll the approval service.

**Data boundary:** approval policies and request history are workspace-scoped. Reviewer assignment records reference member IDs from the tenancy service but do not duplicate member profile data.

---

### 4. Activity feed service

**Responsibility:** owns cursor-based activity feeds per workspace. These are the read surface for what happened, not the canonical record of what happened. The audit trail is the canonical record.

**Key decisions:**

- The feed is derived from domain events. The feed service is a consumer on the event bus, not a direct write path from domain services. This means the feed is eventually consistent, which is acceptable: activity feeds are not correctness surfaces.
- Feed entries are immutable once written. An entry is never updated; a correction surfaces as a new entry of type `correction`.
- Cursor-based pagination uses a stable, monotonically increasing sequence ID, not a timestamp. Timestamps are unreliable as cursors because clock skew and batch inserts produce non-unique values under load.
- Feed reads are workspace-scoped and permission-filtered at the API layer. The feed service stores all events for a workspace; the read API filters by the caller's permission scope.
- Retention policy is configurable at the workspace level with a tenant-level cap. The feed service enforces a hard deletion job on a schedule. Deleted entries are not recoverable from the feed; they remain in the audit trail under its separate retention policy.
- The feed does not replace the audit trail. You sacrifice real-time exactness in the feed to gain a cheap, scalable read surface. The audit trail sacrifices query flexibility to gain tamper resistance.

**Contract surface:** cursor token format is `{sequence_id}_{workspace_id}` encoded as an opaque base64 string. Clients do not parse cursor internals. The API returns `next_cursor: null` when the feed is exhausted.

---

### 5. Audit trail service

**Responsibility:** append-only, tamper-resistant record of all state-affecting operations across all services.

**Key decisions:**

- The audit trail is written by consuming domain events from the bus. It is never written by direct service call. This prevents any service from silently omitting audit entries by skipping the call.
- Entries are immutable. The storage model uses an append-only table with no `UPDATE` or `DELETE` permissions on the audit user. Soft-delete patterns are prohibited on audit records.
- Each entry records: tenant ID, workspace ID, actor ID, actor IP, action type, resource type, resource ID, before-state hash, after-state hash, timestamp, and the originating event ID. The event ID links the audit record back to the bus event that produced it.
- Regional isolation: audit data for a tenant is written only to the tenant's assigned region. Cross-region audit queries require explicit tenant admin authorization and are themselves audited.
- Retention: configurable by tenant up to a regulatory maximum. Entries older than the retention window are archived to cold storage, not deleted. The archive is cryptographically signed at archive time.
- Audit queries use a separate read replica. Audit query traffic must not affect the write path for live event ingestion.

**What the audit trail does not do:** it does not serve as a debugging log, application event log, or error log. Those live in the observability layer. The audit trail records who did what to which resource and when, period.

---

### 6. Webhook delivery service

**Responsibility:** owns outbound webhook registration, delivery, retry, and failure management for customer systems.

**Key decisions:**

- Webhook endpoints are registered at the workspace level. A webhook subscription includes: endpoint URL, event filter, signing secret, and delivery mode (sync attempt with retry, or async queued delivery).
- Webhook delivery is triggered by consuming domain events from the bus, not by direct calls from domain services. Domain services do not know which customer systems subscribe to their events.
- Delivery contract: `POST` to the customer endpoint with a JSON body, an `X-Signature` header using HMAC-SHA256 signed with the workspace-specific secret, and a `trace_id` on every request. Customers verify the signature to authenticate the delivery.
- Retry model: exponential backoff with jitter. `initial_delay: 30s`, `max_delay: 4h`, `max_attempts: 8`. After max attempts, the delivery is marked `failed` and a `webhook.delivery_failed` event is emitted to the internal bus. The workspace admin is notified.
- Circuit breaker: after 5 consecutive failures to an endpoint within 30 minutes, the endpoint is suspended. The workspace admin receives a notification and must re-enable the endpoint. This prevents the retry queue from filling with dead deliveries.
- Payload schema versioning: webhook payloads carry a `schema_version` field. When the domain model changes, a new schema version is introduced. Old versions are supported for 90 days. Deprecation notices are delivered as `webhook.schema_deprecation` events.
- Security constraint: outbound requests to `localhost`, `169.254.*` (link-local), and RFC 1918 private ranges are blocked at the delivery layer. This prevents SSRF.

**Delivery failure visibility:** workspace admins can inspect delivery history, failure reason, request body, and response body for the last N deliveries per endpoint. This data is retained for 30 days.

---

### 7. Automation rules engine (deferred, designed now)

**Responsibility:** customer-defined trigger-condition-action rules evaluated against domain events.

**Why deferred:** the eventing spine, permission model, and audit trail must be stable before automation rules can execute against them safely. Automation that fires before the permission model is fully enforced can produce actions that bypass authorization. You sacrifice faster feature delivery to gain correctness and auditability when automation ships.

**Design decisions settled now:**

- Rules are workspace-scoped. A rule cannot span workspaces or tenants.
- Trigger: a domain event type plus optional field-level filter predicates. Rules do not subscribe to raw database changes; they subscribe to named domain events on the bus.
- Condition: a predicate expression evaluated against the event payload and workspace-level state. The condition evaluator runs in a sandboxed execution context with no network access and a hard CPU and memory ceiling.
- Action: a named action type (not arbitrary code). Supported action types are enumerated: `send_notification`, `update_booking_status`, `assign_reviewer`, `trigger_webhook`, `create_activity`, `add_label`. Arbitrary HTTP calls are not a supported action type; that surface is covered by the webhook service.
- Every rule execution is appended to the audit trail with the triggering event ID, the evaluated condition result, and the action dispatched.
- Rate limiting: a rule may fire at most N times per workspace per hour, configurable by tenant tier. This prevents a misconfigured rule from flooding downstream services.

---

## Eventing spine

The inconsistent background job and event dispatch in the current stack is the root cause of reliability gaps across approvals, webhooks, feeds, and audit. The fix is a durable, ordered event bus with at-least-once delivery semantics.

**Required properties:**

- **Durability**: events survive process restart. In-memory dispatch is not sufficient.
- **At-least-once delivery**: consumers must be idempotent. The bus does not guarantee exactly-once; it guarantees the event will be delivered at least once.
- **Ordered within partition**: events for a given resource (e.g., a specific booking) are ordered by their sequence position within that resource's partition. Global ordering is not required or promised.
- **Dead-letter queue**: events that fail consumer processing after N retries are moved to a DLQ with the failure reason. The DLQ is monitored and alerted on.
- **Schema registry**: event schemas are registered and versioned. Consumers declare the schema versions they accept. A schema change that is not backward-compatible requires a new event type, not a silent mutation.

**Partition key:** use `workspace_id` as the default partition key. This provides ordering within a workspace at acceptable fan-out cost. High-volume workspaces may be sharded further by resource type.

**Event envelope:**

```json
{
  "event_id": "uuid",
  "event_type": "booking.state_changed",
  "schema_version": "1.2",
  "tenant_id": "uuid",
  "workspace_id": "uuid",
  "region": "eu-west-1",
  "actor_id": "uuid",
  "occurred_at": "ISO-8601",
  "sequence": 1048576,
  "payload": {}
}
```

Every consumer checks `region` before processing. An event whose region does not match the consumer's assigned region is rejected and logged, not processed.

---

## Regional data residency

**Model:** strict regional isolation. Tenant data, events, audit records, and feed entries all live in the tenant's assigned region. There is no global data store that spans regions.

**API routing:** the API gateway routes requests to the correct regional cluster using the tenant's region assignment, which is looked up from a global routing table. The global routing table contains only tenant ID to region mappings. It contains no customer data.

**Cross-region operations that are not supported:**

- Cross-region event consumption
- Cross-region audit queries without explicit admin authorization
- Cross-region workspace membership

**Data migration:** tenant region migration is a formal workflow owned by the platform team. It is not a self-service operation. The workflow includes: data copy, consistency verification, read-traffic cut-over, write-traffic cut-over, and old-region data deletion under the applicable data-residency regulation. Until migration completes, the old region remains the write authority.

**Consequences of this model:** you sacrifice operational simplicity (no global dashboards, no cross-region analytics without explicit data export pipelines) to gain genuine regulatory compliance. A shared-database multi-region model would be simpler to operate but cannot satisfy strict data residency requirements without significant exceptions carveouts.

---

## Audit trail and observability separation

These are not the same concern and must not share infrastructure.

| Property | Audit trail | Observability |
|---|---|---|
| Purpose | who did what, legally defensible | why it broke, operationally actionable |
| Write path | event bus consumer | log shipper, metrics exporter |
| Mutability | append-only, no deletes | logs rotate, metrics aggregate |
| Retention | regulatory max, archived cold | typically 30-90 days |
| Query surface | compliance and admin UI | Grafana, tracing UI |
| Schema | strict, versioned | flexible, best-effort |

The observability layer includes: structured logs with `trace_id` on every request and background job, distributed traces spanning service calls, metrics for queue depth, delivery latency, approval age, and circuit breaker state, and alerting on DLQ depth and webhook circuit-breaker trips.

---

## Approval workflow: operational contract

The approval workflow is the part of this architecture most likely to accumulate invisible debt. Name the failure modes explicitly.

**Timeout handling:** every approval request has a deadline set at creation time based on the workspace policy. A background job runs on a schedule (every 5 minutes) and transitions timed-out requests to `timed_out`. The timeout job emits `approval.timed_out`, which the scheduling service consumes to handle the booking according to the workspace's timeout policy (auto-approve, auto-reject, or escalate).

**Escalation:** escalation is a state transition within the approval service triggered either by timeout of the primary reviewer or by an explicit escalation action from the reviewer. Escalation creates a new assignment record pointing to the escalation target defined in the policy. It does not mutate the original assignment.

**Reviewer unavailability:** if the assigned reviewer's workspace membership is revoked between assignment and decision, the approval request is escalated to the workspace admin. This is checked at assignment resolution time, not cached.

**Concurrent approvals:** if two reviewers in a multi-reviewer policy attempt to act simultaneously, the state machine uses optimistic concurrency (version check on the approval request record). The second writer receives a `409 Conflict` and must re-fetch before acting.

---

## Data model boundaries summary

```
tenant
  └─ workspace (scoped to tenant)
       ├─ members + roles (tenancy service)
       ├─ schedules, slots, bookings (scheduling service)
       ├─ approval policies + requests (approval service)
       ├─ activity feed entries (feed service, derived)
       ├─ webhook subscriptions + delivery log (webhook service)
       └─ automation rules (deferred, automation service)

audit_trail (workspace-scoped, separate store, append-only)
event_bus (regional, partitioned by workspace_id)
global_routing_table (tenant_id → region, no customer data)
```

No service reads directly from another service's database. Cross-service data access uses the event bus or a synchron