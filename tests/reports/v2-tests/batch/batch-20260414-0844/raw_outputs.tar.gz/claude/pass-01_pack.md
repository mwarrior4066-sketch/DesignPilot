## Pricing page audit

The page has real structural and accessibility problems that will cost conversions before any visual refinement matters. Here is the diagnosis in intervention order.

---

### 1. Hero: message-action mismatch (fix first)

"Everything your team needs" is a category statement, not a value proposition. It tells a B2B buyer nothing about what differentiates this product, who it is for, or why now. On a pricing page specifically, visitors have already decided to evaluate — the headline should be closing, not introducing.

The CTA being visually small relative to the hero is a symptom of hierarchy inversion. If the hero image is decorative, it is consuming the visual weight that belongs to the action. A background image behind a headline creates a layered contrast risk on top of the sizing problem.

**What to fix:**
- Rewrite the headline toward a buying-context claim. Something like "Simple pricing for teams that ship" or "One plan scales with your team" — concrete, not categorical.
- Increase CTA size so it clears 44px minimum touch target and reads as the dominant interactive element in the hero, not a secondary detail.
- Audit the hero text against its background image at every expected viewport. WCAG 1.4.3 requires 4.5:1 for normal text, 3:1 for large text (18pt+ or 14pt+ bold). Background images make this fragile because contrast shifts across the image. Either add a semi-transparent overlay behind the text or move the headline to a solid-color zone.

**Tradeoff:** A more specific headline will narrow reach slightly — it will not speak equally to every visitor. You sacrifice breadth to gain clarity, which is the correct tradeoff on a pricing page where the decision is being made.

---

### 2. Pricing table: Pro-tier color coding is inaccessible (fix before launch)

Using color alone to signal "this is the recommended tier" fails WCAG 1.4.1 (use of color), which requires that color is not the only visual means of conveying information. A user who cannot perceive the color distinction cannot identify which tier is highlighted.

**What to fix:**
- Add a non-color signal: a "Most popular" or "Recommended" label badge on the Pro tier, a border or card elevation change, or a visible size or weight difference in the tier header.
- Then verify that the color itself passes contrast. If the Pro tier uses, say, a medium blue background with white text, confirm the ratio. If the card background shifts against surrounding table text, check non-text contrast at 3:1 (WCAG 1.4.11).
- Run the page through a grayscale check. If the Pro tier is not distinguishable without color, the signal is not accessible.

**Tradeoff:** Adding a text label ("Most popular") slightly reduces visual elegance. You sacrifice a cleaner minimal look to gain compliance and usability for a meaningful percentage of your audience, including users in high-ambient-light conditions where color differentiation also degrades.

---

### 3. Three-column pricing table: structure and scan cost

Three tiers is the right number for B2B SaaS. The problem is likely in how the tiers communicate decision boundaries.

Common failure pattern: the columns describe features but do not describe the user. A B2B buyer wants to know "which tier is for a team like mine" before they read any feature row. If the tier names are just "Starter / Pro / Enterprise" with no audience framing, the buyer has to reverse-engineer their fit from feature lists.

**What to fix:**
- Add a one-line descriptor under each tier name: "For individuals and small teams" / "For growing teams that need more control" / "For organizations with custom needs." This reduces cognitive load on the feature table.
- Confirm that Enterprise "custom pricing" includes a clear next step. "Contact sales" is table stakes, but if the CTA on Enterprise is visually equivalent to or smaller than the buy buttons on Starter and Pro, you are suppressing your highest-value conversion path. Enterprise should have a distinct, prominent CTA that signals a different process (a call, a demo, a form), not just a smaller version of the buy button.

**Tradeoff:** Adding descriptors requires space that may feel heavy in a compact table. You sacrifice compactness to gain faster tier-fit recognition. On a pricing page, decision speed is more valuable than visual minimalism.

---

### 4. Feature comparison table: density and readability

Feature comparison tables accumulate rows quickly. Common failures:

- No visual grouping: rows blur together without section headers (e.g., "Collaboration," "Integrations," "Admin and security"). Without grouping, buyers have to scan the entire table to find the feature they care about.
- Checkbox or dot grids with no hover or focus state: interactive tables that use tick marks must be keyboard-navigable if any interactivity exists, and the tick/cross distinction must pass 3:1 non-text contrast.
- Mobile collapse behavior: a three-column comparison table almost certainly breaks on narrow viewports. The pattern is usually to show one tier at a time with a toggle or accordion, or to collapse to a prioritized single-column view. If this behavior is not designed, it is likely broken.

**What to fix:**
- Add section headers to group feature rows thematically.
- If the table has any interactivity, confirm keyboard access and visible focus indicators.
- Confirm mobile layout pattern exists and works.

---

### 5. Testimonials strip: placement is doing low-value work

Testimonials at the bottom of a pricing page arrive after the decision has essentially been made, or after the visitor has bounced. They are more useful as trust signals positioned near the moment of hesitation, which on a pricing page is usually just before the CTA.

**What to fix:**
- Consider moving one or two high-credibility quotes (company name, role, and a specific claim — not generic praise) to the zone immediately above or beside the pricing table, where they address the "is this worth it" question at the right moment.
- Keep the strip if it serves as social proof for users scrolling to validate, but do not rely on it as the primary trust mechanism at the bottom.

**Tradeoff:** Moving testimonials breaks a common page pattern, which can feel unfamiliar. You sacrifice conventional layout predictability to gain trust reinforcement at the highest-hesitation moment. Test this with a simple scroll-depth and click-rate check if you have the traffic to support it.

---

### Intervention order

| Priority | Problem | Severity |
|---|---|---|
| 1 | Pro-tier color-only highlight | Accessibility blocker — fix before launch |
| 2 | Hero text contrast over background image | Accessibility blocker — verify now |
| 3 | CTA sizing and visual weight | Conversion blocker |
| 4 | Hero headline specificity | Conversion problem |
| 5 | Tier audience descriptors | UX friction |
| 6 | Feature table grouping and mobile behavior | UX friction |
| 7 | Testimonial placement | Optimization |

Fix 1 and 2 unconditionally. Fix 3 and 4 before any launch or paid traffic. Fix 5 and 6 in the next iteration. Test 7.

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "hierarchy_winner: CTA sizing and Pro-tier accessibility fix before headline rewrite",
    "intervention_order: accessibility blockers first, conversion problems second, UX friction third",
    "tradeoff_resolution: specificity over breadth in headline; compliance label over visual minimalism in Pro tier; tier descriptors over compactness"
  ],
  "evidence_classes_cited": [
    "wcag_1_4_1_use_of_color",
    "wcag_1_4_3_contrast_minimum",
    "wcag_1_4_11_non_text_contrast",
    "44px_touch_target_minimum",
    "structural_failure: color-only tier differentiation",
    "structural_failure: hero hierarchy inversion"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What are the actual color values used for Pro tier highlighting?",
    "Does the feature comparison table have any interactive behavior (toggles, filters)?",
    "Is there a designed mobile layout for the three-column table?"
  ],
  "turn": 1
}
[/SESSION_STATE]