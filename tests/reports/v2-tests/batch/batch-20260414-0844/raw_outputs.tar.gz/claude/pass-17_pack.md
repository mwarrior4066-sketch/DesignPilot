## Functional tier

Think of state as "where does this information live, and who needs to see it?"

Local state means a piece of data lives inside one component. If only that component (or its immediate children) needs it, local state is the right home. React's `useState` hook handles this. Context lets you share a value across a tree without passing it down manually through every layer, but it is not a storage or update engine on its own — it is a broadcast channel.

Redux (and similar tools like Zustand or Jotai) adds a separate store outside the component tree. Any component can read from it or write to it without caring where it sits in the hierarchy. The tradeoff is that you add a real system to manage: actions, reducers or slices, selectors, and often middleware.

The practical test: draw a line between data that only one screen needs (a form's draft text, whether a dropdown is open, a loading spinner's visibility) and data that multiple unrelated screens need simultaneously (who is logged in, a shopping cart, a notification count in the header while a checkout form is open on the same page). The first group belongs in local state. The second group is where a global manager earns its cost.

A common mistake is reaching for Redux because the app "might get complex later." That decision imports the full maintenance overhead now in exchange for an imagined future need. Start local. Add global state only when the pain of passing data across unrelated trees becomes real and frequent, not anticipated.

**Governing recommendation:** Use local state and context for this app now, and introduce a dedicated global state manager only when you have concrete cases where the same data is being read or mutated by components that have no shared ancestor at a reasonable level of the tree.

---

## Integrative tier

The real question is not "Redux vs. context" — it is "what are the actual coordination demands of this application, and what is the cheapest architecture that meets them honestly?"

**Local state** is zero-overhead: React owns the lifecycle, rendering is scoped to the subtree, and there is nothing to configure. **Context** extends that by lifting state to a provider and broadcasting it, but every consumer re-renders when the context value changes — which means coarse context usage at the app level can produce silent, hard-to-diagnose performance regressions at scale.

**Redux** (or its modern successors) solves a different problem: it gives you a predictable, inspectable, serializable store that is fully decoupled from the component tree. That decoupling pays off in specific conditions:

- State is shared across many unrelated subtrees simultaneously
- Mutations arrive from multiple sources (user interaction, WebSocket events, optimistic updates, background sync)
- You need time-travel debugging, action logging, or deterministic replay
- You have server state that must be normalized and cached across routes (though here React Query or SWR often serve better than Redux)

The cross-cutting cost that is easy to miss: Redux requires discipline. Without slice ownership rules, action naming conventions, and selector hygiene, Redux codebases drift into implicit coupling that is harder to untangle than a messy prop chain. The architecture tax is real before you even write a feature.

Context is often the right middle layer, but it requires deliberate scoping. A single `AppContext` at the root is an antipattern. Domain-scoped providers (one for auth, one for theme, one for cart) give you broadcast without making every value globally mutable by every component.

The question to answer before deciding: does this app have genuinely cross-cutting mutable state, or does it have a few shared values that can be cleanly owned by domain-scoped providers?

**Governing recommendation:** Architect the app with domain-scoped context providers for values that need to be shared across a subtree (auth, theme, user preferences), use local state for everything else, and adopt a dedicated store like Zustand or Redux Toolkit only if you identify a concrete pattern of cross-cutting mutable state that context's re-render behavior cannot serve without measurable performance cost.

---

## Strategic tier

The Redux-vs-context decision is a proxy for a more fundamental question: what is the consistency and coordination topology of this application's state?

Frame it along two axes:

**Breadth** — how many unrelated subtrees need to read or mutate the same value?  
**Mutation frequency and source count** — does state change from one place (user action) or from many (optimistic writes, server push, background sync, multi-tab coordination)?

Low breadth + single-source mutation: local state and context are both sufficient and correct. Adding Redux here is architecture overhead with no yield.

High breadth + multi-source mutation: this is where Redux's decoupled store, action pipeline, and selector memoization stop being ceremony and start being correctness infrastructure. Without a centralized store in this topology, you accumulate implicit coupling via prop drilling, context fan-out, or ad-hoc event buses — all of which are harder to audit than an explicit store.

The third case — high breadth, but the data is primarily server-derived and cacheable — is better owned by a server-state library (React Query, SWP, RTK Query). Treating server cache as client state inside Redux is a category error that creates unnecessary synchronization work.

**Rendering cost** is a concrete discriminator: context re-renders all consumers on value change; a selector-based store re-renders only subscribers whose selected slice changed. At medium-to-high component count with frequent updates, that difference is measurable in frame time, not theoretical.

The decision is not reversible without refactoring effort. Choosing Redux early when the coordination topology does not justify it creates a permanent maintenance surface. Choosing local state and context when the topology does justify a store creates a later migration with live data flow risk. The asymmetry favors deferring the store until the topology is confirmed, because the cost of deferring is lower than the cost of unnecessary global state machinery.

**Governing recommendation:** Audit the application's actual coordination topology before committing to a store: if genuine cross-subtree mutable state is confirmed, adopt Redux Toolkit or Zustand with explicit slice ownership and selector discipline; if the state profile is primarily server-derived, own it with React Query and keep client state local; if neither condition is met, context with domain-scoped providers is the correct and sufficient architecture.

[SESSION_STATE]
{
  "route": "rt_frontend_architecture",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: React component tree with optional decoupled store",
    "state_ownership: local state and domain-scoped context as default; global store only when coordination topology justifies it",
    "boundary_placement: domain-scoped providers at subtree boundaries, not a single root AppContext",
    "semantic_contract: server-derived state owned by server-state library, not Redux",
    "cost_or_degraded_path: context re-renders all consumers; selector-based store re-renders only changed-slice subscribers"
  ],
  "evidence_classes_cited": [
    "rendering_model",
    "state_ownership",
    "cost_surface",
    "architecture_tax",
    "boundary_placement"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does this app have confirmed cross-subtree mutable state, or is the complexity anticipated?",
    "Is the majority of shared state server-derived and cacheable (React Query territory) or client-owned?",
    "What is the expected mutation source count — user only, or also WebSocket/background sync/optimistic?"
  ],
  "turn": 1
}
[/SESSION_STATE]