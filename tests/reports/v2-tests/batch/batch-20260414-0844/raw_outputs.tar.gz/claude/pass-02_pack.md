## Split Button Component Spec

---

### Component boundary

A split button is a single logical control composed of two interactive segments: a primary action button and a secondary trigger that opens an action menu. The two segments share visual proximity and semantic grouping but are independently focusable, independently disabled, and independently stateful. They are not a single button with a dropdown — they are a compound control.

The menu opened by the trigger is a listbox or menu role, not a tooltip or popover.

---

### Anatomy

```
┌─────────────────────────┬────┐
│        Save             │ ▾  │
└─────────────────────────┴────┘
  Primary action btn       Trigger btn
  role="button"            role="button"
  aria-label="Save"        aria-label="More save options"
                           aria-haspopup="menu"
                           aria-expanded="true|false"
```

Both segments share one visual container but are rendered as two distinct focusable elements in the DOM.

---

### Variants and sizes

| Variant | Use |
|---|---|
| Default | Primary action is the confident default path |
| Destructive | Primary action cannot be undone |
| Ghost / outline | Lower-hierarchy placement in toolbars |

| Size | Primary min-width | Trigger width | Min touch target |
|---|---|---|---|
| SM | 80px | 32px | 44×44px (padding-compensated) |
| MD | 120px | 40px | 44×44px |
| LG | 160px | 48px | 44×44px |

Touch target sizing pads out to 44×44px using padding or a transparent hit extension — the visual size of the button does not need to change.

---

### States

Both segments carry independent states. Not all combinations are valid.

**Primary action states**

| State | Visual | Notes |
|---|---|---|
| Default | Filled, full opacity | — |
| Hover | Slightly darkened | Not on touch-primary devices |
| Focus-visible | Offset ring, 3px min | Keyboard only |
| Active / pressed | Depressed or darkened | Brief |
| Loading | Spinner replaces label, button disabled | See loading rules |
| Disabled | Reduced opacity, no pointer | See disabled rules |

**Trigger states**

| State | Visual | Notes |
|---|---|---|
| Default | Filled, matches primary segment | — |
| Hover | Slightly darkened | — |
| Focus-visible | Offset ring, 3px min | — |
| Active | Depressed | — |
| Open | Pressed/active visual while menu is open | aria-expanded=true |
| Disabled | Reduced opacity, no pointer | May be independently disabled |

---

### Disabled state rules

Three valid disabled configurations:

1. **Both segments disabled** — the entire control is inactive. Add `disabled` to both buttons. Do not rely on pointer-events alone; `disabled` on `<button>` removes it from tab order and keyboard activation correctly.

2. **Primary disabled, trigger active** — valid when secondary actions are still available (for example, "Save" is unavailable until required fields are filled, but "Save as draft" still works).

3. **Trigger disabled, primary active** — valid when secondary options are contextually unavailable but the primary action still works.

Do not use `aria-disabled="true"` as a substitute for `disabled` unless you explicitly need the element to remain in tab order with a custom "why is this disabled" explanation. If you use `aria-disabled`, you must also intercept click and keydown events and prevent the action.

Do not grey out the entire control silently. When the disabled state is conditional, provide a visible or programmatic reason adjacent to the control, or via `aria-describedby`.

---

### Loading state rules

Loading applies to the primary action only, in response to a Save being submitted.

**Behavior:**
- Replace primary button label with a spinner and a visually hidden label: `<span aria-live="polite" class="sr-only">Saving…</span>`
- Disable both segments during loading — the trigger should not open while a save is in flight
- Restore both segments when the operation resolves (success or error)
- Do not leave the button in a loading state indefinitely; set a timeout fallback that restores the control and surfaces an error

**Spinner specs:**
- 16px at MD, 12px at SM, 20px at LG
- Respects `prefers-reduced-motion`: swap the spinner for a static ellipsis (`…`) or a brief progress text rather than removing feedback entirely
- Color matches the button label color, not the background

**Success feedback (optional but recommended):**
A brief checkmark state (500–800ms) before restoring the default label gives the user a clear completion signal without requiring a separate toast for every save.

---

### Menu contents

```
┌────────────────────────────┐
│ ✓  Save as draft           │
│    Save and close          │
└────────────────────────────┘
```

- `role="menu"` on the container
- `role="menuitem"` on each option
- The menu is not a `<select>` — do not use select semantics
- Menu width: at minimum matches the full width of the split button control, not just the trigger width
- Menu position: opens below the trigger by default; flips above when viewport bottom space is insufficient
- Dismiss: Escape closes the menu and returns focus to the trigger; clicking outside closes the menu; selecting an item closes the menu and moves focus back to the trigger (or primary button, depending on action)

---

### Keyboard support

This is the full required keyboard contract. Deviations from this are accessibility failures, not design preferences.

| Key | Context | Behavior |
|---|---|---|
| Tab | Anywhere | Moves focus to primary action first, then trigger (DOM order) |
| Shift+Tab | Anywhere | Reverses tab order |
| Enter or Space | Primary action focused | Triggers Save |
| Enter or Space | Trigger focused, menu closed | Opens menu |
| Arrow Down | Trigger focused, menu closed | Opens menu, moves focus to first menu item |
| Arrow Down | Inside menu | Moves to next item, wraps to first |
| Arrow Up | Inside menu | Moves to previous item, wraps to last |
| Enter or Space | Menu item focused | Activates item, closes menu, returns focus to trigger |
| Escape | Menu open | Closes menu, returns focus to trigger |
| Tab | Inside menu | Closes menu, moves focus to next element outside the control |

Do not trap Tab inside the menu. Tab should exit, not cycle.

Home and End inside the menu are optional but recommended for long menus: move to first and last item respectively.

---

### Touch behavior

- Both segments must hit 44×44px minimum regardless of visual size. Use padding or an invisible tap extension layer (not margin, which does not extend the hit area).
- On touch devices, hover states do not apply. Do not rely on hover to reveal the trigger exists — the trigger chevron must always be visible.
- The trigger opens the menu on tap. The menu should be a bottom sheet or anchored sheet on small viewports (below 480px), not a small floating popover that is difficult to tap accurately.
- Menu items inside the sheet need 48px minimum height on mobile.
- Dismiss on mobile: tap outside the sheet, or drag down if implemented as a bottom sheet. Escape key dismissal applies on keyboards attached to mobile devices.

---

### ARIA contract

```html
<div role="group" aria-label="Save options">
  <button type="button" aria-label="Save">
    Save
  </button>
  <button
    type="button"
    aria-label="More save options"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="save-menu"
  >
    <svg aria-hidden="true" focusable="false"><!-- chevron --></svg>
  </button>
  <ul
    id="save-menu"
    role="menu"
    aria-label="Save options menu"
    hidden
  >
    <li role="none">
      <button role="menuitem">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem">Save and close</button>
    </li>
  </ul>
</div>
```

Notes:
- `role="group"` wraps both buttons so screen readers announce them as a related unit
- `focusable="false"` on the SVG chevron prevents double focus in some older browsers
- `aria-controls` is supported variably; treat it as progressive enhancement, not a required behavior anchor
- When the menu is hidden, use the `hidden` attribute, not `display:none` alone — both work, but `hidden` is semantically cleaner and avoids CSS specificity accidents
- `aria-expanded` flips to `"true"` when the menu is open, `"false"` when closed — never omit it when `aria-haspopup` is present

---

### Implementation boundary

What this component owns:
- both button segments and their states
- the trigger's open/close behavior
- the menu position and dismiss logic
- keyboard navigation within the menu
- loading and disabled state management
- ARIA contract maintenance

What this component does not own:
- the actions themselves (Save, Save as draft, Save and close are wired in by the consumer)
- toast or confirmation feedback after the action resolves
- the form validation state that might drive the disabled condition
- routing or navigation triggered by "Save and close"

The component exposes:
- `onPrimaryAction` callback
- `onSecondaryAction(actionId)` callback
- `isLoading` prop (boolean, drives loading state on primary + disables trigger)
- `isDisabled` prop (boolean, disables both segments)
- `isPrimaryDisabled` / `isTriggerDisabled` props for independent control
- `menuItems` prop (array of `{ id, label, onSelect }`)
- `placement` prop for menu direction override

---

### Tradeoffs named

Using two separately focusable buttons rather than a single button with a submenu trigger means two Tab stops instead of one. This is the correct tradeoff: it preserves independent keyboard activation of each segment (you sacrifice one-tab-stop economy to gain independent keyboard reachability and cleaner state semantics).

Using `role="menu"` rather than a `<select>` means you own all keyboard navigation logic rather than getting browser-native arrow-key handling for free. This is worth it because `<select>` cannot be styled adequately on most platforms and does not support icons, descriptions, or grouping in secondary options (you sacrifice native control behavior to gain full visual and interaction control).

Using `prefers-reduced-motion` to replace the spinner with static text rather than simply removing motion feedback means reduced-motion users still receive a loading signal. Removing feedback entirely to satisfy the preference is incorrect — the preference is for reduced motion, not reduced information.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: two independently focusable segments within a single group container",
    "state_coverage: default, hover, focus-visible, active, loading, disabled — independent per segment",
    "accessibility_behavior: full keyboard contract, ARIA group/menu/menuitem, aria-expanded, aria-haspopup, prefers-reduced-motion spinner fallback",
    "implementation_boundary: component owns button states and menu behavior; consumer owns actions, toasts, routing, and form validation"
  ],
  "evidence_classes_cited": [
    "wcag_target_size_44x44",
    "aria_authoring_practices_menu_button",
    "prefers_reduced_motion_constraint",
    "keyboard_navigation_contract"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the primary Save action submit a form or trigger an API call directly — affects loading state timeout and error recovery behavior",
    "Is there a maximum number of secondary menu items, or can the list grow dynamically"
  ],
  "turn": 1
}
[/SESSION_STATE]