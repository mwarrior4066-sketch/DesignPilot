## Research Gap Map: B2B Project Management Redesign

### What the evidence actually tells you

Before mapping gaps, it helps to be precise about what your current evidence proves versus what it suggests.

**Stakeholder interviews (3)** — organizational priorities, perceived pain points, and internal assumptions. This is not user evidence. It tells you what the business believes is broken, which may or may not match what users experience.

**Usability tests on current product (2)** — observed task failures and friction points on a known flow. Low sample size means you have directional signal, not representative coverage. You cannot generalize across roles or company sizes from two sessions.

**60% drop-off on project creation** — confirms a real behavioral problem. It does not tell you whether users are abandoning because the flow is confusing, because the required information is not ready, because they got interrupted, or because they completed the task elsewhere.

None of your current evidence explains intent, workarounds, or the mental model users bring to the tool.

---

### Gap map by priority

#### 1. Abandonment cause — blocks core design decisions

**What you know:** 60% of users stop during project creation.
**What you do not know:** why they stop, whether they return, whether they complete the task through another path, and whether the drop-off point is consistent across user types.

**Why this is first:** every layout, field order, and flow decision in the redesign will be contested without this. You risk fixing the wrong thing — restructuring a form when the real blocker is a required field users cannot answer yet, or a permission problem, or a distraction outside the tool.

**Methods that close this gap:**
- Exit survey at the drop-off point (intercept, 5 questions maximum) — fast, cheap, gives you reason categories
- Session replay review on the abandonment sessions — look for hesitation, backtracking, rage clicks, and where attention drops
- Short follow-up interviews with users who abandoned in the last 30 days — 6 to 8 sessions, focused on that specific moment

**Evidence class you are missing:** behavioral cause, not just behavioral fact.

---

#### 2. Power user mental models and workarounds — shapes what the system needs to support

**What you know:** nothing about power users.
**What you do not know:** how advanced users structure projects, what shortcuts or workarounds they have built, which parts of the current tool they have adapted, and what constraints they work around. In B2B project management, power users disproportionately influence adoption — they often train others, create templates, and define team conventions.

**Why this matters structurally:** a redesign that optimizes for first-time project creation may actively break the workflows power users have built. This is a common failure mode in B2B redesigns.

**Methods that close this gap:**
- Contextual inquiry or workflow shadowing — 4 to 6 sessions with users who are daily, heavy tool users across different company sizes
- Artifact collection — ask users to share templates, screenshots of project structures, and any external tools they use alongside this one
- Diary or log study if direct observation is difficult — 5 to 7 days of structured self-reporting

**Evidence class you are missing:** expert-use workflow structure and workaround inventory.

---

#### 3. Competitive and alternative-tool framing — sets the expectations your users arrive with

**What you know:** nothing about how users perceive alternatives.
**What you do not know:** which competing tools users have experience with, what interaction conventions they consider normal, and where your tool's current model differs from their prior mental model in ways that create confusion rather than delight.

In B2B, users often arrive with strong habits from previous tools. Drop-off on project creation may partially reflect expectation mismatch, not just UI failure.

**Methods that close this gap:**
- Screener-based recruiting to find users who switched from a named competitor — 4 to 6 interviews focused specifically on the transition experience
- Heuristic walkthrough of 2 to 3 direct competitors using your current usability test tasks as the test script — this gives you a direct comparison on the same task

**Evidence class you are missing:** comparative expectation baseline.

---

#### 4. Role and permission complexity across account types — affects feasibility of any redesign

**What you know:** aggregate drop-off, but not segmented by role, company size, or permission level.
**What you do not know:** whether the 60% figure is driven by one role type (say, project initiators who lack permission to set certain fields), or whether it is evenly distributed. In B2B tools, permission-gating is often invisible to users and shows up as unexplained friction.

**Why this is a design constraint, not just a research question:** if the drop-off is concentrated among users who hit a permission wall, the design solution is a different flow or a progressive disclosure approach — not a visual redesign of the form.

**Methods that close this gap:**
- Analytics segmentation — break the 60% by user role, account tier, and session context before any qualitative research begins. This is low-cost and can reframe priorities immediately.
- 3 to 4 targeted interviews with users in the most-affected role segment, identified from the segmented data

**Evidence class you are missing:** behavioral segmentation by actor type.

---

### Research sequence

This order is not arbitrary. Each step either prevents wasted work or sharpens the next step.

1. **Analytics segmentation** — run first, costs nothing, may immediately reframe whether the project creation problem is UX or permissions
2. **Exit survey + session replay** — run in parallel, closes the abandonment cause gap before design begins
3. **Power user contextual inquiry** — run before detailed flow design, so you are not building a system that breaks expert workflows
4. **Competitor walkthrough + transition interviews** — run before information architecture decisions are locked, because these shape field labels, terminology, and flow conventions
5. **Role-targeted follow-up interviews** — run once segmentation data and early qualitative findings are in hand

---

### What cannot be resolved with current evidence

A few design decisions should be explicitly flagged as unresolved until research closes:

- Whether the project creation flow needs restructuring or progressive disclosure — cannot determine without abandonment cause data
- Whether to preserve or redesign power-user-created template behavior — cannot determine without power user research
- Whether terminology or field naming is contributing to confusion — cannot determine without comparative or transition research
- Whether the drop-off is a single-segment problem or a universal one — cannot determine without analytics segmentation

Proceeding on any of these without closing the relevant gap is a design bet, not a design decision. It is worth being explicit with stakeholders about which bets you are making and why.

[SESSION_STATE]
{
  "route": "rt_ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": [
    "known_evidence: stakeholder interviews (3), usability tests (2), 60% drop-off analytics",
    "gap_priority: abandonment cause > power user mental models > competitive framing > role segmentation",
    "method_mapping: exit survey + replay for abandonment; contextual inquiry for power users; competitor walkthrough + transition interviews for competitive framing; analytics segmentation for role gap",
    "research_sequence: analytics segmentation first, then exit survey + replay in parallel, then power user inquiry, then competitor research, then role-targeted interviews"
  ],
  "evidence_classes_cited": [
    "behavioral_fact_without_cause",
    "low_sample_usability_signal",
    "organizational_assumption_not_user_evidence",
    "missing_expert_workflow_inventory",
    "missing_comparative_expectation_baseline",
    "missing_behavioral_segmentation"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are analytics segmentable by user role and account tier today, or does that require additional instrumentation?",
    "Is there budget or timeline pressure that should reprioritize the research sequence?"
  ],
  "turn": 1
}
[/SESSION_STATE]