To reconstruct your old brand guideline layout system from the 2018 PDF and translate it into a modern, reuse-friendly layout system, I would follow a structured evidence-driven process. Here’s a detailed break-down of what I’d extract and how I’d bridge that legacy system into current templates:

---

## 1. **Extraction from PDF**

**A. Grid Diagrams**

- **Observed/Extracted:**  
  - Number of columns per page type (e.g., 6-column, 12-column)
  - Column width, gutter size, and rhythm  
  - Explicit baseline grid, if shown (e.g., 8pt, 12pt increments)
  - Variance by page size/orientation (A4, Letter, presentation slide, digital banner)

- **Translation:**  
  - Document the exact pixel or point values for columns and gutters
  - Capture any visual hierarchy: Is there a “main” column, supporting columns, or asymmetrical balance?
  - If a baseline grid is present, note both baseline increment and alignment rules for text and object placement

**B. Margin Specifications**

- **Observed/Extracted:**  
  - Margin values for top, bottom, inside, outside edges
  - Notation for print-safe zones, bleed areas, or digital viewport compensation
  - Any minimum/maximum rules for margin scalability (e.g., for responsive/web adaptation)

- **Translation:**  
  - Rebuild as a margin token set or layout variable (e.g., ‘lg-margin: 40px; sm-margin: 24px’)
  - Map print-focused margins to responsive web or slide-safe standards
  - Retain safe minimums for readability and branding “air”

**C. Column Layout Examples**

- **Observed/Extracted:**  
  - Real-world page examples: how modules/content blocks are arranged
  - Variants (e.g., 2/3-1/3 splits, nested grids, feature images spanning columns)
  - Any recurring templates: cover/title, contents, content spread, data tables

- **Translation:**  
  - Catalog sample templates and note which layouts are core vs. legacy-specific
  - Identify constraints (e.g., does a sidebar always live in column 1, or can it float?)
  - Generalize patterns into reusable containers/components for modern systems

---

## 2. **Mapping Evidence to Modern System**

**A. Normalize Units & Modular Scale**

- Translate physical units (pt, mm, inches) to digital-friendly units (px, rem, or CSS grid fractions)
- If the legacy system is not on a strict 4/8/12-point scale, adapt to a modular system for modern flexibility

**B. Derive Responsive Grid Principles**

- If the legacy system is print/A4-centric, define breakpoint logic for digital usage (desktop/tablet/mobile)
- Introduce CSS Grid/Flexbox-compatible models, retaining proportional logic (e.g., retain a 12-column logic at desktop, collapse to 4/1 at mobile)

**C. Codify as Tokens and Primitives**

- Build out design tokens or layout primitives for:
  - Column/gutter/margin sizes
  - Breakpoint rules and edge cases
  - Container widths and max/min constraints
  - Baseline grid increments

**D. Template Componentization**

- Create core Figma/Sketch/Component Library templates using extracted patterns
- Map common modules: Title page, standard content, two-column content, data table, etc.

---

## 3. **Document Decisions & Tradeoffs**

- **Preserved:** Historical proportions, margin "feel," template recognizable structure, grid discipline  
- **Sacrificed:** Rigid print-only constraints, manually fixed-point placement, outdated safety/boundary rules  
- **Modernization:** Introduce responsive scaling, modular tokens, and flexible containers (enabling web/app as well as print)

---

## 4. **Verification**

- Sample a legacy guideline page and rebuild using the new system: margins, columns, module placements
- Test for integrity: does the modern system reproduce the original intent and visual rhythm? Adjust as necessary.

---

**Summary:**  
You’ll extract all measurable layout primitives (columns, gutters, margins, baseline) and core arrangement patterns. These will be translated to modular, responsive rules with design tokens and scalable templates for current tools (web, print, slides). The result is a modern system faithful to the old—but fast to deploy, adapt, and maintain.  

If you’d like a practical grid spec template or sample Figma guideline, let me know what format you need!