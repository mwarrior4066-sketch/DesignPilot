## Type System Recommendation for a Fintech Product

### Reading Context

This fintech product requires a type system serving three distinct platform contexts:
- **Marketing site:** Brand-level communication, trust signals, varied messaging.
- **Web app dashboard:** Dense, tabular financial data, transactional forms, analytical views.
- **Mobile app:** Smaller screens, focused tasks, high legibility demands.

Together, these platforms demand a harmonious system that’s modern, trustworthy, versatile in weight/scale, and excellent for numbers and tabular layouts.

### Scale Decision

**Approach:**  
Adopt a modular scale consistent across platforms—e.g., a 1.25 (Major Third) ratio—starting from a readable base (16px for body on web, 15/16px for mobile). Variable sizing should let headers, stats, labels, and fine print coexist naturally.

**Reason:**  
A consistent scale simplifies hierarchy and responsive behavior, while permitting brand customization where needed.

### Font Recommendation & Pairing Rationale

**Primary Typeface:**  
**Inter** (by Rasmus Andersson)

**Why Inter?**  
- **Modern & trustable:** Designed for UI, widely trusted by tech and financial brands.
- **Tabular excellence:** Includes tabular figures (`tnum`) and financial data-friendly punctuation.
- **Multiple weights:** Ranges from Thin to Black; supports hierarchical depth even in tight dashboards.
- **Web & mobile optimized:** Open source, variable font available, excellent hinting.
- **Readability:** Open shapes, ample x-height, supports rapid scan and dense layouts.
- **Global support:** Latin, Cyrillic, Greek.

**Secondary/Brand Accent Typeface (optional):**  
**Public Sans** or **IBM Plex Sans** — both are publicly trusted, have good contrast for headline/brand uses, and are visually compatible with Inter.

### Adoption Sequence

1. **App Dashboard & Mobile core:**  
   - Deploy Inter for all UI elements.
   - Use tabular numerals for balance sheets, tables, numbers.
2. **Marketing site:**  
   - Inter-primary, accent headings in Public Sans (if extra distinction needed); otherwise, use Inter for consistency.
   - Fine-tune letter-spacing and cases for large hero/CTA messages.
3. **Weight/Hiearchy:**  
   - For hierarchy, use Regular (400), Medium (500), and Bold (700).
   - For emphasis, leverage font weight before color for accessibility and clarity.

### Further Guidance & Tradeoffs

- **What is preserved:**  
  - Modern, trustworthy, readable feel; seamless hierarchy; easy systemwide management.
- **What is sacrificed:**  
  - If the desire is for distinctive brand voice or unique personality, Inter is neutral-positive. Brand distinctiveness must rely on layout, color, accent font, or illustration—not type alone.

### Alternatives (for comparison)

- **SF Pro (Apple)**: Excellent for mobile and native apps, but licensing is limited for web/marketing.
- **Roboto (Google):** Good generalist, but less characterful and less “finance” than Inter.
- **Space Grotesk:** Slightly more unique; tabular support, but less neutral for financial text-heavy tasks.

### Summary Table

| Use case       | Font         | Sizes             | Weights        | Features                  |
|----------------|--------------|-------------------|----------------|---------------------------|
| Dashboard      | Inter        | 15–32px           | 400/500/700    | Tabular nums, high legibility |
| Marketing      | Inter/Public Sans (opt) | 16–48px | 400/700        | Accent in headings optional       |
| Mobile         | Inter        | 15–28px           | 400/700        | OS fallback: San Francisco/Roboto |

### Critical Constraints

- **Accessible contrast** and clear expression at all levels.
- **Tabular figures** (`font-variant-numeric: tabular-nums`) for financial tables.
- **Consistent fallback stack**: Inter, Segoe UI, Roboto, Arial, sans-serif.
- **Open-source licensing** for broad use.

---

**Next Move:**  
If approved, I can provide a starter CSS/font specification for app and brand teams, including variable font setup and typographic rhythm guidance.