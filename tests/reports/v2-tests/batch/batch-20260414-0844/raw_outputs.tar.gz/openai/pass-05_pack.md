Here’s what needs to be done to make your exported InDesign PDF accessible and work well with screen readers, with a logical reading order and correct export semantics:

---

## Diagnosis

**Issues observed:**
- **Two-column layout**: Screen readers may read across columns unless the reading order is correctly tagged.
- **Pull quotes interrupt main text**: Pull quotes may be read out of context, confusing the intended flow.
- **Decorative images not tagged**: These may be announced as "image" by screen readers, distracting users.
- **Broken TOC links**: The Table of Contents does not allow navigation, defeating a core accessibility feature.
- **Exported directly from InDesign**: InDesign’s default PDF export often needs additional tagging and reading order correction, especially with complex layouts.

---

## Recommended Repair Plan

### 1. Artifact and Tag Decorative Images

- **In Acrobat Pro**:
  - Use the Reading Order tool or the Tags pane.
  - Identify each decorative image (purely visual, not informational).
  - Right-click the tag (or add one if missing), and set it as an **Artifact** (background).  
    *Artifacts are ignored by assistive technology.*
  - If a tag exists, rename it from `<Figure>` to `<Artifact>`.
  - If using InDesign, mark decorative images as "Decorative" (Object Export Options > Tagged PDF).

### 2. Fix the Reading Order for Columns and Pull Quotes

- **Columns**:
  - In Acrobat Pro, open the Order pane.
  - Drag and number content blocks so the reading sequence follows the left column top-to-bottom, then right column, not across columns line by line.
- **Pull Quotes**:
  - Pull quotes should be placed in the reading order where they make sense contextually, or tagged as side content.
  - If non-essential to comprehension, tag as `<Aside>` or **Artifact**, so screen readers skip or minimize them.
  - If essential, place them after the surrounding paragraph or at a logical point in the tag tree.
- **Check in the Tags pane** to confirm order matches intended flow.

### 3. Restore and Validate the Table of Contents Links

- In Acrobat Pro:
  - Use the **Link tool** to repair or re-create broken TOC links.  
    Right-click the TOC text, select "Create Link," choose "Go to page view," and select the destination.
  - In the Tags pane, ensure TOC entries are tagged as lists (`<L>`) or links (`<Link>`).
- Test with the Read Out Loud tool or a screen reader emulator to ensure TOC navigation works.

### 4. Validate and Repair Tags

- Use **Acrobat Pro**’s Accessibility Checker (“Full Check”) to find:
    - Untagged content
    - Improper tag types
    - Reading order mismatches
- Manually inspect the Tag Tree for:
    - Proper headings (`<H1>`, `<H2>`, etc.)
    - Correct paragraph (`<P>`) and list (`<L>`) tagging
    - No generic `<Span>` tags wrapping major sections
- Assign meaningful alt text to any remaining images that are not decorative.

### 5. Reflow and Logical Structure Check

- Export a reflowed version or use a screen reader tool to experience the PDF as a non-visual user would.
- Make sure that the content reads in intended sequence, with pull quotes and columns not causing confusion.

---

## Summary Table: Actions and Responsibilities

| Issue            | Action                                     | Repair Tool         | Notes                             |
|------------------|--------------------------------------------|---------------------|------------------------------------|
| Columns          | Fix reading order (Order/Tags)              | Acrobat Pro         | Tag by column, not page           |
| Pull Quotes      | Tag as `<Aside>` or position logically      | Acrobat Pro         | Avoid reading interruptions       |
| Decorative Images| Mark as Artifact/decorative                 | Acrobat Pro/InDesign| Exclude from accessibility tree   |
| TOC Links        | Re-create/repair links                      | Acrobat Pro         | Tag as `<Link>`, test navigation  |
| Tagging          | Validate, retag as needed                   | Acrobat Pro         | Headings, paragraphs, lists       |

---

## What You Preserve vs. Sacrifice

- **Preserved:**  
  - Structural integrity for visual readers (columns, pull quotes, images).
  - Visual design remains unchanged for print and sighted users.
  - Navigability and usability for screen reader/non-sighted users.
- **Sacrificed:**  
  - Some visual complexity or decorative elements may be ignored or skipped by assistive tech.
  - Pull quotes may not have the same dramatic emphasis in the audio experience.

---

## Risks and Safer Path

- **Risk:** Manually fixing tags and order in Acrobat is error-prone for large or frequently-updated reports.
- **Safer path:**  
  - If possible, revise the InDesign source:
    - Use correct article threads.
    - Set Object Export Options for all elements up front.
    - Export as “Tagged PDF” with reading order “Use Document Structure”.
  - Perform a round of accessibility checking post-export.

---

## Verification Method

- Run Acrobat’s Accessibility Checker and manually review the tag tree.
- Test with NVDA, VoiceOver, or JAWS to confirm navigation and reading order.
- Use PAC (PDF Accessibility Checker) for an additional automated scan.

---

**Summary:**  
The fastest, most robust fix is to tag decorative images as artifacts, manually reorder tags for columns and pull quotes, and repair TOC links in Acrobat Pro after export. For better future-proofing, adjust InDesign’s export structure and tagging before export, then validate in Acrobat as a final step.

Would you like step-by-step visuals for performing these fixes in Acrobat, or scripts/checklists to help a team repeat this process?