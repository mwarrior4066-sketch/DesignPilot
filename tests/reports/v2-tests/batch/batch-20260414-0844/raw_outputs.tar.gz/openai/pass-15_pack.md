## Backend Architecture Spec  
**Product:** Multi-tenant Scheduling Platform  
**Key Features:**  
- Team workspaces  
- Cursor-based activity feeds  
- Approval workflows  
- Outbound webhooks to customer systems  
- Regional data residency  
- Audit trails  
- Future: customer-defined automation rules  
- REST APIs, relational DB in place; background jobs/eventing inconsistent  

---

### 1. **Core Services**

#### a. **API Gateway**  
- Aggregates all external REST API traffic  
- Enforces tenant isolation and authentication/authorization (OAuth2/JWT tokens)  
- Directs traffic to region-specific clusters based on tenant residency  

#### b. **Workspace Service**  
- Orchestrates team workspace creation, updates, and permissions  
- Owns workspace membership, invitations, and RBAC (role-based access control)  
- Exposes workspace CRUD, membership, and policy APIs  

#### c. **Scheduling/Events Service**  
- Manages user/team calendars, bookings, schedule slots, and availability logic  
- Handles scheduling conflicts and multi-party logic  
- Enforces approval workflow integration points  
- Interfaces with background job runner for event triggers (reminders, notifications, escalations)  

#### d. **Activity Feed/Timeline Service**  
- Owns feed data model for each workspace  
- Implements cursor-based pagination for efficient infinite scrolling  
- Listens to workspace and scheduling changes (via event bus) to populate feed entries  
- Exposes feed APIs with signed cursors for forward/backward pagination  

#### e. **Workflow/Approval Engine**  
- Encapsulates approval and escalation rules for schedule requests and key actions  
- Stores policy definitions per customer/workspace  
- Owns state transitions, assignment, notification events  
- Produces timeline/audit entries upon key state changes  

#### f. **Outbound Integrations Service**  
- Owns webhook subscriptions, batching, queuing, delivery, and retry  
- Signs and encrypts outbound payloads; provides delivery logs and failure handling  
- Enforces per-tenant rate limits and isolation  
- Observes workspace and scheduling events, triggers configured webhooks with event metadata  

#### g. **Background Job Runner + Event Bus**  
- Centralized, region-aware job queue for all async processing (Celery, Sidekiq, or managed alternative)  
- Event bus (Kafka, RabbitMQ, or cloud-native pub/sub) to publish/subscribe domain events  
- Ensures strong at-least-once delivery, deduplication, and dead letter handling  
- Enables cross-service comms (e.g. feed listens to scheduling events, webhook enqueues on approval completion)  

#### h. **Audit Trail Service**  
- Writes immutable logs for all security/audit-relevant actions (schedule changes, approvals, admin actions)  
- Backs audit log to region-constrained, append-only storage (e.g. regional S3, GCP Bucket, or DB tables)  
- Exposes APIs for audit search/filter per admin/tenant  
- Monitors data residency and access control at log level  

#### i. **Automation Rules Engine** (Future/Extension)  
- Allows customers to author automation rules (“If event X, then action Y,” e.g. via low-code JSON logic)  
- Isolates customer rule execution in sandboxed environment (evaluate CPU/memory guards)  
- Subscribes to domain events, mutates workspace state, enqueues jobs, and triggers integrations  
- Audits rule actions to the audit trail; surfaces failures in workspace runtime  

---

### 2. **Data Boundaries & Isolation**

- **Tenant Data Isolation:**  
  - Every data model row must be tagged with tenant_id; access is filtered by policy in every service  
  - No cross-tenant joins, queries, or calls  
- **Regional Residency:**  
  - Each tenant is pinned to a deployment region at signup (EU, US, etc.)  
  - Data and jobs related to the tenant reside in region’s DB, queues, and storage  
  - API Gateway honors residency when routing and for webhook callouts  
- **Domain Service Boundaries**:  
  - Core domains: Workspace, Schedule/Event, Activity Feed, Workflow, Integrations, Audit, Automation (future)  
  - Only events, not direct DB calls, cross service boundaries  
- **Audit Logs & Legal Holds:**  
  - Audit logs tied to both tenant and region; append-only; immutable  
  - Support "right to be forgotten" and legal holds per region/law  

---

### 3. **Service Contracts**  

#### a. **Domain Events**  
- Services emit domain events (e.g., `"schedule.booked"`, `"approval.completed"`, `"webhook.failed"`) on event bus  
- Consistent event envelope:  
  ```json
  {
    "event_type": "schedule.booked",
    "occurred_at": "2024-06-07T12:34:56Z",
    "actor_id": "user_...",
    "tenant_id": "tenant_...",
    "region": "eu-central-1",
    "payload": { ... }
  }
  ```  
- Events must be idempotent, with unique IDs for deduplication  

#### b. **API Contracts**  
- All APIs prefixed with `/api/v1/`, all endpoints enforce tenant/user scoping  
- Pagination APIs use signed cursors (opaque tokens encoding query position, expiry, tenant, etc.)  
- Webhook endpoint registry per tenant; supports pull and push  
- Output webhook deliveries include event type, occurred time, workspace, resource link, etc.; batched and retried as needed  
- Audit log access is RBAC-filtered per tenant/workspace/admin, and region-constrained  

#### c. **Background Jobs Contracts**  
- All async jobs post job receipt + job_id to calling service  
- Job status exposed via `/jobs/<job_id>` endpoint  
- Retry, error handling, and dead-letter defined per job type  
- Job and event metadata must contain tenant, region, correlation_id for traceability  

---

### 4. **Operational & Observability Concerns**

- **Multi-Region Deployment:**  
  - Each region is an isolated deployment (potentially with shared control plane/meta)  
  - DB, queues, and object storage are region-specific  
- **Data Residency & Compliance:**  
  - All services observe region boundaries for data at rest and in transit  
  - Regulatory requirements for audit, retention, deletion implemented per region  
- **Eventual Automation Controls:**  
  - Rules engine is opt-in, gated by admin approval; sandbox for rule safety  
- **Auditability:**  
  - All critical actions and service-to-service calls are logged in the audit trail  
  - Audit service itself is shielded from user and admin tampering; logs are immutable  
- **Security & Tenancy:**  
  - All service-to-service calls authenticated (mTLS, signed JWT)  
  - "Deny by default" for cross-tenant access at every trust boundary  
  - Per-tenant API rate limiting  
- **Operational Monitoring:**  
  - Distributed tracing (trace_id/correlation_id on all events, jobs, webhooks)  
  - Metrics: event lag, job backlog/staleness, webhook delivery stats, approval SLAs, feed performance  
  - Alerts on queue jams, cross-region failures, audit anomalies  
- **Webhooks Reliability:**  
  - Outbound queueing and retries with exponential backoff + DLQ  
  - Delivery status accessible to customers; notifications for persistent failures  
- **Job and Event Consistency:**  
  - All business logic that changes system state emits events  
  - Services consuming events are idempotent, retry-safe  
  - Jobs that cross trust boundaries (e.g., automation rules) are audited and sandboxed  

---

### 5. **Tradeoffs & Rationale**

- **Why strong region boundaries:** to meet data residency/compliance needs; at the cost of operational complexity and some latency  
- **Why event-driven services:** supports extensibility (automation, webhooks, feeds); at the cost of operational overhead and partial ordering  
- **Cursor-based feeds:** scales better for real-time/team scenarios; avoids offset-based pagination scans, but requires stable index and anti-tamper design  
- **Audit trail as first-order service:** ensures provable integrity, compliance, and customer trust; at storage and implementation cost  
- **Automation as a future extension:** keeps scope separated; ensures initial stability; future proof by making all core events observable and action-trigger-friendly  

---

### 6. **Verification**

- Service boundaries strictly mapped (no cross-domain DB calls, only events/API)  
- Data tagged and filtered by tenant/region everywhere  
- Test data residency with regional cutovers and failovers  
- Audit endpoints validate event lineage and immutability  
- Webhook delivery and retry flows load tested per region  

---

**Authority Model:** Each service denotes tenant ownership, region pinning, and emits traceable events only. Admin actions and automation are always sandboxed and audited.  
**Consistency Stance:** Favor strong consistency per tenant-region, with eventual global propagation only for meta/config.  
**Data Delivery:** Regional DBs and queues; event bus and webhook delivery region-local; cross-region replication for cold-backup only.  
**Observability Tax:** All services pay the cost for distributed tracing, audit emission, and compliance reporting.

---

**If you need:**
- Service deployment diagrams
- Example event contracts or schemas
- Operational runbooks or SOPs  
…Let me know which asset is most helpful for next steps.