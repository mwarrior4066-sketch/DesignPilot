**Architectural Concerns and Governing Decisions**

---

### 1. Idempotency Contract  
**Governing decision:** Idempotency is not enforced (no idempotency key required).

**Reasoning:**  
POST endpoints that mutate membership risk duplicate additions if the request is retried (e.g., network errors, user double-clicking, client retries). Without an idempotency mechanism (e.g., an Idempotency-Key header or an idempotent contract like PUT), repeated calls may create unintended side effects or inconsistent state.  
**Resolution:** For safe, retryable POSTs that can be invoked more than once with the same logical intent, require an Idempotency-Key header and apply the 409/201/200 pattern per [RFC 9457]. This preserves mutation contract integrity and enables robust retry by clients.

---

### 2. Error Response Contract  
**Governing decision:** Error responses return a plain string, not a structured contract.

**Reasoning:**  
Returning a bare string is not robust for API consumers—it prevents structured parsing, internationalization, and programmatic error handling. Most production-grade APIs standardize on typed error bodies (e.g.,  
```json
{ "error": "User is not admin", "code": "forbidden", "details": ... }
```
or RFC 9457 / RFC 7807 Problem Details).  
**Resolution:** APIs should return a structured error object with at minimum a standard `type` (or `code`), human-readable `message`, and optional `details` for context. This improves debugability, client UX, and stability across releases.

---

### 3. Authorization Model  
**Governing decision:** Authorization only requires a logged-in user, not project-level admin privileges.

**Reasoning:**  
Project membership mutations are a sensitive, permissioned operation. Limiting access only by authentication (logged-in status) is insufficient. Correct contract should verify that the caller has project-bound authority—typically project-level "admin", "owner", or explicit permission to manage membership—before allowing member changes.  
**Resolution:** Implement an object-level authorization check: only users with admin/owner roles (or an ACL management permission) on a project can add members.  
_Principle: least privilege. Implementation: check user's project role before mutating membership, reject with 403/Problem Details contract if insufficient._

---

### 4. Response Shape  
**Governing decision:** Successful response returns the full updated member list (200 OK).

**Reasoning:**  
Returning the full member list is practical in some UX settings but can be wasteful for projects with large membership. Consider if returning only the added (or upserted) member, or a reference to the membership resource, would better support scalability and privacy.  
**Tradeoff:** Returning full list is easier for clients needing fresh state, but streaming/partial responses or hypermedia references can be safer at scale.  
**Resolution:** Accept for smaller projects, but document that this pattern may fail cost/rate thresholds for large membership sets. Be explicit about response shape in docs/schemas. For future scalability: consider returning only what changed, with projection/query-style parameters.

---

## Summary Table

| Concern                  | Governing Decision                         | Tradeoff / Risk / Required Action                                    |
|--------------------------|--------------------------------------------|---------------------------------------------------------------------|
| **Idempotency**          | Not enforced (no key)                      | Risk of duplicate/multiple addition on retry; require idempotency key|
| **Error Contract**       | Returns plain string                       | Not robust, unparseable; adopt structured error objects              |
| **Authorization**        | Logged-in only (not project admin checked) | Risk of privilege escalation; enforce project-admin/owner scope      |
| **Response Shape**       | Returns entire updated member list         | Acceptable for small N; not scalable for large teams                 |

---

## Next Steps

- **Require an Idempotency-Key header on POST.**
- **Return errors as structured objects, not strings.**
- **Implement project-level admin/owner check for mutations.**
- **Document or revise response shape to control scale concerns.**  

**You gain rapid prototyping but sacrifice production resilience, client ergonomics, and security. Safe progression requires enforcing these contracts before broad release.**