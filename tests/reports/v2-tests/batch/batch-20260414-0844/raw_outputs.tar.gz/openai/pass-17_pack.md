## Functional Tier

Choosing between Redux (a global state manager) and React’s built-in local state with context is about how your app handles data that multiple components need to share and update.  
- **Local component state** is easier for simple scenarios—each component manages its own data (like small forms or toggles).  
- **React Context** helps you pass down bits of shared data (like current theme or user info) without "threading" props through every layer.
- **Redux** (or similar tools) is useful when you have lots of different parts of your app that all need to access and change the same data—like in big dashboards, complex forms, or when you want things like time-travel debugging.

The tradeoff is:  
- **Local state and context** mean less boilerplate and easier code for small or medium apps, but as the app grows, you may start seeing "prop drilling" or awkward data flow.  
- **Redux** adds more setup, boilerplate, and conceptual overhead, but can make complex data flows and debugging easier, especially in large teams or apps with lots of cross-cutting concerns.

**Decision:**  
For a typical React app without large-scale, deeply interdependent global data, use local component state and context instead of Redux.

---

## Integrative Tier

A React app should only adopt a global state manager like Redux when three conditions are present:  
1. Many components across different parts of the UI need to read, update, and react to the same state (e.g., a complex shopping cart across a checkout process, many filters affecting dashboards, async workflows impacting notifications in several spots).
2. There’s a need for advanced debugging features (time travel, action logging) or third-party tool integration.
3. The workflow, team size, or codebase structure requires fast, predictable state updates to support ongoing growth or maintenance.

Otherwise, React’s local state and Context API offer meaningful advantages:  
- Less default boilerplate and simpler code structure for small to mid-size projects.
- Performance is easier to manage, as local state updates only trigger component re-renders where needed.
- Context covers most "read-heavy, write-rarely" global data (theme, authentication, language) without the ceremony of Redux.

**Tradeoffs:**  
- With Context/local state: You sacrifice universal state visibility and some debugging power for lower learning curve and code simplicity.
- With Redux: You gain standardization and observability at the cost of more setup, stricter patterns, and risk of overengineering for small/medium apps.

**Decision:**  
Unless the app’s complexity, cross-cutting state needs, or debugging requirements demand Redux, the React Context API combined with local state should be used for shared data.

---

## Strategic Tier

State architecture should be driven by the sources of truth, coupling costs, and growth vectors of the product:

- **Redux is justified** when persistent, frequently-mutated, business-critical state needs to be accessible and mutated from many disparate locations, and when the additional complexity (selectors, actions, reducers) is offset by scaling, audit, or team-velocity imperatives.
- **Local state with context** is preferred when most state is interface-local, mutations are shallow and predictable, and global data is primarily configuration or session-related (user, theme, locale).

Integration costs and architectural inertia are non-trivial—introducing Redux early can ossify patterns and increase ramp-up time for new contributors without yielding value until scale is reached. Premature optimization at architecture level can reduce feature velocity.

**Strategic tradeoff:**  
Accept the risk of later migration (to Redux or another state platform) for current simplicity and rapid iteration when the present-state surface area is manageable and well-understood. Prefer targeted context slices and local state unless organizational or domain constraints have proven the need for formalized global mutation.

**Decision:**  
Defer adoption of Redux; use local state and finely-scoped contexts until platform or organizational scale demonstrates a real need for a global state manager.