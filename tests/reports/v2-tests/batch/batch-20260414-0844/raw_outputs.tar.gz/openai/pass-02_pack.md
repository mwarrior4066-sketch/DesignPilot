## Split Button Component Specification

**Component boundary:**  
A “Split Button” combines a primary action (Save) with an adjacent dropdown trigger housing secondary actions (Save as draft, Save and close). The component owns all rendering, states, interaction, and accessible markup for both the primary trigger and the attached dropdown.

---

### 1. Component anatomy and boundaries

- **Primary Action Button:**  
  - Label: "Save"  
  - Executes main action immediately on click or keyboard activation.
- **Dropdown Trigger:**  
  - Adjacent chevron/toggle icon.
  - Opens dropdown menu exposing secondary actions.
- **Dropdown Menu:**  
  - Menu items:  
    - Save as draft  
    - Save and close

**Component boundary:**  
Both triggers and the dropdown menu operate as a single component with one external API surface (props/slots/events). The dropdown is visually and programmatically attached to the main button—never as a free-floating menu elsewhere in the UI.

---

### 2. Supported States

**Primary button and dropdown trigger** must both support:
- **Enabled**  
  - Default, interactive state
- **Disabled**  
  - Appears visually disabled, does not respond to pointer, touch, or keyboard events
- **Loading**  
  - Replaces label with spinner, disables further interaction until resolving

**Menu items**  
- Can be individually disabled if needed (future extensibility), but in this spec, all are enabled by default.
- Menu closes while a selected action is loading, and disables re-trigger.

**Composite state handling:**  
- When loading or disabled, both primary and dropdown triggers are inert.
- Do not allow the menu to open during loading/disabled state.
- Touching/clicking any part while disabled or loading does nothing and does not show focus.

**Accessibility and visuals:**  
- Disabled state uses <button disabled> or aria-disabled as appropriate.
- Loading state provides a visual spinner and aria-busy where supported.

---

### 3. Keyboard & Accessibility Support

**Button structure:**  
- Use two adjacent <button> elements or a <div role="group"> containing buttons.
- Buttons must be focusable in sequence via Tab.

**Keyboard interactions:**
- **Tab:**  
  - Tabs into the Save button, then the dropdown trigger.
- **Enter/Space:**  
  - On primary button: triggers save.
  - On dropdown trigger: opens the menu.
- **Down Arrow:**  
  - On dropdown trigger: opens menu and places focus on first item.
- **Up/Down Arrow (in menu):**  
  - Moves between menu items.
- **Escape:**  
  - Closes the menu and returns focus to the dropdown trigger.
- **Enter/Space (on menu item):**  
  - Activates menu item and closes menu.
- **Type-ahead:**  
  - Optional (advanced): jump to a menu item matching typed text by first character.

**Focus and ARIA:**
- Use [WAI-ARIA Button](https://www.w3.org/WAI/ARIA/apg/patterns/button/) and [Menu Button](https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/) patterns.
- Dropdown trigger gets `aria-haspopup="menu"` and `aria-expanded`.
- Active menu is an element with `role="menu"`, items get `role="menuitem"`.
- Use `aria-disabled` for menu items if ever disabled.
- Announce loading state with `aria-busy` on main button.

---

### 4. Mobile and Touch Target Support

- Both main button and dropdown trigger must meet 44×44px (or 48dp) minimum touch target.
- On touch devices:
  - Tap on Save triggers save.
  - Tap on dropdown chevron opens menu; tap outside or on an item closes menu.
  - Menu items are touch-friendly, with at least 44×44px targets.
- Focus ring must be visible for keyboard users, but does not show for touch input.
- Hit area must extend beyond icon graphic for the dropdown trigger.

---

### 5. Props / External API

- **onSave:** function, triggered by primary button
- **onSelect:** function, called with menu item identifier (e.g., 'draft' or 'save_and_close')
- **disabled:** boolean
- **loading:** boolean
- **menuItems:** array of label/id pairs, default as above but extensible
- **aria-labels:** override for accessibility customization

---

### 6. Accessibility Behavior

- Follows composite button + menu button pattern for full screen reader and keyboard interoperability.
- Loading and disabled states block all interaction, are visually and programmatically represented (`disabled` and `aria-busy`).
- All controls and menu items have accessible names.
- Menu is rendered with `role="menu"` and respects focus and arrow-key navigation per ARIA menu button guidelines.
- No part is ever only accessible by pointer.

---

### 7. Implementation boundaries

- The component is responsible for accessible structure, state management, focus, aria attributes, and event handling.
- Visual and behavioral consistency across mobile, tablet, and desktop breakpoints.
- Styling may be delegated, but basic states (focus, disabled, loading) must be visually distinct in all themes.

---

### 8. Tradeoffs and Key Decisions

- **Combining button and menu:**  
  - Improves density and workflow speed for related actions but requires precision in both accessibility and mobile tap areas.
- **Keyboard pattern:**  
  - Using explicit menu-button ARIA pattern maintains compatibility with assistive tech, but increases implementation complexity.
- **Disabled state strictness:**  
  - Disabling the entire control, including menu, during loading/disabled: preserves UI consistency and prevents race conditions, but eliminates rare cases where another action could be available while main is busy.
- **Touch vs Keyboard:**  
  - Separate triggers instead of “hold to open” afford stronger accessibility and clearer tap targets, at the expense of absolute minimalism.

---

**Summary:**  
The split button is a single compound component exposing “Save” as a primary action and other options in an accessible dropdown. It must support all interactive states (enabled/disabled/loading), have full keyboard and screen reader support, and offer mobile-friendly touch areas. Accessibility behaviors and ARIA semantics are non-negotiable, overriding aesthetics if in tension. All actions must be addressable by keyboard, touch, or assistive technology.

---

**Evidence & Standard References:**  
- [WAI-ARIA Authoring Practices – Menu Button Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/)
- [WCAG Touch Target Size: at least 44×44 CSS px](https://www.w3.org/WAI/WCAG21/Techniques/general/G208)
- [Composite/compound button accessibility](https://inclusive-components.design/buttons/)

---

**Tradeoff summary:**  
This composite button pattern combines speed of access (main action is single press/click) with controlled discoverability for alternatives, making it efficient without sacrificing accessibility. You sacrifice minimalism of a single button for clarity and compliance with keyboard and touch requirements.