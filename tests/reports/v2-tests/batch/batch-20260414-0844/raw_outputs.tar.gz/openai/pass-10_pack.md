## Poster Critique: Design Conference

### Structural Failure

- **Hierarchy Misstep:** The poster places a large, decorative title at the very top, but without supporting context or a succinct descriptor, viewers may not immediately grasp what the event is or who it’s for. The oversized title draws attention before the message or value of the conference is conveyed (“structural_failure: hierarchy_winner is the decorative title, but not the core event descriptor”).
- **Date Visibility:** Placing the date in small gray text in a bottom corner severely limits its visibility—especially against a potentially busy or low-contrast background photo. This risks viewers missing a critical piece of information (“structural_failure: timeline detail de-emphasized”).
- **Logo Positioning:** Centering a white logo over a full-bleed cityscape may create contrast issues. If the background isn’t carefully darkened or blurred, the logo can lose legibility (“visual_confidence_boundary: white on photo risks invisibility, especially with detailed or light areas”).
- **Overused Visuals:** Full-bleed city skylines are visually appealing but generic—this makes the poster less differentiated from other event collateral and offers little specificity about the conference theme or identity (“tradeoff_resolution: attractive imagery at the cost of meaning and brand distinction”).

### Intervention Order

1. **Reorient Information Hierarchy:** Viewers need an immediate anchor—who is this for, what is it, and why attend? Add a subtitle or tagline near the top/title pairing that makes the purpose explicit (“intervention_order: insert conference name or focus subtitle adjacent to main title before proceeding to secondary details”).
2. **Date and Location:** Pull date out of the corner and increase its size and contrast. Consider placing it alongside or below the title, or integrating it within a prominent, high-contrast label (“tradeoff_resolution: prioritize attendance-relevant info over minimalist design preference”).
3. **Logo Legibility:** To ensure brand recall, set the logo apart: add an opaque or blurred overlay beneath it, increase drop shadow, or relocate it where contrast is guaranteed (“visual_confidence_boundary: add a visual anchor to preserve legibility on unpredictable backgrounds”).
4. **Contextual Imagery:** If the city photo is purely decorative, darken or blur it to push it into a secondary role; or, if the city is meaningful, add a caption explaining the connection (“tradeoff: full-bleed imagery can attract but may dilute message clarity if not mapped to event purpose”).

### Tradeoff Resolution

- **What’s preserved:** Visually striking composition with high initial impact.
- **What’s sacrificed:** Immediate clarity, event recall, and differentiation ("you sacrifice meaning and function to gain surface impact").
- **Resolution:** Rebalancing the text hierarchy and improving information architecture can elevate both clarity and impact—without losing visual appeal.

### Visual Confidence Boundary

- **Observed:** Title is prominent and decorative, photo is attractive.
- **Inferred/Unverified:** Logo may have legibility issues; date is likely to be missed; purpose is unclear at a glance.
- **Confidence:** Medium—exact legibility and context impact depend on implementation specifics.

---

**Summary:**  
The current poster prioritizes aesthetics and surface-level impact, but fails to communicate event essentials with clarity or memorability. Reordering the hierarchy, boosting the visibility of logistical details, and ensuring all overlaid elements remain legible against the background will make the design more effective, without sacrificing its professional visual appeal.

---

**Next move:**  
- Draft a revised layout wireframe or annotated markup showing improved information hierarchy and contrast handling, if desired.