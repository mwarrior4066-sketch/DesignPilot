Here’s a production-ready **color system specification** for a healthcare SaaS dashboard with your requirements:

---

## 1. Semantic Roles

- **Status Colors**  
  - Normal (Success/Stable):  
    - Light: Green 600 `#219653`  
    - Dark: Green 400 `#6FCF97`  
  - Warning:  
    - Light: Amber 700 `#FFB300`  
    - Dark: Amber 300 `#FFD866`  
  - Critical (Danger):  
    - Light: Red 600 `#D7263D`  
    - Dark: Red 400 `#EA7186`  

- **Data Visualization (Categorical Palette: 5 colors)**  
  - Category 1: Blue 600 `#3572A5`  
  - Category 2: Teal 600 `#008080`  
  - Category 3: Violet 500 `#7B5FC4`  
  - Category 4: Orange 600 `#F2994A`  
  - Category 5: Pink 600 `#D72660`  
  - *Palette designed for distinctive appearance on both backgrounds.*

- **Base UI**  
  - Light Background: `#FFFFFF`  
  - Light Surface: `#F7F9FB`  
  - Dark Background: `#181C20`  
  - Dark Surface: `#23292F`  
  - Border/Divider: Light: `#E5E8EC`, Dark: `#323842`  
  - Text Primary: Light: `#17202A`, Dark: `#F7F9FB`  
  - Text Secondary: Light: `#4F5B67`, Dark: `#C6CBD2`  

---

## 2. Contrast & Accessibility (WCAG 2.1 AA)

- **Text Contrast:**  
  - All text-background pairs have a minimum contrast ratio of 4.5:1 for normal text and 3:1 for large UI elements and icons.  
  - *Sample checks:*  
    - Green 600 (#219653) on light bg: 4.7:1  
    - Amber 700 (#FFB300) on light bg: 6.9:1  
    - Red 600 (#D7263D) on light bg: 5.0:1  
    - All palette colors selected for contrast against both light and dark backgrounds (viz lines, symbols, legends).  
  - For badges or indicators, reverse colors as needed (e.g., white text on status color for alerts).

- **Non-text Contrast:**  
  - Icons, graph lines, and indicators meet the 3:1 minimum contrast on both background modes.

---

## 3. Dark Mode Mapping

- All major colors have corresponding lighter “tints” for dark backgrounds to retain vibrancy and readability:
  - Status and data colors use lighter variants when in dark mode.
  - UI elements (cards, input fields) use dark surface colors.
  - Text switches to lighter grays/white on dark surfaces.
- *Example:*  
  - Normal: Green 400 (#6FCF97) on Dark Surface (#23292F): 4.5:1  
  - Critical: Red 400 (#EA7186) on Dark Surface (#23292F): 4.7:1

---

## 4. Data Visualization Policy

- **Categorical:**  
  - At least 5 distinct colors with no green/red clash (for colorblind users).
  - Palette tested for Daltonization—distinguishable by those with common color vision deficiencies (Protanopia, Deuteranopia).
  - Add patterns or shapes for redundancy if possible (stripe, dot, etc.).
  - For status charts, always pair color with icon or text for triple coding.

---

## 5. Migration & Usage Notes

- Use tokens/variables for `--color-status-normal`, `--color-status-warning`, etc.
- Reference the ANSI standard when mapping data (e.g., critical = red).
- For all custom content/brand overlays, verify text and key icon contrast at design time via APCA or WCAG tools.

---

**Tradeoff:**  
You gain clarity and accessibility by focusing on contrast and colorblind safety, but may limit brand flexibility—especially if corporate colors do not meet contrast guidelines.

**Summary Table:**

| Semantic Role   | Light Mode    | Dark Mode     | WCAG Contrast |
|-----------------|--------------|--------------|---------------|
| Normal          | #219653      | #6FCF97      | 4.5+:1        |
| Warning         | #FFB300      | #FFD866      | 4.5+:1        |
| Critical        | #D7263D      | #EA7186      | 4.5+:1        |
| Category 1      | #3572A5      | #70C0FF      | 4.5+:1        |
| Category 2      | #008080      | #4DD0E1      | 4.5+:1        |
| Category 3      | #7B5FC4      | #B39DDB      | 4.5+:1        |
| Category 4      | #F2994A      | #FFB682      | 4.5+:1        |
| Category 5      | #D72660      | #EA719B      | 4.5+:1        |

---

**If you need Figma tokens or CSS variables for implementation, just ask.**