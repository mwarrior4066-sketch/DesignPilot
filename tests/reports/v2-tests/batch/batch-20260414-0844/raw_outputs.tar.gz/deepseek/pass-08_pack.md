I’ll audit this mobile app for accessibility issues using a structured accessibility review.

---

## Accessibility audit: mobile app

### 1. Bottom navigation bar — icon-only buttons, no labels
**Issue:**  
Icon-only buttons without visible labels fail WCAG 2.1 Success Criterion 2.4.4 (Link Purpose in Context) and 2.5.3 (Label in Name). Screen-reader users may hear ambiguous names like “button” or the file name of the icon, and sighted users with cognitive or low-vision challenges may not understand the icon’s meaning.

**Severity:** High — core navigation is inaccessible.

**Repair:**  
- Add visible text labels below or beside icons (commonly “Home,” “Search,” “Profile,” etc.).  
- If space is constrained, use an accessible pattern like:
  - **Persistent labels on active tab** (active tab shows label, others icon-only).
  - **Expand-on-hover/focus** (touch: long-press reveals label).
  - **Accessible tooltip** with `aria-label` and `aria-describedby` for screen readers.
- Ensure each button has an `aria-label` matching the visible label (or the icon’s function if a visible label isn’t present).

---

### 2. Form inputs — placeholder text instead of visible labels
**Issue:**  
Placeholders disappear on input, causing users to forget what the field is for. This fails WCAG 2.1 SC 3.3.2 (Labels or Instructions) and 1.3.1 (Info and Relationships). It also creates low contrast (often light gray) that may fail 1.4.3 (Contrast Minimum).

**Severity:** High — forms are critical for task completion.

**Repair:**  
- Provide a visible `<label>` associated with each input using `for` and `id`.  
- If design requires minimalism, use a **floating label** pattern (label moves above input when focused/typed).  
- Placeholders may remain as **hint text** (e.g., example format), but never as the sole label.  
- Ensure labels are programmatically linked (`aria-labelledby` or `<label for>`).

---

### 3. Error messages — red text only, no icon
**Issue:**  
Red-only error messaging fails multiple criteria:
- **WCAG 1.4.1 (Use of Color):** Information must not be conveyed by color alone.
- **WCAG 3.3.1 (Error Identification):** Errors must be programmatically determined and described to the user.
- **WCAG 4.1.3 (Status Messages):** Dynamic content changes should be announced to screen readers.

**Severity:** Medium–High — errors block progress and are not perceivable by all users.

**Repair:**  
- Add an icon (e.g., ⚠️ or ✕) before the error text.  
- Use `aria-live="polite"` or `aria-live="assertive"` on the error container so screen readers announce it when it appears.  
- Include `role="alert"` for critical errors.  
- Ensure sufficient color contrast (red text against background must meet at least 4.5:1).  
- Provide clear, actionable error text (e.g., “Please enter a valid email address” not “Invalid input”).

---

### 4. Loading spinner — no announced state for screen readers
**Issue:**  
A visual spinner without an accessible name or live region leaves screen-reader users unaware that content is loading. This fails WCAG 4.1.3 (Status Messages) and 2.1 (Keyboard Accessibility) if the spinner traps focus without announcement.

**Severity:** Medium — causes confusion and uncertainty.

**Repair:**  
- Wrap the spinner in a container with `aria-live="polite"` and `aria-busy="true"`.  
- Provide an `aria-label` such as “Loading, please wait.”  
- When loading completes, update `aria-busy="false"` and optionally announce “Loading complete” via a live region.  
- If loading is triggered by a button, move focus appropriately after loading finishes (e.g., to new content).

---

## Priority repair sequence
1. **Fix form labels** — forms are high-risk for abandonment.  
2. **Fix navigation labels** — core app navigation must be usable.  
3. **Fix error messaging** — errors must be perceivable and actionable.  
4. **Fix loading announcements** — improves feedback for all users.

## Testing recommendations
- Use **VoiceOver (iOS)** or **TalkBack (Android)** to test navigation and form labels.  
- Test keyboard navigation (Tab/Arrow keys) through the bottom bar — ensure focus is visible and logical.  
- Use a color-contrast checker (e.g., Stark, axe DevTools) on placeholder text and error text.  
- Verify `aria-live` announcements with a screen reader when triggering errors and loading states.

---

## Quick wins
- Add `aria-label="Home"` etc. to each nav button today.  
- Change one error message to include an icon and `role="alert"` as a pilot fix.  
- Add `aria-live` to the loading spinner container with a simple “Loading” label.

Would you like me to draft specific code examples for any of these repairs, or map these fixes to a component spec?