I’ll recommend a type system for a fintech product that works across marketing site, web app dashboard, and mobile—balancing modern trustworthiness, tabular data clarity, and hierarchy.

---

## Type system recommendation

**Primary typeface:** **Inter** (open-source, variable font)  
**Secondary/display typeface:** **IBM Plex Sans** (open-source, robust tabular figures)

### Why this pairing works for fintech

1. **Trust + modernity**  
   Inter is neutral, highly legible, and designed for UI screens. It reads as professional without being cold. IBM Plex Sans adds a touch of IBM’s engineering credibility—excellent for data-heavy contexts.

2. **Tabular data readiness**  
   IBM Plex Sans includes true **tabular figures** (monospaced numbers) in all weights, so financial tables align vertically. Inter’s default proportional figures work for body text; switch to IBM Plex for tables.

3. **Variable font coverage**  
   Inter Variable offers Weight axis 100–900 and Optical Size axis (opsz 8–48). This means one font file can render crisp text from small mobile UI to large marketing headlines.

4. **Cross-platform consistency**  
   Both are open-source (SIL Open Font License), free to embed, and widely available. They render consistently across macOS, Windows, iOS, Android.

5. **Hierarchy range**  
   Inter’s 9 weights + width variants allow subtle hierarchy without switching families. Use IBM Plex for data tables, callouts, and premium-feeling marketing headlines.

---

## Scale structure

**Base unit:** 16px (1rem) for web app, 14px for mobile app UI (adjust via viewport).

| Role | Web (rem) | Mobile (sp) | Weight | Font |
|------|-----------|-------------|--------|------|
| Display 1 | 3.5rem (56px) | 32sp | 700 | Inter |
| Display 2 | 2.5rem (40px) | 28sp | 600 | Inter |
| H1 | 2rem (32px) | 24sp | 600 | Inter |
| H2 | 1.5rem (24px) | 20sp | 600 | Inter |
| H3 | 1.25rem (20px) | 18sp | 500 | Inter |
| Body large | 1.125rem (18px) | 17sp | 400 | Inter |
| Body | 1rem (16px) | 16sp | 400 | Inter |
| Small | 0.875rem (14px) | 14sp | 400 | Inter |
| Caption | 0.75rem (12px) | 12sp | 400 | Inter |
| **Tabular data** | 0.875rem (14px) | 14sp | 400 | IBM Plex Sans |
| **Monospace (code)** | 0.875rem (14px) | 14sp | 400 | IBM Plex Mono |

---

## Usage by surface

### Marketing site
- **Headlines:** Inter 700–800, large optical size (opsz 32+).
- **Body:** Inter 400, opsz auto.
- **Trust signals/testimonials:** IBM Plex Sans 450, tabular figures for stats.

### Web app dashboard
- **UI text:** Inter 400/500, opsz tuned per size.
- **Data tables:** IBM Plex Sans 400, tabular figures, letter-spacing 0.02em for column clarity.
- **KPI numbers:** IBM Plex Sans 600, tabular figures.
- **Form labels:** Inter 500.

### Mobile app
- **UI:** Scale down to 14px base; use Inter’s opsz axis for small text clarity.
- **Tables:** IBM Plex Sans at 13–14sp, ensure horizontal scrolling doesn’t break alignment.

---

## Implementation notes

1. **Variable font loading**  
   Load Inter Variable (`Inter-Variable.woff2`) and IBM Plex Sans Variable (`IBMPlexSans-Variable.woff2`) with `font-display: swap`.  
   Use CSS `font-variation-settings` to control weight and opsz.

2. **Fallback stack**  
   ```css
   font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
   font-family: 'IBM Plex Sans', 'Inter', sans-serif; /* for tables */
   ```

3. **Tabular figures CSS**  
   ```css
   .financial-table {
     font-family: 'IBM Plex Sans', sans-serif;
     font-variant-numeric: tabular-nums;
   }
   ```

4. **Dark mode**  
   Slightly increase letter-spacing (0.01em) and use weight 450 instead of 400 for body text in dark themes to maintain readability.

---

## Tradeoffs

✅ **Pros:**  
- No licensing cost or compliance overhead.  
- Strong readability in UI and tables.  
- Variable fonts reduce HTTP requests and allow fine-tuned optical sizing.  
- Works across marketing, web app, mobile.

⚠️ **Considerations:**  
- IBM Plex Sans has a slightly larger x-height than Inter; test pairing in headlines.  
- If you need expressive brand personality, Inter may feel too neutral (could add a premium serif for marketing hero sections, but adds complexity).  
- Variable font support is excellent but test on older Android devices.

---

## Next steps

1. **Test pairing** in a Figma mockup with real financial data tables.
2. **Implement variable font loading** in your design system.
3. **Set up typography scale tokens** in your CSS/design-tool library.
4. **Verify contrast** meets WCAG AA (minimum) for all text sizes/weights.

Would you like me to generate the CSS variable definitions or a Figma typography style guide from this system?