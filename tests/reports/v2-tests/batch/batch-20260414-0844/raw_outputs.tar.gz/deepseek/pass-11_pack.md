I’ll reconstruct the layout system from your 2018 brand guidelines PDF and translate it into a modern, reusable layout system.

---

## What I’d extract from the PDF

1. **Grid structure**
   - Column count (e.g., 12‑column, 8‑column, or custom)
   - Gutter width (horizontal spacing between columns)
   - Margin width (outside gutters, left/right or all sides)
   - Whether the grid is fluid, fixed, or responsive at certain breakpoints

2. **Baseline grid**
   - Vertical rhythm unit (e.g., 8px, 4px, or custom)
   - Whether text aligns to a baseline grid
   - Spacing multiples used (e.g., all spacing in multiples of 8px)

3. **Layout examples**
   - How columns are combined (e.g., 4‑col + 8‑col, 3‑col + 6‑col + 3‑col)
   - Any asymmetric or modular grid patterns
   - How images, text blocks, and components are placed within the grid

4. **Breakpoints or medium rules**
   - If the PDF specifies different grids for print vs. web, or for different page sizes
   - Any mobile/desktop distinctions (if it’s a digital‑first guideline)

5. **Typography alignment to grid**
   - Whether headings, body text, and captions align to column edges or baseline grid
   - Any vertical spacing rules between elements (e.g., paragraphs, sections)

6. **Component‑grid relationship**
   - How cards, tables, forms, or navigation bars fit the grid
   - Whether components can break out of the grid (full‑bleed exceptions)

---

## How I’d translate it into a modern layout system

### 1. **Modernize the grid for current mediums**
- **Web**: Convert fixed‑pixel gutters/margins to `rem` or fluid units (`%`, `fr`, `clamp()`).
- **Responsive breakpoints**: If the PDF only had one grid, I’d infer breakpoints (mobile: 4‑col, tablet: 8‑col, desktop: 12‑col) using content‑driven logic.
- **CSS Grid + Flexbox**: Map the old column‑based layout to CSS Grid with named grid areas for key templates, and use Flexbox for internal component alignment.

### 2. **Preserve the proportional relationships**
- If the old grid used a 2:1 column ratio, keep that ratio in modern `fr` units.
- Convert gutter:column width ratios to percentages of the container, so they scale fluidly.

### 3. **Extend the baseline grid to a spacing scale**
- Take the vertical rhythm unit (e.g., 8px) and build a modular scale (e.g., 4, 8, 12, 16, 24, 32, 48, 64…).
- Apply this scale to padding, margins, and component spacing for consistency.

### 4. **Document layout tokens**
Create a token system in CSS custom properties:

```css
:root {
  --grid-columns: 12;
  --grid-gutter: 1.5rem;
  --grid-margin: 2rem;
  --spacing-unit: 0.5rem; /* 8px if base font-size = 16px */
  --spacing-scale: 0.5, 1, 1.5, 2, 3, 4, 6, 8; /* multiples of --spacing-unit */
}
```

### 5. **Create layout components**
- **Grid container**: A wrapper that sets max‑width, margins, and grid display.
- **Grid column**: Utility classes for column spans (e.g., `.col-4`, `.col-8`).
- **Layout templates**: Predefined grid templates for common page types (hero, two‑column text, card grid, sidebar layout).

### 6. **Add accessibility and resilience**
- Ensure the grid works with zoom/text‑size increases by using `rem` and `min‑height`.
- Test reflow at narrow widths (320px) to avoid horizontal scrolling.
- Use logical properties (`margin‑inline`, `padding‑block`) for RTL/language support.

### 7. **Provide implementation examples**
Show how to migrate old layouts to the new system:

| Old (2018)                     | New (modern)                          |
|--------------------------------|---------------------------------------|
| Fixed 960px container          | `max‑width: 1200px; margin‑inline: auto;` |
| 12 columns, 20px gutters       | `grid‑template‑columns: repeat(12, 1fr); gap: 1.25rem;` |
| Manual vertical spacing        | `margin‑block: var(--spacing‑6);`     |

---

## Deliverables I’d prepare

1. **Layout system spec** – defines grid, spacing, breakpoints, and usage rules.
2. **CSS/SCSS token file** – ready‑to‑use custom properties and utility classes.
3. **Example templates** – 3‑4 common layouts rebuilt with the new grid.
4. **Migration guide** – how to adapt old pages/components to the new system.
5. **FigJam/Figma grid template** – visual grid overlay for designers.

---

**If you share the PDF**, I can extract the exact grid numbers, infer breakpoints, and give you a tailored layout system with production‑ready CSS. Would you like to upload it?