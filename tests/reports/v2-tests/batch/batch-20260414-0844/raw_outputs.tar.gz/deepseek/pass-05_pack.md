I’ll help you fix this InDesign‑exported PDF for accessibility and reading order.  
Let me start by identifying the governing route for this task.

---

**Route selection reasoning**  
This is a PDF remediation task with known semantic failures: broken reading order, missing tagging, broken TOC links, and visual layout interfering with extraction.  
The governing route is **`rt_pdf_remediation`** (PDF/document remediation plan).  
Supporting skills:  
- `document-accessibility-expert.md` (for tagging, reading order, artifacts, extraction fidelity)  
- `layout-reconstruction-expert.md` (to infer and preserve the two‑column layout structure)  
- `pdf-layout-expert.md` (to maintain visual/layout integrity during repair)

---

## PDF Accessibility Remediation Plan

### 1. **What’s broken (semantic failures)**
- **Reading order mismatch**: Two‑column layout is read left‑to‑right across columns instead of top‑to‑bottom down one column, then the next.
- **Untagged decorative images**: Marked as “Figure” or “Image” without `Alt=""` or artifact tagging.
- **Pull quotes interrupting flow**: Screen readers treat them as inline text, breaking paragraph continuity.
- **Broken TOC links**: Internal hyperlinks don’t navigate correctly.
- **Missing document structure tags**: No `H1`–`H6`, no `Table`, `List`, `Figure` roles.
- **Color‑only information**: Charts or key items using color without text labels.

### 2. **Reading‑order reconstruction**
**Strategy**: Preserve the two‑column visual layout but re‑tag so the reading order flows down the first column entirely, then down the second column.

**Steps**:
1. In Adobe Acrobat Pro: **Tools > Accessibility > Reading Order Tool**.
2. Select each column as a separate region, tag as `Div` (division).
3. Inside each `Div`, tag content in logical order:
   - Headings as `H1`–`H6`
   - Paragraphs as `P`
   - Pull quotes as `Aside` or `BlockQuote` with `Alt="Pull quote: [text]"`
   - Tables as `Table` with `TH` and `TD`
   - Lists as `L` and `LI`
4. Set reading‑order sequence: Column‑1 `Div` → Column‑2 `Div`.

**Verification method**:  
- Use **Tools > Accessibility > Full Check** → check “Reading Order” report.  
- Use **Read Out Loud** to hear the sequence.

### 3. **Image tagging**
- **Decorative images**: Tag as `Figure`, then open **Tags panel**, right‑click the `Figure`, choose **Properties**, check “Artifact”. This removes them from the reading order entirely.
- **Informative images**: Tag as `Figure`, add `Alt` text describing the content and function.
- **Complex charts**: Tag as `Figure`, add `Alt` text summarizing the trend, then ensure data‑table alternative is provided nearby or linked.

### 4. **Pull‑quote handling**
- Tag each pull quote as `BlockQuote` or `Aside`.
- In the **Tags panel**, move the `BlockQuote` outside the main paragraph flow (place it after the paragraph it visually neighbors).
- Add `Alt="Pull quote: [quote text]"` so screen‑reader users know it’s an excerpt.

### 5. **Table of contents repair**
1. Open **Tools > Content > Links**.
2. Delete broken TOC links.
3. Re‑create links:  
   - Select TOC text, **Tools > Content > Add/Edit Link**, choose “Go to a page view”, set destination.  
   - Tag each link as `Link` in the Tags panel.
4. Ensure TOC items are tagged as `L` (list) with `LI` items.

### 6. **Document‑structure tagging**
- Run **Tools > Accessibility > Autotag Document** as a starting point.
- Manually correct in **Tags panel**:
  - Ensure one `H1` for the report title.
  - Section headings as `H2`, subsections as `H3`.
  - Tables get `Table`, `TR`, `TH`, `TD`.
  - Lists get `L` and `LI`.
- Set document language: **File > Properties > Advanced > Language**.

### 7. **Color‑and‑contrast check**
- **Tools > Accessibility > Full Check** → check “Color contrast”.
- Fix any contrast below WCAG 2.1 AA (4.5:1 for normal text, 3:1 for large text).
- Replace color‑only indicators with text labels or patterns.

### 8. **Preserved vs. sacrificed**
**Preserved**:
- Two‑column visual layout remains unchanged for sighted readers.
- Pull quotes stay in their original visual positions.
- All images remain in place.
- Typography, spacing, and margins stay intact.

**Sacrificed**:
- The reading order will not match the visual left‑to‑right sweep across columns (screen‑reader users will get a single‑column experience).
- Decorative images will be hidden from screen readers (as required).
- Extra time to manually re‑tag complex tables and lists.

### 9. **Export‑fidelity verification**
After remediation:
1. **File > Save As > Optimized PDF** → check “Create PDF/A‑compliant file” (PDF/A‑2u or PDF/A‑3u for accessibility).
2. Test extraction:  
   - Copy all text (**Ctrl+A, Ctrl+C**) and paste into Notepad. Verify logical order.  
   - Use **Adobe Export PDF** to Word; check if structure transfers.
3. Screen‑reader test with NVDA, VoiceOver, or JAWS.

### 10. **Safer path**
**Do not**:
- Flatten the PDF or convert to image‑based PDF — destroys all accessibility.
- Use “Recognize text” (OCR) unless the PDF is scanned — it adds garbled layers.
- Skip manual pull‑quote and column re‑ordering — automated tools will fail on multi‑column layouts.

**Do**:
- Work on a copy of the original PDF.
- Save incremental versions after each major tagging step.
- Validate with both Acrobat’s Full Check and a real screen reader.

---

**Next steps**:
If you upload the PDF, I can:
1. Diagnose the specific tagging errors.
2. Provide a step‑by‑step repair script for Acrobat Pro.
3. Generate a pre‑flight checklist for future InDesign exports to avoid these issues.

Would you like me to proceed with any of those?

---

[SESSION_STATE]
{
  "route": "rt_pdf_remediation",
  "escalation_level": "compound",
  "decisions_committed": ["semantic_failure: reading_order_mismatch", "reading_order_or_extraction: column_flow_reconstruction", "verification_method: acrobat_full_check_and_read_out_loud", "destructive_shortcut_rejected: flattening_or_ocr"],
  "evidence_classes_cited": ["wcag_rule", "tool_specific_step"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": ["Do you have Adobe Acrobat Pro or another PDF‑remediation tool?", "Can you share the PDF for specific diagnosis?"],
  "turn": 1
}
[/SESSION_STATE]