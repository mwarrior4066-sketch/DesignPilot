I’ll rewrite this case study for a design portfolio, focusing on clarity, structure, and credibility while preserving the core facts.

---

## Redesigning the Onboarding Flow: A 40% Lift in Conversion

### The Problem  
During initial user research, we observed that new users struggled to complete the onboarding process. Common points of confusion included unclear value propositions, ambiguous next steps, and a lack of progress visibility. This led to high early drop-off and low activation rates.

### My Role  
I led the end-to-end redesign—from research and wireframing through prototyping and collaboration with engineering. My goal was to transform a confusing, linear flow into a guided, confidence-building experience.

### Research & Insights  
- Conducted moderated usability tests with 12 new users  
- Mapped pain points to specific steps in the existing flow  
- Key finding: users didn’t understand what the product could do for them until after they’d already given up  

### The Redesign  
**1. Structured the narrative**  
   - Introduced a clear value-proposition up front  
   - Broke the process into distinct, named stages with progress visibility  

**2. Reduced cognitive load**  
   - Simplified input fields using progressive disclosure  
   - Added inline validation and real-time feedback  

**3. Prototyped and tested**  
   - Built interactive prototypes in Figma  
   - Ran two rounds of usability testing, iterating on navigation clarity and microcopy  

### Outcome  
After launch, we saw:  
- **40% increase in completed onboarding**  
- 22% reduction in support tickets related to setup  
- Higher user confidence scores in post-onboarding surveys  

### What I Learned  
- Early, tangible value demonstration is critical—users need a “win” within the first few interactions.  
- Close collaboration with engineering ensured technical feasibility without compromising the user experience.  
- Clear progress indicators aren’t just decorative—they reduce anxiety and increase completion rates.

---

**Portfolio-ready notes:**  
- Lead with the outcome (40% conversion lift)  
- Show your process: research → insights → design decisions → results  
- Quantify where possible; when numbers aren’t available, describe observable behavior changes  
- End with reflective learnings—this shows professional growth and strategic thinking

Would you like me to adjust the tone for a specific audience (e.g., startup, enterprise, agency), or add a visual/wireframe section to accompany the narrative?