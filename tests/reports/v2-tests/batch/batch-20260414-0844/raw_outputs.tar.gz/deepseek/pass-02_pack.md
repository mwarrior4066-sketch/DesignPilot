I’ll write a component spec for a split button with primary action, dropdown secondary actions, and full accessibility and state coverage.

---

## Component spec: SplitButton

**Component boundary**  
A split button combines a primary action button and a dropdown trigger that reveals secondary actions.  
It is used when one action is dominant but related alternatives exist, and space is limited.

**State coverage**  
- Default (idle, hover, focus, active)  
- Disabled (primary, trigger, or both)  
- Loading (primary action in progress)  
- Dropdown open (with keyboard focus inside menu)  
- Mobile touch active states  

**Accessibility behavior**  
- Primary button: `aria-label` if icon-only; `aria-disabled` when disabled; `aria-busy` during loading.  
- Dropdown trigger: `aria-haspopup="menu"`, `aria-expanded` true/false, `aria-controls` referencing menu ID.  
- Menu: `role="menu"`, items `role="menuitem"`, arrow key navigation, `aria-label` for menu.  
- Focus trapped in open menu; Escape closes menu and returns focus to trigger.  
- Touch target minimum 44×44px on mobile.

**Implementation boundary**  
- CSS custom properties for theming (colors, spacing, radii).  
- No framework dependency; can be implemented as Web Component, React, Vue, or vanilla JS.  
- Icon slots for primary action and dropdown arrow.  
- Events: `primary-click`, `secondary-select`, `dropdown-toggle`.  

---

## 1. Anatomy

```
┌─────────────────────────────────────────┐
│  [Primary action label/icon]  │  [▼]   │
└─────────────────────────────────────────┘
```

**Parts:**
1. **Primary button** – click triggers main action.
2. **Divider** (optional visual separator).
3. **Dropdown trigger button** – click toggles secondary menu.
4. **Menu** – positioned below or above trigger; contains secondary action items.

---

## 2. States & variants

### Interactive states (per element)
- **Primary button**: default, hover, focus, active, disabled, loading.
- **Dropdown trigger**: default, hover, focus, active, disabled, expanded.
- **Menu item**: default, hover, focus, active, disabled.

### Variants
- **Size**: small (32px), medium (40px), large (48px) – height includes touch target on mobile.
- **Style**: primary, secondary, ghost, danger – applies to primary button; trigger inherits or is subtle.
- **Width**: auto (fit content), full (100% container width).

### Loading state
- Primary button shows spinner and `aria-busy="true"`.
- Trigger is disabled during primary action loading.
- Menu cannot open while loading.

### Disabled state
- Can disable primary, trigger, or both.
- `aria-disabled="true"` plus `pointer-events: none` and opacity reduction.

---

## 3. Accessibility specs

### Keyboard
- **Tab** – focuses primary button, then trigger.
- **Enter/Space** on primary – activates primary action.
- **Enter/Space** on trigger – opens menu.
- **Arrow down** on trigger – opens menu and focuses first item.
- **Arrow up/down** in menu – navigates items.
- **Escape** – closes menu, focus returns to trigger.
- **Tab** in menu – cycles within menu only (focus trap).
- **Shift+Tab** in menu – cycles backward; if at first item, closes menu and focuses trigger.

### Screen reader
- Trigger announces “Menu button, expanded” / “collapsed”.
- Menu items read label and state.
- Loading state announced via `aria-live`.

### Touch
- 44×44px minimum touch target for both buttons (can extend hit area visually smaller).
- Long press on trigger does not open context menu.
- Tap outside menu closes it.

---

## 4. Menu content

Secondary actions are `menuitem` elements.
Can include:
- Icons + labels
- Keyboard shortcuts (display only)
- Dividers (`role="separator"`)
- Disabled items

No nested menus.

---

## 5. Theming & layout tokens

```css
--splitbutton-height: 2.5rem;
--splitbutton-gap: 1px;
--splitbutton-radius: 0.375rem;
--splitbutton-primary-bg: var(--color-primary);
--splitbutton-trigger-bg: var(--color-primary-dark);
--splitbutton-menu-shadow: 0 4px 12px rgba(0,0,0,0.15);
```

Divider: 1px solid, matches border color between buttons.

---

## 6. Usage rules

**Do**
- Use when one action is clearly primary (≥80% usage).
- Keep secondary actions closely related (Save → Save as draft, Save and close).
- Label primary action clearly (Save, Submit, Download).
- Provide text labels for icons in menu.

**Don’t**
- Use for unrelated actions.
- Put more than 5–6 items in secondary menu.
- Hide critical actions only in dropdown.
- Use on mobile if touch target compromises primary action speed.

---

## 7. Implementation notes

### React example (conceptual)
```jsx
<SplitButton
  primaryAction={{ label: "Save", onClick: handleSave }}
  loading={isSaving}
  disabled={!isDirty}
  menuItems={[
    { label: "Save as draft", onClick: saveDraft },
    { label: "Save and close", onClick: saveAndClose },
  ]}
  size="medium"
  variant="primary"
/>
```

### Focus management
- Focus trap in menu uses `focus-trap-js` or similar.
- On menu close, focus returns to trigger.

### Mobile consideration
- On narrow screens, consider converting to a single dropdown button to avoid tiny touch zones.
- Use `@media (hover: none)` to increase tap area.

---

## 8. Testing checklist

- [ ] Primary click works.
- [ ] Trigger opens/closes menu.
- [ ] Menu items can be selected.
- [ ] Keyboard navigation works (arrows, Enter, Escape, Tab trap).
- [ ] Disabled state prevents interaction.
- [ ] Loading state shows spinner and disables trigger.
- [ ] Screen reader announces states.
- [ ] Touch targets meet 44px on mobile.
- [ ] Menu closes on outside click.
- [ ] Focus returns correctly after close.

---

**Decision log**  
- **component_boundary**: split button with primary action + dropdown secondary menu.  
- **state_coverage**: default, disabled, loading, dropdown open, mobile touch.  
- **accessibility_behavior**: full keyboard nav, ARIA labels, focus trap, touch target minimums.  
- **implementation_boundary**: framework-agnostic with CSS tokens, focus management, and mobile fallback consideration.

This spec is ready for implementation review.