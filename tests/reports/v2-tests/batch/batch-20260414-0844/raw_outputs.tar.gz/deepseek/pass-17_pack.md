## Functional tier

Let’s break this down step by step.

**What’s the problem?**  
You’re deciding whether to use a global state manager (like Redux) or local state with React Context for a React app. This choice affects how data flows, how components communicate, and how you handle updates.

**What’s global state?**  
Global state means data that’s shared across many parts of the app—like user info, theme settings, or a shopping cart. Redux is one tool that stores this data in a central place, and components can read from it or request changes through actions.

**What’s local state with Context?**  
Local state is data that stays inside a component or a small group of components. React Context lets you pass data down the component tree without manually passing props at every level. It’s simpler than Redux but can get slow if you overuse it or update it too often.

**How to choose?**  
Ask these questions:

1. **How many components need this data?**  
   - If it’s just a few nearby components, local state + Context is fine.
   - If it’s many components across different screens, global state might be better.

2. **How often does the data change?**  
   - If it changes a lot (like form inputs, real-time updates), global state can help manage performance.
   - If it changes rarely (like theme or user role), Context is simpler.

3. **Do you need time-travel debugging or undo/redo?**  
   - Redux makes this easier because it tracks every state change.
   - Context doesn’t do this automatically.

4. **How complex is your app?**  
   - Small to medium apps: Context is often enough.
   - Large apps with many features: Redux can keep things organized.

**Tradeoffs:**  
- **Redux** adds more code and setup, but gives you control, performance tools, and easier testing.
- **Context** is built into React, so less to learn, but can cause unnecessary re-renders if not used carefully.

**Recommendation:**  
If your app is small or medium-sized, and the shared data doesn’t change too often, start with React Context. If your app grows or you need advanced features like undo/redo, switch to Redux later.

**Governing recommendation:**  
Use React Context for shared state unless you need time-travel debugging, complex state updates, or have performance issues from too many re-renders—then use Redux.

---

## Integrative tier

This decision sits at the intersection of front-end architecture, team workflow, and long-term maintainability. Let’s examine the technical and organizational factors.

**Technical dimensions:**

1. **State shape and update frequency**  
   - Global state managers (Redux, Zustand, etc.) excel when state is normalized (like a database), updates are frequent, and changes need to be predictable across distant components.
   - Context works well for shallow, nested state that changes infrequently (theme, auth status, static config). It struggles with frequent updates because every consumer re-renders unless you memoize heavily.

2. **Performance and scaling**  
   - Redux uses selective subscription (via `useSelector`), so only components that depend on changed data re-render.
   - Context re-renders all consumers when the context value changes, which can become a bottleneck in large apps.

3. **Dev experience and debugging**  
   - Redux DevTools give you time-travel, action logging, and state snapshots—valuable for debugging complex interactions.
   - Context has no built-in debugging; you rely on React DevTools and manual inspection.

4. **Data dependencies and side effects**  
   - Redux middleware (like Redux Toolkit’s `createAsyncThunk`) standardizes async logic, error handling, and loading states.
   - With Context, you often end up mixing async logic inside components or custom hooks, which can scatter business logic.

**Team and workflow considerations:**

- **Learning curve:** Redux (especially Redux Toolkit) requires upfront learning; Context is simpler for React developers.
- **Code structure:** Redux enforces a pattern (actions, reducers, selectors) that can keep large codebases organized. Context can lead to ad-hoc solutions.
- **Testing:** Redux state and reducers are easy to unit test; testing Context often requires full component rendering.

**Tradeoffs in practice:**

- **Choosing Context** means accepting that you may hit performance walls or logic duplication later, but you move faster now.
- **Choosing Redux** means investing in architecture early, which pays off in maintainability for complex apps but adds overhead for simple ones.

**Governing recommendation:**  
If your app has complex state interactions, needs predictable debugging, or will scale beyond a few screens, use Redux Toolkit. If the app is simple, mostly UI state, and won’t grow in complexity, use React Context.

---

## Strategic tier

**Core question:** Does the state need to be centralized and externally managed, or can it stay colocated with UI?

**Decision drivers:**

1. **State ownership:**  
   - Global state: state lives outside components, owned by the store. Mutations are explicit actions.
   - Local + Context: state lives in a React component tree; mutations are direct `setState` or context updates.

2. **Architecture tax:**  
   - Redux adds bundle size, boilerplate, and mental overhead. The cost is upfront and ongoing.
   - Context’s cost is rendering performance: unnecessary re-renders as the app scales.

3. **Boundary placement:**  
   - With Redux, the server/client boundary is clearer—state can be hydrated from SSR, and async flows are managed via middleware.
   - With Context, you often end up pushing async logic into hooks or components, blurring the boundary.

4. **Long-term trajectory:**  
   - If the app will accumulate complex business logic, multi-step workflows, or real-time updates, Redux’s predictability outweighs its cost.
   - If the app is mostly presentational, with limited interactive state, Context is sufficient and keeps the stack lighter.

**Tradeoff:**  
You trade development speed and simplicity (Context) for scalability, debugging, and state consistency (Redux).

**Governing recommendation:**  
Use Redux if the app has or will have complex client-side state, async workflows, or needs time-travel debugging. Use Context if the app is UI‑focused, state is minimal, and you prioritize simplicity over scalability.