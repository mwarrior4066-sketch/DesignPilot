**Hierarchy failure**  
The title is visually dominant but lacks context — the audience must read the small date and logo to understand what they’re looking at. This creates a cognitive tax before the message lands.

**Layout and composition**  
The full‑bleed photo competes with the central logo, reducing clarity. The date is tucked in a corner where it’s easy to miss, yet it’s essential information.

**Type and color**  
Decorative typefaces can work for headlines, but here it’s the only strong typographic element — no supporting hierarchy guides the eye. White‑on‑photo contrast may be adequate in bright areas of the skyline, but in darker zones the logo and text could disappear.

**What to preserve, what to change**  
Keep the energy of the city‑skyline metaphor and the bold title treatment.  
Reposition the conference logo and date so they work with — not against — the visual flow.  
Add a clear subtitle or tagline that frames the event before the decorative title takes over.

---

### Rebuild moves

1. **Lead with context**  
   Place the conference logo or a concise subtitle (e.g., “Annual Design Conference”) above or beside the main title, using a clean, readable typeface. This tells the viewer *what* this is before the decorative title adds style.

2. **Restructure the visual flow**  
   Move the date out of the corner and group it with location, time, and a call‑to‑action (website, register) in a clearly defined block — perhaps along one edge of the photo where contrast is reliable.  
   Use the skyline photo as a backdrop, not a competing foreground element. Consider darkening or blurring part of the image behind text areas to ensure readability.

3. **Test contrast rigorously**  
   Check white‑on‑photo contrast in both light and dark areas of the skyline. If contrast falls below WCAG AA (4.5:1), add a semi‑transparent overlay or reposition text to a more consistent part of the image.

4. **Simplify the type system**  
   Use the decorative face only for the main title. Support it with a clean sans‑serif for all other text (subtitle, date, location, URL). Establish a clear size hierarchy so the eye moves naturally from “what is this” → “when/where” → “what to do.”

5. **Consider grid and alignment**  
   Align all text elements to a consistent margin — don’t let the date float alone in a corner. A simple column grid (e.g., 8‑ or 12‑column) can organize the title block, details block, and logo without over‑designing.

---

### Tradeoffs
- **You gain** immediate comprehension and a more professional, accessible layout.  
- **You sacrifice** some of the “surprise” of the decorative title standing alone — but the trade is worth it because the poster’s job is to inform, not to puzzle.

---

### Next steps
- Mock up the revised layout with the logo/tagline first, then the decorative title, then the details block.
- Test contrast with a tool like WebAIM’s Contrast Checker on multiple skyline samples.
- If the client loves the current title treatment, keep it large but add a clear subtitle directly beneath it in a smaller, high‑contrast sans‑serif.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": ["communication_goal: inform before styling", "hierarchy_failure: title before context", "rebuild_move: lead with context, restructure flow", "distance_tradeoff: clarity over surprise"],
  "evidence_classes_cited": ["visual_hierarchy", "contrast_threshold"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]