I'll define a color system for a healthcare SaaS dashboard that meets your requirements for status communication, dark mode, data visualization, and accessibility.

## Color System for Healthcare SaaS Dashboard

### Core Principles
- **Clinical clarity**: Colors must be unambiguous in healthcare contexts
- **Accessibility first**: WCAG AA compliance for all text and UI elements
- **Semantic roles**: Colors map to meaning, not just aesthetics
- **Dark mode parity**: Full palette works in both light and dark modes
- **Data visualization ready**: 5+ categorical colors with clear differentiation

### Semantic Color Roles

#### 1. Status Colors (Primary Communication)
```
✅ Normal/Positive: #2E7D32 (Forest Green)
  - WCAG AA: 4.5:1 on white, 7:1 on dark
  - Healthcare association: Healthy, stable, normal range
  - Dark mode: #4CAF50 (Brighter Green)

⚠️ Warning/Caution: #F57C00 (Amber Orange)
  - WCAG AA: 3.1:1 on white (use with care), 5.5:1 on dark
  - Healthcare association: Monitor, borderline, attention needed
  - Dark mode: #FF9800 (Softer Amber)

🔴 Critical/Alert: #D32F2F (Clinical Red)
  - WCAG AA: 4.6:1 on white, 6.8:1 on dark
  - Healthcare association: Critical, emergency, abnormal
  - Dark mode: #F44336 (Brighter Alert Red)
```

#### 2. Data Visualization Palette (5+ Categorical Colors)
```
#1 Primary Data: #1976D2 (Trust Blue)
  - WCAG AA: 4.8:1 on white, 7.2:1 on dark
  - Use: Primary metric, main patient data

#2 Secondary Data: #7B1FA2 (Healthcare Purple)
  - WCAG AA: 7.1:1 on white, 4.9:1 on dark
  - Use: Comparative data, secondary metrics

#3 Tertiary Data: #00897B (Teal)
  - WCAG AA: 3.9:1 on white (use with care), 5.8:1 on dark
  - Use: Demographic categories, time periods

#4 Quaternary Data: #FF8F00 (Golden Amber)
  - WCAG AA: 3.0:1 on white (requires careful pairing), 4.5:1 on dark
  - Use: Risk factors, optional data layers

#5 Quinary Data: #5D4037 (Brown)
  - WCAG AA: 8.5:1 on white, 3.2:1 on dark (requires careful pairing)
  - Use: Background/contextual data

#6 Senary Data: #546E7A (Slate Blue)
  - WCAG AA: 7.0:1 on white, 4.0:1 on dark
  - Use: Reference lines, benchmarks
```

#### 3. UI Foundation Colors
```
Primary/Interactive: #1565C0 (Confidence Blue)
  - WCAG AA: 4.9:1 on white, 7.3:1 on dark
  - Use: Buttons, links, primary actions

Background Light: #FFFFFF → #FAFAFA (White to Off-White)
Background Dark: #121212 → #1E1E1E (Near Black to Dark Gray)

Surface Light: #F5F5F5 (Light Gray)
Surface Dark: #2D2D2D (Medium Dark Gray)

Text Primary Light: #212121 (Near Black)
Text Primary Dark: #E0E0E0 (Light Gray)

Text Secondary Light: #757575 (Medium Gray)
Text Secondary Dark: #B0B0B0 (Medium Light Gray)

Borders/Divider Light: #E0E0E0 (Light Gray)
Borders/Divider Dark: #424242 (Dark Gray)
```

### Dark Mode Specific Adjustments

**Status colors brighten in dark mode** to maintain contrast against darker backgrounds while preserving meaning:
- Normal: #2E7D32 → #4CAF50 (+20% brightness)
- Warning: #F57C00 → #FF9800 (+15% brightness)
- Critical: #D32F2F → #F44336 (+20% brightness)

**Data visualization colors adjust for dark mode readability**:
- Blues and purples maintain similar contrast
- Teal and amber brighten slightly
- Brown shifts to warmer, lighter tone (#5D4037 → #8D6E63)

### Accessibility Implementation Rules

#### 1. Minimum Contrast Requirements
- **Text on background**: 4.5:1 (WCAG AA)
- **Large text (18pt+ or 14pt+bold)**: 3:1
- **Non-text UI components**: 3:1
- **Status indicators**: Must pass both color and shape/symbol redundancy

#### 2. Color-Blind Safe Pairings
All status and data colors pass deuteranopia (red-green) simulation:
- Normal vs. Critical: Different brightness and hue (green vs. red)
- Data colors: Different lightness values and saturation
- **Critical information never relies on color alone**: Always include icons, patterns, or text labels

#### 3. Implementation Guardrails
```css
/* Example implementation rules */
:root {
  /* Status colors with fallbacks */
  --status-normal: #2E7D32;
  --status-warning: #F57C00;
  --status-critical: #D32F2F;
  
  /* Data colors */
  --data-1: #1976D2;
  --data-2: #7B1FA2;
  --data-3: #00897B;
  --data-4: #FF8F00;
  --data-5: #5D4037;
  --data-6: #546E7A;
  
  /* Contrast verification classes */
  .contrast-check {
    border: 2px solid transparent;
  }
  
  .contrast-check:focus-within {
    border-color: var(--status-critical);
  }
}

/* Dark mode overrides */
@media (prefers-color-scheme: dark) {
  :root {
    --status-normal: #4CAF50;
    --status-warning: #FF9800;
    --status-critical: #F44336;
    /* ... other dark mode adjustments */
  }
}
```

### Healthcare-Specific Considerations

#### 1. Cultural & Clinical Associations
- **Green** = Normal, healthy, within range (universal healthcare association)
- **Red** = Critical, stop, emergency (clear emergency signaling)
- **Amber** = Caution, monitor, review needed (standard warning)
- **Avoid red-green pairing as only differentiator** for color-blind users

#### 2. Data Visualization Best Practices
- Use **sequential palette** for severity scales (light to dark)
- Use **diverging palette** for above/below normal ranges
- **Categorical colors** maintain consistent assignment across charts
- **Always include legend** with color meanings
- **Support pattern fills** as optional overlay for printed reports

#### 3. Status Communication Hierarchy
```
Level 1: Critical (Red + ! icon + bold text)
  - Immediate action required
  - Flashing not recommended (seizure risk)

Level 2: Warning (Amber + ⚠ icon + regular text)
  - Review needed
  - May require follow-up

Level 3: Normal (Green + ✓ icon + regular text)
  - Within expected parameters
  - No action needed
```

### Migration & Adoption Strategy

#### Phase 1: Foundation
1. Implement status colors across alerts and indicators
2. Apply UI foundation colors to components
3. Verify WCAG AA compliance with automated tools

#### Phase 2: Data Visualization
1. Apply categorical palette to existing charts
2. Create chart templates with accessibility patterns
3. Train team on color semantics

#### Phase 3: Dark Mode
1. Implement media query overrides
2. Test contrast in both modes
3. User testing with healthcare professionals

### Verification Methods
1. **Automated**: Use tools like axe, Lighthouse, Color Contrast Analyzer
2. **Manual**: Check with color-blind simulation (Deuteranopia, Protanopia)
3. **Real-world**: Print grayscale reports to ensure information survives
4. **User testing**: Healthcare staff validation of status clarity

### Tradeoffs and Constraints

**What this system preserves:**
- Clinical clarity and unambiguous status communication
- WCAG AA compliance for all interactive elements
- Dark mode parity without meaning shift
- Color-blind safety through brightness and pattern redundancy

**What this system sacrifices:**
- Some vibrant marketing colors (healthcare requires restraint)
- Pure aesthetic flexibility (semantic roles limit creative choices)
- Simple implementation (requires careful contrast management)

**The constraint is**: Healthcare dashboards cannot afford ambiguous color coding—patient safety depends on clear, accessible communication. This means accepting more conservative color choices and stricter contrast requirements than a consumer app might use.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "standard",
  "decisions_committed": ["semantic_roles: status/data/ui", "state_mapping: light/dark parity", "contrast_boundary: WCAG AA minimum", "migration_strategy: phased adoption"],
  "evidence_classes_cited": ["threshold", "rule", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]