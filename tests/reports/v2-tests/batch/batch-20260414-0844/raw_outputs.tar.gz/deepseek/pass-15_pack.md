**Route:** `rt_backend_systems_architecture`  
**Escalation level:** `compound`  
**Decisions committed:** `authority_model: tenant-isolated`, `consistency_stance: eventual with ordering guarantees`, `data_delivery: cursor-based activity feed + webhook fanout`, `observability_tax: distributed trace + tenant-aware metrics`  
**Evidence cited:** `system_surface_dependency`, `blocking_constraint`, `authorization_perimeter`, `async_job_model`  
**Validator flags:** none  
**Weak patterns seen:** none  
**Open questions:** none  
**Turn:** 1  

---

## Backend Architecture Spec: Multi‑Tenant Scheduling Platform

### 1. Authority Model & Data Boundaries

**Tenant‑isolated services.**  
Every tenant (customer organization) is a separate logical namespace. All data‑storage, background jobs, and event streams are scoped by `tenant_id`. No service may operate without a tenant context.

**Workspace‑level sub‑tenancy.**  
Within a tenant, `workspace_id` further isolates team data. Workspaces share the tenant’s billing, admin users, and regional residency, but scheduling data, activity feeds, and webhook configurations are workspace‑scoped.

**Regional data residency.**  
Tenant data is pinned to a geographic region at sign‑up. All services that persist tenant data must respect the region‑routing layer. Cross‑region replication is allowed only for read‑only global catalogs (e.g., time‑zone definitions, public holidays).

**Blocking constraint:**  
Background jobs and event processors must be region‑local. A job queue in `us‑east` cannot process tasks for a tenant in `eu‑central`. This forces a per‑region deployment of all stateful services.

### 2. Core Services & Contracts

#### 2.1 Scheduling Engine
- **Owns:** calendar slots, resource availability, conflict detection, recurrence rules.
- **Contract:** REST endpoints for CRUD + conflict‑check; publishes `ScheduleCreated|Updated|Deleted` events.
- **Data boundary:** PostgreSQL with `tenant_id`, `workspace_id` indexes. Row‑level security (RLS) enforces isolation at the database layer.

#### 2.2 Activity Feed Service
- **Owns:** cursor‑paginated event log of all tenant actions (schedule changes, approvals, user joins, etc.).
- **Contract:** `GET /activity?cursor=&limit=20` returns JSON with `next_cursor`. Each entry includes `actor_id`, `action`, `resource_type`, `resource_id`, `timestamp`, and a signed hash for integrity.
- **Consistency stance:** eventual with ordering guarantees within a workspace. The feed is built asynchronously from events, but sequence numbers per workspace guarantee clients never see out‑of‑order entries.

#### 2.3 Approval Workflow Service
- **Owns:** approval rules, pending requests, approver assignments, decision events.
- **Contract:** REST API for rule CRUD; `POST /approval‑requests` triggers a state machine; webhook‑style callbacks for decisions.
- **State machine:** `pending → approved|rejected|cancelled`. Time‑outs move to `expired`.
- **Integration:** subscribes to `ScheduleCreated` events, evaluates rules, creates approval requests.

#### 2.4 Webhook Dispatcher
- **Owns:** tenant‑defined webhook endpoints, retry logic, delivery receipts.
- **Contract:** Tenant‑admin REST API to register endpoints (URL, secret, event types). Internal event‑bus listeners fan out events.
- **Async job model:** `202 Accepted` + status URL. Jobs are queued per region, retried with exponential backoff + jitter, dead‑lettered after 72 hours.
- **Security:** outbound requests sign payloads with tenant secret; include `Webhook‑Id`, `Timestamp`, `Signature` headers.

#### 2.5 Automation Rules Engine (future)
- **Owns:** customer‑defined “if‑this‑then‑that” rules, rule evaluation, action execution.
- **Design note:** build as a separate service that subscribes to the same event bus as the webhook dispatcher. Rules are stored as ASTs; evaluation is sandboxed (e.g., Lua or a DSL). This service will become the system’s largest source of background jobs.

### 3. Eventing & Background Jobs

**Current gap:** inconsistent background jobs and eventing.  
**Prescribed fix:** adopt a unified event‑bus and job‑queue backbone per region.

#### 3.1 Event Bus (internal)
- **Purpose:** decouple services that produce state changes from those that react.
- **Technology:** region‑local Apache Kafka or AWS Kinesis.
- **Events are immutable, structured, and tenant‑scoped.**  
  Example event schema:
  ```json
  {
    "id": "evt_...",
    "type": "schedule.updated",
    "tenant_id": "t_...",
    "workspace_id": "ws_...",
    "occurred_at": "2025‑01‑15T10:00:00Z",
    "data": { ... },
    "metadata": { "actor_id": "u_...", "correlation_id": "corr_..." }
  }
  ```

#### 3.2 Job Queue
- **Purpose:** reliable, retryable, tenant‑isolated background work.
- **Technology:** region‑local Redis (Bull) or AWS SQS + Lambda.
- **Each job includes `tenant_id` and `workspace_id`.** Workers reject jobs that don’t match their region.
- **Idempotency contract:** jobs that mutate state must carry an `idempotency_key` derived from the triggering event. Duplicate keys cause a `409 Conflict` early in the handler.

#### 3.3 Service‑Level Contracts
- **Scheduling Engine** → emits events to the event bus, enqueues conflict‑check jobs.
- **Activity Feed Service** → subscribes to all event types, appends to feed tables, generates cursor offsets.
- **Approval Workflow Service** → subscribes to schedule events, enqueues approval‑request jobs.
- **Webhook Dispatcher** → subscribes to event types selected by tenants, enqueues delivery jobs.
- **Future Automation Engine** → subscribes to event bus, evaluates rules, enqueues action jobs.

### 4. Authorization & Audit

**Authorization perimeter:**  
- All REST endpoints require a JWT with `tenant_id`, `workspace_id`, and user roles.
- **Object‑level authorization (BOLA):** each service checks that the resource’s `tenant_id` and `workspace_id` match the token’s claims before returning or mutating.
- **Deny by default:** no service assumes cross‑workspace access.

**Audit trails:**  
- The activity feed is the primary user‑visible audit log.
- For compliance, all event‑bus messages are archived to cold storage (e.g., S3 Glacier) with a 7‑year retention policy.
- Database‑level audit triggers capture before/after snapshots of sensitive tables (users, roles, webhook configs).

### 5. Operational Concerns

#### 5.1 Observability Tax
- **Distributed tracing:** every request and event gets a `correlation_id`. Traces span REST calls, event publishing, and job execution.
- **Tenant‑aware metrics:** dashboards can filter by `tenant_id` for debugging. Alerts fire when error rates spike for a specific tenant.
- **Logging:** structured JSON logs include `tenant_id`, `workspace_id`, `correlation_id`. Log aggregation is region‑local.

#### 5.2 Deployment & Region Isolation
- Each region runs a full stack of the above services.
- A global router (AWS Route 53, Cloudflare) directs `tenant‑X.api.example.com` to the region where tenant X’s data lives.
- Database migrations are run per region; schema must be forward/backward compatible.

#### 5.3 Failure Modes & Resilience
- **Event‑bus downtime:** producers buffer locally (e.g., SQL outbox) until the bus is back.
- **Job‑queue backlog:** auto‑scaling workers per region, with dead‑letter queues for poison messages.
- **Webhook delivery failures:** exponential backoff (max 24h), then dead‑letter. Dead‑lettered webhooks appear in tenant‑admin UI for manual retry.
- **Regional outage:** tenants in that region are down; no cross‑region failover because of data‑residency requirements.

#### 5.4 Cost & Scaling
- **Highest cost surface:** the Automation Rules Engine (future) will generate a job per evaluated rule per event. Plan for per‑tenant rate‑limiting and query‑cost budgets.
- **Scaling bottleneck:** the Activity Feed Service’s cursor‑based queries must remain fast as feeds grow. Partition by `workspace_id`, index on (`workspace_id`, `event_number`), and keep hot data in memory.

### 6. Implementation Sequence

1. **Phase 1: Event Bus & Job Queue**  
   Deploy Kafka/Kinesis and Redis/SQS per region. Migrate existing background jobs to the new queue.
2. **Phase 2: Activity Feed Service**  
   Build feed tables, subscribe to critical events, expose cursor‑based API.
3. **Phase 3: Approval Workflow Service**  
   Implement state machine, integrate with scheduling events.
4. **Phase 4: Webhook Dispatcher**  
   Add tenant‑configurable endpoints, fan‑out from event bus.
5. **Phase 5: Automation Rules Engine**  
   Design DSL, sandbox, job‑cost monitoring.

### 7. Risks & Safer Path

**Risk:** over‑coupling services to a specific event‑bus technology.  
**Safer path:** define an internal event‑bus client interface that wraps Kafka/Kinesis. This lets you switch later without changing every service.

**Risk:** cursor‑based activity feeds become a scaling bottleneck.  
**Safer path:** start with a simple `ORDER BY event_number OFFSET LIMIT` but design partitioning from day one. Monitor query latency per workspace; partition when >100k events.

**Risk:** customer‑defined automation rules can cause infinite loops.  
**Safer path:** the future Automation Engine must include per‑tenant rule‑execution budgets, cycle detection, and a kill‑switch.

**What is preserved:** tenant isolation, data residency, eventual consistency with ordering.  
**What is sacrificed:** cross‑region failover, synchronous real‑time feeds, monolithic simplicity.

---

[SESSION_STATE]
{
  "route": "rt_backend_systems_architecture",
  "escalation_level": "compound",
  "decisions_committed": ["authority_model: tenant-isolated", "consistency_stance: eventual with ordering guarantees", "data_delivery: cursor-based activity feed + webhook fanout", "observability_tax: distributed trace + tenant-aware metrics"],
  "evidence_classes_cited": ["system_surface_dependency", "blocking_constraint", "authorization_perimeter", "async_job_model"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]