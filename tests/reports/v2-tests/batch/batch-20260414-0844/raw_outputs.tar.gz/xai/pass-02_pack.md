# Split Button Component Specification

Below is a detailed specification for a split button component with a primary action ("Save") and a dropdown trigger for secondary actions ("Save as draft" and "Save and close"). This spec addresses keyboard support, disabled states, loading states, and mobile touch target requirements.

## Component Boundary
- **Purpose**: A split button combines a primary action with immediate effect and a secondary dropdown for related actions, optimizing for frequent primary use while providing access to less common options.
- **Scope**: This component is a self-contained UI element usable in forms, toolbars, or modal dialogs. It handles two interaction zones: the primary button and the dropdown trigger.
- **Variants**: Base variant includes primary action and dropdown. No additional size or style variants are defined here unless requested.
- **Usage Context**: Primarily for action-heavy interfaces like editors, workflows, or data entry forms where a default action ("Save") is paired with contextual alternatives.

## State Coverage
- **Default State**: Primary button labeled "Save" with a right-side dropdown trigger (chevron icon or similar). Dropdown is closed by default.
- **Hover State**: Visual feedback on both primary button and dropdown trigger (e.g., background shade change or border highlight) to indicate interactivity.
- **Focus State**: Clear focus indicator (e.g., outline or glow) on either the primary button or dropdown trigger when navigated via keyboard.
- **Active/Pressed State**: Visual depression or color shift when the primary button or dropdown trigger is clicked or tapped.
- **Disabled State**: Both primary button and dropdown trigger are visually dimmed (e.g., reduced opacity, grayed-out text/icon). Non-interactive in this state.
- **Loading State**: Primary button shows a spinner or loading indicator replacing the "Save" label. Dropdown trigger remains visible but non-interactive during loading.
- **Expanded State**: Dropdown is open, displaying "Save as draft" and "Save and close" as selectable menu items. Menu items have their own hover and focus states.

## Accessibility Behavior
- **Keyboard Support**:
  - Tab navigation: Primary button and dropdown trigger are separate tab stops (two focusable elements).
  - Enter/Space: Activates the primary button ("Save") when focused; opens the dropdown or selects a menu item when the trigger or menu is focused.
  - Arrow keys: Navigate between dropdown items when expanded; do not cycle back to the primary button.
  - Escape: Closes the dropdown if open, returning focus to the trigger.
- **ARIA Attributes**:
  - Primary button: `role="button"` with `aria-label="Save"` if icon-only or ambiguous.
  - Dropdown trigger: `role="button"` with `aria-expanded="true/false"` based on dropdown state, and `aria-controls` pointing to the dropdown menu ID.
  - Dropdown menu: `role="menu"` with each item as `role="menuitem"`.
- **Focus Management**: When dropdown closes after selection, focus returns to the dropdown trigger, not the primary button, to maintain user context.
- **Touch Targets**: Minimum 44x44px per actionable area (primary button and dropdown trigger) per WCAG 2.1 guidelines for mobile accessibility. Padding or hit areas must ensure tappable separation on small screens.
- **Screen Reader**: Announces primary action as "Save, button" and trigger as "More save options, button, expanded/collapsed" based on state.

## Visual and Interaction Design
- **Layout**:
  - Primary button occupies ~70-80% of total width for emphasis; dropdown trigger takes the remaining ~20-30% with a subtle separator (e.g., vertical line or color shift).
  - Dropdown menu aligns to the right edge of the trigger, dropping below with a slight offset to avoid occlusion.
- **Mobile Considerations**: On smaller viewports, ensure touch targets remain distinct by increasing padding or using a stacked layout if separation becomes unclear. Dropdown menu must not overflow viewport edges (use scrollable menu if needed).
- **Loading Feedback**: Spinner or loading icon replaces "Save" text during operation; text does not truncate or shift layout. Dropdown trigger grays out to prevent secondary action during loading.
- **Disabled Feedback**: Both zones dim uniformly (e.g., 50% opacity or gray scale) to signal non-interactivity without confusing which part is disabled.

## Implementation Boundary
- **Rendering Model**: Component is client-side rendered for immediate interactivity. Dropdown menu should use a portal or similar mechanism to ensure proper z-index stacking outside parent containers.
- **State Ownership**: Parent component passes props for `disabled` and `loading` states. Internal state manages dropdown `expanded` status unless controlled by parent for specific use cases.
- **Event Handling**:
  - Primary action emits `onSave` event.
  - Secondary actions emit distinct events (e.g., `onSaveAsDraft`, `onSaveAndClose`).
  - Dropdown toggle emits `onToggle` for tracking or analytics if needed.
- **Dependencies**: Requires a CSS framework or custom styles for hover/focus/active states. Dropdown positioning may need a library like Popper.js if not natively supported.
- **Semantic Contract**: HTML structure must use `<button>` for both primary and trigger actions (no `<div>` with click handlers). Dropdown items are `<li>` or `<button>` within a `<ul role="menu">` for semantic clarity.
- **Performance Notes**: Avoid heavy re-renders on dropdown toggle; use memoization for static menu items. Loading spinner should not trigger layout shifts.

## Tradeoffs and Rationale
- **Separate Focus Stops**: Making primary button and dropdown trigger distinct tab stops increases keyboard navigation precision at the cost of an extra tab press. This preserves clarity over merging them into one focusable unit.
- **Dropdown Trigger Visibility in Loading State**: Keeping the trigger visible but disabled during loading avoids layout shifts and maintains UI consistency, sacrificing the ability to hide secondary options temporarily.
- **Client-Side Rendering**: Prioritizes instant feedback over server-side simplicity, accepting a small client bundle increase to ensure responsive dropdown behavior.

This spec provides a clear blueprint for a split button component that balances usability, accessibility, and implementation feasibility. If you need adjustments for specific design systems, additional variants, or deeper integration details, let me know.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: self-contained UI element for forms and dialogs", "state_coverage: default, hover, focus, active, disabled, loading, expanded", "accessibility_behavior: separate tab stops, ARIA roles, 44x44px touch targets"],
  "evidence_classes_cited": ["accessibility_threshold", "touch_target_rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]