I’ll recommend a type system for your fintech product that balances modernity, trust, and functionality across your marketing site, web app dashboard, and mobile interfaces. Below is a detailed plan tailored to your needs, focusing on readability, hierarchy, and data density.

## Typeface Selection
I recommend **Inter** as the primary typeface for your fintech product. Here’s why it fits your requirements:

- **Modern and Trustworthy Aesthetic**: Inter is a sans-serif typeface designed for digital interfaces with a clean, neutral appearance. Its geometric structure conveys a modern feel, while its balanced proportions and subtle humanist touches inspire confidence—key for a fintech product where trust is paramount.
- **Versatility Across Platforms**: Inter is optimized for screen rendering, with excellent legibility at small sizes on both desktop and mobile devices. It works well for marketing copy, UI elements, and dense dashboard data.
- **Support for Hierarchy**: Inter offers a wide range of weights (from Thin to Black, with 9 weights total) and matching italics, allowing for clear typographic hierarchy across headings, body text, and data tables.
- **Tabular Data Handling**: Inter includes tabular figures (monospaced numbers) as an OpenType feature, ensuring proper alignment in financial tables and dashboards where numbers are critical.
- **Licensing and Accessibility**: Inter is open-source under the SIL Open Font License, making it free to use across all platforms without licensing costs. It also supports a broad range of Latin-based languages for global accessibility.

## Type System Configuration

### Marketing Site
- **Headings**: Inter Bold (700) at 48px for H1, scaling down to 24px for H4. Use tighter letter-spacing (-0.02em) to enhance visual impact and convey authority.
- **Subheadings**: Inter Medium (500) at 18-20px to differentiate from body text while maintaining a polished look.
- **Body Text**: Inter Regular (400) at 16px with a line-height of 1.5 (24px) for readability on longer marketing content.
- **CTAs and Buttons**: Inter SemiBold (600) at 16px to create emphasis and encourage action.

### Web App Dashboard
- **Headings**: Inter Bold (700) at 24px for primary section titles, down to 14px for smaller labels, ensuring clear hierarchy in a dense UI.
- **Body/UI Text**: Inter Regular (400) at 14px with a line-height of 1.4 (19.6px) for compact readability in navigation and tooltips.
- **Tabular Data**: Inter Regular (400) at 12-14px with tabular figures enabled. Use Inter Medium (500) for column headers to distinguish them from data cells. Line-height of 1.3 (15.6-18.2px) to keep tables scannable.
- **Microcopy (Labels, Tags)**: Inter Regular (400) at 11-12px for small annotations, ensuring clarity even at reduced sizes.

### Mobile Interfaces
- **Headings**: Inter Bold (700) at 20px for primary titles, scaling down to 14px for smaller headings to fit constrained screen space.
- **Body/UI Text**: Inter Regular (400) at 14px with a line-height of 1.45 (20.3px) to maintain readability on smaller screens.
- **Tabular Data**: Inter Regular (400) at 12px with tabular figures enabled, and Inter Medium (500) for headers. Adjust line-height to 1.3 (15.6px) for tighter spacing.
- **Buttons and Navigation**: Inter SemiBold (600) at 14px to ensure tappable elements are visually distinct.

## Scale and Hierarchy Logic
Using a modular type scale with a ratio of 1.25 ensures proportional harmony across platforms:
- **Marketing Site**: 48px (H1), 38px (H2), 30px (H3), 24px (H4), 16px (body).
- **Dashboard**: 24px (H1), 18px (H2), 14px (H3), 14px (body), 12px (microcopy).
- **Mobile**: 20px (H1), 16px (H2), 14px (H3), 14px (body), 12px (microcopy).

This scale preserves hierarchy while adapting to screen constraints. Weights (Bold for headings, Medium/SemiBold for emphasis, Regular for body) reinforce visual order.

## Variable Font Usage
Inter is available as a variable font, which is ideal for modern web and app development:
- **Performance**: Use the variable font version to reduce file size and HTTP requests compared to loading multiple static weights.
- **Flexibility**: Adjust weight dynamically for subtle hierarchy tweaks (e.g., between 500 and 600 for specific UI states) without additional font files.
- **Implementation**: Serve Inter Variable via Google Fonts CDN or self-host for better control. Ensure fallback to static weights for older browsers (e.g., IE11) if needed.

## Fallback Stack
To ensure rendering consistency across devices, use this fallback stack:
- **Primary**: Inter (self-hosted or via Google Fonts).
- **Fallbacks**: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif.
This stack prioritizes system fonts for performance and familiarity if Inter fails to load.

## Readability and Accessibility
- **Line Length**: Target 45-75 characters per line for body text on marketing pages and 30-50 characters for mobile to optimize reading comfort.
- **Leading (Line-Height)**: Use 1.4-1.5 for body text and 1.2-1.3 for headings and tables to balance density and clarity.
- **Contrast**: Pair Inter with foreground/background colors meeting WCAG 2.1 AA (4.5:1 for normal text, 3:1 for large text). Test against dark mode and high-contrast modes.
- **Small Text**: Avoid weights lighter than Regular (400) below 14px to prevent legibility issues on low-DPI screens.

## Adoption Sequence
1. **Procurement**: Download Inter from Google Fonts or rsms.me/inter for self-hosting. Use the variable font for web/app, and static weights for older systems if needed.
2. **Implementation**: Define CSS custom properties (e.g., `--font-family-base`, `--font-weight-heading`) for consistent application across platforms. Enable tabular figures via `font-variant-numeric: tabular-nums` for financial data.
3. **Testing**: Validate rendering on iOS, Android, Windows, and macOS. Test tabular data alignment in dashboards and ensure variable font support in modern browsers.
4. **Documentation**: Create a type style guide with sizes, weights, line-heights, and usage rules for marketing, dashboard, and mobile contexts to maintain consistency.

## Tradeoffs
- **Preserved**: Legibility and trust through a clean, neutral typeface; performance via variable fonts; data clarity with tabular figures.
- **Sacrificed**: A highly unique or bespoke brand feel—Inter is widely used, so it won’t stand out as a custom typeface. If brand differentiation becomes a priority, consider pairing with a secondary display font for marketing headings (e.g., a serif like Playfair Display for contrast, used sparingly).

This type system ensures your fintech product feels modern and reliable while handling the functional demands of financial data and cross-platform consistency. If you’d like alternatives to Inter or need a secondary typeface for branding, I can explore those next.