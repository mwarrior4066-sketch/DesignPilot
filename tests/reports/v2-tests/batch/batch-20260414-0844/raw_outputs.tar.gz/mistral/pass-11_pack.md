Here’s how I would reconstruct the layout system from your 2018 brand guidelines PDF, structured as a **governing route** (`rt_layout_reconstruction_plan`) with supporting skills (`pdf-layout-expert`, `grid-system-expert`, `type-system-expert`). This ensures the output is implementation-ready, preserves legacy intent, and avoids destructive shortcuts.

---

### **1. Evidence Extraction (Visual Input Protocol)**
**Goal**: Separate *observed* specifications from *inferred* structure, with confidence levels.
**From the PDF**, extract:
- **Grid diagrams** (observed):
  - Column count (e.g., 12-column), gutter width, margin width.
  - Breakpoint behavior (if specified, e.g., "mobile collapses to 4 columns").
  - Baseline grid increment (e.g., 4px or 8px) and alignment rules (e.g., "all elements snap to baseline").
  - *Confidence*: High (directly visible in diagrams).

- **Margin specifications** (observed):
  - Inner/outer margins (e.g., "20mm outer, 15mm inner").
  - Safe zones for text/images (e.g., "no critical content within 10mm of trim").
  - *Confidence*: High (explicitly stated).

- **Column examples** (inferred):
  - Span logic (e.g., "headlines span 8 columns, body text spans 6").
  - Max-width rules (e.g., "body text never exceeds 70ch").
  - *Confidence*: Medium (requires cross-referencing examples).

- **Typography scale** (inferred):
  - Hierarchy (e.g., "H1 = 48pt, H2 = 36pt, body = 12pt").
  - Line-height ratios (e.g., "1.5× for body text").
  - *Confidence*: Medium (may need normalization for digital use).

- **Mismatches** (flagged):
  - Discrepancies between diagrams and real-world examples (e.g., "diagram shows 12 columns, but examples use 8").
  - Unlabeled behavior (e.g., "no mobile grid specified").

---

### **2. Reconstruction Plan**
**Governing Route**: `rt_layout_reconstruction_plan`
**Supporting Skills**: `pdf-layout-expert` (frame logic), `grid-system-expert` (modern adaptation), `type-system-expert` (digital typography).

#### **A. Preserved Elements**
- **Grid foundation**:
  - Use the *observed* column count (e.g., 12) and gutter width as the base.
  - Retain margin ratios (e.g., "outer margins = 2× gutter width").
- **Typography**:
  - Preserve the *relative* hierarchy (e.g., "H1 is 4× body text size").
  - Convert absolute units (pt → rem/px) for digital use (e.g., "12pt → 1rem").
- **Alignment rules**:
  - Keep baseline grid snapping if critical to brand identity.

#### **B. Inference Boundaries**
- **Breakpoints**:
  - If missing, infer from legacy examples (e.g., "mobile = 4 columns, tablet = 8, desktop = 12").
  - *Confidence*: Low (document explicitly if assumed).
- **Responsive behavior**:
  - Assume fluid columns unless the PDF specifies fixed widths.
  - *Rule*: "Columns scale proportionally; gutters remain fixed."

#### **C. Modern Adaptations**
- **Digital-first adjustments**:
  - Replace print-specific margins (e.g., "trim zones") with safe-area insets for mobile.
  - Add a "max-width" container for readability (e.g., "70ch for body text").
- **CSS Grid/Flexbox translation**:
  - Convert the grid to CSS variables (e.g., `--grid-columns: 12; --gutter: 24px;`).
  - Use `minmax()` for fluid columns (e.g., `minmax(0, 1fr)`).
- **Typography**:
  - Replace fixed pt sizes with `clamp()` for fluid scaling (e.g., `clamp(1rem, 2vw, 1.2rem)`).
  - Add variable font support if the original typeface allows it.

#### **D. Verification Method**
- **Grid overlay tool**:
  - Generate a transparent grid overlay (e.g., using Figma or CSS) to validate alignment in new templates.
- **Typography audit**:
  - Check line-length and contrast ratios (WCAG AA) for digital readability.
- **Legacy comparison**:
  - Overlay reconstructed layouts on original PDF examples to spot deviations.

---

### **3. Output Artifact: Modern Layout System Spec**
**Format**: Implementation-ready CSS/Figma variables + documentation.

#### **CSS Variables (Example)**
```css
:root {
  /* Grid */
  --grid-columns: 12;
  --gutter-width: 24px;
  --margin-outer: calc(var(--gutter-width) * 2);
  --max-width: 1200px;

  /* Typography */
  --font-scale-h1: clamp(2.5rem, 5vw, 3rem);
  --font-scale-body: clamp(1rem, 1.5vw, 1.2rem);
  --line-height-body: 1.5;
  --baseline-increment: 4px; /* For snapping */
}
```

#### **Figma/Design Token Equivalent**
- Create a "Grid" component with:
  - 12-column layout + gutters.
  - Auto-layout rules for responsive behavior.
- Typography styles:
  - Fluid text styles using `clamp()`.
  - Baseline grid overlay for alignment checks.

#### **Documentation**
- **Grid rules**:
  - "All content must align to the 12-column grid. Exceptions require approval."
  - "Gutters are fixed at 24px; columns scale fluidly."
- **Typography**:
  - "Use `clamp()` for responsive typography. Never exceed 70ch line-length."
- **Breakpoints**:
  - "Mobile: 4 columns, Tablet: 8 columns, Desktop: 12 columns."

---

### **4. Tradeoffs and Risks**
- **Preserved**:
  - Brand consistency (grid ratios, typography hierarchy).
  - Print-to-digital fidelity (margins, alignment rules).
- **Sacrificed**:
  - Absolute print units (pt → rem) for digital flexibility.
  - Fixed-width layouts (replaced with fluid/responsive).
- **Risks**:
  - Inferred breakpoints may not match legacy intent (mitigation: flag as "assumed").
  - Digital typography may deviate from print (mitigation: audit readability).

---

### **5. Next Steps**
1. **Validate with legacy examples**:
   - Overlay the new grid on original PDF layouts to check alignment.
2. **Test responsive behavior**:
   - Use browser dev tools to simulate breakpoints.
3. **Document exceptions**:
   - Note any deviations from the PDF (e.g., "mobile grid inferred, not specified").

---

### **Why This Approach?**
- **Governing route**: `rt_layout_reconstruction_plan` ensures the output is a *reconstruction* (not a new grid) and preserves legacy intent.
- **Supporting skills**:
  - `pdf-layout-expert` handles frame logic (margins, safe zones).
  - `grid-system-expert` translates print grids to digital.
  - `type-system-expert` modernizes typography for screens.
- **Evidence classes**: Separates observed (high confidence) from inferred (medium/low confidence) to avoid false specificity.