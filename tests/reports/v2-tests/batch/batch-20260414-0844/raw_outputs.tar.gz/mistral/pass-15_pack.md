Here’s a **backend architecture spec** for your multi-tenant scheduling platform, structured as a **governing route** (`rt_backend_architecture_spec`) with supporting skills (`back-end-systems-architect`, `api-reliability-security-expert`, `back-end-aware-planner`). The output adheres to the contract decision index (authority model, consistency stance, data delivery, observability tax) and includes tradeoffs, risks, and implementation boundaries.

---

## **Backend Architecture Spec**
**Product**: Multi-tenant scheduling platform with team workspaces, activity feeds, approvals, and webhooks.
**Constraints**: Regional data residency, audit trails, customer-defined automation (future), REST APIs + relational DB (existing), inconsistent background jobs/eventing.
**Governing Route**: `rt_backend_architecture_spec`
**Supporting Skills**:
- `back-end-systems-architect` (authority model, consistency, observability)
- `api-reliability-security-expert` (webhooks, async jobs, resilience)
- `back-end-aware-planner` (feasibility, permissions, data boundaries)

---

## **1. Core Services & Boundaries**
### **Service Model**
| Service               | Responsibility                                                                 | Data Boundary                          | Tenancy Model               |
|-----------------------|-------------------------------------------------------------------------------|----------------------------------------|-----------------------------|
| **Tenant Service**    | Tenant metadata, regional residency, billing, auth (OAuth2/OIDC).             | `tenants` table + regional replicas.  | Multi-tenant (shared).      |
| **Workspace Service** | Team workspaces, roles, permissions (RBAC).                                   | `workspaces`, `workspace_members`.    | Tenant-isolated.            |
| **Scheduling Service**| Core scheduling (events, attendees, conflicts, recurrence).                   | `events`, `attendees`, `recurrence`.  | Tenant-isolated.            |
| **Activity Service**  | Cursor-based activity feeds (events, approvals, comments).                    | `activity_logs` (append-only).        | Tenant-isolated.            |
| **Approval Service**  | Approval workflows (requests, transitions, notifications).                    | `approval_requests`, `transitions`.   | Tenant-isolated.            |
| **Webhook Service**   | Outbound webhooks (retries, idempotency, payload signing).                    | `webhook_subscriptions`, `deliveries`.| Tenant-isolated.            |
| **Audit Service**     | Immutable audit trails (events, actors, timestamps).                          | `audit_logs` (append-only).           | Tenant-isolated.            |
| **Automation Service**| *Future*: Customer-defined rules (e.g., "auto-approve if <X attendees").       | `automation_rules`.                   | Tenant-isolated.            |
| **Job Service**       | Background jobs (retries, circuit breakers, observability).                   | `jobs`, `job_events`.                 | Multi-tenant (shared).      |

**Tradeoffs**:
- **Preserved**: Clear ownership boundaries, regional data residency, audit immutability.
- **Sacrificed**: Cross-service joins (e.g., "list events + approvals") require client-side composition or API aggregation.

---

## **2. Data Boundaries & Residency**
### **Regional Data Residency**
- **Tenant Service**: Replicates tenant metadata to all regions (read-only replicas).
- **Workspace/Scheduling Services**: Deployed per-region with tenant-isolated schemas.
  - *Example*: EU tenants → `eu_scheduling.events`, US tenants → `us_scheduling.events`.
- **Audit/Activity Logs**: Append-only tables replicated to tenant’s home region (eventual consistency).
- **Webhook Service**: Deliveries stored in tenant’s home region; retries use regional job queues.

**Tradeoffs**:
- **Preserved**: Compliance with regional laws (e.g., GDPR), low-latency reads.
- **Sacrificed**: Cross-region queries (e.g., "global admin view") require federation or API aggregation.

---

## **3. Contracts & APIs**
### **Key API Contracts**
#### **Scheduling Service**
- **`POST /events`**: Create event (idempotency-key header for retries).
  - *Request*: `{ "workspace_id": "ws_123", "title": "Sync", "start": "2024-01-01T09:00:00Z", "attendees": ["user_1"] }`
  - *Response*: `201 Created` + `{ "event_id": "evt_456", "status": "confirmed" }`
- **`GET /events?cursor=abc123&limit=50`**: Cursor-based pagination (activity feed).
  - *Response*: `{ "data": [...], "next_cursor": "def456" }`

#### **Approval Service**
- **`POST /approvals/requests`**: Submit approval request.
  - *Request*: `{ "event_id": "evt_456", "requester": "user_1", "approver": "user_2" }`
  - *Response*: `202 Accepted` + `{ "approval_id": "appr_789", "status": "pending" }`
- **`PATCH /approvals/{id}`**: Transition state (e.g., `approve`/`reject`).
  - *Request*: `{ "action": "approve", "actor": "user_2" }`
  - *Response*: `200 OK` + `{ "status": "approved" }`

#### **Webhook Service**
- **`POST /webhooks/subscriptions`**: Register webhook.
  - *Request*: `{ "workspace_id": "ws_123", "url": "https://customer.com/webhook", "events": ["event.created", "approval.approved"] }`
  - *Response*: `201 Created` + `{ "subscription_id": "sub_101" }`
- **`GET /webhooks/deliveries?cursor=xyz789`**: List deliveries (retries, failures).
  - *Response*: `{ "data": [...], "next_cursor": "uvw012" }`

**Tradeoffs**:
- **Preserved**: Idempotency, cursor-based pagination, explicit state transitions.
- **Sacrificed**: RESTful purity (e.g., `PATCH` for approvals instead of `PUT`).

---

## **4. Async Jobs & Eventing**
### **Job Service**
- **Responsibilities**:
  - Retries with exponential backoff + jitter.
  - Circuit breakers for failing endpoints.
  - Observability (traces, metrics, logs).
- **Job Types**:
  - `webhook_delivery`: Send payload to customer URL.
  - `activity_feed_update`: Append event to cursor-based feed.
  - `audit_log_write`: Immutable audit trail entry.
  - `automation_rule_execute`: *Future*: Run customer-defined rules.

**Tradeoffs**:
- **Preserved**: Reliability, observability, scalability.
- **Sacrificed**: Latency (jobs may take seconds/minutes to complete).

### **Eventing Model**
- **Event Bus**: Pub/sub (e.g., Kafka, AWS EventBridge) for cross-service events.
  - *Example Events*:
    - `event.created` → Activity Service, Webhook Service.
    - `approval.approved` → Scheduling Service, Webhook Service.
- **Event Payload**:
  ```json
  {
    "event_id": "evt_123",
    "type": "event.created",
    "timestamp": "2024-01-01T09:00:00Z",
    "tenant_id": "tenant_456",
    "workspace_id": "ws_789",
    "data": { "event_id": "evt_123", "title": "Sync" }
  }
  ```

**Tradeoffs**:
- **Preserved**: Decoupling, scalability, replayability.
- **Sacrificed**: Eventual consistency (e.g., webhook delivery may lag).

---

## **5. Operational Concerns**
### **Observability**
- **Metrics**:
  - `webhook_delivery_latency`: P99 latency per tenant.
  - `job_failure_rate`: Retries/failures per job type.
  - `approval_transition_time`: Time from `pending` to `approved`/`rejected`.
- **Traces**: Distributed tracing (e.g., OpenTelemetry) for cross-service flows.
- **Logs**: Structured logs (JSON) with `tenant_id`, `workspace_id`, `trace_id`.

### **Security**
- **Webhooks**:
  - Payload signing (HMAC-SHA256) with tenant-specific secret.
  - Idempotency keys (UUID) to prevent duplicate deliveries.
- **Audit Logs**:
  - Immutable (append-only) with cryptographic hashes (e.g., Merkle trees).
  - Readable only by tenant admins or compliance roles.

### **Resilience**
- **Webhooks**:
  - Retry policy: 5 attempts (1s, 5s, 30s, 5m, 30m).
  - Circuit breaker: Open after 3 consecutive failures.
- **Jobs**:
  - Dead-letter queue (DLQ) for failed jobs (manual review).

**Tradeoffs**:
- **Preserved**: Security, compliance, reliability.
- **Sacrificed**: Complexity (e.g., Merkle trees for audit logs).

---

## **6. Risks & Safer Paths**
### **Risks**
1. **Cross-Region Latency**: Activity feeds/audit logs may lag if replicated across regions.
   - *Mitigation*: Use regional event buses + eventual consistency.
2. **Webhook Overload**: Customer endpoints may throttle or fail.
   - *Mitigation*: Rate limiting (e.g., 100 deliveries/minute/tenant) + circuit breakers.
3. **Automation Complexity**: *Future* customer-defined rules may introduce loops or conflicts.
   - *Mitigation*: Sandboxed execution (e.g., WASM) + rule validation.

### **Safer Paths**
1. **Start with Regional Event Buses**: Avoid global event bus until cross-region traffic justifies it.
2. **Use Managed Job Queues**: (e.g., AWS SQS, GCP Cloud Tasks) instead of custom job service.
3. **Implement Webhook Circuit Breakers Early**: Prevent cascading failures.

---

## **7. Implementation Boundaries**
### **Phase 1 (MVP)**
- **Services**: Tenant, Workspace, Scheduling, Activity, Approval, Webhook, Audit.
- **Data**: Regional schemas for tenant-isolated tables.
- **Jobs**: Webhook deliveries, activity feed updates, audit logs.
- **Observability**: Metrics (latency, failure rates), structured logs.

### **Phase 2 (Automation)**
- **Services**: Add Automation Service.
- **Data**: `automation_rules` table (tenant-isolated).
- **Jobs**: Rule execution (sandboxed).

---

## **8. Required Decisions (Contract Index)**
| Decision ID               | Value                                                                 |
|---------------------------|-----------------------------------------------------------------------|
| **authority_model**       | Tenant Service owns tenant metadata; Workspace Service owns permissions. |
| **consistency_stance**    | Eventual consistency for activity feeds/audit logs; strong for scheduling. |
| **data_delivery**         | Cursor-based pagination (activity feeds/webhooks); idempotent APIs.  |
| **observability_tax**     | Distributed tracing, structured logs, metrics (latency, failure rates). |
| **resilience_strategy**   | Retries (exponential backoff), circuit breakers, DLQ for jobs.        |

---

## **9. Evidence Classes Cited**
- **Regional Data Residency**: `tenants` table + regional schemas (e.g., `eu_scheduling.events`).
- **Webhook Reliability**: RFC 9457 (Problem Details), idempotency-key header, circuit breakers.
- **Audit Immutability**: Append-only `audit_logs` table + cryptographic hashes.
- **Activity Feeds**: Cursor-based pagination (`next_cursor` in responses).

---

## **10. Next Steps**
1. **Federate Tenant Metadata**: Replicate `tenants` table to all regions.
2. **Deploy Regional Services**: Workspace, Scheduling, Activity, Approval, Webhook, Audit.
3. **Implement Job Service**: Retries, circuit breakers, observability.
4. **Add Webhook Circuit Breakers**: Prevent cascading failures.
5. **Instrument Observability**: Metrics, traces, logs.