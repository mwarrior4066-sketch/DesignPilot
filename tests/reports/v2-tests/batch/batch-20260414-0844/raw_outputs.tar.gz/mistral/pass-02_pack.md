Here’s a **component spec** for the **Split Button** following production-grade accessibility, interaction, and implementation requirements.

---

# **Split Button Component Spec**
**Component ID**: `SplitButton`
**Purpose**: A compound button with a primary action (`Save`) and a dropdown trigger for secondary actions (`Save as draft`, `Save and close`). Designed for keyboard, touch, and screen-reader support.

---

## **1. Component Boundary**
- **Primary action button**: Triggers the default action (`Save`).
- **Dropdown trigger button**: Opens a menu of secondary actions.
- **Menu**: Contains secondary actions (`Save as draft`, `Save and close`).
- **Container**: Groups the two buttons into a single interactive unit.

---

## **2. States & Variants**
| State               | Primary Button | Dropdown Trigger | Menu          | Notes                                                                 |
|---------------------|----------------|------------------|---------------|-----------------------------------------------------------------------|
| **Default**         | Enabled        | Enabled          | Closed        | Ready for interaction.                                                |
| **Hover**           | Hover          | Hover            | -             | Visual feedback on both buttons.                                      |
| **Focus**           | Focus          | Focus            | -             | Keyboard focus ring on the last-focused button.                       |
| **Active**          | Active         | Active           | -             | Pressed state for both buttons.                                       |
| **Disabled**        | Disabled       | Disabled         | -             | Both buttons disabled (e.g., no changes to save).                     |
| **Loading**         | Loading        | Disabled         | Closed        | Primary action shows spinner; dropdown disabled.                      |
| **Menu Open**       | Enabled        | Active           | Open          | Dropdown trigger shows active state; menu visible.                    |
| **Menu Hover**      | -              | -                | Hover (item)  | Highlight on menu items.                                              |
| **Menu Focus**      | -              | -                | Focus (item)  | Keyboard navigation in menu.                                          |

---

## **3. Accessibility & Interaction Behavior**
### **Keyboard Support**
| Key               | Behavior                                                                 |
|-------------------|--------------------------------------------------------------------------|
| **Tab**           | Moves focus to the **primary button** (first) or **dropdown trigger** (second). |
| **Space/Enter**   | Triggers the focused button (primary action or dropdown).                |
| **↓ (Down Arrow)**| Opens the dropdown menu (if focus is on dropdown trigger).               |
| **↑/↓ (Arrows)**  | Navigates menu items (when menu is open).                                |
| **Esc**           | Closes the menu (if open).                                               |
| **Tab (in menu)** | Closes the menu and moves focus to the next focusable element.           |

### **Screen Reader Support**
- **Primary button**: `"Save, button"` (default action).
- **Dropdown trigger**: `"Save options, menu button"` (announces as a menu button).
- **Menu items**: `"Save as draft, menu item"` / `"Save and close, menu item"`.
- **Expanded state**: Dropdown trigger announces `"expanded"` or `"collapsed"`.
- **Loading state**: Primary button announces `"Saving, loading"` (spinner + aria-live).

### **Touch Targets (Mobile)**
- Minimum **48×48px** touch target for both buttons.
- **Primary button**: Full-width (e.g., 60% of container).
- **Dropdown trigger**: Remaining width (e.g., 40% of container).
- **Menu items**: Minimum **48px height** with sufficient padding.

---

## **4. Implementation Boundary**
### **HTML Structure (Semantic)**
```html
<div class="split-button" role="group" aria-label="Save options">
  <!-- Primary Action -->
  <button
    type="button"
    class="split-button__primary"
    aria-disabled="false"
    aria-busy="false"
  >
    <span>Save</span>
    <span class="visually-hidden">(default action)</span>
  </button>

  <!-- Dropdown Trigger -->
  <button
    type="button"
    class="split-button__dropdown"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-label="Save options"
  >
    <span class="icon-chevron-down" aria-hidden="true"></span>
  </button>

  <!-- Menu (hidden by default) -->
  <ul class="split-button__menu" role="menu" aria-hidden="true">
    <li role="none">
      <button role="menuitem" type="button">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem" type="button">Save and close</button>
    </li>
  </ul>
</div>
```

### **CSS/Styling Rules**
- **Container**: `display: inline-flex` (ensures buttons sit side-by-side).
- **Primary button**: Full-width flex-grow, rounded left corners.
- **Dropdown trigger**: Fixed width, rounded right corners, chevron icon.
- **Menu**: Absolute positioning below the button group, `z-index` above other content.
- **Focus styles**: Visible outline (or custom focus ring) for keyboard users.
- **Disabled state**: `opacity: 0.5`, `pointer-events: none`.

### **JavaScript Behavior**
- **Dropdown toggle**: Clicking the dropdown button toggles `aria-expanded`.
- **Menu navigation**: Arrow keys cycle through menu items; `Enter` selects.
- **Loading state**: Primary button shows spinner, `aria-busy="true"`, dropdown disabled.
- **Close on blur**: Menu closes when focus leaves the component.

---

## **5. Validation & Edge Cases**
### **Required Tests**
| Test Case                          | Expected Behavior                                                                 |
|------------------------------------|-----------------------------------------------------------------------------------|
| **Keyboard navigation**            | Tab order: primary → dropdown → menu items.                                      |
| **Screen reader announcement**     | Correctly announces button roles, states, and menu items.                        |
| **Touch target size**              | Buttons and menu items meet 48×48px minimum.                                     |
| **Disabled state**                 | Both buttons disabled; no interaction.                                           |
| **Loading state**                  | Primary button shows spinner; dropdown disabled.                                 |
| **Menu closes on Esc**             | Menu collapses; focus returns to dropdown trigger.                               |
| **Menu closes on outside click**   | Menu collapses when clicking outside the component.                              |

### **Error States**
- **No actions available**: Disable both buttons (e.g., no changes to save).
- **Network error**: Show error state on primary button (e.g., "Retry").
- **Menu item disabled**: Gray out and `aria-disabled="true"` (e.g., "Save and close" unavailable).

---

## **6. Design Tokens (Optional)**
| Token                     | Purpose                                  | Example Value       |
|---------------------------|------------------------------------------|---------------------|
| `--split-button-bg`       | Primary button background                | `#0066cc`           |
| `--split-button-text`     | Primary button text color                | `#ffffff`           |
| `--split-button-hover`    | Hover state                              | `#0052a3`           |
| `--split-button-disabled` | Disabled state                           | `#cccccc`           |
| `--split-button-border`   | Border radius (left/right)               | `4px`               |
| `--split-button-spacing`  | Gap between primary and dropdown buttons | `0` (seamless)      |

---

## **7. Open Questions**
1. Should the dropdown menu **align left or right** with the button group?
   - *Default*: Right-aligned (prevents overflow on small screens).
2. Should the **primary action** be triggered on **mouse down** or **mouse up**?
   - *Default*: Mouse up (standard button behavior).
3. Should the **menu close** when a secondary action is selected?
   - *Default*: Yes (immediate feedback).

---

## **8. Tradeoffs**
| Preserved                          | Sacrificed                          |
|------------------------------------|-------------------------------------|
| Clear primary/secondary separation | Slightly more complex than a single button. |
| Full keyboard/touch support        | Requires JavaScript for menu behavior. |
| Mobile-friendly touch targets      | Takes up more horizontal space.     |

---

## **9. Next Steps**
- [ ] Implement HTML/CSS/JS prototype.
- [ ] Test with screen readers (VoiceOver, NVDA, JAWS).
- [ ] Validate touch targets on mobile devices.
- [ ] Add to design system documentation.

---