Here’s a **type system recommendation** for your fintech product, balancing **modern trustworthiness**, **hierarchy**, **data readability**, and **cross-platform consistency** (marketing site, web app dashboard, mobile). The system prioritizes:
- **Clarity** for financial data (tables, charts, forms).
- **Authority** without stiffness (warm but precise).
- **Variable font flexibility** for hierarchy and responsiveness.
- **Licensing safety** (open-source or permissive).

---

### **Core Type System**
#### **1. Primary Typeface: *Inter Variable***
**Why?**
- **Designed for UI/data**: Optimized for screens, with tabular figures (monospaced numbers) and clear financial symbols (e.g., `$`, `%`).
- **Variable font**: Supports `wght` (100–900) and `opsz` (optical sizing) for hierarchy and readability at all sizes.
- **Trustworthy neutrality**: Clean but not sterile; avoids "tech bro" or "banking cliché" vibes.
- **Open-source**: Free for commercial use (SIL Open Font License).

**Roles:**
| Role               | Weight (`wght`) | Optical Size (`opsz`) | Use Case                          |
|--------------------|-----------------|-----------------------|-----------------------------------|
| **Display**        | 700–900         | 48–72pt               | Marketing headlines, app titles   |
| **Heading 1**      | 600             | 24–48pt               | Section titles, dashboard KPIs    |
| **Heading 2**      | 500             | 18–24pt               | Subsections, card titles          |
| **Body**           | 400             | 12–18pt               | Paragraphs, form labels           |
| **Data/Table**     | 400             | 10–12pt               | Financial tables, charts          |
| **Caption**        | 300             | 10–12pt               | Labels, footnotes, tooltips       |
| **UI Controls**    | 500             | 12–14pt               | Buttons, tabs, input fields       |

**Key Features:**
- **Tabular figures**: Numbers align vertically in tables (critical for financial data).
- **OpenType features**: Enable `tnum` (tabular numbers), `zero` (slashed zero), and `frac` (fractions).
- **Dark mode**: Test contrast ratios (WCAG AA/AAA) with your color palette.

---

#### **2. Secondary Typeface: *IBM Plex Sans Variable***
**Why?**
- **Fallback for branding**: Slightly more character than Inter, with a warmer tone for marketing copy.
- **Variable font**: Supports `wght` (100–700) and `wdth` (width) for tighter data tables.
- **Multilingual**: Supports Latin, Cyrillic, Greek, and more (future-proof for global fintech).
- **Open-source**: SIL Open Font License.

**Roles (limited use):**
- **Marketing headlines**: Where a touch of personality is needed (e.g., "Your money, simplified").
- **Long-form content**: Blog posts, legal disclaimers (better readability than Inter at small sizes).
- **Mobile app accents**: For buttons or CTAs where Inter feels too neutral.

---

### **3. Monospace: *JetBrains Mono***
**Why?**
- **Code/data clarity**: Essential for transaction IDs, API snippets, or developer-facing tools.
- **Readable at small sizes**: Clear distinction between `0/O`, `1/l/I`.
- **Open-source**: Apache 2.0 License.

**Roles:**
- **Transaction IDs**: `TXN-1a2b3c4d`
- **Code snippets**: API examples, developer docs.
- **Input fields**: Where monospace improves alignment (e.g., credit card numbers).

---

### **Type Scale & Hierarchy**
Use a **modular scale** (e.g., 1.25 ratio) for consistency:
- **Base size**: 16px (body text on web/mobile).
- **Scale**:
  - 12px (captions) → 16px (body) → 20px (H3) → 25px (H2) → 31px (H1) → 39px (display).
- **Mobile**: Reduce base size to 14px, but keep the same ratio.

**Example Hierarchy (Dashboard):**
```markdown
# Account Overview (H1: Inter 600, 31px)
## Your Balance (H2: Inter 500, 25px)
$12,345.67 (Data: Inter 400, 20px, tabular figures)
*Updated 5 mins ago* (Caption: Inter 300, 12px)
```

---

### **Implementation Notes**
#### **1. Variable Font Setup**
- **Web**:
  ```css
  @font-face {
    font-family: 'Inter';
    src: url('Inter.var.woff2') format('woff2-variations');
    font-weight: 100 900;
    font-style: oblique 0deg 10deg;
    font-display: swap;
  }
  body { font-variation-settings: "wght" 400, "opsz" 16; }
  .data-table { font-variation-settings: "wght" 400, "opsz" 12, "tnum" 1; }
  ```
- **Mobile**: Use `UIFont` (iOS) or `Typeface` (Android) with weight/optical size axes.

#### **2. Fallback Stack**
```css
font-family: 'Inter Variable', -apple-system, 'IBM Plex Sans', 'Helvetica Neue', sans-serif;
```

#### **3. Accessibility**
- **Contrast**: Ensure body text meets **WCAG AA** (4.5:1) and headings meet **AAA** (7:1).
- **Line height**: 1.5× for body text, 1.2× for data tables.
- **Letter spacing**: Slightly increase for all-caps (e.g., `0.05em`).

#### **4. Dark Mode**
- Test with your palette, but avoid pure white text on dark backgrounds (use `#F0F0F0` for better readability).
- Reduce `opsz` slightly in dark mode to compensate for perceived weight.

---

### **Pairing Examples**
| Context          | Primary Typeface       | Secondary Typeface       | Notes                                  |
|------------------|------------------------|--------------------------|----------------------------------------|
| Marketing site   | Inter (Display/Headings) | IBM Plex Sans (Body)     | Warmer tone for storytelling.          |
| Web app dashboard | Inter (All)            | —                        | Consistency for data-heavy screens.    |
| Mobile app       | Inter (All)            | IBM Plex Sans (CTAs)     | Buttons can use IBM Plex for emphasis. |
| PDF reports      | Inter (Body/Tables)    | IBM Plex Sans (Headings) | Better print rendering.                |

---

### **Why Not Other Fonts?**
| Font               | Rejected Because...                          |
|--------------------|---------------------------------------------|
| **Helvetica**      | Overused in finance; lacks tabular figures. |
| **Roboto**         | Too generic; weak hierarchy.                |
| **SF Pro**         | Apple-only; licensing restrictions.         |
| **GT Walsheim**    | Paid license; not open-source.              |
| **Manrope**        | Lacks optical sizing; weaker data support.  |

---

### **Adoption Sequence**
1. **Start with Inter Variable** for all UI/data contexts.
2. **Add IBM Plex Sans** for marketing/long-form content.
3. **Test JetBrains Mono** in transactional contexts.
4. **Audit hierarchy** with real financial data (e.g., tables, charts).
5. **Refine optical sizes** for mobile vs. desktop.

---

### **Tradeoffs**
| Preserved                          | Sacrificed                          |
|------------------------------------|-------------------------------------|
| Data clarity (tabular figures)     | Some brand personality (Inter is neutral) |
| Cross-platform consistency         | Slightly less "premium" feel than paid fonts (e.g., GT Walsheim) |
| Open-source licensing              | Limited decorative options          |

---

### **Next Steps**
1. **Prototype**: Test in Figma/CodePen with real financial data.
2. **Contrast check**: Use [APCA Contrast Calculator](https://www.myndex.com/APCA/).
3. **Variable font tuning**: Adjust `opsz` for your smallest (mobile) and largest (marketing) use cases.
4. **Fallback testing**: Disable variable fonts to ensure graceful degradation.