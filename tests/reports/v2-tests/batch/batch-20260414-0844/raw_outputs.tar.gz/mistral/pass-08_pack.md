Here’s a concise, production-level accessibility audit of the mobile app following **`rt_accessibility_feedback_audit`** (governing route) with **`ui-system-expert`** and **`motion-interaction-expert`** as supporting skills.

---

### **Barrier Audit**
*(Severity: **Critical** = blocks users; **High** = major friction; **Medium** = degrades experience)*

| **Barrier**                     | **WCAG Rule**               | **Severity** | **Repair Priority** | **Verification Method**                     |
|----------------------------------|-----------------------------|--------------|---------------------|---------------------------------------------|
| Bottom nav: icon-only buttons   | 2.5.3 Label in Name (A)     | Critical     | 1                   | Screen reader + manual label check          |
| Form inputs: placeholder labels | 3.3.2 Labels or Instructions (A) | Critical | 1                   | Screen reader + visual label presence       |
| Error messages: red text only   | 1.4.1 Use of Color (A)      | High         | 2                   | Screen reader + color-blind simulation      |
| Loading spinner: no announcement | 4.1.3 Status Messages (AA)  | Critical     | 1                   | Screen reader + manual state announcement   |

---

### **Repair Plan**
*(Preserved: existing visual hierarchy, spacing, and interaction patterns.
Sacrificed: placeholder text as sole labels, color-only feedback, and silent loading states.)*

#### **1. Bottom Navigation Bar**
**Problem:** Icon-only buttons fail **Label in Name** (WCAG 2.5.3). Screen readers announce the icon filename (e.g., "home.svg") or nothing.
**Fix:**
- Add **visible text labels** under icons (preserves visual hierarchy; adds ~10px height).
- **OR** use **`aria-label`** (e.g., `aria-label="Home"`) if space is constrained (sacrifices visual labels for screen readers).
- **Tradeoff:** Visible labels improve usability for all users but may require layout adjustments.

**Code Example:**
```html
<!-- Visible labels (preferred) -->
<button>
  <svg aria-hidden="true"><path d="..."/></svg>
  <span>Home</span>
</button>

<!-- OR aria-label (space-constrained) -->
<button aria-label="Home">
  <svg aria-hidden="true"><path d="..."/></svg>
</button>
```

---

#### **2. Form Inputs**
**Problem:** Placeholder text disappears on focus, violating **Labels or Instructions** (WCAG 3.3.2). Screen readers may ignore placeholders.
**Fix:**
- Replace placeholders with **visible floating labels** (e.g., Material Design) or **static labels**.
- **Tradeoff:** Floating labels add complexity but preserve context; static labels are simpler but may take more space.

**Code Example:**
```html
<!-- Floating label (Material Design) -->
<div class="floating-label">
  <input id="email" type="text" aria-labelledby="email-label">
  <label id="email-label" for="email">Email</label>
</div>

<!-- OR static label -->
<label for="email">Email</label>
<input id="email" type="text">
```

---

#### **3. Error Messages**
**Problem:** Red text only fails **Use of Color** (WCAG 1.4.1). Color-blind users may miss errors.
**Fix:**
- Add **icon + text** (e.g., ❌ + "Invalid email").
- Use **`aria-live="polite"`** to announce errors dynamically.
- **Tradeoff:** Icons add visual noise but improve clarity for all users.

**Code Example:**
```html
<div role="alert" aria-live="polite" class="error-message">
  <svg aria-hidden="true" focusable="false"><path d="M12 2L2 22h20L12 2z"/></svg>
  <span>Invalid email</span>
</div>
```

---

#### **4. Loading Spinner**
**Problem:** No screen reader announcement violates **Status Messages** (WCAG 4.1.3).
**Fix:**
- Add **`aria-live="polite"`** to announce loading state.
- Use **`aria-busy="true"`** on the parent container.
- **Tradeoff:** Announcements may interrupt workflow but prevent confusion.

**Code Example:**
```html
<div aria-live="polite" aria-busy="true">
  <span class="sr-only">Loading...</span>
  <div class="spinner" role="status"></div>
</div>
```

---

### **Verification Method**
1. **Screen Reader Test:** Navigate with VoiceOver (iOS) or TalkBack (Android). Confirm labels, errors, and loading states are announced.
2. **Color-Blind Simulation:** Use tools like [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/) to verify error visibility.
3. **Manual Check:** Ensure all fixes are visible and functional without assistive tech.

---

### **Next Steps**
1. **Implement fixes** in order of priority (1–2).
2. **Test with users** who rely on screen readers.
3. **Document** the accessibility improvements in the app’s release notes.

**Evidence Classes Cited:**
- WCAG 2.1 rules (A/AA)
- Screen reader behavior (observed)
- Color contrast thresholds (APCA/WCAG)