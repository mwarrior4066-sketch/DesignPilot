Here is a component specification for the split button, detailing its structure, states, and accessibility behavior for both desktop and mobile contexts.

## Split Button Component Specification

This specification defines a `SplitButton` component, combining a primary action button with a dropdown trigger for secondary, related actions.

### 1. Component Boundary

The `SplitButton` comprises two distinct, interactive elements contained within a single logical component.

*   **Primary Action Button:**
    *   **Role:** Performs the main, most frequently used action (e.g., "Save").
    *   **Interaction:** Standard button behavior (click/tap).
    *   **Visual:** Typically fills the majority of the component width, clearly indicating its primary function.
*   **Dropdown Trigger Button:**
    *   **Role:** Toggles the visibility of a dropdown menu containing secondary, related actions (e.g., "Save as draft", "Save and close").
    *   **Interaction:** Click/tap to open/close the dropdown.
    *   **Visual:** A smaller segment adjacent to the primary action, often containing an icon (e.g., a caret).
*   **Dropdown Menu:**
    *   **Role:** Contains a list of secondary actions.
    *   **Interaction:** Standard menu item selection, closes on selection or outside click.
    *   **Visual:** Appears relative to the trigger, typically below or beside it.

**Relationship:** The two buttons form a single conceptual control, allowing a quick primary action while providing access to alternatives.

### 2. State Coverage

The `SplitButton` must support a range of visual and functional states for both its primary and trigger elements, as well as the overall component.

*   **Default/Enabled:** Both primary and trigger buttons are active and visually distinct.
*   **Hover/Focus:**
    *   **Primary Button:** Visual feedback when hovered or keyboard-focused.
    *   **Dropdown Trigger:** Visual feedback when hovered or keyboard-focused.
    *   **Dropdown Menu Items:** Visual feedback on individual menu items when hovered or keyboard-focused.
*   **Active/Pressed:**
    *   **Primary Button:** Visual feedback indicating it is currently being pressed.
    *   **Dropdown Trigger:** Visual feedback indicating it is currently being pressed, and the dropdown menu is open.
*   **Disabled:**
    *   **Primary Button Disabled:** The primary button is visually muted, non-interactive, and not tab-focusable.
    *   **Trigger Button Disabled:** The dropdown trigger is visually muted, non-interactive, and not tab-focusable.
    *   **Component Disabled (both disabled):** Both parts are disabled. The dropdown menu cannot be opened.
    *   **Tradeoff:** Disabling the primary button while the trigger remains active is a valid state if secondary actions are still possible, but it may cause confusion if the primary action's context also disables secondary options. If all actions are disabled, the entire component should be disabled.
*   **Loading:**
    *   **Primary Button Loading:** The primary button displays an inline loading indicator (e.g., spinner), and the primary action is temporarily non-interactive.
    *   **Component Loading (both loading):** A loading state applies to the entire component, often disabling both parts and showing an indicator.
    *   **Tradeoff:** It's generally safer to disable both elements during a loading state affecting the entire component's context to prevent unexpected intermediate actions.
*   **Dropdown Open:** The dropdown menu is visible and positioned correctly relative to the trigger.

### 3. Accessibility Behavior

Robust accessibility support is critical for keyboard, screen reader, and touch users.

*   **Keyboard Support:**
    *   `Tab` / `Shift+Tab`: Moves focus between the primary action button and the dropdown trigger button.
    *   `Space` / `Enter`:
        *   On Primary Button: Activates the primary action.
        *   On Dropdown Trigger: Toggles the dropdown menu open/closed.
    *   `Down Arrow` (when dropdown trigger focused and menu open): Moves focus to the first item in the dropdown menu.
    *   `Up Arrow` / `Down Arrow` (within dropdown menu): Navigates between menu items.
    *   `Esc`: Closes the dropdown menu if open, returning focus to the dropdown trigger.
*   **Screen Reader Support (ARIA):**
    *   **Primary Button:** Standard `role="button"`.
    *   **Dropdown Trigger:**
        *   `role="button"`
        *   `aria-haspopup="true"`: Indicates a popup menu is associated.
        *   `aria-expanded="true"` / `aria-expanded="false"`: Reflects the open/closed state of the dropdown menu.
        *   `aria-controls="[id_of_dropdown_menu]"`: Explicitly links the trigger to its controlled menu.
    *   **Dropdown Menu:**
        *   `role="menu"`
        *   Each item within the menu: `role="menuitem"`
*   **Focus Management:**
    *   When the dropdown opens, focus does not automatically move into the menu; it remains on the trigger. Users must press `Down Arrow` to enter the menu. This preserves expected ARIA menu patterns.
    *   When the dropdown closes (via selection, `Esc`, or outside click), focus returns to the dropdown trigger.
*   **Touch Targets (Mobile):**
    *   Both the Primary Action Button and the Dropdown Trigger Button must have a minimum interactive target size of **44x44 CSS pixels**. This may require increasing the visual padding or hit area for smaller elements, especially the dropdown trigger.
    *   **Tradeoff:** While the visual width of the trigger may be small to preserve space for the primary action, its effective touch target must still meet the 44x44px minimum for reliable mobile interaction.
*   **Contrast:** All text and interactive elements must meet WCAG 2.1 AA contrast requirements (4.5:1 for text, 3:1 for non-text components).
*   **Disabled State:** `aria-disabled="true"` must be applied to disabled buttons, preventing interaction and informing screen readers. Disabled elements must be removed from the tab order.

### 4. Implementation Boundary

This section outlines key considerations for front-end development handoff.

*   **HTML Structure:**
    *   A root container for the `SplitButton`.
    *   `<button>` element for the primary action.
    *   `<button>` element for the dropdown trigger.
    *   A `<div>` or `<nav>` element with `role="menu"` for the dropdown menu, containing child `<button>` or `<a>` elements with `role="menuitem"`.
*   **CSS Styling:**
    *   Layout for the two-part button (e.g., flexbox or grid).
    *   Visual states (default, hover, focus, active, disabled, loading).
    *   Dropdown menu positioning (absolute or fixed, ensuring it appears above other content).
    *   Ensuring touch target sizes are respected, possibly with invisible hit areas.
*   **JavaScript / React / Vue Logic:**
    *   **State Management:**
        *   `isDropdownOpen`: Boolean to control dropdown visibility.
        *   `isDisabledPrimary`: Boolean to control primary button disabled state.
        *   `isDisabledTrigger`: Boolean to control dropdown trigger disabled state.
        *   `isLoadingPrimary`: Boolean to control primary button loading state.
    *   **Event Handling:**
        *   Click handler for the primary action.
        *   Click handler for the dropdown trigger (to toggle `isDropdownOpen`).
        *   Click handlers for each dropdown menu item.
        *   Global click listener to close the dropdown when clicking outside.
        *   Keyboard event listeners for `Tab`, `Shift+Tab`, `Enter`, `Space`, `Esc`, and arrow keys (within the dropdown).
    *   **Dynamic ARIA attributes:** Ensure `aria-expanded` and `aria-controls` are updated dynamically based on `isDropdownOpen`.
    *   **Focus Trapping (Optional but Recommended for Menus):** For complex menus, consider basic focus trapping within the dropdown when open, though standard ARIA menu patterns often suffice.

---
[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: defined", "state_coverage: defined", "accessibility_behavior: defined", "implementation_boundary: defined"],
  "evidence_classes_cited": ["WCAG threshold", "ARIA role", "keyboard rule", "target-size threshold"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]