Here is a color system definition for your healthcare SaaS dashboard, designed to meet your requirements for status communication, dark mode support, data visualization, and WCAG AA accessibility.

## Healthcare SaaS Dashboard Color System Specification

This color system defines semantic roles for all colors, ensures robust status communication, supports dual light/dark mode presentation, and provides a distinct palette for data visualization while strictly adhering to WCAG AA contrast standards.

### 1. Semantic Roles

Colors are assigned specific semantic roles rather than arbitrary values to ensure consistency and meaning across the dashboard.

*   **Primary Accent**: Used for primary calls-to-action, key interactive elements, and brand presence. (e.g., a specific shade of blue/teal common in healthcare tech)
*   **Secondary Accent**: For secondary actions, selected states, and less prominent interactive elements.
*   **Success/Normal**: For positive status, completion, and successful operations.
*   **Warning**: For amber-level alerts, caution, and situations requiring attention but not immediate crisis.
*   **Critical**: For severe errors, critical alerts, and urgent issues requiring immediate intervention.
*   **Informative**: For neutral feedback, general information, and non-urgent notifications.
*   **Neutral Palette**: For backgrounds, surfaces, text, borders, and disabled states. This range supports both light and dark modes.
    *   **Background**: Main canvas color.
    *   **Surface**: Card backgrounds, panels, and elevated elements.
    *   **Text**: Primary, secondary, subtle (for hints/meta-data), and inverse.
    *   **Border/Divider**: For UI separation.

### 2. State Mapping and Status Communication

The core status requirements (`normal`, `warning`, `critical`) are mapped directly to dedicated semantic colors.

*   **Normal**: Mapped to the `Success` color.
    *   **Light Mode**: A clear, but not overly vibrant, green (e.g., `#28A745` or similar).
    *   **Dark Mode**: A slightly lighter, desaturated green to maintain visibility against dark backgrounds (e.g., `#6BBF56` or similar).
*   **Warning**: Mapped to the `Warning` color.
    *   **Light Mode**: A distinct amber/orange (e.g., `#FFC107` or similar).
    *   **Dark Mode**: A slightly brighter amber to ensure visibility (e.g., `#FFDA6A` or similar).
*   **Critical**: Mapped to the `Critical` color.
    *   **Light Mode**: A standard red (e.g., `#DC3545` or similar).
    *   **Dark Mode**: A slightly desaturated red that stands out without being harsh (e.g., `#E47983` or similar).

**Dark Mode Strategy**:
The system employs a reciprocal approach for dark mode. Light mode surfaces are typically dark text on light backgrounds with vibrant accents. Dark mode will reverse this, utilizing light text on dark backgrounds. Semantic colors (Success, Warning, Critical, Informative) will be adjusted to maintain their perceived intensity and contrast against the new background while preserving their core hue. This ensures **state_mapping** consistency across themes.

### 3. Contrast Boundary (WCAG AA)

All text, interactive elements, and meaningful graphical elements will meet or exceed WCAG AA contrast requirements.

*   **Text Contrast**:
    *   Normal text (14pt/18.66px and smaller): Minimum 4.5:1 contrast ratio against its background.
    *   Large text (18pt/24px and larger, or 14pt/18.66px bold and larger): Minimum 3:1 contrast ratio against its background.
*   **Non-Text Contrast**:
    *   User interface components (e.g., form input borders, toggle states) and graphical objects essential for understanding (e.g., chart lines, icons) will have a minimum 3:1 contrast ratio against adjacent colors.

**Verification Method**:
Automated tools will be used during design and development (e.g., Axe, Lighthouse, browser dev tools) alongside manual color contrast checkers to ensure all color pairs meet these thresholds in both light and dark modes.

### 4. Categorical Data Visualization Colors

A palette of 6 distinct categorical colors is provided for data visualization, designed for perceptual differentiation and accessibility. These are distinct from the status colors to avoid confusion.

*   **Categorical Color Palette (Example, final values will be fine-tuned for contrast)**:
    1.  **Teal**: Light Mode: `#008080`, Dark Mode: `#4DB8B8`
    2.  **Indigo**: Light Mode: `#4B0082`, Dark Mode: `#8D4DBC`
    3.  **Gold**: Light Mode: `#B8860B`, Dark Mode: `#E0C25A`
    4.  **Magenta**: Light Mode: `#8B008B`, Dark Mode: `#C459C4`
    5.  **Forest Green**: Light Mode: `#228B22`, Dark Mode: `#6BB26B`
    6.  **Slate Blue**: Light Mode: `#6A5ACD`, Dark Mode: `#A096E7`

These colors are chosen to be perceptually distinct even for users with common forms of color blindness. Their dark mode variants are carefully lightened to maintain similar perceived contrast against dark backgrounds. This ensures **density_or_navigation_decision** in chart interpretation is not hindered by color choice.

### 5. Migration Strategy

Given this is for defining a new system, the **migration_strategy** focuses on principled adoption rather than remediation of existing color debt.

*   **Phased Rollout**: Implement the new color system incrementally, starting with core UI components and status indicators, then extending to data visualization.
*   **Documentation and Training**: Create comprehensive documentation for designers and developers, including usage guidelines, do's and don'ts, and examples for both light and dark modes. Provide training sessions.
*   **Automated Linting**: Integrate color token usage into design system linting and code reviews to ensure strict adherence to the new palette and semantic roles.
*   **Legacy Avoidance**: Any existing visual elements will either be updated to the new system or explicitly flagged for deprecation, rejecting any destructive shortcuts that would compromise the new system's integrity.

---
[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "standard",
  "decisions_committed": ["semantic_roles: defined", "state_mapping: defined for normal, warning, critical, and dark mode", "contrast_boundary: WCAG AA for text and non-text", "migration_strategy: principled adoption for new system"],
  "evidence_classes_cited": ["WCAG threshold", "dark-mode fallback"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]