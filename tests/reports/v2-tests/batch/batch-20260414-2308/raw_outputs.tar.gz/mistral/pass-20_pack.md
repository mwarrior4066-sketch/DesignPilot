Here’s a **backend architecture spec** for your multi-tenant scheduling platform, structured to address scalability, consistency, security, and extensibility. The spec follows the **contract decision index** for `backend_architecture_spec` (authority_model, consistency_stance, data_delivery, observability_tax) and includes tradeoffs, rationale, and implementation boundaries.

---

## **Backend Architecture Spec: Multi-Tenant Scheduling Platform**
**Governing Route**: `rt_backend_systems_architecture`
**Supporting Skills**: `api-reliability-security-expert`, `back-end-aware-planner`, `ux-research-expert`
**Task Weight**: `compound` (architecture-sensitive, multi-constraint)

---

### **1. Authority Model**
**Decision**: *Centralized tenant isolation with scoped permissions*
**Rationale**:
- Multi-tenancy requires strict isolation to prevent data leakage. A centralized model (e.g., `tenant_id` on all records) simplifies auditing and enforcement.
- **Tradeoff**: Centralized authority adds latency for cross-tenant queries (e.g., admin dashboards), but this is acceptable for 99% of use cases. For rare cross-tenant needs (e.g., enterprise rollups), use a dedicated "super-tenant" with explicit opt-in.

**Implementation**:
- **Tenant Context**: Inject `tenant_id` into every request via JWT claims or API gateway headers. Reject requests without a valid tenant.
- **Permissions**: Use a role-based access control (RBAC) system with tenant-scoped roles (e.g., `tenant:admin`, `tenant:member`). Deny by default.
- **Data Partitioning**:
  - *Postgres*: Schema-per-tenant (for strict isolation) or row-level security (RLS) with `tenant_id` columns.
  - *NoSQL*: Prefix keys with `tenant_id` (e.g., `tenant_123:schedule_456`).
- **API Gateway**: Enforce tenant routing and rate limiting at the edge (e.g., Kong, AWS API Gateway).

---

### **2. Consistency Stance**
**Decision**: *Strong consistency for scheduling core; eventual consistency for activity feeds and webhooks*
**Rationale**:
- **Scheduling Core** (bookings, conflicts, approvals): Requires linearizability to avoid double-booking or stale state. Use database transactions (Postgres `SERIALIZABLE` or `REPEATABLE READ`).
- **Activity Feeds**: Cursor-based pagination tolerates eventual consistency. Use a log-based architecture (e.g., Kafka) to stream events to a read-optimized store (e.g., Elasticsearch or Postgres with materialized views).
- **Webhooks**: At-least-once delivery with idempotency keys. Retry failed webhooks with exponential backoff.
- **Tradeoff**: Eventual consistency for feeds/webhooks reduces latency but requires clients to handle duplicates (e.g., via idempotency keys).

**Implementation**:
- **Scheduling Core**:
  - Postgres with `SERIALIZABLE` isolation for critical paths (e.g., booking a slot).
  - Optimistic concurrency control (OCC) for high-contention resources (e.g., popular time slots).
- **Activity Feeds**:
  - Write events to Kafka (partitioned by `tenant_id`).
  - Consume events into a read-optimized store (e.g., Elasticsearch for full-text search, Postgres for structured queries).
  - Cursor-based pagination: Use `created_at` + `event_id` as the cursor.
- **Webhooks**:
  - Store outbound webhook payloads in a `webhook_deliveries` table with status (`pending`, `delivered`, `failed`).
  - Use a background worker (e.g., Sidekiq, Celery) to retry failed deliveries with exponential backoff.
  - Idempotency: Require clients to include an `Idempotency-Key` header.

---

### **3. Data Delivery**
**Decision**: *Hybrid sync/async model with real-time updates for critical paths*
**Rationale**:
- **Sync**: REST/GraphQL for CRUD operations (e.g., creating a booking, approving a request).
- **Async**: WebSockets (e.g., Socket.io) or Server-Sent Events (SSE) for real-time updates (e.g., activity feed, approval notifications).
- **Webhooks**: Push events to customer systems (e.g., Slack, CRM) via HTTP callbacks.
- **Tradeoff**: WebSockets add complexity but reduce polling latency for real-time features. SSE is simpler but lacks bidirectional communication.

**Implementation**:
- **REST/GraphQL**:
  - Use cursor-based pagination for lists (e.g., `/bookings?cursor=abc123`).
  - Support `Prefer: return=minimal` headers for lightweight responses.
- **Real-Time Updates**:
  - WebSockets: Broadcast events to subscribed clients (e.g., `tenant_123:activity_feed`).
  - SSE: Fallback for clients that don’t support WebSockets (e.g., `/events?stream=activity_feed`).
- **Webhooks**:
  - Allow tenants to register webhook URLs with optional filters (e.g., `event_type=booking_created`).
  - Sign payloads with HMAC-SHA256 (secret per tenant).
  - Support retry policies (e.g., 5 attempts over 24 hours).

---

### **4. Observability Tax**
**Decision**: *Structured logging, distributed tracing, and tenant-scoped metrics*
**Rationale**:
- Multi-tenancy requires per-tenant observability to debug issues without exposing other tenants’ data.
- **Tradeoff**: Observability adds overhead (e.g., 10-20% latency for tracing), but this is necessary for production reliability.

**Implementation**:
- **Logging**:
  - Structured logs (JSON) with `tenant_id`, `user_id`, `request_id`, and `trace_id`.
  - Log retention: 30 days for raw logs, 1 year for aggregated metrics.
- **Tracing**:
  - Distributed tracing (e.g., OpenTelemetry) with `tenant_id` as a resource attribute.
  - Sample 100% of requests for tenants with active issues.
- **Metrics**:
  - Tenant-scoped metrics (e.g., `bookings_created{tenant_id="123"}`).
  - Alerts for anomalies (e.g., `booking_failure_rate > 5%` for a tenant).
- **Error Tracking**:
  - Capture errors with `tenant_id` and `user_id` (e.g., Sentry).
  - Group errors by tenant to prioritize fixes.

---

### **5. Team Workspaces**
**Decision**: *Hierarchical teams with nested permissions*
**Rationale**:
- Teams need to share schedules, approvals, and activity feeds without exposing data to other teams.
- **Tradeoff**: Nested permissions add complexity but enable fine-grained access control (e.g., "Team A can see Team B’s bookings but not edit them").

**Implementation**:
- **Data Model**:
  ```sql
  CREATE TABLE teams (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    name TEXT NOT NULL,
    parent_team_id UUID REFERENCES teams(id)  -- For nested teams
  );

  CREATE TABLE team_members (
    team_id UUID NOT NULL REFERENCES teams(id),
    user_id UUID NOT NULL REFERENCES users(id),
    role TEXT NOT NULL CHECK (role IN ('admin', 'member', 'viewer')),
    PRIMARY KEY (team_id, user_id)
  );
  ```
- **Permissions**:
  - Use a permission service to check access (e.g., `can_user_edit_booking(user_id, booking_id)`).
  - Cache permissions in Redis with a short TTL (e.g., 5 minutes).
- **Activity Feeds**:
  - Scope feeds to the user’s teams (e.g., `WHERE team_id IN (SELECT team_id FROM team_members WHERE user_id = ?)`).

---

### **6. Approval Workflows**
**Decision**: *State machine with explicit transitions and audit logs*
**Rationale**:
- Approvals require clear state transitions (e.g., `draft → pending → approved → scheduled`) and auditability.
- **Tradeoff**: State machines add rigidity but prevent invalid transitions (e.g., skipping approvals).

**Implementation**:
- **Data Model**:
  ```sql
  CREATE TABLE approval_workflows (
    id UUID PRIMARY KEY,
    booking_id UUID NOT NULL REFERENCES bookings(id),
    status TEXT NOT NULL CHECK (status IN ('draft', 'pending', 'approved', 'rejected')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE approval_audit_logs (
    id UUID PRIMARY KEY,
    workflow_id UUID NOT NULL REFERENCES approval_workflows(id),
    actor_id UUID NOT NULL REFERENCES users(id),
    from_status TEXT NOT NULL,
    to_status TEXT NOT NULL,
    reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  ```
- **Transitions**:
  - Use a service to enforce transitions (e.g., `approve_booking(workflow_id, user_id)`).
  - Notify stakeholders via WebSockets/SSE when status changes.
- **Idempotency**:
  - Require an `Idempotency-Key` header for approval actions to prevent duplicate transitions.

---

### **7. Outbound Webhooks**
**Decision**: *At-least-once delivery with idempotency and retry logic*
**Rationale**:
- Webhooks must be reliable but tolerate failures (e.g., customer systems being down).
- **Tradeoff**: At-least-once delivery may cause duplicate events, but idempotency keys mitigate this.

**Implementation**:
- **Data Model**:
  ```sql
  CREATE TABLE webhook_endpoints (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    url TEXT NOT NULL,
    secret TEXT NOT NULL,  -- For HMAC signing
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE webhook_deliveries (
    id UUID PRIMARY KEY,
    endpoint_id UUID NOT NULL REFERENCES webhook_endpoints(id),
    event_id UUID NOT NULL,  -- Reference to the event (e.g., booking_created)
    payload JSONB NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'delivered', 'failed')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  ```
- **Delivery**:
  - Use a background worker to process `webhook_deliveries` with status `pending`.
  - Sign payloads with HMAC-SHA256 (e.g., `X-Signature: sha256=abc123`).
  - Retry failed deliveries with exponential backoff (e.g., 1s, 5s, 30s, 2m, 10m).
  - Mark as `failed` after 5 attempts.
- **Idempotency**:
  - Require customers to include an `Idempotency-Key` header in responses to deduplicate events.

---

### **8. Scalability Considerations**
| Component               | Scaling Strategy                                                                 |
|-------------------------|---------------------------------------------------------------------------------|
| **Database**            | Read replicas for Postgres; sharding by `tenant_id` if needed.                 |
| **API**                 | Horizontal scaling with Kubernetes; rate limiting by tenant.                    |
| **Activity Feeds**      | Kafka for event streaming; Elasticsearch for full-text search.                 |
| **Webhooks**            | Dedicated worker pool (e.g., Sidekiq) with backpressure.                        |
| **Real-Time Updates**   | Redis Pub/Sub for WebSockets; SSE for lightweight clients.                      |
| **Caching**             | Redis for permissions, tenant metadata, and frequent queries.                   |

---

### **9. Security**
- **Authentication**: JWT with short-lived tokens (e.g., 15-minute expiry) and refresh tokens.
- **Authorization**: RBAC with tenant-scoped roles. Deny by default.
- **Data Isolation**: Schema-per-tenant or row-level security (RLS) in Postgres.
- **Webhooks**: HMAC-SHA256 signing; allowlist customer IPs if needed.
- **Rate Limiting**: Per-tenant rate limits (e.g., 1000 requests/minute).
- **Audit Logs**: Log all sensitive actions (e.g., approvals, tenant creation).

---

### **10. Risks and Safer Path**
#### **Risks**:
1. **Cross-Tenant Data Leakage**: Mitigate with strict `tenant_id` enforcement and automated testing.
2. **Webhook Retry Storms**: Mitigate with exponential backoff and circuit breakers.
3. **Real-Time Update Latency**: Mitigate with WebSockets/SSE and horizontal scaling.
4. **Approval Workflow Deadlocks**: Mitigate with timeouts (e.g., auto-reject after 7 days).

#### **Safer Path**:
- Start with **schema-per-tenant** for strict isolation, then migrate to RLS if needed.
- Use **feature flags** for webhooks to enable/disable per tenant.
- **Monitor** tenant-scoped metrics (e.g., booking failure rates, webhook delivery success).

---

### **11. Open Questions**
1. Should cross-tenant admin dashboards be supported? If so, how to handle permissions?
2. What’s the SLA for webhook delivery (e.g., 99.9% within 5 minutes)?
3. Should approval workflows support custom states (e.g., `escalated`)?

---

### **12. Next Steps**
1. **Prototype**: Build a minimal tenant-scoped booking flow with Postgres RLS.
2. **Benchmark**: Test WebSocket/SSE latency under load (e.g., 10k concurrent users).
3. **Validate**: Review webhook retry logic with a customer integration.

---

**Evidence Classes Cited**:
- `authority_model`: RBAC, tenant isolation, deny-by-default.
- `consistency_stance`: Strong consistency for bookings, eventual for feeds/webhooks.
- `data_delivery`: REST/GraphQL, WebSockets, SSE, webhooks.
- `observability_tax`: Structured logging, distributed tracing, tenant-scoped metrics.