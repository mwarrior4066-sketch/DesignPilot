Here’s a **back-end feasibility review** for adding real-time collaboration to your React/REST/PostgreSQL stack. This follows the `backend_feasibility_review` contract, covering **hidden system requirements**, **explicit blockers**, and a **phased safer path**.

---

### **1. Hidden System Requirements**
*(What the request implies but doesn’t state explicitly)*

#### **Data Model**
- **Document granularity**: Real-time collaboration requires finer-grained data than REST/PostgreSQL typically handles. You’ll need:
  - **Operational Transform (OT)** or **CRDTs** to resolve concurrent edits (e.g., two users typing at the same position).
  - **Per-character/per-block versioning** to track changes (PostgreSQL’s row-level versioning won’t suffice).
  - **Cursor/selection state** (user ID, position, timestamp) to render live cursors/selections.

#### **API Surface**
- **WebSocket or Server-Sent Events (SSE)**: REST is request/response; real-time needs persistent connections.
  - **Connection management**: Handle reconnects, heartbeats, and user presence (e.g., "User X is typing").
  - **Message serialization**: Compact binary formats (e.g., Protocol Buffers) beat JSON for high-frequency updates.
- **Conflict resolution endpoint**: A way to resolve merge conflicts when OT/CRDTs can’t auto-resolve (e.g., overlapping deletions).

#### **Permissions**
- **Object-level authorization**: Ensure users can only edit documents they have access to (e.g., `documents:write` permission).
- **Presence permissions**: Hide cursors/selections for users without read access.

#### **Storage**
- **Event sourcing or append-only logs**: To replay edits for late joiners or recovery (PostgreSQL’s `UPDATE` won’t preserve history).
- **Snapshot storage**: Periodic snapshots to avoid replaying thousands of edits on load.

#### **Observability**
- **Latency monitoring**: Real-time systems fail silently (e.g., high latency feels like lag, not an error).
- **Conflict metrics**: Track how often OT/CRDTs fail to auto-resolve (indicates UX friction).

#### **Degraded Modes**
- **Offline support**: Queue edits locally and sync when reconnected (requires client-side OT/CRDT logic).
- **Read-only fallback**: If the WebSocket fails, allow read-only access via REST.

---

### **2. Feasibility Assessment**
#### **Explicit Blockers**
| **Blocker**               | **Risk**                                                                 | **Severity** |
|---------------------------|--------------------------------------------------------------------------|--------------|
| **PostgreSQL’s row-level locking** | Can’t handle per-character edits; leads to write contention.             | High         |
| **REST API design**       | No persistent connections; polling would kill performance.               | High         |
| **No event sourcing**     | Can’t replay edits for late joiners or recover from conflicts.           | High         |
| **No OT/CRDT library**    | Manual conflict resolution is error-prone and scales poorly.             | High         |
| **No WebSocket infra**    | Need a WebSocket server (e.g., Socket.io, Pusher) or custom solution.    | Medium       |
| **No presence system**    | Can’t show live cursors/selections without tracking user state.          | Medium       |

#### **Feasibility Verdict**
- **Not feasible as-is**: Your current stack (REST + PostgreSQL) lacks the primitives for real-time collaboration.
- **Feasible with changes**: Requires adding WebSockets, OT/CRDTs, and a finer-grained data model.

---

### **3. Safer Implementation Path (Phased)**
#### **Phase 1: Foundation (MVP)**
**Goal**: Enable basic real-time editing with conflict resolution.
**Changes**:
1. **Add WebSocket Server**
   - Use [Socket.io](https://socket.io/) or [ws](https://github.com/websockets/ws) to handle persistent connections.
   - Example:
     ```javascript
     // Server
     io.on('connection', (socket) => {
       socket.on('edit', (delta) => {
         // Apply OT/CRDT logic here
         io.to(roomId).emit('edit', delta);
       });
     });
     ```
2. **Integrate OT/CRDT Library**
   - Use [Slate.js + Yjs](https://docs.yjs.dev/) (for React) or [Quill + OT](https://quilljs.com/).
   - Example (Yjs):
     ```javascript
     import * as Y from 'yjs';
     const doc = new Y.Doc();
     const text = doc.getText('document');
     text.observe((event) => {
       // Broadcast changes via WebSocket
     });
     ```
3. **Upgrade PostgreSQL Schema**
   - Add tables for:
     - `document_edits` (append-only log of deltas).
     - `document_snapshots` (periodic snapshots to avoid replaying all edits).
     - `user_presence` (cursor positions, active users).

**Validation**:
- Test with 2–3 concurrent users.
- Measure latency and conflict rates.

---

#### **Phase 2: Scale & Polish**
**Goal**: Add presence, permissions, and observability.
**Changes**:
1. **Add Presence System**
   - Track active users and cursors:
     ```javascript
     // Client
     socket.emit('update_cursor', { position: 42 });
     // Server
     io.to(roomId).emit('cursor_update', { userId, position });
     ```
2. **Implement Permissions**
   - Check `documents:write` permission before applying edits.
   - Example (PostgreSQL):
     ```sql
     SELECT 1 FROM document_permissions
     WHERE document_id = ? AND user_id = ? AND permission = 'write';
     ```
3. **Add Observability**
   - Log WebSocket latency, conflicts, and reconnects.
   - Example (Prometheus):
     ```javascript
     const latency = Date.now() - message.timestamp;
     metrics.observe('websocket_latency', latency);
     ```

**Validation**:
- Test with 10+ concurrent users.
- Simulate network partitions (e.g., using [Chaos Mesh](https://chaos-mesh.org/)).

---

#### **Phase 3: Degraded Modes & Offline Support**
**Goal**: Handle edge cases (offline, slow networks).
**Changes**:
1. **Add Offline Queue**
   - Use [IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API) to store edits locally.
   - Sync when reconnected:
     ```javascript
     // Client
     const pendingEdits = JSON.parse(localStorage.getItem('pending_edits')) || [];
     pendingEdits.forEach((edit) => socket.emit('edit', edit));
     ```
2. **Implement Read-Only Fallback**
   - If WebSocket fails, fetch the latest snapshot via REST:
     ```javascript
     fetch(`/api/documents/${id}/snapshot`)
       .then((res) => res.json())
       .then((snapshot) => renderReadOnly(snapshot));
     ```

**Validation**:
- Test offline mode and reconnects.
- Measure sync success rate.

---

### **4. Tradeoffs & Recommendations**
| **Decision**               | **Preserves**                          | **Sacrifices**                          |
|----------------------------|----------------------------------------|-----------------------------------------|
| Use OT/CRDTs               | Auto-conflict resolution               | Complexity (need to learn OT/CRDTs)     |
| WebSockets over REST       | Real-time updates                      | Scalability (more connections to manage)|
| PostgreSQL for snapshots   | Familiarity                            | Performance (snapshots are slow)        |
| Yjs over custom OT         | Battle-tested library                  | Vendor lock-in                          |

**Recommendations**:
1. **Start with Yjs + Socket.io**: Lowest effort for React apps.
2. **Avoid custom OT/CRDTs**: Use libraries (Yjs, Automerge) to reduce risk.
3. **Phase 1 first**: Validate the core UX before adding presence/offline.
4. **Monitor conflicts**: If conflicts are frequent, revisit OT/CRDT logic.

---

### **5. Next Steps**
1. **Prototype Phase 1** (1–2 weeks):
   - Set up WebSocket server + Yjs.
   - Test with 2 users.
2. **Review data model**:
   - Ensure `document_edits` and `document_snapshots` tables are correct.
3. **Plan observability**:
   - Add latency/conflict metrics.

**Blockers to resolve first**:
- Choose an OT/CRDT library (Yjs recommended).
- Set up WebSocket infrastructure.