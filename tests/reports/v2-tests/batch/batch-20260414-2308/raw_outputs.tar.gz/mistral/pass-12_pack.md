Here’s a **type system recommendation** for your fintech product, balancing **modern trustworthiness**, **hierarchy**, **tabular data clarity**, and **cross-platform consistency** (marketing site, web app dashboard, mobile). The system prioritizes **readability**, **accessibility**, and **implementation feasibility** while avoiding licensing pitfalls.

---

### **Core Type System: "Fintech Neo-Grotesque"**
**Primary Typeface:** [Inter](https://rsms.me/inter/) (Variable)
**Fallback Stack:**
1. Inter (variable, `wght` 100–900)
2. [SF Pro](https://developer.apple.com/fonts/) (macOS/iOS)
3. [Roboto](https://fonts.google.com/specimen/Roboto) (Android/Web)
4. `system-ui`, `-apple-system`, sans-serif

**Why Inter?**
- **Modern + Trustworthy:** Clean, neutral grotesque with subtle fintech-friendly details (e.g., rounded terminals on `a`, `e`, `g` for approachability).
- **Hierarchy:** 9 weights (`100`–`900`) + italics for emphasis, labels, and data tables.
- **Tabular Data:** Monospace-like numerals (`tnum` feature) for aligned columns in financial tables.
- **Accessibility:** High x-height, open apertures, and WCAG-compliant contrast at all weights.
- **Licensing:** SIL Open Font License (free for commercial use).
- **Performance:** Variable font reduces file size (~100KB for full range).

---

### **Scale and Hierarchy**
Use a **modular scale** (1.25 ratio) for vertical rhythm and proportional hierarchy. Base sizes adapt to platform:

| **Role**               | **Marketing Site** | **Web App Dashboard** | **Mobile**       | **Weight**       | **Features**                     |
|------------------------|--------------------|-----------------------|------------------|------------------|----------------------------------|
| **Display (Hero)**     | 48px (3.84rem)     | 36px (2.88rem)        | 32px (2rem)      | 700–800          | `opsz=144` (optical sizing)      |
| **Heading 1**          | 32px (2.56rem)     | 28px (2.24rem)        | 24px (1.5rem)    | 600–700          | `opsz=96`                        |
| **Heading 2**          | 24px (1.92rem)     | 22px (1.76rem)        | 20px (1.25rem)   | 600              |                                  |
| **Heading 3**          | 20px (1.6rem)      | 18px (1.44rem)        | 18px (1.125rem)  | 500–600          |                                  |
| **Body (Base)**        | 16px (1rem)        | 15px (0.9375rem)      | 16px (1rem)      | 400              | `tnum` (tabular numerals)        |
| **Small Text**         | 14px (0.875rem)    | 13px (0.8125rem)      | 14px (0.875rem)  | 400              | `tnum`, `case` (all-caps)        |
| **Micro (Labels)**     | 12px (0.75rem)     | 12px (0.75rem)        | 12px (0.75rem)   | 400–500          | `tnum`, `case`                   |
| **Data Tables**        | 14px (0.875rem)    | 13px (0.8125rem)      | 14px (0.875rem)  | 400              | `tnum`, `zero` (slashed zero)    |

**Key Adjustments:**
- **Dashboard:** Slightly smaller base size (15px) to fit dense data.
- **Mobile:** Larger touch targets (16px base) for readability.
- **Tabular Data:** Use `tnum` (tabular numerals) and `zero` (slashed zero) to prevent misreading financial figures (e.g., `0` vs `O`).

---

### **Pairing for Contrast (Optional)**
For **marketing site hero sections** or **editorial content**, pair Inter with a **serif for trust signals**:
- **Secondary Typeface:** [Lora](https://fonts.google.com/specimen/Lora) (Variable)
  - **Role:** Pull quotes, testimonials, long-form content.
  - **Why?** Elegant serif with modern proportions; conveys authority without feeling dated.
  - **Usage:** Limited to 2–3 weights (`400`, `500`, `700`) to avoid visual noise.

---

### **Color and Contrast**
- **Primary Text:** `#1A1A1A` (near-black) on light backgrounds; `#F0F0F0` on dark.
- **Secondary Text:** `#555555` (60% opacity on `#1A1A1A`).
- **Data Tables:**
  - **Headers:** `#1A1A1A` (800 weight) with 1px bottom border.
  - **Positive Values:** `#2E7D32` (green, WCAG AA+).
  - **Negative Values:** `#C62828` (red, WCAG AA+).
  - **Neutral Values:** `#1A1A1A` (400 weight).
- **Dark Mode:** Use Inter’s built-in dark-mode optimizations (e.g., slightly increased letter spacing).

**Contrast Checks:**
- All text meets **WCAG AA** (4.5:1 for normal text, 3:1 for large text).
- Use [APCA](https://www.myndex.com/APCA/) for dark-mode contrast (e.g., `#F0F0F0` on `#121212` = ~75% APCA).

---

### **Implementation Notes**
#### **1. Variable Font Setup**
```css
@font-face {
  font-family: 'Inter';
  src: url('inter.var.woff2') format('woff2-variations');
  font-weight: 100 900;
  font-display: swap;
}

/* Enable tabular numerals and slashed zero */
body {
  font-variation-settings: 'wght' 400, 'tnum' 1, 'zero' 1;
}
```

#### **2. Platform-Specific Tweaks**
- **Web App Dashboard:**
  - Use `letter-spacing: -0.01em` for dense data tables.
  - Enable `font-smooth: antialiased` for crisp rendering.
- **Mobile:**
  - Increase line height to `1.5` for touch readability.
  - Use `text-size-adjust: 100%` to prevent iOS font boosting.
- **Marketing Site:**
  - Use `opsz` (optical sizing) for display text (e.g., `font-variation-settings: 'opsz' 144`).

#### **3. Fallback Strategy**
- **SF Pro/Roboto:** Match weights to Inter (e.g., `Inter 500` ≈ `SF Pro 500`).
- **System UI:** Test on Windows (`Segoe UI`), macOS (`San Francisco`), and Android (`Roboto`).

#### **4. Performance**
- **Subset Inter:** Use [Google Fonts’ variable subset](https://fonts.google.com/variablefonts) or self-host a subset with only needed glyphs (e.g., Latin, numerals, basic symbols).
- **Preload:** Critical weights (400, 500, 600) for above-the-fold content.

---

### **Accessibility Considerations**
1. **Dyslexia-Friendly:**
   - Increase line height to `1.5`–`1.6`.
   - Avoid justified text in body copy.
2. **Low Vision:**
   - Support browser zoom (test up to 200%).
   - Use `rem` units for scalable sizing.
3. **Color Blindness:**
   - Avoid red/green for status alone (pair with icons or patterns).
   - Test with [Sim Daltonism](https://apps.apple.com/us/app/sim-daltonism/id693112260).

---

### **Example UI Applications**
#### **1. Marketing Site (Hero Section)**
- **Headline:** `Inter 800, 48px, opsz=144`
- **Subheadline:** `Inter 500, 20px`
- **Body:** `Inter 400, 16px, line-height: 1.6`
- **CTA Button:** `Inter 600, 16px, all-caps`

#### **2. Web App Dashboard (Data Table)**
| **Account**       | **Balance**       | **Change**       |
|-------------------|-------------------|------------------|
| Checking          | $12,345.67        | **+$123.45**     |
| Savings           | $9,876.54         | **-$56.78**      |
- **Headers:** `Inter 600, 13px, tnum, case`
- **Data:** `Inter 400, 13px, tnum, zero`
- **Positive/Negative:** Green/red with `+`/`-` prefix.

#### **3. Mobile (Transaction List)**
- **Transaction Name:** `Inter 500, 16px`
- **Amount:** `Inter 400, 16px, tnum, zero`
- **Date:** `Inter 400, 14px, #555555`

---

### **Tradeoffs and Rationale**
| **Decision**               | **Preserved**                          | **Sacrificed**                          |
|----------------------------|----------------------------------------|-----------------------------------------|
| **Inter as primary**       | Modern trust, hierarchy, tabular data  | Unique brand personality (use color/spacing instead) |
| **Variable font**          | Performance, flexibility               | Slightly higher initial load time       |
| **Modular scale**          | Vertical rhythm, consistency           | Some manual tuning for edge cases       |
| **Limited serif pairing**  | Trust signals in marketing             | Visual complexity in dashboards         |
| **Tabular numerals**       | Financial data clarity                 | Slightly less "designy" feel            |

---

### **Adoption Sequence**
1. **Audit:** Replace existing typefaces with Inter (start with body text).
2. **Test:** Validate contrast, readability, and performance on all platforms.
3. **Refine:** Adjust weights/scales for edge cases (e.g., dense tables).
4. **Document:** Create a [design token](https://design-tokens.github.io/community-group/) file for handoff.
5. **Monitor:** Track performance impact (e.g., Lighthouse scores).

---

### **Alternatives Considered**
| **Typeface**       | **Pros**                              | **Cons**                              | **When to Use**               |
|--------------------|---------------------------------------|---------------------------------------|-------------------------------|
| **Helvetica Now**  | Classic, ultra-readable               | Expensive licensing                   | High-budget projects          |
| **IBM Plex Sans**  | Free, techy, good for data            | Less "modern" than Inter              | Enterprise fintech            |
| **Manrope**        | Friendly, rounded                     | Less authoritative for finance        | Consumer-facing apps          |
| **Satoshi**        | Geometric, modern                     | Paid license, less tabular support    | Brand-heavy projects          |

---

### **Final Recommendation**
**Use Inter (variable) as your primary typeface** with the scale, hierarchy, and implementation notes above. It’s **free**, **modern**, **trustworthy**, and **optimized for financial data**—while scaling seamlessly across platforms. Pair it with **Lora for marketing** if you need serif contrast, but keep it minimal to avoid diluting the system’s clarity.