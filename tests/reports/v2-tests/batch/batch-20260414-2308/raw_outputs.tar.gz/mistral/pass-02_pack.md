Here’s a **component spec** for a **Split Button** that meets your requirements, covering structure, states, behavior, accessibility, and implementation boundaries.

---

# **Component Spec: Split Button**
**Component ID**: `SplitButton`
**Purpose**: A composite button with a primary action and a dropdown for secondary actions, supporting keyboard, touch, disabled, and loading states.

---

## **1. Component Boundary**
- **Primary action**: Default button (e.g., "Save") that triggers the most common action.
- **Dropdown trigger**: Chevron button that opens a menu of secondary actions (e.g., "Save as draft," "Save and close").
- **Menu**: A dropdown list of secondary actions, positioned below the button.
- **Scope**: Does not include the menu’s content logic (e.g., dynamic items, search) or backend actions—only the UI and interaction layer.

---

## **2. States & Variants**
### **2.1. Base States**
| State          | Description                                                                 | Visual Cues                                                                 |
|----------------|-----------------------------------------------------------------------------|------------------------------------------------------------------------------|
| **Default**    | Ready for interaction.                                                      | Primary button: filled. Dropdown: outlined with chevron.                   |
| **Hover**      | User hovers over the primary button or dropdown.                            | Primary: slight darkening. Dropdown: background highlight.                  |
| **Active**     | User clicks/taps the primary button or dropdown.                            | Primary: pressed effect. Dropdown: pressed effect.                          |
| **Focus**      | Keyboard focus on the primary button or dropdown.                           | Primary: focus ring. Dropdown: focus ring.                                  |
| **Disabled**   | Neither button nor dropdown is interactive.                                 | Both buttons: grayed out, `cursor: not-allowed`.                            |
| **Loading**    | Primary action is in progress (e.g., saving).                               | Primary: spinner + "Saving...". Dropdown: disabled.                         |

### **2.2. Menu States**
| State          | Description                                                                 | Visual Cues                                                                 |
|----------------|-----------------------------------------------------------------------------|------------------------------------------------------------------------------|
| **Closed**     | Menu is hidden.                                                             | Chevron points down.                                                        |
| **Open**       | Menu is visible.                                                            | Chevron points up. Menu: shadow, border, z-index above other content.       |
| **Item Hover** | User hovers over a menu item.                                               | Background highlight.                                                       |
| **Item Focus** | Keyboard focus on a menu item.                                              | Focus ring.                                                                 |

---

## **3. Accessibility Behavior**
### **3.1. Keyboard Support**
| Key            | Behavior                                                                                     |
|----------------|----------------------------------------------------------------------------------------------|
| **Tab**        | Moves focus between primary button and dropdown trigger.                                    |
| **Enter/Space**| Triggers the focused button (primary or dropdown).                                           |
| **↓ (Down)**   | Opens the dropdown menu and focuses the first item.                                          |
| **↑ (Up)**     | Opens the dropdown menu and focuses the last item.                                           |
| **Esc**        | Closes the dropdown menu and returns focus to the dropdown trigger.                         |
| **Tab (in menu)** | Moves focus to the next menu item. If at the last item, closes the menu.                  |
| **Shift+Tab**  | Moves focus to the previous menu item. If at the first item, closes the menu.               |

### **3.2. ARIA Attributes**
| Element        | ARIA Attributes                                                                              |
|----------------|----------------------------------------------------------------------------------------------|
| **Primary Button** | `role="button"` + `aria-label="Save"` (or dynamic label).                                   |
| **Dropdown Trigger** | `role="button"` + `aria-haspopup="menu"` + `aria-expanded="false"` (toggles to `true`).      |
| **Menu**       | `role="menu"` + `aria-labelledby="[dropdown-trigger-id]"`.                                   |
| **Menu Items** | `role="menuitem"` + `tabindex="-1"` (focusable only via keyboard navigation).                |

### **3.3. Touch Targets**
- **Minimum size**: 48×48px for both primary button and dropdown trigger (WCAG 2.5.5).
- **Spacing**: 8px gap between primary button and dropdown to prevent accidental taps.

---

## **4. Interaction Logic**
### **4.1. Primary Button**
- Triggers the default action (e.g., "Save") on click/tap or `Enter/Space`.
- If in `loading` state, ignores interactions.

### **4.2. Dropdown Trigger**
- Opens/closes the menu on click/tap or `Enter/Space`/`↓` (when focused).
- Closes the menu on `Esc` or when an item is selected.

### **4.3. Menu Items**
- Triggers the selected action and closes the menu.
- Supports hover/focus states for keyboard navigation.

---

## **5. Implementation Boundary**
### **5.1. Frontend Contract**
- **Props**:
  ```tsx
  interface SplitButtonProps {
    primaryLabel: string;          // e.g., "Save"
    primaryAction: () => void;     // Callback for primary action
    menuItems: Array<{          // Secondary actions
      label: string;
      action: () => void;
      disabled?: boolean;
    }>;
    disabled?: boolean;            // Disables both buttons
    loading?: boolean;             // Shows spinner on primary button
    size?: "small" | "medium" | "large"; // Default: "medium"
  }
  ```
- **Events**:
  - `onPrimaryClick`: Fires when the primary button is triggered.
  - `onMenuItemClick`: Fires when a menu item is selected.

### **5.2. Styling Tokens**
| Token                     | Purpose                                                                 |
|---------------------------|-------------------------------------------------------------------------|
| `--split-button-bg`       | Background color (primary button).                                      |
| `--split-button-text`     | Text color (primary button).                                            |
| `--split-button-hover`    | Hover state background.                                                 |
| `--split-button-disabled` | Disabled state opacity.                                                 |
| `--split-button-border`   | Border color (dropdown trigger).                                        |
| `--split-button-spacing`  | Gap between primary button and dropdown (default: `8px`).               |

### **5.3. Backend Integration**
- **Primary Action**: Calls the default save endpoint (e.g., `POST /api/save`).
- **Secondary Actions**:
  - "Save as draft": `POST /api/save?draft=true`.
  - "Save and close": `POST /api/save?close=true`.
- **Loading State**: Toggles during API calls; disables interactions until resolved.

---

## **6. Mobile-Specific Considerations**
- **Touch Targets**: Ensure 48×48px minimum for both buttons (WCAG 2.5.5).
- **Viewport Constraints**: Menu should flip upward if space is limited below.
- **Long Press**: Ignore long-press interactions to avoid accidental triggers.

---

## **7. Validation Checklist**
| Requirement               | Validation Method                                                                 |
|---------------------------|-----------------------------------------------------------------------------------|
| Keyboard navigation       | Test with `Tab`, `Enter`, `↓`, `↑`, `Esc`.                                       |
| Touch targets             | Verify 48×48px minimum size in dev tools.                                         |
| Disabled state            | Confirm no interactions are possible.                                            |
| Loading state             | Verify spinner appears and buttons are disabled.                                 |
| ARIA attributes           | Audit with screen reader (e.g., VoiceOver, NVDA).                                |
| Menu positioning          | Test on mobile to ensure it doesn’t overflow the viewport.                       |

---

## **8. Tradeoffs & Decisions**
| Decision                  | Preserved                          | Sacrificed                          |
|---------------------------|------------------------------------|-------------------------------------|
| Split button pattern      | Clear primary/secondary separation | Slightly more complex than a single button. |
| Keyboard support          | Full WCAG compliance               | Additional JS logic for focus management. |
| Touch targets             | Mobile usability                   | Larger footprint than desktop-only. |
| Loading state             | Feedback during async actions      | Requires state management.          |

---

## **9. Open Questions**
1. Should the dropdown menu support icons alongside labels?
2. Should the primary button’s label change dynamically (e.g., "Saving...") during loading?
3. Should the menu close after an item is selected, or stay open for multi-selection (if applicable)?

---

## **10. Evidence Classes Cited**
- **WCAG 2.5.5**: Touch target size (48×48px).
- **WCAG 2.1.1**: Keyboard operability.
- **ARIA Authoring Practices**: Menu button pattern.