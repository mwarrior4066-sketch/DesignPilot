Here’s a **PDF remediation plan** to fix screen reader accessibility and reading order for your InDesign-exported report. The plan preserves the two-column layout while ensuring semantic flow, correct tagging, and functional navigation.

---

### **1. Semantic Structure & Reading Order Fix**
**Problem:**
- Two-column layout causes screen readers to read left-to-right across columns (e.g., "Column 1, Line 1 → Column 2, Line 1 → Column 1, Line 2"), breaking narrative flow.
- Pull quotes and decorative images are untagged, disrupting reading order.

**Solution:**
#### **A. Reconstruct Reading Order in Adobe Acrobat Pro**
1. **Open Tags Panel** (`View > Show/Hide > Navigation Panes > Tags`).
2. **Delete existing tags** (likely auto-generated and incorrect).
3. **Manually retag content** in this order:
   - **Header** (H1/H2/H3)
   - **Body text** (left column first, then right column, top-to-bottom)
   - **Pull quotes** (tag as `<Quote>` *after* the paragraph they reference)
   - **Decorative images** (tag as `<Artifact>` to hide from screen readers)
   - **Tables** (tag as `<Table>` with proper header rows)
   - **Table of Contents (TOC)** (tag as `<TOC>` and `<TOCItem>`; see Section 3 for link fixes).

4. **Use "Order" Panel** (`View > Show/Hide > Navigation Panes > Order`) to verify visual vs. semantic order.
   - Drag elements to match the intended reading flow (e.g., left column → right column → pull quote).

#### **B. Column-Specific Fixes**
- **Option 1 (Recommended):** Use **Adobe InDesign’s "Articles Panel"** before export to define reading order.
  - Group left-column content into one "Article," right-column into another.
  - Export with "Create Tagged PDF" enabled.
- **Option 2:** Use **Acrobat’s "Reading Order Tool"** to draw regions around each column and assign tags.

---

### **2. Pull Quote Tagging**
**Problem:**
Pull quotes are untagged or interrupt the reading flow.

**Solution:**
1. Tag pull quotes as `<Quote>`.
2. **Place them *after* the paragraph they reference** in the tag tree (not mid-paragraph).
3. Add **ARIA labels** (via Acrobat’s "Properties" panel) to describe their purpose:
   - Example: `aria-label="Pull quote: [first 5 words of quote]..."`.

---

### **3. Decorative Image Tagging**
**Problem:**
Decorative images (e.g., dividers, background graphics) are untagged or mislabeled.

**Solution:**
1. Tag as `<Artifact>` (not `<Figure>`).
2. Set **alternative text to blank** (`""`) to hide from screen readers.
3. In Acrobat:
   - Right-click image → **Properties** → **Tag** → Select "Artifact."
   - Under **Alternate Text**, enter `""`.

---

### **4. Table of Contents (TOC) Fix**
**Problem:**
TOC links are broken (likely due to InDesign’s hyperlink export issues).

**Solution:**
1. **Rebuild TOC in Acrobat:**
   - Open **Links Panel** (`View > Show/Hide > Navigation Panes > Links`).
   - Delete broken links.
   - Use **Edit PDF > Link > Add/Edit Web or Document Link** to recreate links.
   - Ensure each TOC entry links to the correct **bookmark** (not page number).

2. **Verify Bookmarks:**
   - Open **Bookmarks Panel** (`View > Show/Hide > Navigation Panes > Bookmarks`).
   - Ensure bookmarks match TOC entries and link to the correct headings.

3. **Tag TOC Properly:**
   - Tag the TOC container as `<TOC>`.
   - Tag each entry as `<TOCItem>` with `Link` attributes.

---

### **5. Table Accessibility**
**Problem:**
Tables may lack headers or have merged cells.

**Solution:**
1. Tag tables as `<Table>`.
2. Define **header rows** (`<TH>`) and **scope** (column/row).
3. Add **summaries** (via `summary` attribute or `<Caption>` tag).
4. In Acrobat:
   - Right-click table → **Table Editor** → Assign header rows.
   - Use **Reading Order Tool** to tag cells correctly.

---

### **6. Validation & Testing**
**Tools:**
- **Adobe Acrobat Pro:** Full Accessibility Check (`Tools > Accessibility > Full Check`).
- **PAC 2024:** Free tool to test WCAG compliance (focus on PDF/UA).
- **Screen Reader Test:** Use NVDA or VoiceOver to verify reading order.

**Key Checks:**
1. **Reading Order:** Does the screen reader follow the narrative flow (left column → right column → pull quote)?
2. **Links:** Do TOC links jump to the correct sections?
3. **Decorative Images:** Are they skipped by screen readers?
4. **Tables:** Are headers announced correctly?
5. **Pull Quotes:** Are they announced as quotes *after* the referenced text?

---

### **7. Export Settings for Future PDFs (InDesign)**
To avoid repeating these fixes:
1. **Enable "Create Tagged PDF"** in Export Settings.
2. **Use Articles Panel** to define reading order.
3. **Tag Styles:** Map InDesign styles (e.g., "Heading 1") to PDF tags (e.g., `<H1>`).
4. **Decorative Images:** Set as "Artifact" in Object Export Options.
5. **Hyperlinks:** Verify TOC links export correctly (test in Acrobat).

---

### **8. Deliverables**
1. **Remediated PDF** (tagged, tested).
2. **Validation Report** (from Acrobat’s Accessibility Check).
3. **InDesign Template Fixes** (if you control the source file).

---

### **Tradeoffs**
- **Preserved:** Two-column layout, visual design, pull quotes.
- **Sacrificed:** Some manual effort (automated tools like InDesign’s export can’t perfectly handle complex layouts).
- **Verification Method:** Screen reader testing + PAC 2024 validation.