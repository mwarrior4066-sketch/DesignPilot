Here’s a structured critique of the poster design, grounded in hierarchy, communication goals, and accessibility—with clear tradeoffs and next steps:

---

### **1. Hierarchy Failure (Governing Issue)**
**Problem:**
The title dominates before the audience understands *what* the event is. A decorative typeface at large scale competes with the skyline background, making the title hard to parse quickly. The logo (brand identifier) is buried in the middle, and the date (critical for decision-making) is nearly invisible.

**Why it matters:**
Posters must communicate **what → when → where → why** in under 3 seconds. This sequence is reversed here, forcing viewers to work backward.

**Evidence:**
- Observed: Title is largest element; date is smallest and low-contrast.
- Inferred: Decorative typeface likely prioritizes style over readability at a distance.
- Tradeoff: Sacrificing *immediate clarity* for *visual drama*.

---

### **2. Visual Noise vs. Signal**
**Problem:**
The full-bleed skyline photo creates three conflicts:
- **Legibility:** The title’s decorative typeface and white logo overlay clash with the busy background (e.g., skyscraper edges intersecting letters).
- **Semantic mismatch:** A cityscape may not align with the conference’s theme (e.g., if the event is about "design for rural communities," the skyline feels arbitrary).
- **Accessibility:** Low contrast between white logo/text and bright/light areas of the photo risks failing WCAG AA (minimum 4.5:1 for text).

**Tradeoff:**
- Preserves *atmosphere* but sacrifices *readability* and *brand recall*.

---

### **3. Logo Placement**
**Problem:**
The logo is centered but layered over the photo, making it part of the visual noise rather than a clear brand anchor. Logos should be:
- **Discoverable** (not competing with other elements).
- **Scalable** (reproducible at small sizes, e.g., social media thumbnails).

**Tradeoff:**
- *Design cohesion* (logo as part of the composition) vs. *brand recognition* (logo as a standalone identifier).

---

### **4. Date Visibility**
**Problem:**
The date is in small gray text in the bottom corner—a "dead zone" for attention. Critical details (date, location, cost) should be:
- **High-contrast** (e.g., black on white or vice versa).
- **Proximate to the call-to-action** (e.g., "Register now" link).

**Tradeoff:**
- *Minimalism* (avoiding clutter) vs. *usability* (ensuring key info is seen).

---

### **5. Missing Contextual Hooks**
**Problem:**
The poster lacks:
- **Audience frame:** Who is this for? (e.g., "For UX designers and researchers").
- **Differentiation:** Why this conference over others? (e.g., "Hands-on workshops with industry leaders").
- **Call-to-action:** How to register/learn more (e.g., QR code, URL, or social handle).

**Tradeoff:**
- *Aesthetic purity* vs. *actionable information*.

---

### **Rebuild Moves (Prioritized)**
1. **Flip the hierarchy:**
   - **Top:** Conference name (clear, readable typeface) + 1-line descriptor (e.g., "A conference for design systems practitioners").
   - **Middle:** Date/location (high-contrast, larger than current).
   - **Bottom:** Logo + call-to-action (e.g., QR code or "Register at [URL]").

2. **Simplify the background:**
   - Option A: Replace skyline with a *solid color* or *gradient* to improve text contrast.
   - Option B: Use a *blurred/desaturated* version of the skyline to reduce noise while keeping atmosphere.

3. **Test legibility:**
   - Print a thumbnail-sized version (e.g., 2" tall) to ensure all text is readable.
   - Check contrast ratios (use [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)).

4. **Add a hook:**
   - Include a *tagline* or *keynote speaker name* to differentiate (e.g., "Featuring [Industry Leader]").

---

### **Tradeoffs Named Explicitly**
| **Preserved**               | **Sacrificed**                     |
|-----------------------------|------------------------------------|
| Visual drama (skyline)      | Immediate clarity (hierarchy)      |
| Decorative typeface         | Readability at a distance          |
| Minimalist layout           | Actionable details (CTA, date)     |

---

### **Next Steps**
- **Quick fix:** Overlay a semi-transparent *color block* behind the title/logo to improve contrast.
- **Structural fix:** Redesign with a *grid* (e.g., 3-column layout) to separate "what," "when/where," and "why."
- **Validation:** Test with 3 people for 3 seconds each—ask: "What is this event, and when is it?"

**Governing rule:** *Hierarchy must serve the viewer’s decision-making, not the designer’s aesthetic preference.*