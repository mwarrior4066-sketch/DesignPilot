Here’s the reconstruction plan, governed by `rt_layout_reconstruction_plan` and supported by `rt_pdf_layout_expert` and `rt_grid_system_expert`.

---

### **1. Evidence Extraction (Observed, Not Inferred)**
From the 2018 PDF, extract these **observed** artifacts:
- **Grid diagrams**: column count, gutter width, margin width, baseline increment (if shown).
- **Margin specs**: left/right/top/bottom values (in mm, pt, or px).
- **Column examples**: screenshots of layouts using the grid (e.g., 12-column, 6-column).
- **Breakpoint cues**: if the PDF shows responsive behavior (e.g., "mobile: 6 columns").
- **Typography scale**: body text size, heading sizes, line-height ratios (if tied to the grid).
- **Visual hierarchy**: how headings, body text, and images align to the grid (e.g., "H1 spans 8 columns").
- **Confidence level**: High (directly visible in the PDF).

**Flag mismatches**:
- If the PDF describes a 12-column grid but examples show 8-column layouts, note this as a **legacy-preservation rule** (e.g., "Theoretical 12-column grid, but legacy templates use 8-column").

---

### **2. Inferred Structure (Medium/Low Confidence)**
From the PDF’s **examples**, infer:
- **Baseline grid**: If text aligns vertically, assume a baseline increment (e.g., 6pt).
- **Modular scales**: If headings grow by a ratio (e.g., 1.25x), document it.
- **Image/text alignment**: If images align to columns/gutters, note the rule.
- **Confidence level**: Medium (suggested by spacing, but not explicit).

**Do not infer**:
- Interaction logic (e.g., hover states).
- Accessibility behavior (e.g., focus order).
- Source-file semantics (e.g., layers in InDesign).

---

### **3. Reconstruction Rules**
#### **Preserved Elements** (High Confidence)
- **Grid math**: Use the PDF’s column/gutter/margin values as the **primary scaffold**.
  - Example: `12 columns × 20px gutters + 60px margins = 1200px container`.
- **Typography**: Keep the PDF’s type scale if it aligns to the grid (e.g., "Body text = 16px on a 4px baseline").
- **Hierarchy**: Preserve how headings/images span columns (e.g., "H1 spans 8 columns").

#### **Normalization Rules** (Modern Adjustments)
- **Breakpoints**: Add modern breakpoints (e.g., 768px, 1024px) if the PDF only shows desktop.
- **Gutters**: Widen gutters for touch (e.g., 24px instead of 12px).
- **Margins**: Adjust margins for edge-to-edge designs (e.g., "Mobile: 16px margins").
- **Baseline**: Align text to a 4px or 8px baseline for digital precision.

#### **Legacy-Preservation Rules**
- If the PDF shows **inconsistent** column usage (e.g., 8-column in examples but 12-column in diagrams), default to the **example-driven rule** (e.g., "Use 8-column for legacy compatibility").
- If the PDF’s grid is **print-only** (e.g., 210mm × 297mm), convert to digital units (e.g., "A4 → 1200px container").

---

### **4. Modern Translation**
#### **Grid System Spec**
| Property          | Value (Example)                     | Source          | Confidence |
|-------------------|-------------------------------------|-----------------|------------|
| Container width   | 1200px                               | PDF diagram     | High       |
| Columns           | 12                                  | PDF diagram     | High       |
| Gutters           | 20px                                | PDF diagram     | High       |
| Margins           | 60px (desktop), 16px (mobile)       | PDF + modern    | High       |
| Baseline increment| 4px                                 | Inferred        | Medium     |
| Breakpoints       | 768px, 1024px, 1440px                | Modern addition | High       |

#### **Typography Scale**
| Text Style        | Size (px) | Line Height | Column Span | Source      |
|-------------------|-----------|-------------|-------------|-------------|
| Body              | 16        | 1.5         | 6           | PDF         |
| H1                | 48        | 1.2         | 8           | PDF         |
| H2                | 32        | 1.3         | 6           | PDF         |

#### **Layout Rules**
- **Images**: Align to columns/gutters (e.g., "Full-bleed images span 12 columns + margins").
- **Text**: Align to baseline grid (e.g., "Body text starts at 4px increments").
- **Components**: Size to column multiples (e.g., "Buttons = 2 columns").

---

### **5. Verification Method**
- **Grid overlay**: Superimpose the reconstructed grid on the PDF’s examples to check alignment.
- **Responsive test**: Apply the grid to a modern template (e.g., Figma) and verify:
  - Text aligns to baseline.
  - Images respect gutters.
  - Mobile layouts use adjusted margins/columns.
- **Legacy check**: Ensure new templates match the PDF’s **visual rhythm** (e.g., "H1 still feels like the 2018 brand").

---

### **6. Output Artifact**
#### **Reconstructed Grid System**
```markdown
# Brand Guidelines 2024: Layout System
**Source**: 2018 PDF (grid diagrams, margin specs, examples)

## Grid Spec
- **Desktop (1200px container)**:
  - 12 columns × 20px gutters + 60px margins.
  - Baseline: 4px increment.
- **Mobile (768px container)**:
  - 6 columns × 24px gutters + 16px margins.
- **Breakpoints**: 768px, 1024px, 1440px.

## Typography
- **Body**: 16px / 1.5 (6 columns).
- **H1**: 48px / 1.2 (8 columns).
- **H2**: 32px / 1.3 (6 columns).

## Rules
- **Images**: Align to columns/gutters (no bleed unless specified).
- **Text**: Align to baseline grid.
- **Components**: Size to column multiples (e.g., buttons = 2 columns).

## Legacy Notes
- Original PDF used 8-column layouts in examples (despite 12-column diagrams).
  **Rule**: Default to 8-column for legacy compatibility.
```

---

### **7. Tradeoffs**
- **Preserved**: Brand rhythm, column logic, typography scale.
- **Sacrificed**: Print-specific units (e.g., mm → px), fixed breakpoints (added responsive tiers).
- **Why**: Modern templates need digital precision, but the 2018 PDF’s **visual DNA** must stay intact.

---

### **8. Next Steps**
1. **Apply to templates**: Use the grid in Figma/Adobe XD to rebuild a sample page.
2. **Verify alignment**: Overlay the grid on the PDF’s examples to check fidelity.
3. **Adjust for edge cases**: If a component doesn’t fit (e.g., a wide table), create a **modular exception rule** (e.g., "Tables span 10 columns + 1 column gutters").