Here’s the audit structured by the four required dimensions, with **hard failures**, **required decisions**, and **tradeoffs** explicitly named per the `api-reliability-security` contract.

---

### 1. Failure Semantics & Error Contract
**Hard failures**
- **hr_unsupported_superlative**: “HTTP 200 for all responses” violates RFC 9457 (Problem Details) and removes the ability to distinguish success from transient vs. permanent errors.
- **hr_missing_route_decision**: No decision on terminal states or retry safety.

**Required decisions (from contract decision index)**
- **problem_details_contract**: Must adopt RFC 9457 media type `application/problem+json`.
- **async_job_model**: Must move to 202 Accepted + status URL or streaming.

**Evidence classes cited**
- RFC 9457 (Problem Details)
- Internal enum leakage → observed in error payloads

**Tradeoffs**
- **Preserved**: PDF generation remains a single logical operation.
- **Sacrificed**: Synchronous blocking; user must now poll or stream instead of waiting.

---

### 2. Authorization & Resource Protection
**Hard failures**
- **hr_accessibility_floor**: No object-level authorization check → any authenticated user can trigger exports for any resource.

**Required decisions**
- **authorization_perimeter**: Must gate by session owner + object-level permission (`export:create` on the target resource).

**Evidence classes cited**
- BOLA (Broken Object-Level Authorization) rule
- Deny-by-default stance

**Tradeoffs**
- **Preserved**: Simple caller experience.
- **Sacrificed**: Unrestricted export surface; risk of quota exhaustion or data exfiltration.

---

### 3. Idempotency & Async Lifecycle
**Hard failures**
- **hr_missing_route_decision**: No idempotency key → duplicate submissions create duplicate PDFs.

**Required decisions**
- **idempotency_contract**: Must accept `Idempotency-Key` header and return 409 Conflict on duplicate.

**Evidence classes cited**
- Idempotency-key header (RFC draft)
- 409 Conflict on duplicate

**Tradeoffs**
- **Preserved**: Exactly-once semantics.
- **Sacrificed**: Caller must generate and store keys; adds client-side complexity.

---

### 4. Resilience & Observability
**Hard failures**
- **hr_missing_route_decision**: No retry-safe contract → clients retry blindly, risking thundering herd.

**Required decisions**
- **resilience_strategy**: Must adopt exponential backoff with jitter + circuit breaker.
- **async_job_model**: Must expose `status` URL with terminal states `queued → running → completed | failed`.

**Evidence classes cited**
- Exponential backoff with jitter
- Circuit breaker pattern
- Trace_id on all errors

**Tradeoffs**
- **Preserved**: PDF fidelity and atomicity.
- **Sacrificed**: Synchronous simplicity; caller must now handle async lifecycle.

---

### Quick-fix checklist (lightweight path)
1. **Problem contract**: Adopt RFC 9457 + 4xx/5xx status codes.
2. **Auth**: Add object-level `export:create` permission check.
3. **Idempotency**: Add `Idempotency-Key` header + 409 Conflict.
4. **Async**: Move to 202 Accepted + status URL + exponential backoff.