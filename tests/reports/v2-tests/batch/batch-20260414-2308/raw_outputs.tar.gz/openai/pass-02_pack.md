## Split Button Component Spec

### Component Boundary

- **Component Name:** SplitButton
- **Purpose:** A two-part button where the primary action (“Save”) is directly invokable, and a dropdown trigger reveals secondary actions (“Save as draft”, “Save and close”).
- **Usage Context:** Toolbars, forms, modals—where multiple closely related save behaviors should be accessible but one is dominant.

### States and Variants

#### 1. States

- **Default:** Both buttons enabled, no dropdown open.
- **Dropdown open:** Secondary menu is visible and anchored to the split button.
- **Disabled:** Both parts visually disabled and non-interactive (see Accessibility).
- **Loading:** Shows loading indicator (spinner) on the primary button (and optionally, disables both parts to prevent duplicate or conflicting actions).

#### 2. Variants

- **Full-width on mobile:** Adjusts hit area, optional block mode.
- **Menu items active/disabled:** Each menu item may be independently enabled or disabled based on context.

### Accessibility Behavior

#### Keyboard Support

- **Tab:** Focuses the primary button first, then the dropdown trigger (each is a reachable focusable element).
- **Enter/Space (on primary):** Invokes Save.
- **Enter/Space (on trigger):** Opens dropdown menu.
- **Arrow Down (on trigger):** Opens dropdown and focuses first menu item.
- **Esc (when menu open):** Closes dropdown, focuses trigger.
- **Arrow Up/Down (in menu):** Moves focus between menu items.
- **Enter/Space (in menu):** Invokes the selected secondary action.
- **Disabled state:** Both buttons are removed from tab order and announce as disabled when disabled.

#### ARIA and Roles

- Primary button: `role="button"`, `aria-disabled="true"` when disabled, `aria-busy="true"` when loading.
- Dropdown trigger: `aria-haspopup="menu"`, `aria-expanded="true/false"`, `aria-controls` points to the menu panel.
- Dropdown menu: `role="menu"`, menu items `role="menuitem"` or `role="menuitemradio"` for exclusive selection.
- Loading: Announces progress to screen readers (`aria-live="polite"`, loading indicator is visually and accessibly linked).

### Touch and Mobile Support

- **Target Size:** Every tap/clickable surface is at least 48x48dp on mobile screens.
- **Touch Behavior:** Separate target for primary and menu trigger—ensure adequate spacing and visual indication of both parts.
- **Dropdown Menu:** Opens on tap of trigger; menu is touch-scrollable and dismisses when tapping outside.
- **Loading and Disabled:** On touch, ignore further taps/clicks when loading or disabled is active.

### Implementation Boundary

- **Component Hierarchy:**  
  - `<SplitButton>`  
    - `<PrimaryButton>`
    - `<DropdownTrigger>`
    - `<DropdownMenu>` (portal when open)
- **Props:**
  - `primaryLabel` (e.g. "Save")
  - `secondaryActions` (array: `{label, action, disabled}`)
  - `onPrimary`
  - `disabled`
  - `loading`
- **Controlled/Uncontrolled:** Menu open state can be internal or lifted.

### Tradeoffs and Decisions

- **Keyboard navigation prioritizes** direct and predictable focus order—Tab stops at each button, not as a single grouped widget. This aids screen reader users.
- **Loading disables both parts** to prevent conflicting actions during async submission.
- **On mobile, a single large hit area per segment** (not a split-tap where a single button triggers both).
- **Dropdown uses native focus management** to ensure accessibility and menu closure on Esc or selection.
- **Disabled always disables both Save & menu** because partial disables can be confusing unless UI requirements are more nuanced.

### What’s preserved vs. sacrificed

- Preserved: Predictable, accessible navigation; adequate touch targets; implementation clarity; menu focus order; async-safe state.
- Sacrificed: Some flexibility for partial disables (e.g. disabling only “Save as draft”) is omitted for simplicity unless requirements expand.

---

**Evidence/Rationale:**  
- Button and dropdown separation mirrors common web accessibility patterns.  
- Minimum 48x48dp tap area complies with [WCAG 2.1 2.5.5 Target Size](https://www.w3.org/WAI/WCAG21/Understanding/target-size.html).  
- Focus and ARIA logic follows [WAI-ARIA Authoring Practices for menu buttons](https://www.w3.org/WAI/ARIA/apg/patterns/menubutton/).  
- Disabling during async prevents double submissions per implementation best practice.

---

**Next moves:**  
- Provide visual mockups for mobile and desktop.
- Author storybook stories covering all states.
- Add a test matrix for keyboard/touch/assistive tech interaction.