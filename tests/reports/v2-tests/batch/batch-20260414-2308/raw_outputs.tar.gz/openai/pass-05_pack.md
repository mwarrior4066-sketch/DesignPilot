To remediate your InDesign-exported PDF for screen reader accessibility and logical reading order, you need to correct several common issues: reading order (especially with two columns and pull quotes), decorative image tagging, and broken TOC links. Here’s a direct plan and the decisions behind each step.

---

## 1. Problem Summary

- **Reading order** is likely incorrect due to two columns and interrupting pull quotes; text may jump unpredictably for screen readers.
- **Decorative images** are untagged and will be announced as unlabelled graphics or may appear as "Figure" with junk descriptions.
- **Broken Table of Contents links** prevent navigation and harm accessibility.
- Assumption: You have the original PDF and, ideally, source files.

---

## 2. Fixing the PDF

### A. Set Logical Reading Order

**Why:** Screen readers follow the tag reading order in the PDF, not always the visual layout. Two columns plus floating quotes often produce jumbled order unless the tags are sequenced explicitly.

**How:**
1. **Open PDF in Adobe Acrobat Pro.**
2. Go to **"Accessibility" > "Reading Order" tool** (you may find it under "Tools" > "Accessibility" > "Reading Order").
3. **Check tag order**:
   - Use the “Order” panel: It visually numbers reading order.
   - Select and drag items to match the logical reading flow: left-to-right, top-to-bottom for columns (finish one column before starting the next).
   - **Move pull quotes** to the end of a paragraph or as a separate artifact (so they don’t interrupt main text).
4. **Tag all text**: Ensure all content is within <P> (Paragraph), <H1>-<H6> (Headings), <L> (Lists), and other semantically correct tags.

**Tradeoff:** You may need to group some objects together or create custom reading order that does not exactly visually match the page, but ensures text flows logically for assistive tech. This sacrifices exact visual-to-tag mapping for screen-reader usability.

---

### B. Mark Decorative Images as Artifacts

**Why:** Decorative images should be hidden from assistive tech to prevent distraction and clutter.

**How:**
1. Use the **"Reading Order" tool**:
   - Select each decorative image.
   - Click “Background/Artifact” in the tool. This will remove it from the tag tree and screen readers.
2. Alternatively, in the **Tags pane**, right-click the image tag and select “Change Tag to Artifact.”

**Note:** Only hide images that are truly decorative. Informative images need alt text.

---

### C. Repair TOC Links

**Why:** Non-working links harm navigation for all users, especially those using keyboard or screen readers.

**How:**
1. In Acrobat Pro, enter **Edit mode** (“Edit PDF” tool).
2. Select each TOC text/link.
3. Right-click and choose “Create Link” → “Go to a page view.”
4. Manually set the destination for each TOC entry.
5. If the TOC links are tagged as plain text in the Tags tree, convert them to <Link> and set the correct /A (action) attribute pointing to the correct page or section.

**Testing:** Press Tab to verify keyboard focus moves through links correctly.

---

### D. Save and Verify

1. Use **"Accessibility Check"** in Acrobat Pro or PAC 3 for a deeper check.
2. **Tab through the document** with a screen reader (NVDA, JAWS, or VoiceOver) to check reading order.
3. Use the **Tags pane** (View > Show/Hide > Navigation Panes > Tags) to ensure all elements are properly tagged.

---

## 3. Verification Methods

- Run the built-in Accessibility Checker in Acrobat Pro.
- Check the **tag structure** visually; <Document> must correctly nest Headings and Paragraphs, in order.
- Use a screen reader or try "Read Aloud" to spot reading order mistakes.
- Validate links by keyboard navigation.

---

## 4. Destructive Shortcut Rejected

**Do not** flatten content to images or use "flattened PDF" hacks: that destroys accessibility for all users.

---

## Summary of Necessary Decisions

- **semantic_failure:** Old PDF had poor tag structure and reading order.
- **reading_order_or_extraction:** Fixed by explicit reordering and correct tagging.
- **verification_method:** Accessibility checker, manual tag review, and screen reader spot testing.
- **destructive_shortcut_rejected:** No content flattening or image-only pages; all remediated content maps to logical structure.

---

## What You Gain

By following this plan, the PDF will be properly accessible:
- Logical, predictable reading order for screen readers—even with columns and pull quotes.
- Decorative images are hidden (not distracting).
- TOC is navigable.
- Extraction and reflow for accessible export (e.g., conversion to HTML or EPUB) will be possible.

---

If you need a remediated sample tag tree, alt-text guidance, or a checklist for your team, just ask!