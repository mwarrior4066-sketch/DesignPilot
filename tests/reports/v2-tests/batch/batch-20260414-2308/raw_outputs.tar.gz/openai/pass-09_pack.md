## Color System Specification: Healthcare SaaS Dashboard

### Overview

This color system is designed for a healthcare SaaS dashboard that must:

- Accurately communicate status (normal, warning, critical)
- Support both light and dark modes
- Provide at least 5 categorical/data visualization colors that remain distinguishable (for charts, segmentations, etc.)
- Meet [WCAG 2.1 AA](https://www.w3.org/WAI/standards-guidelines/wcag/) contrast requirements for all text, including status indicators and data vis labels

---

## 1. Semantic Roles & Color Assignments

| Semantic Role        | Light Mode Color   | Dark Mode Color     | Usage                                                           |
|----------------------|-------------------|---------------------|-----------------------------------------------------------------|
| Background           | #FFFFFF           | #181C20             | Main dashboard background                                       |
| Surface (Card)       | #F7F9FA           | #22282E             | Cards, panels                                                   |
| Text/Primary         | #1A1A1A           | #FFFFFF             | Default text                                                    |
| Subtle Text          | #49505B           | #C7CED6             | Secondary labels/hints                                          |
| Divider/Border       | #E4E9EB           | #333A41             | Card borders, chart axis                                        |
| Interactive/Accent   | #3264FF           | #7CB2FF             | Links, interactive icons, focused states                        |
| Disabled             | #BAC2CB           | #49505B             | Disabled text/icons                                             |

---

## 2. Status Colors

| Status    | Light Mode                | Dark Mode                  | WCAG AA Compliant? | Note                                 |
|-----------|---------------------------|----------------------------|--------------------|--------------------------------------|
| Normal    | #218838 (green 700)       | #54E28D (green 300)        | Yes                | Used for “OK” states                 |
| Warning   | #FFC107 (amber 600)       | #FFE666 (amber 300)        | Yes                | Used for “attention needed”          |
| Critical  | #D90429 (red 700)         | #FF6482 (red 300)          | Yes                | Used for “urgent/failure” states     |
| Informational | #007AA6 (blue 700)    | #7CC2F7 (blue 300)         | Yes                | For tips/info banners/audit messages |

**Text overlays on status colors:** Always use the following for readability:
- On light status backgrounds: #1A1A1A (almost black)
- On dark status backgrounds: #FFFFFF (white)

---

## 3. Data Visualization Colors (Categorical, 5+)

To ensure data series are easily distinguished, avoid red/green confusion and maintain minimum [APCA](https://www.myndex.com/APCA/) or WCAG contrast for legends and value labels.

| Series | Light Mode | Dark Mode | Example Use                        |
|--------|-----------|-----------|------------------------------------|
| 1      | #3264FF   | #7CB2FF   | Primary                           |
| 2      | #2ECDA7   | #3CE2CD   | Cyan/Turquoise                    |
| 3      | #7267ED   | #BAA9FF   | Purple                            |
| 4      | #FFB72B   | #FFD96B   | Yellow/Gold                       |
| 5      | #FF6B6B   | #FFB2B2   | Coral/Red                         |
| 6      | #46B3E6   | #73D9F5   | Blue                              |
| 7      | #81C784   | #BDF5B0   | Green                             |

**Note:** For pie/donut/bar charts, sequence is 1–5 for high contrast. Series 6–7 provide extension for more than 5 data classes.

---

## 4. Accessibility & Contrast Notes

- All text on colored backgrounds meets WCAG AA (contrast ratio ≥ 4.5:1 against its background for normal text, 3:1 for large/bold text).
- Data labels (numbers, legends, chart values) **must** use high-contrast overlays (white/black as above) calculated for each chart background.
- Avoid using red/green alone for status—instead, supplement with shapes/icons (ex: warning triangle, checkmark, exclamation).
- Colorblind-safe palette: avoid problematic combinations (e.g., red/green) where color alone indicates state.
- Interactive highlights (e.g., hover/selected states) darken or lighten the base color by at least 12% for visible feedback, keeping contrast accessible.

---

## 5. Migration/Implementation Strategy

- Define all palette colors as CSS variables or design tokens for easy mapping to components in both modes.
- Use semantic tokens (ex: `color-status-critical`) to refer to status colors, not literal hex codes in code.
- Include dark mode logic in the component/theme provider from the start.
- Provide a reference table (as above) for front-end and charting library implementation.
- **Testing:** Run all color/text overlays through automated contrast checkers (ex. axe, Lighthouse, Myndex/APCA).
- Consider an accessibility review with real users, including those with color vision deficiencies, before release.

---

## Tradeoffs and Notes

- **Preserved:** Visual clarity, accessibility, WCAG AA compliance, and rapid status recognition, including for colorblind users.
- **Sacrificed:** Slight reduction in expressive/cosmetic range (especially for categorical colors) to maximize functional/accessible contrast and avoid ambiguous color meanings.
- **Rationale:** For healthcare, **clarity and accessibility supersede branding or aesthetic variety**, because unsafe color choices introduce real patient and workflow risk.

---

## Sample CSS Variable Usage

```css
:root {
  --color-bg-light: #FFFFFF;
  --color-bg-dark: #181C20;

  --color-status-normal-light: #218838;
  --color-status-normal-dark: #54E28D;
  /* ...etc for other roles/colors */
}
```

---

### Next Steps

- Map these semantic color roles into your design tokens and component library.
- Validate each token’s use (for text, icons, backgrounds, borders) with both automated tools and quick user review.
- Plan for regular accessibility regression checks as the dashboard evolves.