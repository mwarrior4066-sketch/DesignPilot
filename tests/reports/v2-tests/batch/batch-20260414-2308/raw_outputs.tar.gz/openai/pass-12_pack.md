## Type System Recommendation for a Fintech Product

### Reading Contexts
- **Marketing site:** Must communicate trustworthiness, modernity, and clarity—supporting both headlines and long-form copy. Needs to scale well on large displays.
- **Web app dashboard:** Requires dense tabular data, numeric clarity, rapid scan, and crisp distinction between headings, values, and secondary info.
- **Mobile:** Must remain readable at small sizes, with strong differentiation between display and body roles, good number alignment, and legibility in motion.

### Core Typeface Recommendation

**Inter** (https://rsms.me/inter/) — Open Source

#### Why Inter?
- **Modern and trustworthy**: Designed for contemporary digital interfaces, Inter projects a neutral, professional tone—a strong match for fintech.
- **Tabular/Punctuation Alignment**: Includes tabular figures and well-aligned numerals, supporting financial data integrity in tables and charts.
- **Multiple weights:** 9 weights from Thin to Black; regular, italic, and variable font options make hierarchy simple without mixing families.
- **Extensive language support:** Latin, Extended Latin, Cyrillic, Greek—well-suited if your product will internationalize.
- **Web and mobile optimized:** Excellent rendering on all major browsers, platforms, and devices; includes optical adjustments for small sizes.
- **Implementation-friendly:** Google Fonts (web, mobile) and variable font support enable easy performance optimization.

### Hierarchy & Weight Assignment
- **Display/Headlines:** Inter Bold or SemiBold (700/600)
- **Section Headings:** Inter SemiBold (600)
- **Body Copy:** Inter Regular (400)
- **Dense Data / Table Labels:** Inter Medium (500)
- **Numbers/Data Values:** Inter Regular or Medium (400/500) with tabular figures enabled (`font-variant-numeric: tabular-nums`)
- **Footnotes/Meta:** Inter Regular or Light (400/300)
- **Buttons/Labels (UI):** Inter Medium (500) or SemiBold (600) for emphasis

### Pairing Strategy (If Brand Needs a Second Family)
**Optional, only for major headings or marketing copy to add brand flavor.**  
Consider pairing Inter with **DM Serif Display** for hero headlines if you want a touch of classical trust—but keep Inter as the backbone everywhere else for consistency and data clarity.

### Adoption Sequence & Practical Steps

1. **Audit Existing Surfaces:** Inventory text roles on web, dashboard, and mobile (heading, number, body, label, etc).
2. **Implement Inter via variable font when possible** for the leanest bundle across platforms.
3. **Test font rendering in tabular data, currency values, and dashboards**—verify alignment and numeric legibility.
4. **Establish Type Scale:** Use a 1.2–1.25 major third/augmented second scale for easy hierarchy in dense UI.
5. **Tune Sizes per Platform:** Slightly larger minimums for mobile (e.g. body at 16–17px), crisper display for tables (test at 13–14px min).
6. **Apply tabular figures wherever numbers align**: CSS `font-variant-numeric: tabular-nums;`.
7. **Check internationalization samples** if you anticipate multilingual expansion.

### Tradeoffs and Rationale

- **Why not use a brand serif or decorative headline everywhere?**
  - While serifs can signal trust, too much contrast or flourish impairs data alignment and scan (especially in dense tables). The proposed optional serif is isolated to marketing hero headings only.
- **Why a single core family?**
  - Reduces visual drift, cognitive switching, and implementation friction. Variable weight coverage in Inter makes full hierarchy mapping clean.
- **Alternative options rejected:**
  - **Roboto**: ubiquitous—can feel generic, less distinctive.
  - **Open Sans**: good fallback, but lacks typographic refinement of Inter.
  - **San Francisco/Apple System Font:** Not open to all, inconsistent metrics across platforms.
  - **Montserrat, Lato, etc:** Poorer numeric alignment, less optimized for dense data.

### Final Summary

**Inter** meets every functional and trust requirement for a modern, cross-platform fintech product:
- Modern neutrality and credibility for both marketing and product UI
- Excellent number handling for tabular/financial data
- Full weight range for hierarchy
- Great cross-platform (web/app/mobile) support
- Easy performance optimization via variable fonts
- Free and open license for unlimited use

**If you want to express a unique brand flavor for major marketing headlines,** selectively add a serif display like DM Serif Display for hero banners—always keeping Inter as the backbone for core/commercial tasks, tables, and UI.

---

#### Next Steps
- Map out your current typography usage to assign precise weights/sizes/roles.
- Replace existing families in design tokens or theme files.
- Test key screens with financial data and export tables to ensure clarity.

If you need starter CSS/type scale examples or Figma tokens for Inter, just ask!