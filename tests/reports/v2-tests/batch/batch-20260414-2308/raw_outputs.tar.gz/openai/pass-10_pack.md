## Poster Critique — Design Conference

### Structural Failure

- **Hierarchy Out of Context**: Leading with a large decorative title before conveying what the event is puts form before function. Without a clear, early signpost (such as “Design Conference” or a tagline), the audience must puzzle out the poster’s meaning, risking confusion or disengagement. Effective posters establish context in the first scan, especially when targeting busy or distracted viewers.

- **Event Information De-emphasized**: The date, in small gray text in the bottom corner, is visually and functionally deprioritized. This risks it being overlooked, especially against a potentially complex city skyline photo. Key logistical information such as date and location must be legible at a glance to drive attendance.

### Visual and Accessibility Tradeoffs

- **Logo Placement and Legibility**: Overlaying a white logo in the center, atop a photographic background, risks insufficient contrast depending on the photo’s brightness and complexity. This can reduce brand recognition (“at the cost of” clarity and accessibility).

- **Decorative Type for Title**: Decorative typefaces can add style, but if not chosen or sized with legibility in mind, they hamper readability, especially at distance or when printed at various sizes. Form cannot outweigh function here.

- **Color and Contrast**: Small gray text on a photo increases the likelihood of failing WCAG AA contrast thresholds. Users with visual impairments or in poor lighting might not be able to read event details. Accessible poster design requires text to maintain strong contrast over varied backgrounds.

### Intervention Order

1. **Restore Logical Hierarchy**: Position the event context (“[Year] Design Conference” or appropriate tagline) near the top or directly beneath the title, so that the audience knows what, where, and when, before being drawn in by visuals.
2. **Elevate Date and Location**: Place date (and location, if missing) in a more prominent, readable spot, with larger size and higher-contrast color, either integrated with the main title area or along a consistent edge.
3. **Logo and Background Handling**: Ensure the logo is always legible — either by adding a translucent overlay, keyline, or ensuring sufficient photo masking/blur. The logo should not compete with the title or event information for attention.

### Tradeoff Resolution

- Prioritizing decorative appeal “at the cost of” clarity and scanning speed undermines the poster’s communication goal. You sacrifice a little visual drama by strengthening structure and accessibility, but you gain impact and functional effectiveness.

### Visual Confidence Boundary

- Confidence in these critiques is high: the described layout maps to common readability and hierarchy pitfalls in poster and large-format event design. However, the exact impact depends on the image complexity, typeface choice, and proportions in the real artifact.

### Summary

**The poster’s current hierarchy and layout place aesthetics above communication, making it harder for viewers to immediately grasp what and when the event is. Without a strong contextual frame and accessible key information, the poster risks failing its core job: to inform and attract the right audience quickly and clearly.**