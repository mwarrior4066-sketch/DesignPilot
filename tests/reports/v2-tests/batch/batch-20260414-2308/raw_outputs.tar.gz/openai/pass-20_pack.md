## Backend Architecture Spec  
**System:** Multi-Tenant Scheduling Platform  
**Features covered:** Team Workspaces · Cursor-based Activity Feeds · Approval Workflows · Outbound Webhooks to Customer Systems

---

### 1. Authority Model

- **Tenant Isolation:**  
  Each customer organization (“tenant”) acts as a distinct namespace.  
  Data, scheduled events, activity feeds, and workflow state are partitioned by tenant.  
  All access tokens and session credentials are hard-scoped to a single tenant boundary—cross-tenant requests are forbidden except for system operators under explicit escalation.

- **Team Roles within Workspaces:**  
  - `admin`: full CRUD on workspaces/events/approvals, manage users, configure webhooks.
  - `member`: create+modify events, request approvals, read feeds, see workspace data.
  - `observer`: read-only access to workspace schedules and feed.
  _Authority enforced server-side for all mutations and sensitive reads (object-level authorization)._

---

### 2. Consistency Stance

- **Primary Model:**  
  Data is single-source-of-truth per tenant, normal strong consistency within a tenant.  
  - **Reads:** Event and feed reads are served from the latest committed state; no eventual consistency for live UI or transactional writes.
  - **Writes & Workflows:** Approvals and status transitions are processed transactionally (no partial workflow state).
- **Feed Delivery:**  
  Feeds support high-volume read, leveraging append-only activity/event log per workspace.
  Cursor-based pagination uses stable sort (isochronous time plus event UUID) to guard against missing or duplicating feed entries in case of concurrent writes.
- **Webhook Delivery:**  
  Outbound webhooks are fired as part of an async, idempotent job—webhook queue state is independent of primary data commit to preserve user transaction consistency in the core application, even if customer systems are slow/offline.

---

### 3. Data Delivery & Boundaries

- **Tenant Context:**  
  - All API requests require a tenant-context identifier (in domain, subdomain, or request header).
  - All data-access and job-execution code paths key off tenant boundaries to enforce isolation.

- **Activity Feeds:**  
  - Feeds are implemented as a logical topic per workspace (e.g. with a Kafka topic or append-only DB table).
  - Feeds support cursor-based pagination:  
    ```
    GET /api/feed?workspace_id=...&cursor=...&limit=N
    ```
    Feed item ordering is deterministic based on (event_timestamp, event_id).

  - To reduce skip/duplicate risk in high-volume teams:  
    Use monotonic, per-workspace logical clock appended to each event for cursor calculation.

- **Approval Workflows:**  
  - Events requiring approval are created as pending, ownership and permitted approver roles attached.
  - Workflow states: `draft` → `pending_approval` → (`approved` | `rejected` | `expired`)
  - All workflow transitions are auditable (event log entry, with actor and timestamp).

- **Webhooks:**  
  - Each tenant can manage one or more outbound webhook endpoints (per event type or globally).
  - All webhooks are dispatched from a durable job queue (e.g. SQS, Redis, or transactional DB-backed queue for at-least-once delivery).
  - Webhook payloads include event data, tenant & workspace context, unique delivery IDs, and canonical resource URLs (for idempotency and security tracing).

  - Webhook failures are retried with exponential backoff and dead-letter if persistent; tenants are notified of failed deliveries with surfaced errors in their workspace admin activity feed.

---

### 4. Observability & Architecture Tax

- **Audit Trail:**  
  All success/failure cases for business mutations (event updates, approval decisions, webhook dispatch) are logged with context (tenant, user, workspace, action, before/after state).

- **Metrics:**  
  - Per-tenant traffic, per-workspace event rates, webhook job state breakdown, approval success/failure rates.
  - Systemwide latency/throughput, with error rates surfaced at both tenant and operator escalation levels.

- **Security/Isolation:**  
  - All authentication tokens are tenant-scoped; API keys, JWTs or session cookies contain tenant ID (signed).
  - Authorization boundaries are enforced early in request lifecycle, before any business or job logic.

- **Webhooks Security:**  
  - Outbound webhooks sign each payload (e.g. HMAC-SHA256) and require HTTPS endpoints.
  - Tenants cannot configure endpoints that would allow recursive delivery or SSRF.

- **Cost surface:**  
  - Activity feeds and webhook queues are implemented to scale per tenant/workspace, but with limits:
    - Per-tenant rate limits (feed queries/sec, events created/hour, webhook dispatches/minute).
    - System-level enforcement to prevent "noisy neighbor" issues in multi-tenant scenarios.

---

### 5. Major Tradeoff

- **Strong tenant isolation** is chosen even at the cost of additional duplicate infrastructure for feed logs and job queues per tenant, to prevent cross-tenant data leakage and security escalation.
- **Strict workflow transactional guarantees** are prioritized over in-UI latency, so rare global latency spikes may occur when multiple approvals or event changes are processed in rapid succession.
- **Webhook delivery is non-blocking and idempotent.** This means:
  - User-facing transactions do not wait on third-party systems but delivery ordering is not strictly real-time.
  - At-least-once delivery guarantees may result in retries to customer systems—outbound webhook payloads include explicit idempotency keys and sequencing metadata to prevent duplicate side effects.

---

## Summary Table

| Architecture Layer | Model / Mechanism | Key Constraint                    | Tradeoff                                   |
|--------------------|------------------|-----------------------------------|--------------------------------------------|
| Authority          | Tenant & workspace scoping  | Strict isolation, object-level roles | More ops/infrastructure per tenant         |
| Consistency        | Strong within tenant         | Transactional workflow steps        | No eventual consistency for feeds/workflows|
| Feeds              | Append-only log, cursor pagination | Monotonic ordering, stable cursors  | Slightly slower writes, consistent reads   |
| Approvals          | State machine per event, auditable | No partial transitions, full audit   | Extra logic per state change               |
| Webhooks           | Async, durable job queue   | Idempotent, secure, with retries     | Delivery lags behind mutation, possible repeats |
| Observability      | Comprehensive audit + metrics | All mutating actions, webhook failures tracked | Per-tenant and system-level logging/storage|
| Security           | Per-tenant auth + HMAC webhooks | Request isolation, signed payloads   | More up-front integration friction         |

---

### Required decisions satisfied:
- **authority_model**: tenant isolation, object-level roles, scoped tokens
- **consistency_stance**: strong per-tenant, transactional workflow
- **data_delivery**: feed log, cursor pagination, durable webhook queues
- **observability_tax**: audit trail, per-tenant and global metrics, rate limits  
- **tradeoff_resolution**: prioritized security/isolation at cost of infra and integration friction

---

**This architecture supports secure multi-tenant operation, guarantees data partitioning, delivers traceable approval/audit records, and gives customer IT teams reliable webhook integrations with clear idempotency and failure-handling models.**