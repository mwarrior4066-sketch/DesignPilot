To reconstruct your layout system from the 2018 brand guidelines PDF for new templates, I will use a structured approach, separating observed evidence from inferred structure, and then translating it into a modern, flexible system. This process is governed by the `rt_layout_reconstruction_plan` route, supported by `layout-reconstruction-expert`, `grid-system-expert`, and `pdf-layout-expert` skills.

### Extraction Strategy from PDF (Observed Evidence & Inferred Structure)

I will perform a visual pre-pass on the PDF, extracting specific information while noting confidence levels.

#### 1. Explicit Grid Definitions (High Confidence - Observed)
*   **Page Margins:** Measure consistent top, bottom, left, and right margins across different page types.
*   **Column Structure:** Identify the number of columns used in various layouts (e.g., 1-column, 2-column, 3-column), their widths, and the widths of the gutters between them. Note if these are fixed pixel/point values or appear proportional.
*   **Baseline Grid (If present):** Look for explicit instructions on vertical rhythm or consistent vertical spacing that suggests a baseline grid. If not explicit, I'll infer a fundamental line-height.
*   **Module Sizes:** If the guidelines show modular blocks or consistent spacing units for content elements, I will extract these.

#### 2. Layout Patterns and Content Placement (Medium to High Confidence - Observed & Inferred)
*   **Content-to-Grid Mapping:** Document how different content types (headings, body text, images, captions, lists, tables) are positioned within the defined columns and modules.
*   **Hierarchy Cues:** Analyze typography scale, spacing above/below headings, and indentation to understand the visual hierarchy and its relationship to the layout.
*   **Image Sizing & Alignment:** Observe common image aspect ratios, scaling behavior, and alignment rules within the grid.
*   **Implicit Spacing:** Systematically measure consistent vertical and horizontal spacing between elements (paragraphs, list items, image-to-caption) to identify underlying spacing principles.

#### 3. Typography and Color (Low Confidence for Layout-Specific Inference)
While not the primary focus, observed typographic elements and color usage can inform layout decisions, especially if they dictate spacing or visual weight. I will note approximate type scale and key color usage, but will not infer deeper type or color system rules without explicit instruction.

---

### Translation to a Modern Layout System

The reconstruction will translate the static, print-oriented directives into a dynamic, adaptable layout system suitable for digital and flexible template usage.

#### 1. Abstraction to a Flexible Grid System (`preserved_elements`)
*   **Unit Conversion:** Convert fixed pixel/point measurements from the PDF (margins, column widths, gutters) into relative units like `rem` (for spacing and typography) and `fr` (for flexible column sizing in CSS Grid).
*   **CSS Grid / Flexbox Foundation:** Define a responsive grid system using modern CSS Grid properties (`grid-template-columns`, `gap`) and Flexbox where appropriate for component-level internal layouts. This allows for fluid adaptation rather than fixed dimensions.
*   **Container System:** Establish `max-width` properties for content containers to maintain readability on large screens, while allowing fluid behavior within those bounds.

#### 2. Modular Spacing System (Design Tokens)
*   **Tokenization:** Abstract the extracted implicit and explicit spacing values into a finite, named design token scale (e.g., `space-2xs`, `space-xs`, `space-sm`, `space-md`, `space-lg`, etc.). This ensures consistency across new templates.
*   **Vertical Rhythm:** If a baseline grid was identified, this will inform the base `line-height` and vertical spacing tokens to maintain a consistent rhythm.

#### 3. Content-to-Grid Integration
*   **Component Slotting:** Define how common content components (e.g., `TextBlock`, `Image`, `Heading`, `List`) should occupy or span columns within the new grid system.
*   **Layout Utilities:** Create utility classes or props (e.g., `col-span-2`, `margin-bottom-md`) that leverage the new grid and spacing tokens, enabling flexible but governed layouts.

#### 4. Responsiveness and Adaptability (`inference_boundary`)
*   **Breakpoint Inference:** Since the 2018 PDF likely lacks explicit digital breakpoints, I will **infer** a pragmatic set of responsive breakpoints (e.g., mobile, tablet, desktop) based on common device widths and the layout complexity observed in the original. This is a significant `inference_boundary` as it introduces new, unstated behavior.
*   **Reflow Strategies:** Propose how layouts should reflow or stack on smaller screens (e.g., multi-column layouts collapsing to single column).

#### 5. Documentation and Governance (`reconstruction_order`)
*   **System Specification:** Document the new layout system comprehensively, including grid definitions, spacing tokens, responsive behaviors, and content-to-grid mapping.
*   **Guidelines for New Templates:** Provide clear instructions and examples for applying the reconstructed system to new templates, ensuring consistency and ease of implementation.

---

### Tradeoffs and Validation

*   **Tradeoff (`sr_tradeoff_visibility`):** The translation from a fixed, print-specific layout (observed from PDF) to a fluid, responsive digital system (inferred for modern templates) inevitably involves a **tradeoff**. We gain **flexibility, adaptability to various screen sizes, and a component-friendly foundation** at the cost of **losing pixel-perfect replication of every original print detail** and introducing **inferred responsive behaviors** that were not present in the original guidelines.
*   **Verification Method (`verification_method`):** To validate the reconstructed system, I would propose:
    1.  **Visual Comparison:** Render key template examples using the new system and visually compare them against the original PDF layouts to ensure fidelity where intended.
    2.  **Stress Testing:** Test the new system with varying content lengths, image sizes, and dynamic data to ensure robustness and graceful degradation.
    3.  **Developer Review:** Collaborate with front-end developers to ensure the system is implementable, performant, and aligns with modern best practices.