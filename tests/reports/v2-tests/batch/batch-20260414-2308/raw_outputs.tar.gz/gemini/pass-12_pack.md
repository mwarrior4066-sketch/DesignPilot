For a fintech product requiring a type system that spans a marketing site, a web app dashboard, and mobile, while feeling modern and trustworthy, excelling with tabular financial data, and supporting robust hierarchy through multiple weights, I recommend **Inter** as your primary typeface.

Inter is a highly optimized variable font designed specifically for user interfaces, which positions it exceptionally well for your diverse product needs.

### Recommended Type System: Inter

**Primary Typeface:** Inter (Google Fonts)

---

### Reading Context (`reading_context`)

Inter excels across the specified reading contexts due to its clear letterforms, generous x-height, and meticulous design for screen legibility.

*   **Marketing Site:** Its modern, professional aesthetic ensures brand trustworthiness without feeling cold. Inter's range of weights allows for expressive headlines and highly readable body text, maintaining engagement while conveying authority.
*   **Web App Dashboard:** This is where Inter truly shines for fintech. Its excellent numeral differentiation (e.g., clear 0, 1, and lowercase l) and consistent character width make it highly effective for dense tabular financial data, ensuring accurate reading and scanability. The various weights also clearly delineate KPIs, labels, and action items.
*   **Mobile:** Designed for UI, Inter performs consistently at smaller sizes on high-DPI screens, maintaining legibility and clarity essential for mobile banking or financial management. Touch targets with associated text remain clear and unambiguous.

**Causal Grounding:** Inter's design principles prioritize clarity and optical correction at small sizes, which directly translates to enhanced legibility and reduced cognitive load across all three distinct user environments, especially critical for accuracy in financial contexts.

### Scale Decisions and Hierarchy (`scale_decision`)

Inter offers a comprehensive range of weights, typically from Thin to Black, which provides fine-grained control over visual hierarchy without resorting to multiple font families.

*   **Weight Range:** With 9 weights (plus italics), you can establish a clear hierarchical scale for headings (e.g., Black/Extra Bold), subheadings (Semi-Bold/Medium), body text (Regular), and fine print/metadata (Light). This ensures that critical information stands out and related information is grouped effectively.
*   **Variable Font Capabilities:** As a variable font, Inter allows for precise adjustments along its weight axis. This enables subtle, programmatic control over visual density and emphasis, which can be invaluable for responsive design and maintaining consistent visual stress across different screen sizes and data densities on the dashboard.

**Causal Grounding:** The extensive weight axis and variable font support provide a robust system for establishing clear information hierarchy. This is crucial because it allows users to quickly scan and understand the relative importance of financial data points and navigate complex interfaces efficiently, directly impacting usability and error reduction.

### Pairing Rationale (`pairing_rationale`)

For a fintech product, a strong, singular sans-serif is often the safest and most trustworthy approach. Inter can effectively be used as the sole typeface across all contexts.

*   **Single-Font Strategy (Recommended Default):** Using Inter exclusively minimizes asset load, simplifies design system governance, and ensures consistent brand perception across all touchpoints. Its versatility allows it to cover all required roles from expressive headlines to data tables.
*   **Optional Pairing (Marketing Context):** If a more distinct brand voice is desired for the marketing site's large display headings, a carefully chosen serif font could be introduced. However, this is a tradeoff.

    *   **Serif for Marketing Headlines (e.g., Lora, Playfair Display):** A contrasting serif could add sophistication and warmth, softening the purely functional feel.
    *   **Monospace for Code/Specific Data (e.g., Fira Code, IBM Plex Mono):** For very specific technical displays or code snippets within documentation, a monospace font would be appropriate.

**Tradeoff Resolution:** The primary recommendation is a single-font strategy with Inter because it prioritizes clarity, performance, and cross-platform consistency — essential for a trustworthy fintech brand — at the cost of a potentially more unique, but also more complex, brand-specific typographic expression. A single font reduces implementation complexity and potential visual dissonance across marketing and product.

### Adoption Sequence (`adoption_sequence`)

A phased approach will ensure a smooth transition and allow for validation at each step.

1.  **Pilot Implementation (Dashboard):** Begin by implementing Inter within a core section of the web app dashboard. This allows for rigorous testing of its performance with tabular data, legibility at various zoom levels, and consistency across different components.
2.  **Style Guide Integration:** Document Inter's usage rules, including weight assignments for different semantic elements (H1, H2, body, labels, data points), line heights, and letter spacing. Define a core typographic scale.
3.  **Marketing Site Rollout:** Apply Inter across the marketing site, using its full range of weights to establish compelling visual hierarchy and a modern feel.
4.  **Mobile App Integration:** Port the established Inter type system to the mobile application, verifying responsiveness, readability on smaller screens, and accessibility considerations (e.g., dynamic type scaling).
5.  **Accessibility Audit:** Conduct a full accessibility audit (WCAG 2.1+) to ensure that all text elements meet contrast requirements, readability standards, and scale appropriately for users with diverse needs.

**Causal Grounding:** This sequence prioritizes validating the critical functional requirements of the dashboard first because legibility of financial data is paramount. Without successful implementation there, the system would fail its core purpose, regardless of marketing appeal. This structured rollout mitigates risk and ensures that the practical needs of the product are met before broader aesthetic considerations dominate.

---
[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing_site_web_app_dashboard_mobile",
    "scale_decision: multiple_weights_and_variable_font",
    "pairing_rationale: single_font_strategy_with_optional_serif_or_monospace",
    "adoption_sequence: phased_implementation_starting_with_dashboard"
  ],
  "evidence_classes_cited": [
    "design_principle",
    "usability_consideration",
    "technical_capability",
    "tradeoff_analysis",
    "risk_mitigation"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]