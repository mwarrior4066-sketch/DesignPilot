A robust color system for a healthcare SaaS dashboard must balance clear communication, accessibility, and adaptability across themes. This system will define semantic roles for UI elements, status states, and data visualization, ensuring WCAG AA compliance and dark mode support.

## Color System Specification for Healthcare SaaS Dashboard

### 1. Semantic Roles and Core Palette (`semantic_roles`)

The core palette establishes the foundational colors for the dashboard's interface, favoring clarity and trust crucial in healthcare.

*   **Primary Accent**: A cool-toned color (e.g., a moderate blue or teal) for primary calls to action, active states, and key navigational elements. This visually anchors the brand and guides user focus.
    *   *Light Mode Example*: `#007BFF` (Blue 500)
    *   *Dark Mode Example*: `#66B2FF` (Blue 300)
*   **Neutral Palette**: A range of greys for backgrounds, surfaces, borders, and secondary text. This ensures readability and reduces visual noise.
    *   *Light Mode Example (Backgrounds)*: `#F8F9FA` (Grey 50)
    *   *Light Mode Example (Surfaces)*: `#FFFFFF` (White)
    *   *Dark Mode Example (Backgrounds)*: `#1A1A1A` (Grey 900)
    *   *Dark Mode Example (Surfaces)*: `#2B2B2B` (Grey 800)
*   **Text Colors**: High-contrast options for primary, secondary, and disabled text against both light and dark backgrounds.
    *   *Light Mode Example (Primary Text)*: `#212529` (Grey 900)
    *   *Dark Mode Example (Primary Text)*: `#E0E0E0` (Grey 100)

### 2. Status State Mapping (`state_mapping`)

Clear communication of status is critical in a healthcare context. These colors convey immediate meaning and are distinct across both themes.

*   **Normal / Success**: Represents a healthy, stable, or successful state. Often green.
    *   *Light Mode Example*: `#28A745` (Green 500)
    *   *Dark Mode Example*: `#5cb85c` (Green 300)
*   **Warning / Attention**: Indicates an issue that requires attention but is not immediately critical. Often amber or orange.
    *   *Light Mode Example*: `#FFC107` (Yellow 500)
    *   *Dark Mode Example*: `#FFD700` (Yellow 300)
*   **Critical / Alert**: Signifies an urgent, severe, or error state that needs immediate action. Always red.
    *   *Light Mode Example*: `#DC3545` (Red 500)
    *   *Dark Mode Example*: `#FA8072` (Red 300)
*   **Information**: For general informational messages that are not status-driven. Often a lighter blue.
    *   *Light Mode Example*: `#17A2B8` (Cyan 500)
    *   *Dark Mode Example*: `#87CEEB` (Cyan 300)

### 3. Data Visualization Categorical Palette

To support at least 5 distinct data categories, a carefully chosen palette is required that ensures perceptual distinction, even for users with color vision deficiencies.

*   **Categorical 1 (Primary)**: Example Blue `#007BFF` (reusing primary accent)
*   **Categorical 2 (Secondary)**: Example Orange `#FD7E14`
*   **Categorical 3 (Tertiary)**: Example Teal `#20C997`
*   **Categorical 4 (Quaternary)**: Example Purple `#6F42C1`
*   **Categorical 5 (Quinary)**: Example Pink `#E83E8C`
*   **Categorical 6+ (Optional)**: Extend with desaturated versions or additional hues (e.g., Brown, a lighter Green) that maintain distinction.

This palette should be tested for colorblind-friendliness using tools like Color Safe or simulating different vision types because misinterpreting data can have critical implications in healthcare.

### 4. Dark Mode Support

Dark mode is implemented by defining corresponding color tokens that adapt the UI without altering the semantic meaning of colors. This requires a dedicated set of tokens because simply inverting colors often leads to poor contrast or readability.

*   **Backgrounds**: Shift from light greys to deep, muted dark greys (e.g., `#1A1A1A`).
*   **Surfaces/Containers**: Slightly lighter dark greys to provide depth (e.g., `#2B2B2B`).
*   **Text**: Lighter text colors (e.g., `#E0E0E0`) are used against dark backgrounds to maintain WCAG AA contrast.
*   **Status & Categorical Colors**: While the hues remain consistent, their lightness/saturation may be adjusted. Dark mode status colors will typically be brighter than their light mode counterparts to stand out against a dark background, because a direct dark inverse can appear muddy or difficult to distinguish. For example, a bright red for 'Critical' in light mode might be slightly desaturated or a deeper red, whereas in dark mode it would be a vibrant, distinct red. This means accepting a slight shift in perceived vibrancy to maintain legibility.

### 5. Contrast Boundaries (`contrast_boundary`)

All text within the dashboard must meet WCAG AA contrast standards.

*   **Normal Text (14pt/18.66px and smaller)**: Minimum contrast ratio of **4.5:1**.
*   **Large Text (18pt/24px or 14pt/18.66px bold and larger)**: Minimum contrast ratio of **3:1**.
*   **Non-Text UI Components (e.g., icons, input borders, chart elements)**: Minimum contrast ratio of **3:1** against adjacent colors because these elements convey information.
*   **Verification Method**: Contrast ratios will be verified using automated tools during design and development, complemented by manual checks on critical UI paths. This requires defining a clear color token usage guide.

### 6. Implementation and Migration Strategy (`migration_strategy`)

To ensure consistency and maintainability, the color system should be implemented using design tokens.

*   **Design Tokens**: Define all colors as semantic tokens (e.g., `--color-text-primary`, `--color-status-critical`, `--color-data-categorical-1`). These tokens should map to specific hex values for light and dark themes. This provides a single source of truth, without which maintaining color consistency across a complex SaaS product becomes impossible.
*   **Theming Logic**: Implement a theming mechanism (e.g., CSS variables) that allows easy switching between light and dark modes by changing a single class on the root element.
*   **Documentation**: Create comprehensive documentation of all color tokens, their intended use cases, and their light/dark mode variants. Include examples of WCAG AA compliance for common text/background pairings.
*   **Gradual Rollout (if existing product)**: If this is a new system for an existing product, prioritize critical UI elements (text, status indicators) for migration first. This means accepting a temporary period of mixed styles to gain the benefit of improved accessibility and maintainability.