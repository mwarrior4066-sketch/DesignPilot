Here is a component specification for the split button, detailing its structure, states, accessibility, and implementation considerations.

## Split Button Component Specification

This specification outlines the requirements for a split button component, which combines a primary, immediate action with a dropdown for secondary actions.

### 1. Component Boundary (component_boundary)

*   **Component Name**: Split Button
*   **Purpose**: To group a primary, frequently used action with a set of related, secondary actions under a single, visually cohesive component. This optimizes for common workflows while providing access to less frequent but related options.
*   **Structure**: The component consists of two distinct, interactive parts that are visually grouped:
    1.  **Primary Action Button**: Displays the main action (e.g., "Save"). This button performs its action immediately upon activation.
    2.  **Dropdown Trigger Button**: Typically displays an icon (e.g., a caret) and, when activated, reveals a menu of secondary actions.
*   **Relationship**: The primary action button and dropdown trigger are adjacent and styled to appear as a single unit, but are independently actionable controls.
*   **Variants**: Future considerations may include icon-only primary buttons (requiring `aria-label` for accessibility) or primary actions with leading icons.

### 2. State Coverage (state_coverage)

The split button must support the following states for both its primary action and dropdown trigger, communicating current status and interactivity.

*   **Default**:
    *   **Behavior**: Both the primary action button and the dropdown trigger are enabled and interactive. The dropdown menu is closed.
    *   **Visual**: Displays standard enabled styling.
*   **Hover/Focus**:
    *   **Behavior**: When a pointer hovers over either the primary action or the dropdown trigger, or when either receives keyboard focus.
    *   **Visual**: Provides distinct visual feedback (e.g., background color change, border highlight) to indicate interactivity. The dropdown menu remains closed until explicitly opened.
*   **Active/Pressed**:
    *   **Behavior**: When either button is pressed (e.g., mouse down, touch tap, keyboard `Enter`/`Space`).
    *   **Visual**: Provides visual feedback indicating activation (e.g., slightly darker background, subtle press animation). If the dropdown trigger is activated, the dropdown menu becomes visible.
*   **Disabled**:
    *   **Behavior**: Both the primary action button and the dropdown trigger are non-interactive. They do not respond to clicks, hovers, or keyboard input.
    *   **Rationale**: Prevents users from attempting actions that are currently unavailable due to data constraints, permissions, or system state. This reduces user confusion and avoids potential error messages.
    *   **Tradeoff**: Sacrifices immediate user feedback about *why* the button is disabled for clarity on *what* cannot be done. A tooltip or status message near the button can mitigate this by providing context for the disabled state.
    *   **Visual**: Displays a distinct disabled style (e.g., reduced opacity, grayed out text/icon, no hover effects).
*   **Loading**:
    *   **Behavior**: When the primary action (or any action triggered by the button) is in progress. Both the primary button and the dropdown trigger become disabled to prevent duplicate submissions or conflicting actions.
    *   **Rationale**: Clearly communicates that an operation is active, manages user expectations regarding response time, and prevents accidental re-triggers.
    *   **Tradeoff**: The loading indicator temporarily replaces the primary action's label, requiring users to infer the ongoing action based on its prior context.
    *   **Visual**: The primary action button replaces its text/icon with a loading indicator (e.g., a spinner). The dropdown trigger adopts a disabled style.
*   **Dropdown Open**:
    *   **Behavior**: The dropdown menu containing secondary actions is visible, typically positioned directly below or adjacent to the dropdown trigger.
    *   **Visual**: The dropdown trigger may adopt an "active" or "pressed" visual state, and the menu itself is rendered above other page content (using `z-index`).

### 3. Accessibility Behavior (accessibility_behavior)

Robust accessibility is critical for inclusive interaction.

*   **Keyboard Support**:
    *   **Focus Order**: Pressing `Tab` moves focus sequentially: first to the Primary Action button, then to the Dropdown Trigger button.
    *   **Primary Action**: `Enter` or `Space` activates the primary action when focused.
    *   **Dropdown Trigger**: `Enter` or `Space` toggles the visibility of the dropdown menu when focused.
    *   **Menu Navigation**: When the dropdown menu is open:
        *   `ArrowDown` moves focus to the first item in the dropdown menu.
        *   `ArrowUp` and `ArrowDown` navigate between menu items.
        *   `Home` moves focus to the first item, `End` to the last.
        *   `Escape` closes the dropdown menu and returns focus to the Dropdown Trigger button.
*   **ARIA Roles & Attributes**:
    *   **Primary Action**: Utilizes `role="button"` (if not a native `<button>` element) and has a clear accessible name (either from visible text content or `aria-label`).
    *   **Dropdown Trigger**: Utilizes `role="button"` (if not a native `<button>` element), `aria-haspopup="menu"` to indicate it controls a menu, and `aria-expanded="true/false"` to convey whether the menu is open or closed. A clear accessible label (e.g., "More save options") is provided via `aria-label`.
    *   **Dropdown Menu**: Utilizes `role="menu"` for the container, with each secondary action item inside using `role="menuitem"`. The menu itself is dynamically shown/hidden using the `hidden` attribute or `display: none` for better semantic hiding.
*   **Mobile Touch Targets**:
    *   **Size**: Both the primary action button and the dropdown trigger must meet a minimum touch target size of **44x44 CSS pixels**, as specified by WCAG 2.1 Success Criterion 2.5.5 (Target Size).
    *   **Spacing**: Sufficient spacing must exist between the primary action and the dropdown trigger to minimize the risk of accidental activation of the wrong control on touch devices.
    *   **Rationale**: Ensures reliable interaction for users with motor impairments, those using less precise input methods (like a stylus), or in situations where device handling is unsteady.
    *   **Tradeoff**: Meeting larger touch target requirements may consume more screen real estate, especially on compact mobile viewports, potentially affecting information density. Careful design is needed to balance usability and space.

### 4. Implementation Boundary (implementation_boundary)

This section defines the expected front-end implementation structure and logic.

*   **Semantic Markup Structure**:
    ```html
    <div class="split-button-container">
      <button id="save-button" class="split-button__primary" type="button">
        Save
      </button>
      <div class="split-button__dropdown-wrapper">
        <button id="save-options-trigger" class="split-button__trigger" type="button" aria-haspopup="menu" aria-expanded="false" aria-label="More save options">
          <span class="icon-caret-down" aria-hidden="true"></span>
        </button>
        <ul id="save-options-menu" class="split-button__menu" role="menu" hidden>
          <li role="none"><button role="menuitem" type="button" tabindex="-1">Save as draft</button></li>
          <li role="none"><button role="menuitem" type="button" tabindex="-1">Save and close</button></li>
        </ul>
      </div>
    </div>
    ```
    *   The `tabindex="-1"` on `menuitem` buttons is crucial for JavaScript to manage focus inside the `role="menu"` correctly without interference from browser tab order.
*   **Dependencies**: Requires a base button component styling, an icon system for the caret, and possibly a utility for accessible dropdown positioning.
*   **Styling Considerations**:
    *   The `.split-button-container` should use `display: inline-flex` (or similar) to ensure the primary button and dropdown trigger are visually grouped.
    *   The `.split-button__primary` and `.split-button__trigger` will share core button styles, with the trigger potentially having a distinct visual separation (e.g., a subtle border, different background color on its left edge) to visually distinguish it as a separate interactive target.
    *   The `.split-button__menu` must be positioned absolutely, with a sufficient `z-index` to appear above other content. It must be semantically hidden (e.g., using the `hidden` attribute or `display: none`) when closed.
*   **Interaction Logic (JavaScript)**:
    *   **Dropdown Toggle**: JavaScript handles click events on the `.split-button__trigger` to toggle the `aria-expanded` attribute and the `hidden` attribute (or `display` style) of the `.split-button__menu`. It also handles clicks outside the menu to close it.
    *   **Keyboard Management**: Dedicated JavaScript is required to manage focus within the dropdown menu, ensuring `ArrowUp`/`ArrowDown` navigation, `Home`/`End` behavior, and `Escape` key handling correctly moves focus and closes the menu.
    *   **State Propagation**:
        *   **Disabled**: The `disabled` HTML attribute is applied to both `<button>` elements (`#save-button` and `#save-options-trigger`) when the component is in a disabled or loading state.
        *   **Loading**: The content of the `#save-button` is dynamically replaced with a loading indicator (e.g., an SVG spinner). The `disabled` attribute is also applied to both buttons.
    *   **Event Handling**: The primary button triggers the "Save" action directly. The menu items trigger "Save as draft" and "Save and close" respectively, closing the menu after activation.