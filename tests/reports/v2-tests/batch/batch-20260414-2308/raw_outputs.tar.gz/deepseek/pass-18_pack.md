[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": ["problem_details_contract: RFC 9457", "authorization_perimeter: object-level authorization required", "idempotency_contract: idempotency-key header required", "async_job_model: not applicable", "resilience_strategy: not applicable"],
  "evidence_classes_cited": ["threshold", "standard_reference"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Governing Decisions

1.  **Problem Details Contract**: The error response must be a structured JSON object following RFC 9457 (Problem Details for HTTP APIs), not a plain string.
2.  **Authorization Perimeter**: The endpoint must enforce object-level authorization (BOLA check). The caller must be a project admin, not just any logged-in user.
3.  **Idempotency Contract**: The endpoint must be idempotent and require an `Idempotency-Key` header to safely handle retries and prevent duplicate member additions.

## Architectural Review

### 1. Error Response (Problem Details Contract)
**Decision**: Adopt RFC 9457 for all error responses.
**Reasoning**: A plain string error provides no machine-readable structure for clients to handle failures programmatically. It lacks a standard `type` URI, a specific `title`, the HTTP `status`, and a detailed `detail` message. This forces clients to parse fragile, human-oriented strings, breaking automation and degrading developer experience. RFC 9457 is the modern standard for HTTP API errors.

**Revised Error Response Example (403 Forbidden)**:
```json
{
  "type": "https://api.example.com/errors/forbidden",
  "title": "Insufficient Permissions",
  "status": 403,
  "detail": "Caller must be a project administrator to add members.",
  "instance": "/api/v1/projects/abc-123/members"
}
```

### 2. Authorization (Authorization Perimeter)
**Decision**: Implement object-level authorization (BOLA).
**Reasoning**: Checking only for a logged-in user is a Broken Object Level Authorization (BOLA) vulnerability. Any user who knows a project ID could add members to it. The correct model is a deny-by-default perimeter: the caller must possess a specific privilege (e.g., `project:admin`) for the target project resource. This is a non-negotiable security requirement.

**Implementation**:
*   **Pre-condition**: Validate the caller's session.
*   **Authorization Check**: Verify the caller's role within the specific project `{id}` includes admin privileges.
*   **Failure**: Return 403 Forbidden with a Problem Details object if the check fails.

### 3. Idempotency & Duplicate Prevention (Idempotency Contract)
**Decision**: Require an `Idempotency-Key` header for POST, PATCH, and other non-idempotent operations.
**Reasoning**: Without idempotency handling, network retries or client double-clicks can lead to duplicate members. A 200 response on duplicate requests is incorrect behavior. The standard pattern is for the client to send a unique `Idempotency-Key` header (e.g., a UUID). The server stores this key with the request's result. A subsequent request with the same key returns the stored response (e.g., 200 with the same member list) without executing the operation again. A missing key should result in a 428 Precondition Required response, guiding clients to use the contract.

**Implementation Flow**:
1.  Client sends `POST /api/v1/projects/{id}/members` with header `Idempotency-Key: 123e4567-e89b-12d3-a456-426614174000`.
2.  Server checks for a stored response for this key + project ID.
3.  **If found**: Return the stored response (200 with member list).
4.  **If not found**: Execute auth check, add member, store the result with the key, and return 200.
5.  **If key missing**: Return 428 with a Problem Details object explaining the requirement.

### 4. Success Response (200 OK)
**Decision**: 200 OK is acceptable, but 201 Created is more semantically precise.
**Reasoning**: A POST request that creates a new subordinate resource (a project membership) should typically return 201 Created with a `Location` header pointing to the new resource. However, if the membership is not a separately addressable resource and the endpoint returns the *entire* updated project member list, 200 OK is defensible. The primary issues are the missing idempotency and authorization, not the success code.

**Recommendation**: If a membership has its own ID/URI, use 201 Created and return the new member object. If not, 200 OK with the full list is fine, but ensure the idempotency contract prevents duplicates.

## Summary of Required Changes
1.  **Replace all plain-string errors** with RFC 9457 Problem Details JSON objects.
2.  **Add an object-level authorization check** requiring project admin rights.
3.  **Implement idempotency** via required `Idempotency-Key` header, returning 428 if missing and handling duplicates correctly.
4.  **(Optional) Consider 201 Created** if a new addressable resource is created.

These changes transform the endpoint from a vulnerable, client-unfriendly operation into a secure, reliable, and professionally contracted API surface.