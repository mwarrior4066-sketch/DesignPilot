**Audit: B2B SaaS pricing page**

**Primary failure:** The page is visually structured but fails at conversion clarity and accessibility. The hero’s CTA is undersized and the pricing table’s color-coding creates a WCAG 2.1 contrast failure. The layout also misses an opportunity to guide the user toward a confident decision.

---

### 1. **Hierarchy and conversion flow**
- **Hero CTA is too small** — In a B2B context, the primary action should be immediately scannable and tap‑friendly. The current proportion risks being overlooked.
- **Pricing table color‑coding highlights Pro** — Good intent, but the chosen colors likely fail contrast thresholds (see below). This undercuts the visual emphasis.
- **Testimonials are placed after the feature table** — This is a logical sequence, but they could be integrated closer to the pricing decision to reinforce trust at the moment of choice.

### 2. **Accessibility failures**
- **Color‑coding in the pricing table** — If the highlight relies only on color (e.g., a light background tint), users with low vision or color‑blindness won’t perceive the differentiation.  
  *WCAG 1.4.1 Use of Color* requires a non‑color indicator (icon, label, border weight, texture) to convey the same information.
- **Contrast likely insufficient** — Light tinted backgrounds often have contrast ratios below 4.5:1 against black text. This violates *WCAG 1.4.3 Contrast (Minimum)*.
- **Custom “Enterprise” tier** — If the “Contact us” link is not clearly a button or focusable, keyboard and screen‑reader users may miss it.

### 3. **Information architecture**
- **Three‑column pricing** — Clear and standard.
- **Feature comparison table** — Helpful, but could be simplified. Consider grouping features by job‑to‑be‑done (e.g., “Collaboration,” “Security,” “Support”) rather than a flat list.
- **Testimonials strip** — Good social proof, but the strip format can feel generic. Adding a photo, role, and company logo to each testimonial increases credibility.

### 4. **Visual and interaction details**
- **Hero background image** — Ensure it doesn’t reduce text legibility. Add a dark overlay if needed.
- **Pricing cards** — The “Pro” card should have a stronger visual elevation (border, shadow, icon) beyond color alone.
- **CTA buttons** — Use consistent button styling across the page. The hero CTA should be the largest button on the page.

---

### **Recommended fixes**

1. **Enlarge the hero CTA**  
   - Minimum tap target: 44×44px.  
   - Use a high‑contrast button color that stands out from the background image.

2. **Repair the pricing table accessibility**  
   - Add a checkmark icon or “Recommended” badge to the Pro tier.  
   - Ensure background‑tint contrast meets 4.5:1 for normal text.  
   - Provide a visible border (2px) around the highlighted card.

3. **Strengthen the decision path**  
   - Insert a short “Most teams choose Pro” line above the pricing table.  
   - Move one testimonial next to the Pro card (or add a “Trusted by [logos]” strip above the table).  
   - Make the Enterprise “Contact us” a proper button, not just a text link.

4. **Simplify the feature table**  
   - Group features into 3‑4 categories.  
   - Use icons to aid scanning.  
   - Hide advanced features under a “See all features” expander for Starter and Pro tiers.

5. **Verify contrast everywhere**  
   - Run the page through a contrast checker (e.g., WebAIM Contrast Checker).  
   - Test the color‑coding in grayscale mode to confirm the highlight remains visible.

---

### **Tradeoffs**
- **Adding visual weight to the Pro tier** may reduce Starter conversions, but in B2B, guiding users toward the tier that best fits team needs improves overall satisfaction and reduces churn.
- **Grouping features** adds a small cognitive step but reduces visual clutter and helps users match features to their own jobs.

---

### **Next steps**
1. Adjust the hero CTA size and contrast.
2. Replace color‑only highlighting with an icon + border.
3. Re‑test the page with keyboard navigation and a screen‑reader.
4. Consider A/B testing the grouped feature table vs. the flat list.

Would you like a quick mockup of the repaired pricing table, or a WCAG‑focused color palette for the tier highlights?