I'll write a component spec for a split button with primary action, dropdown, and full state coverage.

**Component: SplitButton**

## Purpose
A split button combines a primary action button with a dropdown trigger for secondary related actions. It saves space while keeping the most common action immediately accessible.

## Anatomy
```
[ Primary action label ] [ Dropdown trigger icon ]
└── Button segment       └── Trigger segment
```

## Variants
- **Default** – Primary action + dropdown trigger
- **Icon-only trigger** – Primary action + chevron icon (no separate label)
- **Compact** – Reduced padding for dense interfaces

## States

### Primary segment
- **Default** – Ready for interaction
- **Hover** – Visual feedback on mouseover
- **Focus** – Keyboard navigation indicator (2px outline, 4px offset)
- **Active** – Pressed state (deeper shadow, color shift)
- **Disabled** – 40% opacity, `pointer-events: none`, `aria-disabled="true"`
- **Loading** – Spinner replaces label, `aria-busy="true"`, action disabled during load

### Trigger segment
- **Default** – Ready to open dropdown
- **Hover** – Visual feedback
- **Focus** – Keyboard navigation indicator
- **Active** – Pressed state
- **Disabled** – Inherits from parent disabled state
- **Expanded** – Dropdown is open, `aria-expanded="true"`

## Accessibility

### Keyboard support
- **Tab** – Focus moves to primary segment first
- **Enter/Space** on primary segment – Activates primary action
- **ArrowDown/Enter/Space** on trigger segment – Opens dropdown
- **ArrowUp/ArrowDown** in dropdown – Navigates menu items
- **Escape** – Closes dropdown, returns focus to trigger
- **Tab** in dropdown – Moves through menu items, closes on exit

### ARIA attributes
```html
<div role="group" aria-label="Save actions">
  <button aria-label="Save">
    Save
  </button>
  <button 
    aria-haspopup="menu" 
    aria-expanded="false"
    aria-label="More save options"
  >
    ▾
  </button>
</div>
```

### Screen reader announcements
- Dropdown open/close state announced
- Loading state announced
- Disabled state announced

## Mobile touch targets
- **Minimum touch target**: 44×44px (WCAG 2.5.5)
- **Segment spacing**: 1px visual separation, but combined touch area
- **Long press** on primary segment could show context menu with all options (optional enhancement)

## Dropdown behavior
- **Position**: Below trigger, aligned right
- **Width**: Matches combined button width (min 200px)
- **Items**: Each secondary action as `button` or `a` element
- **Selection**: Click/tap selects and closes
- **Outside click**: Closes dropdown
- **Scroll**: Dropdown scrolls independently if many items

## Loading state pattern
```html
<button aria-busy="true" disabled>
  <span class="visually-hidden">Saving...</span>
  <svg class="spinner" ...></svg>
</button>
```

## Visual design tokens

### Spacing
- **Horizontal padding**: 16px primary, 12px trigger
- **Vertical padding**: 10px (44px total height)
- **Gap between segments**: 1px visual, 0px interactive

### Typography
- **Primary label**: System UI, 14px, 600 weight
- **Dropdown items**: System UI, 14px, 400 weight

### Colors
- **Primary segment**: Primary brand color
- **Trigger segment**: Slightly darker shade of primary
- **Hover**: 10% lighter
- **Active**: 10% darker
- **Disabled**: 40% opacity + gray background

## Responsive behavior
- **Desktop**: Full button with text labels
- **Tablet**: Same as desktop
- **Mobile**: Consider stacked variant if space constrained
- **Touch**: Active state persists for 100ms after release

## Usage guidelines

### When to use
- One primary action with 2–5 related secondary actions
- Need to save space compared to separate buttons
- Primary action is used >70% of the time

### When not to use
- More than 5 secondary actions (use regular dropdown)
- Actions aren't closely related
- Primary action isn't clearly dominant

## Implementation notes

### React example
```jsx
<SplitButton
  primaryAction={{
    label: "Save",
    onClick: handleSave,
    loading: isSaving
  }}
  dropdownActions={[
    { label: "Save as draft", onClick: saveDraft },
    { label: "Save and close", onClick: saveAndClose },
    { label: "Save as copy", onClick: saveCopy }
  ]}
  disabled={isDisabled}
  ariaLabel="Save actions"
/>
```

### CSS structure
```css
.split-button {
  display: inline-flex;
  border-radius: 6px;
  overflow: hidden; /* Contains dropdown */
}

.split-button__primary {
  /* Primary button styles */
}

.split-button__trigger {
  /* Trigger button styles */
  border-left: 1px solid rgba(0,0,0,0.1);
}

.split-button__dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  /* Dropdown styles */
}
```

## Testing checklist
- [ ] Primary action works with click/tap
- [ ] Dropdown opens/closes with trigger
- [ ] Keyboard navigation works fully
- [ ] Screen reader announces all states
- [ ] Touch targets meet 44px minimum
- [ ] Loading state disables interaction
- [ ] Disabled state prevents all interaction
- [ ] Focus visible in high contrast mode
- [ ] Works with reduced motion preference

---

**Component boundary**: This spec defines the split button as a single interactive widget, not a collection of separate buttons.  
**State coverage**: All interactive states defined with clear visual and ARIA signals.  
**Accessibility behavior**: Full keyboard support, proper ARIA, touch target compliance.  
**Implementation boundary**: Spec defines the contract; implementation may vary by framework but must preserve accessibility and state behavior.