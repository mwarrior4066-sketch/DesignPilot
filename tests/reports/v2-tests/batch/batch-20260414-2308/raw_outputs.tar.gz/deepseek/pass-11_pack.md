I’ll reconstruct the layout system from your 2018 brand guidelines PDF and translate it into a modern, reusable layout system.

**What I’ll extract from the PDF:**
- Grid structure (columns, gutters, margins)
- Breakpoints or responsive behavior
- Typographic scale and baseline grid
- Spacing units (margins, padding, vertical rhythm)
- Component layout patterns
- Any layout constraints or “never” rules

**How I’ll translate it into a modern layout system:**

1. **Grid normalization**  
   Convert fixed pixel/point measurements to relative units (rem, fr, %) where appropriate, preserving proportions.

2. **Responsive mapping**  
   Map any fixed breakpoints to a modern mobile-first scale (e.g., 320px → 640px → 1024px → 1440px), adjusting column counts and gutters accordingly.

3. **Spacing system**  
   Derive a modular spacing scale (e.g., 4px or 8px base) from the margin/gutter specs, ensuring vertical rhythm aligns with typography.

4. **Layout tokens**  
   Define CSS custom properties for:
   - `--grid-columns`
   - `--grid-gutter`
   - `--container-margin`
   - `--section-padding`
   - Breakpoint-specific overrides

5. **Component adaptation**  
   Identify recurring layout patterns (cards, hero, sidebar-content) and translate them into modern CSS Grid/Flexbox templates.

6. **Accessibility & performance**  
   Ensure spacing meets WCAG 2.2 touch target minima, and grid implementation avoids layout thrashing.

7. **Documentation**  
   Provide a clear token reference and usage examples for designers and developers.

**Next steps:**
If you upload the PDF, I can:
- Extract the exact grid measurements
- Show you the derived spacing scale
- Provide a starter CSS layout module
- Flag any legacy constraints that should be relaxed or updated

Would you like to share the PDF?