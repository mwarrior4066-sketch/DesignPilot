I’ll write a backend architecture spec for a multi-tenant scheduling platform with the features you described.  
Let me start by identifying the core domains, then define services, data boundaries, contracts, and operational concerns.

---

## Backend Architecture Spec: Multi‑Tenant Scheduling Platform

### 1. Core Domains & Bounded Contexts

| Bounded Context | Responsibility | Key Entities |
|----------------|----------------|--------------|
| **Tenant & Workspace** | Tenant onboarding, workspace membership, regional data residency, billing context. | `Tenant`, `Workspace`, `Member`, `Region` |
| **Scheduling** | Calendar‑based scheduling, resource allocation, availability rules, conflicts. | `Schedule`, `Resource`, `Slot`, `Booking` |
| **Activity Feed** | Cursor‑based event sourcing for user‑visible activity, audit‑ready immutable log. | `ActivityEvent`, `FeedCursor`, `EventType` |
| **Approval Workflow** | Configurable approval chains, state transitions, approver assignments, SLA tracking. | `Workflow`, `ApprovalRequest`, `ApprovalStep`, `Approver` |
| **Webhook & Integration** | Outbound event delivery, retry queues, customer‑defined endpoints, payload templates. | `WebhookSubscription`, `DeliveryAttempt`, `Endpoint`, `PayloadTemplate` |
| **Automation Rules** | Customer‑defined triggers/actions, rule engine, execution history. | `AutomationRule`, `Trigger`, `Action`, `ExecutionLog` |
| **Background Jobs** | Async job execution, idempotency, job lifecycle, queue management. | `Job`, `Queue`, `Worker`, `JobResult` |
| **Audit Trail** | Immutable system‑level audit log for compliance, data‑change tracking. | `AuditRecord`, `AuditEventType`, `Actor` |

---

### 2. Service Boundaries

**Service 1: Tenant & Workspace Service**  
- Manages tenant lifecycle, workspace creation, member invites, role assignments.
- Enforces regional data residency: each tenant’s data pinned to a `Region` (e.g., `us‑east`, `eu‑west`).
- Exposes REST endpoints for CRUD, member management, region selection.
- **Data isolation:** Database sharding by `region_id` + `tenant_id`.

**Service 2: Scheduling Service**  
- Core scheduling engine: availability calculation, conflict detection, booking lifecycle.
- Uses tenant‑aware `Resource` (people, rooms, equipment) and `Schedule` templates.
- **Contract:** REST + iCalendar‑compatible endpoints for external calendar integration.

**Service 3: Activity Feed Service**  
- Immutable, cursor‑paginated event stream.
- Events sourced from other services via internal event bus.
- **Cursor contract:** `after_cursor` and `limit` for pagination; cursor = `(timestamp, event_id)`.
- Events include: `actor`, `action`, `target`, `metadata`, `tenant_id`, `workspace_id`.

**Service 4: Approval Workflow Service**  
- Configurable approval chains per workspace/booking type.
- State machine: `pending` → `approved`/`rejected`/`cancelled`.
- SLA tracking: alerts if a step exceeds configured time.
- **Integration:** Listens to `BookingCreated` events, emits `ApprovalCompleted`.

**Service 5: Webhook Service**  
- Manages customer‑defined webhook subscriptions.
- Reliable delivery with exponential backoff + jitter, dead‑letter queue after max retries.
- **Webhook contract:** RFC 9457 problem details for errors, `X‑Idempotency‑Key` for retry safety.
- Payload templates allow customers to map internal events to their expected schema.

**Service 6: Automation Rules Engine**  
- Customer‑defined rules: `ON trigger DO action`.
- Triggers: `BookingCreated`, `ApprovalCompleted`, `ScheduleUpdated`, etc.
- Actions: `SendEmail`, `CallWebhook`, `UpdateBooking`, `CreateTask`.
- **Execution:** Isolated sandbox per rule; time‑bounded execution.

**Service 7: Background Job Service**  
- Unified job queue system (replaces inconsistent existing background jobs).
- Supports scheduled, recurring, and ad‑hoc jobs.
- **Job lifecycle:** `queued` → `running` → `completed`/`failed`.
- Idempotency via `idempotency_key` (deduplication window = 24h).

**Service 8: Audit Service**  
- Immutable log of all system‑level data changes and sensitive actions.
- Separate from activity feed (audit is for compliance, activity feed is for user visibility).
- **Log retention:** 7 years for compliance tenants; configurable per region.

---

### 3. Data Boundaries & Isolation

**Multi‑Tenancy Model:**  
- **Layer 1:** Database sharding by `region_id` (data residency).  
- **Layer 2:** Row‑level isolation by `tenant_id` within each shard.  
- **Layer 3:** Workspace‑level partitioning where needed (`workspace_id`).  

**Access Pattern:**  
All queries must include `tenant_id` (enforced by service‑layer middleware).  
Cross‑tenant queries are impossible at the database level.

**Data Residency:**  
- `Region` table defines allowed data‑storage locations.  
- Tenant chooses region at sign‑up; immutable after creation.  
- Replication across regions is prohibited for compliance tenants.

---

### 4. Contracts & APIs

**Internal Event Bus (Async)**  
- Events follow CloudEvents spec: `type`, `source`, `subject`, `data`.  
- Example events:  
  - `booking.created`  
  - `approval.completed`  
  - `webhook.delivery.failed`  
  - `audit.record.created`

**External REST APIs**  
- RESTful, JSON‑API‑style where appropriate.  
- Authentication: JWT (issued by central Identity Provider).  
- Authorization: RBAC per workspace + object‑level checks (BOLA prevention).  
- Idempotency: `Idempotency‑Key` header on POST/PATCH.  
- Error responses: RFC 9457 problem details.

**Webhook Delivery Contract**  
- `POST` to customer endpoint with signature header (`X‑Signature`).  
- Payload includes: `event_id`, `event_type`, `timestamp`, `data`.  
- Retry: 5 attempts with exponential backoff (1s, 5s, 15s, 60s, 300s).  
- Dead‑letter queue after final failure; manual replay possible.

**Cursor‑Based Activity Feed API**  
```
GET /activity?after_cursor=<cursor>&limit=50
Response:
{
  "events": [...],
  "next_cursor": "...",
  "has_more": true
}
```

---

### 5. Operational Concerns

**Observability**  
- Structured logging with `trace_id`, `tenant_id`, `user_id`.  
- Metrics: per‑tenant request rate, error rate, job‑queue depth, webhook delivery latency.  
- Distributed tracing across services (OpenTelemetry).  

**Resilience**  
- **Circuit breakers** on external dependencies (customer webhooks, email providers).  
- **Graceful degradation:** If approval service is down, bookings can be configured to auto‑approve or queue.  
- **Data consistency:** Use saga pattern for cross‑service transactions (e.g., booking + approval creation).  

**Security**  
- **Authentication:** Central OAuth2 provider; service‑to‑service mTLS.  
- **Authorization:** Object‑level access checks (e.g., `user can view booking in workspace`).  
- **Audit:** All data‑change events logged immutably; access‑log retention per region’s legal requirement.  

**Scalability**  
- **Read‑heavy:** Activity feed and audit services use read‑replicas.  
- **Write‑heavy:** Job queues and webhook deliveries use partitioned queues by tenant/region.  
- **Hot tenants:** Can be moved to dedicated infrastructure via configuration.  

**Deployment & Region‑Awareness**  
- Each region runs a full stack of services; data does not leave region.  
- Global management plane for tenant‑region assignment, cross‑region reporting (aggregated, anonymized).  

---

### 6. Migration & Evolution

**Phase 1: Job & Event Unification**  
- Replace ad‑hoc background jobs with unified job service.  
- Introduce internal event bus; existing services publish key events.  

**Phase 2: Multi‑Tenancy & Region Isolation**  
- Migrate database to sharded model (`region_id`, `tenant_id`).  
- Update all queries to include tenant context.  

**Phase 3: New Services Rollout**  
- Deploy activity‑feed, approval‑workflow, webhook services.  
- Migrate existing approval logic to new service.  

**Phase 4: Automation Rules Engine**  
- Deploy rule engine; allow customer‑defined rules via UI/API.  

---

### 7. Key Decisions & Tradeoffs

| Decision | Rationale | Tradeoff |
|----------|-----------|----------|
| **Database sharding by region first, tenant second** | Meets data‑residency requirements; simplifies compliance. | Cross‑region queries require aggregation layer; operational complexity higher. |
| **Separate activity feed and audit log** | Activity feed is for user visibility (can be curated); audit is immutable compliance record. | Storage cost doubled; must keep both streams in sync. |
| **RFC 9457 for all error responses** | Consistent error handling across internal and external APIs; better client debugging. | Slightly larger payloads; clients must adopt standard. |
| **Idempotency‑Key on all mutating endpoints** | Prevents duplicate bookings/approvals when retries occur. | Requires storage layer to deduplicate; 24‑hour window increases storage needs. |
| **Customer‑defined webhook payload templates** | Lets customers map internal events to their existing schema without code changes. | Template engine adds complexity; must sandbox execution for security. |

---

### 8. Next Steps

1. **Define detailed API specs** for each service (OpenAPI).  
2. **Design data‑migration plan** for existing tenants into regional shards.  
3. **Build job‑service prototype** to replace inconsistent background jobs.  
4. **Implement audit‑log capture** early to ensure compliance coverage during rollout.  
5. **Pilot with one region and a small tenant group** before full rollout.  

---

Let me know if you’d like to drill into any of these services, data models, or contracts in more detail.