I'll analyze this PDF accessibility remediation request and provide a structured plan.

## PDF Accessibility Remediation Plan

**Governing route:** `rt_pdf_remediation` (PDF/document remediation governs when semantics, extraction, or reading order are at risk)

**Supporting skills:** `document-accessibility-expert.md`, `layout-reconstruction-expert.md`

### 1. Semantic Failures Identified

Based on your description, this InDesign-exported PDF has these accessibility barriers:

1. **Missing semantic structure** - No proper tagging for headings, paragraphs, lists
2. **Reading order disruption** - Two-column layout and pull quotes break logical reading flow
3. **Decorative images without alt-text suppression** - Images marked as decorative need proper artifact tagging
4. **Broken navigation** - Table of contents links don't function
5. **Probable color contrast issues** - Common in InDesign exports without proper color management

### 2. Reading Order & Extraction Priority

**Primary goal:** Screen reader users must encounter content in logical order, not visual layout order.

**Required fixes in sequence:**

1. **Rebuild document structure tree** - Create proper parent/child relationships:
   - Document → Part → Chapter → Section → Heading levels → Paragraphs
   - Two columns become sequential reading: left column top to bottom, then right column top to bottom

2. **Handle pull quotes strategically**:
   - Option A: Move them to endnotes with references in main text
   - Option B: Tag them as `Aside` elements with `aria-label="pull quote"`
   - Option C: Place them after the paragraph they reference with proper semantic markup

3. **Image remediation**:
   - Decorative images → Tag as artifacts (suppressed from accessibility tree)
   - Informative images → Add descriptive alt text
   - Complex images (charts, diagrams) → Provide extended descriptions

4. **Table of contents repair**:
   - Rebuild internal links using named destinations
   - Ensure heading tags match TOC entries
   - Test keyboard navigation

### 3. Verification Method

**Destructive shortcut rejected:** We cannot simply flatten the PDF or convert to single column without preserving design intent. Instead:

**Preservation strategy:**
- Maintain visual two-column layout for sighted users
- Create separate logical reading order for assistive technology
- Use PDF/UA (ISO 14289-1) compliance as target standard

**Verification steps:**
1. **Automated check:** PAC 2024 or Adobe Acrobat Pro accessibility checker
2. **Manual check:** Keyboard navigation through entire document
3. **Screen reader test:** NVDA, JAWS, or VoiceOver read-through
4. **Reflow test:** Extract text to verify logical order

### 4. Required Tools & Process

**Tools needed:**
- Adobe Acrobat Pro (for tagging and repair)
- Optional: CommonLook PDF Validator, PAC 2024
- Screen reader for testing

**Process:**
```
1. Open PDF in Acrobat Pro → Accessibility tools
2. Run full accessibility check (identifies all issues)
3. Use Reading Order tool to define logical flow
4. Rebuild tag tree manually (auto-tagging fails on complex layouts)
5. Fix images: Artifact decorative, alt-text for informative
6. Repair TOC links using "Create Links from Destinations"
7. Set document language and title metadata
8. Verify with screen reader
```

### 5. Specific Fixes for Your Elements

**Two-column layout fix:**
- Use Reading Order tool to draw rectangles in logical sequence
- Tag each column section with appropriate heading levels
- Add `aria-owns` relationships if needed for complex layouts

**Pull quote handling recommendation:**
Given this is a report (not fiction), I recommend **Option B**: Tag as `Aside` elements placed after their reference paragraph. This:
- Preserves visual design
- Maintains logical reading flow
- Provides semantic meaning to screen readers

**Broken TOC links:**
- Recreate all internal links using "Create Links from Destinations"
- Ensure each heading has a named destination
- Test each link navigates correctly

### 6. Time Estimate & Tradeoffs

**Estimated effort:** 2-4 hours for a typical 20-page report

**What you preserve:** Visual design integrity, brand consistency

**What you sacrifice:** Some automated export workflows may need manual adjustment for future updates

**Alternative considered and rejected:** Converting to single-column HTML or EPUB would solve accessibility but destroy the designed report format.

### 7. Deliverables You'll Have

1. **Accessible PDF** - WCAG 2.1 AA compliant, PDF/UA ready
2. **Remediation report** - Documenting fixes applied
3. **Testing summary** - Screen reader and keyboard test results
4. **Maintenance guide** - How to keep future exports accessible

---

**Next step:** If you can share the PDF (or a sample page), I can provide specific tagging instructions and verify the reading order approach matches your content structure. Would you like me to generate the exact Acrobat Pro steps for any of these fixes?

[SESSION_STATE]
{
  "route": "rt_pdf_remediation",
  "escalation_level": "compound",
  "decisions_committed": ["semantic_failure: missing_structure_and_reading_order", "reading_order_or_extraction: logical_sequence_over_visual_layout", "verification_method: automated_plus_manual_testing", "destructive_shortcut_rejected: preserve_visual_design_with_separate_logical_order"],
  "evidence_classes_cited": ["wcag_rule", "standard_reference"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": ["Can you share the PDF or a sample page for specific tagging guidance?"],
  "turn": 1
}
[/SESSION_STATE]