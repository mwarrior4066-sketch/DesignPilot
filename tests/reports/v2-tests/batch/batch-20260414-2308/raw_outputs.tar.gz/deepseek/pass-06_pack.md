[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": ["audience_frame: freelancers as business owners, not just gig workers", "differentiation_frame: operational simplicity and financial clarity as trust", "trust_logic: trust through control and visibility, not institutional legacy", "messaging_consequence: avoid 'banky' language; use plain, actionable, partner-like terms"],
  "evidence_classes_cited": ["trust_constraints", "differentiation_tradeoffs", "proof_gaps"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Brand Positioning Pass: Fintech for Freelancers

**Positioning Territory:** **The Operational Partner for the Self-Employed**

This territory centers on the freelancer’s core need: to run their business smoothly, not just move money. It shifts trust from institutional authority (traditional banks) to operational reliability and clarity (a partner that makes complexity simple).

### Audience Frame: Freelancers as Business Owners
The target isn't just "gig workers" needing payouts. They are **sole proprietors wearing every hat**—CEO, CFO, sales, and operations. Their anxiety isn't about banking fees; it's about cash flow predictability, tax readiness, client invoicing, and understanding their real profitability. Positioning must speak to this **business-owner identity**, not just a transactional user.

### Trust Logic: Control and Visibility Over Legacy
For this audience, trust is built through **transparency and control**, not marble lobbies or century-old charters.
*   **Trust requires** giving them a crystal-clear, real-time view of their cash position, obligations, and runway.
*   **The audience will not accept** black-box fees, surprise holds, or jargon-filled statements. Trust is broken by opacity.
*   Therefore, trust is demonstrated through **interface clarity, proactive guidance** (e.g., "set aside 30% for taxes"), and **predictable behavior**—not through traditional banking symbols.

### Differentiation vs. Competitors
*   **vs. Stripe:** Stripe is the **payments and treasury infrastructure** for platforms and larger businesses. Your territory is the **day-to-day financial operating system** for the individual. You sacrifice Stripe's vast third-party ecosystem to gain a deeply integrated, opinionated workflow for a single user.
*   **vs. Mercury:** Mercury is the **VC-backed startup's bank**. It speaks the language of fundraising, burn rate, and cap tables. Your territory is **profitability, sustainability, and owner's pay**. You sacrifice the "startup" cachet to gain relevance for the bootstrap-focused freelancer.
*   **vs. Relay:** Relay is a **multi-account money manager** for small businesses. Your territory is **unified workflow integration** (invoicing, tax, expenses, banking) rather than pure banking. You sacrifice Relay's banking-focused simplicity to gain a more holistic toolset, which means accepting a higher bar for seamless integration.

### Messaging Consequence: Approachable, Not "Banky"
The tone must be that of a **competent, calm partner**, not a distant institution.
*   **Use:** "Cash flow," "runway," "set aside for taxes," "get paid faster," "understand your profit."
*   **Avoid:** "Financial solutions," "wealth management," "institutional-grade," "leverage," "synergy."
*   **Visual & Interaction Cue:** Interfaces should feel **spacious, guided, and explanatory**. Use progressive disclosure, plain-language tooltips, and visualizations that turn data into insight (e.g., "You can afford this new laptop in 2 months based on current projects").

### Proof Gaps & What Remains Unverified
This positioning makes specific claims that require evidence:
*   **Open gap: No data on** whether freelancers perceive "operational partner" as more trustworthy than "better bank." This is a hypothesis.
*   **Proxy evidence:** High engagement with tax-estimation or invoice-tracking features would stand in for proof of the "operational" need.
*   **Cannot claim "most trusted"** without longitudinal data on user retention during financial stress (e.g., tax season, client non-payment).

### Recommended Positioning Statement
**For freelancers and solo business owners who need to manage their business finances with clarity and control, [Product Name] is the operational financial partner that integrates banking, invoicing, taxes, and insights into one simple workflow. Unlike traditional banks or generic fintech tools, we give you a real-time picture of your business health and help you make confident decisions, so you can focus on your work, not your finances.**

**Next useful moves:**
1.  **Map this to messaging:** Generate key headlines, value prop phrases, and a tone-of-voice guide.
2.  **Audit visual identity:** Review logo, color, and typography against this "calm, competent partner" position.
3.  **Generate research prompts:** Create 3-4 deep-research questions to validate the core hypothesis about trust and operational needs.