**Hierarchy failure**  
The decorative title is visually dominant, but the audience doesn’t yet know *what* this event is or *who* it’s for. A conference poster must answer “what, who, when, where” in that order—otherwise the viewer’s attention is wasted on style before substance.

**Visual competition**  
The full‑bleed city photo and the overlaid white logo compete for the same visual weight as the title. This creates three focal points with no clear reading path.

**Date placement**  
Small gray text in the corner is functionally invisible—attendees need the date and location at a glance, not as a footnote.

---

### Rebuild moves

1. **Lead with the conference name or a clear tagline** in a strong, legible typeface—save the decorative title for a secondary element or remove it entirely.
2. **Establish a clear visual sequence:**  
   - Conference name / tagline (largest)  
   - Date + location (high contrast, prominent)  
   - Key details (speakers, themes, call‑to‑action)  
   - Logo as an endorsement, not a centerpiece
3. **Simplify the background** so it supports text legibility—either soften the photo with an overlay or crop to a less busy area.
4. **Use the decorative typeface sparingly**—maybe for the word “conference” or a thematic phrase—so it adds personality without breaking hierarchy.

---

### Tradeoffs
- **You sacrifice** some dramatic visual impact by reducing the title’s size and moving the logo.
- **You gain** immediate communication clarity and a usable reading order for someone scanning the poster from a distance.

---

### Quick test
Cover the logo with your thumb—can you still tell this is a design‑conference poster in under 3 seconds? If not, rebuild the hierarchy.

Would you like a sketched layout, a type‑pairing suggestion, or a legibility‑first grid for this?