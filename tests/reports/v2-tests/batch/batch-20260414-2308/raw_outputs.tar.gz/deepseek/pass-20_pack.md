I'll write a backend architecture spec for this multi-tenant scheduling platform. Let me start by identifying the governing route and required decisions.

**Route analysis**: This is a backend systems architecture task, which falls under `rt_backend_architecture_spec`. The contract requires decisions about authority model, consistency stance, data delivery, and observability tax.

**Key architectural decisions needed**:
1. **Authority model**: Multi-tenancy approach (database-level vs schema-level vs row-level isolation)
2. **Consistency stance**: Eventual vs strong consistency for scheduling conflicts, activity feeds, and approvals
3. **Data delivery**: Real-time vs polling for activity feeds, webhook delivery guarantees
4. **Observability tax**: What we instrument and what it costs us

**Visual pre-pass**: No visual input, so I'll proceed with standard architecture spec.

---

## Backend Architecture Spec: Multi-Tenant Scheduling Platform

### 1. System Overview
A multi-tenant scheduling platform supporting team workspaces, cursor-based activity feeds, approval workflows, and outbound webhooks to customer systems. The system must handle scheduling conflicts, team permissions, audit trails, and reliable webhook delivery while maintaining tenant isolation.

### 2. Authority Model: Database-per-Tenant with Shared Control Plane

**Decision**: Database-per-tenant isolation with a shared control plane database for tenant metadata and cross-tenant operations.

**Rationale**:
- **Tenant isolation**: Each tenant gets a dedicated PostgreSQL database. This provides strong data isolation, independent backups, and tenant-specific scaling.
- **Shared control plane**: A separate database stores tenant metadata, billing, user accounts, and cross-tenant analytics.
- **Authentication layer**: All requests authenticate via JWT containing `tenant_id` and `user_id`. The API gateway routes to the appropriate tenant database connection pool.
- **Team workspaces**: Within each tenant, teams are organizational units with their own resource quotas and member permissions. Team membership is stored in the tenant database with RBAC (Role-Based Access Control).

**Implementation**:
```sql
-- Control plane database
CREATE TABLE tenants (
  id UUID PRIMARY KEY,
  subdomain VARCHAR(63) UNIQUE,
  database_name VARCHAR(63),
  status VARCHAR(20),
  created_at TIMESTAMPTZ
);

-- Tenant database (per tenant)
CREATE TABLE teams (
  id UUID PRIMARY KEY,
  name VARCHAR(255),
  settings JSONB
);

CREATE TABLE team_members (
  team_id UUID REFERENCES teams(id),
  user_id UUID,
  role VARCHAR(50), -- 'admin', 'editor', 'viewer'
  PRIMARY KEY (team_id, user_id)
);
```

**Tradeoff**: Database-per-tenant increases operational complexity (migrations across N databases) but provides superior isolation and simplifies compliance (GDPR deletion requests). The cost is approximately 50MB overhead per tenant for system tables.

### 3. Consistency Stance: Eventual Consistency with Conflict Resolution

**Decision**: Eventual consistency for activity feeds and webhooks, strong consistency for scheduling conflicts.

**Rationale**:
- **Scheduling conflicts**: Require strong consistency (linearizable) to prevent double-booking. Use database transactions with row-level locking on time slots.
- **Activity feeds**: Can be eventually consistent since they're append-only and ordering matters but absolute immediacy doesn't.
- **Approval workflows**: Require at-least-once semantics with idempotent transitions to handle retries.
- **Webhooks**: Eventual consistency with at-least-once delivery and deduplication.

**Implementation**:
```python
# Strong consistency for scheduling
def book_appointment(tenant_db, time_slot_id, user_id):
    with tenant_db.transaction():
        # SELECT FOR UPDATE locks the row
        slot = tenant_db.execute("""
            SELECT * FROM time_slots 
            WHERE id = %s AND status = 'available'
            FOR UPDATE
        """, [time_slot_id])
        
        if not slot:
            raise ConflictError("Time slot no longer available")
        
        # Update within same transaction
        tenant_db.execute("""
            UPDATE time_slots 
            SET status = 'booked', booked_by = %s
            WHERE id = %s
        """, [user_id, time_slot_id])
        
        # Emit event for async processing (activity feed, webhooks)
        emit_event('appointment.booked', {
            'slot_id': time_slot_id,
            'user_id': user_id,
            'tenant_id': current_tenant.id
        })
```

**Tradeoff**: We accept the performance cost of row-level locking for scheduling to prevent business-critical double-booking. Activity feeds may lag by 100-500ms during peak load, which users will tolerate.

### 4. Data Delivery: Hybrid Real-time + Polling with Webhook Queues

**Decision**: Real-time WebSockets for active workspaces, polling fallback, and dedicated webhook worker queues per tenant.

**Rationale**:
- **Activity feeds**: Cursor-based pagination over WebSocket connections for active users, with HTTP long-polling fallback.
- **Webhooks**: Dedicated SQS queues per tenant for isolation and independent scaling.
- **Approval notifications**: Immediate push notifications via WebSocket, email fallback.

**Implementation**:
```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   API Layer     │───▶│   Event Bus      │───▶│  Activity Feed  │
│ (REST/WebSocket)│    │   (Redis Stream) │    │   Processor     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       ▼
         │                       │              ┌─────────────────┐
         │                       └─────────────▶│   Webhook       │
         │                                      │   Dispatcher    │
         ▼                                      └─────────────────┘
┌─────────────────┐                                    │
│   Scheduler     │                                    ▼
│   Engine        │                          ┌─────────────────┐
└─────────────────┘                          │ Tenant-specific │
         │                                   │   SQS Queues    │
         ▼                                   └─────────────────┘
┌─────────────────┐                                    │
│   Approval      │                                    ▼
│   Workflow      │                          ┌─────────────────┐
│   Engine        │                          │   Webhook       │
└─────────────────┘                          │   Workers       │
                                             └─────────────────┘
```

**Cursor-based activity feed**:
```sql
-- Activity feed table (tenant database)
CREATE TABLE activities (
  id BIGSERIAL PRIMARY KEY,
  team_id UUID REFERENCES teams(id),
  type VARCHAR(50),
  data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  -- Composite index for cursor pagination
  INDEX idx_team_created (team_id, created_at DESC, id DESC)
);

-- Query for cursor pagination
SELECT * FROM activities 
WHERE team_id = $1 
  AND (created_at < $2 OR (created_at = $2 AND id < $3))
ORDER BY created_at DESC, id DESC 
LIMIT 50;
```

**Webhook delivery guarantee**:
- Webhook events go to tenant-specific SQS queue
- Exponential backoff with jitter: 1s, 2s, 4s, 8s, 16s, 32s, 64s
- Dead-letter queue after 24 hours for manual inspection
- Idempotency key in webhook payload to prevent duplicate processing

**Tradeoff**: WebSocket connections increase memory usage (~50KB per connection) but reduce polling load. We accept this cost for better real-time experience in active workspaces.

### 5. Approval Workflow Engine: State Machine with Audit Trail

**Decision**: Configurable state machine with immutable audit trail and idempotent transitions.

**Rationale**:
- Teams need custom approval chains (sequential, parallel, any-approver)
- Audit trail must be immutable for compliance
- Transitions must be idempotent for retry safety

**Implementation**:
```python
class ApprovalWorkflow:
    def __init__(self, tenant_db, workflow_config):
        self.db = tenant_db
        self.config = workflow_config  # JSON schema defining states, transitions, roles
        
    def request_approval(self, resource_id, requester_id):
        # Create immutable audit entry
        audit_id = self.db.insert("""
            INSERT INTO approval_audit 
            (resource_id, from_state, to_state, actor_id, reason)
            VALUES (%s, 'draft', 'pending', %s, 'submitted')
            RETURNING id
        """, [resource_id, requester_id])
        
        # Create approval records for each approver
        approvers = self.get_approvers_for_resource(resource_id)
        for approver in approvers:
            self.db.insert("""
                INSERT INTO approval_tasks
                (resource_id, approver_id, status, audit_id)
                VALUES (%s, %s, 'pending', %s)
            """, [resource_id, approver['id'], audit_id])
        
        # Emit event for activity feed
        emit_event('approval.requested', {
            'resource_id': resource_id,
            'audit_id': audit_id
        })

    def approve(self, resource_id, approver_id, reason):
        # Idempotent check
        existing = self.db.query("""
            SELECT status FROM approval_tasks
            WHERE resource_id = %s AND approver_id = %s
        """, [resource_id, approver_id])
        
        if existing and existing[0]['status'] == 'approved':
            return {'already_approved': True}
        
        with self.db.transaction():
            # Update task
            self.db.execute("""
                UPDATE approval_tasks
                SET status = 'approved', decided_at = NOW()
                WHERE resource_id = %s AND approver_id = %s
            """, [resource_id, approver_id])
            
            # Audit trail
            self.db.insert("""
                INSERT INTO approval_audit
                (resource_id, from_state, to_state, actor_id, reason)
                VALUES (%s, 'pending', 'approved', %s, %s)
            """, [resource_id, approver_id, reason])
            
            # Check if all approvals complete
            pending = self.db.query("""
                SELECT COUNT(*) as count FROM approval_tasks
                WHERE resource_id = %s AND status = 'pending'
            """, [resource_id])
            
            if pending[0]['count'] == 0:
                self.transition_to_approved(resource_id)
```

**Tradeoff**: The immutable audit trail increases storage requirements (approximately 2KB per state transition) but provides non-repudiation for compliance. We accept this storage tax.

### 6. Observability Tax: Structured Logging + Distributed Tracing

**Decision**: Structured logging with tenant context, distributed tracing for cross-service calls, and metrics for business events.

**What we instrument**:
- **Webhook delivery**: Success rate, latency, retry count per tenant
- **Scheduling conflicts**: Conflict rate, resolution time
- **Approval workflows**: Time in each state, bottleneck detection
- **Database performance**: Query latency, connection pool usage per tenant
- **Tenant isolation**: Cross-tenant data access attempts (security audit)

**What we don't instrument by default**:
- Individual user activity within tenant (privacy)
- Full request/response bodies (storage cost)
- WebSocket message content (privacy + volume)

**Implementation**:
```python
# Structured logging with tenant context
logger.info("webhook.delivery.attempt", 
    extra={
        "tenant_id": tenant_id,
        "webhook_id": webhook_id,
        "attempt": attempt_number,
        "duration_ms": duration,
        "success": success,
        "trace_id": trace_id
    })

# Metrics
metrics.increment("scheduling.conflicts", tags={"tenant_id": tenant_id})
metrics.histogram("approval.duration", duration_ms, 
                  tags={"tenant_id": tenant_id, "workflow_type": "sequential"})
```

**Tradeoff**: Structured logs increase storage by ~30% compared to plain text but enable powerful tenant-specific debugging. Distributed tracing adds ~5ms overhead per span but is essential for debugging cross-service issues.

### 7. Deployment and Scaling Strategy

**Multi-region consideration**: Tenant databases stay in primary region; control plane can be multi-region read replicas.

**Scaling approach**:
1. **Vertical scaling first**: Upgrade tenant database instance size based on usage
2. **Horizontal scaling**: Shard control plane if needed (by tenant hash)
3. **Queue scaling**: Auto-scale webhook workers based on SQS queue depth

**Disaster recovery**:
- Tenant database backups: Daily full + WAL streaming (RPO < 5 minutes)
- Control plane: Multi-AZ with failover (RTO < 15 minutes)
- Webhook queue: SQS with message retention (DLQ after 24h)

### 8. Security Considerations

1. **Tenant isolation**: No JOINs between tenant databases; connection pool per tenant
2. **API authorization**: JWT validation + tenant context + team RBAC
3. **Webhook security**: HMAC signatures for outbound, IP whitelisting for inbound
4. **Audit trail**: Immutable logs for all state transitions
5. **Data encryption**: AES-256 at rest, TLS 1.3 in transit

### 9. Risks and Safer Path

**Primary risk**: Database-per-tenant operational complexity. Migrations require careful orchestration across N databases.

**Mitigation**: Start with schema-level isolation (PostgreSQL schemas) for first 100 tenants, migrate to database-per-tenant later. This sacrifices some isolation early for simpler operations.

**Secondary risk**: Webhook delivery failures causing customer system inconsistencies.

**Mitigation**: Implement webhook status dashboard per tenant with manual retry capability. Provide webhook testing suite during tenant onboarding.

**Performance risk**: Row-level locking on scheduling causing contention during peak hours.

**Mitigation**: Implement optimistic concurrency control as fallback, shard time slots by date range.

---

## Summary of Architecture Decisions

1. **Authority model**: Database-per-tenant with shared control plane (strong isolation, operational complexity)
2. **Consistency stance**: Strong for scheduling, eventual for feeds/webhooks (business-critical vs nice-to-have)
3. **Data delivery**: WebSocket real-time + SQS webhook queues (user experience vs reliability)
4. **Observability tax**: Structured logging + tracing (debuggability vs storage/performance cost)

This architecture provides tenant isolation, reliable scheduling, audit-ready approvals, and scalable webhook delivery while maintaining the ability to debug and monitor cross-tenant issues.

[SESSION_STATE]
{
  "route": "rt_backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": ["authority_model: database-per-tenant with shared control plane", "consistency_stance: eventual consistency with conflict resolution", "data_delivery: hybrid real-time + polling with webhook queues", "observability_tax: structured logging + distributed tracing"],
  "evidence_classes_cited": ["constraint", "tradeoff", "implementation_boundary"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]