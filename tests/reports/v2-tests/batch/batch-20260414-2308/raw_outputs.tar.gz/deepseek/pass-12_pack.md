I’ll recommend a type system for a fintech product that works across marketing site, web app dashboard, and mobile, balancing modern trustworthiness, tabular data clarity, and hierarchy.

---

## Type system recommendation

### Primary typeface: **Inter**
- **Why**: A highly legible, neutral, open-source sans-serif designed for UI and dense data. It has excellent readability at small sizes, clear numerals, and strong weight range (Thin to Black).
- **Trustworthiness**: Neutral, professional, no distracting personality—ideal for financial clarity.
- **Tabular data**: Includes tabular figures (monospaced numerals) in its variable font, ensuring financial tables align vertically.
- **Platform support**: Web (variable font), iOS/Android (system fallback or bundled), print-ready.
- **Licensing**: Open source (SIL Open Font License), free for any use.

### Secondary/display option: **Source Serif Pro** (for marketing headlines)
- **Why**: A readable, warm serif that adds credibility and editorial tone for marketing pages, without feeling old-fashioned.
- **Pairing rationale**: Contrasts clearly with Inter, reinforcing hierarchy between marketing storytelling and app UI.
- **Use case**: Hero headlines, section titles on marketing site, quote blocks, print reports.
- **Licensing**: Open source (SIL Open Font License).

### Fallback stack
```
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
```
For marketing serif:
```
font-family: 'Source Serif Pro', Georgia, 'Times New Roman', serif;
```

---

## Scale and sizing

### Web app / dashboard
- **Base size**: 16px (1rem) for body, 14px for dense tables and secondary text.
- **Scale ratio**: 1.25 (major third) for clear hierarchy without excessive jumps.
- **Example scale**:
  - 12px (0.75rem) · table footnotes, microcopy
  - 14px (0.875rem) · table cells, input labels, helper text
  - 16px (1rem) · body, paragraph, default UI
  - 20px (1.25rem) · subheaders, card titles
  - 25px (1.563rem) · section headers
  - 31px (1.953rem) · page titles
  - 39px (2.441rem) · major dashboard KPIs

### Marketing site
- **Base size**: 18px for body readability.
- **Scale ratio**: 1.333 (perfect fourth) for more expressive marketing hierarchy.
- **Headlines**: Source Serif Pro at 2.5rem–4rem for impact.

### Mobile
- **Base size**: 17px (iOS guideline) or 16px (Material), adjust with `text-size-adjust: 100%`.
- **Touch targets**: Minimum 44px height for interactive text elements.
- **Line height**: 1.5–1.6 for body, 1.2–1.3 for headings.

---

## Weight and color usage

### Weight mapping
- **Thin (100) / Extra Light (200)**: Rare, only for large display numerals in dashboards.
- **Light (300)**: Marketing subheads, subtle labels.
- **Regular (400)**: Body text, most UI.
- **Medium (500)**: Button labels, active navigation, table headers.
- **Semibold (600)**: Strong emphasis, key metrics, important alerts.
- **Bold (700)**: Primary headlines, critical warnings.
- **Black (900)**: Only for major KPI numbers in dashboard.

### Color contrast
- **Primary text**: `#111827` (gray-900) on light mode, `#f9fafb` (gray-50) on dark.
- **Secondary**: `#6b7280` (gray-500).
- **Disabled**: `#9ca3af` (gray-400).
- **WCAG**: All combos meet AA, critical data meets AAA.

---

## Tabular data specifics

- **Use tabular figures**: `font-variant-numeric: tabular-nums;` for any financial table, balance, or transaction list.
- **Monospaced alignment**: Ensures decimal points line up vertically.
- **Row height**: Minimum 1.5× font size for scanability.
- **Zebra striping**: Light background `#f3f4f6` (gray-100) with regular weight, avoid bold in table body.

---

## Variable font implementation

Inter variable axis:
- `wght` 100–900
- `opsz` optional (optical size) for fine-tuning readability at small sizes.

CSS example:
```css
:root {
  --font-inter: 'Inter', sans-serif;
  --font-serif: 'Source Serif Pro', serif;
}

body {
  font-family: var(--font-inter);
  font-weight: 400;
  font-size: 16px;
  line-height: 1.5;
}

h1 {
  font-family: var(--font-serif);
  font-weight: 700;
  font-size: 3rem;
  line-height: 1.2;
}

.table-numeric {
  font-variant-numeric: tabular-nums;
  font-weight: 400;
}
```

---

## Platform delivery

- **Web**: Host variable Inter and Source Serif Pro via Google Fonts or self-host with `woff2`.
- **iOS**: Use Inter via Swift Package (Google Fonts iOS) or fallback to SF Pro for system consistency.
- **Android**: Bundle Inter or use downloadable fonts via Android’s font API.
- **Print/PDF**: Embed Inter and Source Serif Pro for consistent rendering.

---

## Adoption sequence

1. **Start with Inter** across app and marketing site for consistency.
2. **Add Source Serif Pro** only to marketing headline sections.
3. **Implement tabular figures** in all financial data tables.
4. **Tune optical size** for small UI labels (11–14px) using `opsz` axis if needed.
5. **Test contrast** in dark mode and high-density dashboard views.

---

## Rationale and tradeoffs

**Why Inter over system fonts?**
- **Preserves**: Consistent cross-platform rendering, tabular figures, weight granularity.
- **Sacrifices**: Some platform-native feel on iOS/Android, but Inter is close enough to SF Pro and Roboto to avoid mismatch.

**Why add a serif for marketing?**
- **Preserves**: Editorial credibility, visual separation between marketing and app.
- **Sacrifices**: Slight extra font load (~150KB). Mitigate by loading serif only on marketing pages.

**Why variable fonts?**
- **Preserves**: Fine weight control, smaller bundle than multiple static files.
- **Sacrifices**: Older browser support (IE11 none), but fintech apps likely target modern browsers.

This system balances modern clarity, financial data precision, and cross-platform trustworthiness without overcomplicating the stack.

---

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": ["reading_context: fintech product", "scale_decision: 1.25 for app, 1.333 for marketing", "pairing_rationale: neutral sans + credible serif", "adoption_sequence: start with Inter, add serif later"],
  "evidence_classes_cited": ["threshold", "rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]