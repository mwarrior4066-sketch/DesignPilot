## Functional tier

Let’s walk through the decision step by step.

First, we need to understand what the app does. Is it mostly showing static content, or does it have many interactive parts that need to share data across different screens? For example, a shopping cart, user login status, or theme preferences often need to be available in many components.

If the app is simple—like a blog or a single-page form—adding a global state manager adds extra complexity without much benefit. You can manage state locally in components, and use React Context to pass data down a few levels when needed. This keeps things straightforward and easier to maintain.

If the app is more complex—like a dashboard with real-time updates, or an e-commerce site with a cart, user session, and filters—then a global state manager helps keep everything organized. It gives you a single source of truth, makes debugging easier with tools like Redux DevTools, and helps avoid prop drilling (passing data through many intermediate components).

So the key questions are:
1. How much shared state is there?
2. How often does that state change?
3. Do different parts of the app need to react to the same updates?

If the answer is “a lot,” a global manager is worth the setup. If not, local state with Context is simpler and faster to build.

**Governing recommendation:** Use local component state with React Context for shared values like theme or user info, and avoid adding Redux unless you have multiple independent UI regions updating from the same data source.

---

## Integrative tier

This decision sits at the intersection of front-end architecture, team workflow, and long-term maintenance. The choice isn’t just about today’s code—it’s about how the system evolves.

**Local state + Context** works well when:
- State is mostly confined to a subtree of the component hierarchy.
- Updates are infrequent and don’t cause widespread re-renders.
- The team is small, iteration speed is high, and you want to avoid upfront configuration.

However, Context is not a state manager. It’s a dependency injection mechanism. When a Context value changes, *all* components that consume that Context re-render unless you memoize carefully. That can become a performance bottleneck in medium-to-large apps.

**Redux (or similar global stores)** introduces indirection but gives you:
- Predictable state updates via actions and reducers.
- Centralized debugging and time-travel inspection.
- Middleware for side effects (API calls, logging, persistence).
- Separation of state logic from UI components.

The cost is boilerplate, a steeper learning curve, and often over-engineering for simpler apps.

Tradeoffs to weigh:
- **Complexity vs. control:** Redux adds upfront complexity but pays off in debuggability and scalability.
- **Team coordination:** A global store can become a coordination bottleneck if many developers modify the same slices without clear boundaries.
- **Bundle size:** Redux adds ~2KB gzipped; Zustand or Jotai are lighter alternatives with similar benefits.

If the app is likely to grow in interactive complexity, starting with a lightweight global store (like Zustand) can give you the benefits without the full Redux overhead. If the app is mostly presentational with limited interactivity, Context plus local state is sufficient.

**Governing recommendation:** Adopt a lightweight global store (Zustand or Valtio) if the app has more than three independent UI regions that need to react to the same mutable data; otherwise, use local state with Context for shared read-only values and component state for interactivity.

---

## Strategic tier

**Context:** React app, scaling expectations unclear, team size unknown.

**Core conflict:** Global state managers add indirection and learning cost; local state + Context can lead to performance cliffs and refactoring debt.

**Analysis:**
- Global stores win when state updates are decoupled from component hierarchy and when multiple distant UI regions must stay in sync.
- Context is sufficient for shallow dependency injection (theme, auth provider) but becomes inefficient for frequent updates.
- The decision is less about Redux vs. Context and more about **state ownership granularity** and **update frequency**.

**If the app has:**
- High interactivity across disjoint screens → use a global store.
- Mostly static content with sporadic updates → local state + Context.
- Unknown growth trajectory → start with Context but structure state to be easily extracted into a store later (colocate state logic, avoid deep prop drilling).

**Recommendation:** Use React Context for dependency injection (theme, auth, routing) and a lightweight global store (Zustand) for any shared mutable state that updates independently of the UI tree. Avoid Redux unless you need its middleware ecosystem or time-travel debugging.

**Governing recommendation:** Implement a lightweight global store (Zustand) for shared mutable state, keep React Context for dependency injection, and avoid Redux unless required for middleware or team convention.