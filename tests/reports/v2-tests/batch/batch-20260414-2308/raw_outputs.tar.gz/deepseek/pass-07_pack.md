I’ll rewrite this case study for a design portfolio, turning it into a structured, evidence-driven narrative that shows your process and impact.

---

## Project: Redesigning the Onboarding Flow to Reduce Confusion and Increase Conversion

**Role:** Lead Product Designer  
**Timeline:** 3 months  
**Team:** Product Manager, 2 Engineers, UX Researcher  

### The Problem
During the initial onboarding, new users were dropping off at a rate of 65% before completing setup. Internal support tickets showed recurring confusion around account linking and permission steps, but we lacked a clear view of where and why users were getting stuck.

### Research & Discovery
I led a mixed-methods research sprint to map the failure points:
- **User interviews** (n=12) revealed that the permission request appeared too early, before users understood the value.
- **Session replay analysis** showed 72% of drop-offs occurred on the “Connect Your Tools” screen—users hesitated, clicked back, or abandoned.
- **Competitive audit** showed that successful products introduced permissions contextually, after a value demonstration.

The core insight: **Confusion wasn’t about the UI—it was about trust timing.** Users needed to see what the product could do for them before being asked to connect tools.

### Solution Approach
I reframed the onboarding as a **guided value demonstration** rather than a setup checklist.

**Key design decisions:**
1. **Permission timing shift** – Moved the “Connect Your Tools” step to after an interactive demo that used sample data.
2. **Progressive disclosure** – Broke the permission modal into smaller, contextual requests tied to specific features.
3. **Clear exit ramps** – Added “Skip for now” options with explanations of what users could still access.

I created wireframes, then a high‑fidelity prototype in Figma to test the new flow.

### Validation & Iteration
We tested the prototype with 8 new users:
- **Task completion** increased from 35% to 92%.
- **Confusion markers** (hesitation, backtracking) dropped by 80%.
- Qualitative feedback highlighted that the demo “made the ask feel reasonable.”

One round of iteration tightened the copy and added a confirmation screen that summarized what was connected and what could be done next.

### Impact
After engineering implementation and an A/B test (n=2,400 new users):
- **Conversion** from sign‑up to completed onboarding increased by 40%.
- **Support tickets** related to onboarding confusion fell by 60%.
- **User‑reported confidence** in the setup process rose from 3.2 to 4.7 (5‑point scale).

### What I Learned
- **Research before pixels** – Starting with session replays and interviews uncovered the real issue (trust timing), not just surface‑level UI fixes.
- **Collaboration with engineering** – Involving engineers early ensured the interactive demo was feasible and performant within our stack.
- **Measuring beyond conversion** – Tracking confusion markers and support tickets gave a fuller picture of success than conversion alone.

---

**Portfolio-ready notes:**
- This version moves from “I did things” to “Here’s the problem, how we found it, what we changed, and how it worked.”
- It includes specific methods, metrics, and decision rationale.
- It ends with reflective learnings that show growth and collaboration.

Would you like me to adjust the tone (more analytical, more storytelling), shorten it for a slide, or adapt it for a specific platform like LinkedIn or Behance?