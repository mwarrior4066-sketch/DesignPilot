[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": ["rendering_model: server-rendered with client islands", "state_ownership: server-owned data, client-owned UI state", "boundary_placement: filter chips and table updates as client islands", "semantic_contract: native buttons, ARIA live regions", "cost_or_degraded_path: progressive enhancement, fallback to server-side filters"],
  "evidence_classes_cited": ["threshold", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Architectural Critique

The current plan introduces several systemic risks for a permissions-heavy, data-dense dashboard:

**Structural failures:**
1.  **Large client-side rendering (CSR)** for a table-heavy, permission-gated page creates a poor Core Web Vitals profile (slow LCP, high TBT) and exposes raw data/filter logic before authorization checks can run on the client.
2.  **Boolean state explosion** (`isLoading`, `isError`, `isSuccess`) is fragile and doesn't model mutually exclusive states or pending transitions.
3.  **Custom `<div>` buttons** break accessibility (keyboard, screen reader, focus management) and require reinventing browser behavior.
4.  **Optimistic updates for recurring edits** without a rollback strategy and conflict detection is dangerous with server-driven filters and multi-role access.

## Safer Architecture

### 1. Rendering and Mutation Strategy
**Decision: Server-rendered with client islands.**
*   **Why:** The dashboard shell, primary navigation, and permission-gated table skeleton are server-rendered. This ensures initial load performance, delivers a meaningful first paint, and allows the server to enforce role-based visibility *before* sending HTML.
*   **Client Islands:** Interactive filter chips and the data table itself become hydration boundaries. They are shipped as minimal JavaScript bundles that hydrate only their own subtree.
*   **Cost:** This approach requires a framework supporting partial hydration (e.g., Astro, Next.js App Router with React Server Components). The tax is build-time complexity, but the payoff is automatic performance and safer permissions.

### 2. State Ownership
**Decision: Server-owned data, client-owned UI state.**
*   **Data:** The canonical state of schedules, filters, and permissions lives on the server. The client receives snapshots via APIs.
*   **UI State:** Use a state machine (e.g., `{ state: 'idle' | 'loading' | 'success' | 'error', data, error }`) for each async operation (fetch, filter, edit). This replaces the boolean explosion with explicit, mutually exclusive states.
*   **Example:** A filter chip's state: `{ state: 'filtering', appliedFilter: 'upcoming', previousData: [...] }`. This models pending transitions and enables rollback.

### 3. Boundary Placement
**Decision: Filter chips and table updates as client islands.**
*   Filters are implemented as native `<button>` elements or `<input type="checkbox">` within a `<fieldset>`. They trigger a client-side fetch to the filtered API endpoint and update the table island.
*   The table island manages its own view state (sort, pagination) but defers to server-owned data.
*   This keeps the JavaScript footprint minimal and scoped to the interactive parts.

### 4. Semantic Contract & Accessibility
**Decision: Native buttons, ARIA live regions, server-validated mutations.**
*   **Filter Chips:** Use `<button role="switch" aria-checked="true/false">` or a toggle button pattern. This gives you keyboard, focus, and screen reader semantics for free.
*   **Loading & Error States:** Use `aria-live="polite"` regions to announce async status changes. Connect these regions to the state machine.
*   **Optimistic Updates:** Only allow optimistic UI for **non-destructive, reversible actions** (e.g., marking a single appointment "tentative"). For recurring edits, show a persistent "Applying changes..." status with a cancel option until server confirmation is received. **Never** optimistically delete or edit recurring series without a confirmed server response.

### 5. Risks and Safer Path
*   **Risk:** Client-side filtering logic duplicating server logic, leading to drift.
*   **Safer Path:** Implement **progressive enhancement**. The default server-rendered table includes the applied filters. If JavaScript loads, the filter chips become interactive and fetch filtered data client-side. If JavaScript fails, the filters fall back to traditional form submissions (`<form method="GET">`). This guarantees core functionality.
*   **Risk:** Complex state machines become verbose.
*   **Safer Path:** Use a lightweight library like `@xstate/fsm` or a simple custom hook that enforces the state transition logic.

## Summary of Changes
1.  **Shift rendering model** from full CSR to server-rendered with islands.
2.  **Replace boolean state** with explicit state machines for each async operation.
3.  **Replace custom `<div>` buttons** with semantic HTML (`<button>`, `<fieldset>`).
4.  **Restrict optimistic updates** to safe, reversible actions; use pending states for server-driven edits.
5.  **Implement progressive enhancement** so core filtering works without JavaScript.

This preserves the interactive experience while fixing performance, accessibility, state fragility, and permission safety. The cost is a more deliberate architecture, but it avoids the compounding debt of the original plan.