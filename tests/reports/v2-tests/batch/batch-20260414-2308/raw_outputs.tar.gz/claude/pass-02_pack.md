## Split Button Component Spec

---

### Component boundary

A split button is a single compound control consisting of two interactive segments that share a visual container: a **primary action trigger** and a **secondary action trigger** (dropdown). They are logically related but independently operable. The component boundary ends at the dropdown menu list — the menu items themselves are governed by the menu/listbox pattern, not the button pair.

---

### Anatomy

```
┌─────────────────────────┬────┐
│         Save            │ ▾  │
└─────────────────────────┴────┘
      Primary trigger    Chevron trigger
```

- **Primary trigger**: executes the default action ("Save") immediately on activation
- **Divider**: visual separator, not interactive, carries no semantic role
- **Chevron trigger**: opens the dropdown menu of secondary actions
- **Dropdown menu**: a positioned listbox containing secondary action items

---

### Variants and sizes

| Variant | Use case |
|---|---|
| `default` | Standard page-level save action |
| `disabled` | Entire control unavailable |
| `primary-disabled` | Primary segment unavailable; secondary still operable |
| `loading` | Primary action in flight |
| `destructive` | Reserved for future extension — do not apply to Save actions |

| Size | Primary min-width | Chevron width | Min height | Touch target |
|---|---|---|---|---|
| `md` (default) | 88px | 40px | 36px | 44×44px enforced |
| `lg` | 104px | 44px | 44px | 44×44px satisfied natively |
| `sm` | 72px | 36px | 32px | 44×44px via invisible tap zone |

Touch targets use invisible tap-zone extension (via `padding` or `::after` pseudo-element), not visual size inflation, because the split boundary must remain visually distinct.

---

### State coverage

Every state must be defined for both segments independently.

| State | Primary trigger | Chevron trigger | Menu |
|---|---|---|---|
| `default` | Actionable, full color | Actionable, full color | Closed |
| `hover` | Tinted background | Tinted background | Closed |
| `focus-visible` | 2px offset ring | 2px offset ring | Closed |
| `active` (pressed) | Depressed fill | Depressed fill | Closed / opening |
| `loading` | Spinner replaces label; non-interactive | Disabled appearance; non-interactive | Closed, blocked |
| `disabled` (full) | Muted, `aria-disabled="true"` | Muted, `aria-disabled="true"` | Inaccessible |
| `primary-disabled` | Muted, `aria-disabled="true"` | Actionable | Opens normally |
| `menu-open` | Appears default or subtly active | Chevron rotates 180° | Visible, focused |

**Loading state detail**: when the primary action fires, disable both segments, show a spinner inside the primary trigger (spinner replaces label text, not added alongside it), and retain the label width so the button does not reflow. Restore both segments on completion or error. Do not let the loading state persist indefinitely — pair it with a timeout or error boundary.

**Disabled distinction**: `aria-disabled="true"` is preferred over the `disabled` HTML attribute on the primary trigger when the chevron segment must remain operable. The `disabled` attribute prevents all tab focus; `aria-disabled` preserves focus while communicating unavailability. Apply `pointer-events: none` in CSS to suppress click without removing keyboard access.

---

### Accessibility behavior

#### Semantic structure

```html
<div role="group" aria-label="Save options">
  <button type="button" aria-label="Save">Save</button>
  <button
    type="button"
    aria-label="More save options"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="save-menu"
  >
    <svg aria-hidden="true"><!-- chevron --></svg>
  </button>
</div>

<ul
  role="menu"
  id="save-menu"
  aria-label="Save options"
  hidden
>
  <li role="menuitem">Save as draft</li>
  <li role="menuitem">Save and close</li>
</ul>
```

**Why `role="group"` not a single button**: the two triggers have independent activation behaviors. A single `button` with an internal split is not communicable to assistive technology. The group conveys that the elements are related without merging their actions.

**Chevron icon**: must be `aria-hidden="true"`. The button label carries the accessible name — the icon is decorative within it.

**`aria-haspopup="menu"`**: signals that the chevron opens a `menu` widget, not a `listbox` or `dialog`. Use this value only if the dropdown genuinely uses `role="menu"` with `role="menuitem"` children.

**`aria-expanded`**: toggles between `"false"` (menu closed) and `"true"` (menu open) on the chevron trigger only — not on the primary trigger.

#### Keyboard contract

| Key | Context | Behavior |
|---|---|---|
| `Tab` | Either trigger focused | Moves focus to next focusable element outside the component |
| `Shift+Tab` | Either trigger focused | Moves focus to previous focusable element |
| `Enter` or `Space` | Primary trigger focused | Executes "Save" immediately |
| `Enter` or `Space` | Chevron trigger focused | Opens dropdown menu; moves focus to first menu item |
| `ArrowDown` | Chevron trigger focused | Opens dropdown menu; moves focus to first menu item |
| `ArrowDown` | Inside menu | Moves focus to next menu item (wraps) |
| `ArrowUp` | Inside menu | Moves focus to previous menu item (wraps) |
| `Enter` or `Space` | Menu item focused | Executes that action; closes menu; returns focus to chevron trigger |
| `Escape` | Menu open | Closes menu; returns focus to chevron trigger |
| `Home` | Inside menu | Moves focus to first menu item |
| `End` | Inside menu | Moves focus to last menu item |
| `Tab` | Inside menu | Closes menu; moves focus forward in page (does not cycle within menu) |

Focus must return to the chevron trigger (not the primary trigger) after menu close — because that is the trigger that opened it.

#### Focus ring

Use a 2px solid outline with a 2px offset. Do not suppress `focus-visible` in any variant. The ring must be visible against both light and dark backgrounds — use a color token that passes 3:1 non-text contrast against the button surface and the page background (WCAG 2.1 SC 1.4.11).

---

### Mobile and touch

- Both segments must meet 44×44px minimum touch target (WCAG 2.5.5 AA; 24×24px is the Level AAA minimum — use 44px)
- On small viewports (< 360px), the primary trigger label may truncate with an ellipsis and a `title` attribute, but the button must remain activatable
- Tap on primary trigger: fires "Save" immediately — no hold or long-press behavior
- Tap on chevron trigger: opens bottom sheet or anchored dropdown depending on viewport and implementation context (see implementation boundary below)
- The divider between segments must remain visually clear at touch scale — minimum 1px contrast-passing separator, not removed at `sm` size
- Do not rely on hover states to communicate split affordance on touch — the chevron must be visually sufficient on its own

---

### Implementation boundary

This spec defines tokens, states, accessible markup, and keyboard behavior.

**Inside this spec:**
- Component HTML structure
- `aria-*` attributes and their values
- Keyboard interaction model
- State styling rules
- Touch target enforcement method

**Outside this spec (requires a separate decision):**
- Dropdown positioning engine (Floating UI, Popper, native `<details>`, or custom) — because the correct anchoring behavior depends on the application's scroll container, z-index stack, and viewport awareness
- Whether the mobile dropdown renders as a sheet or an anchored popover — because this depends on the design system's modal and overlay strategy
- Animation timing for open/close — because this requires reduced-motion compliance decisions at the motion system level, not the component level
- Form integration behavior — whether "Save" calls an API or submits a form depends on the consuming page, not the component

---

### Token contract

| Token | Purpose | Required value |
|---|---|---|
| `--btn-split-radius` | Outer border radius | Match design system button radius |
| `--btn-split-divider-color` | Divider line between segments | Passes 3:1 against button fill |
| `--btn-split-focus-ring-color` | Focus ring color | Passes 3:1 against button surface and page bg |
| `--btn-split-disabled-opacity` | Disabled segment opacity | 0.40–0.45 (sufficient muting without full invisibility) |
| `--btn-split-loading-size` | Spinner diameter | 16px at `md`, 18px at `lg` |
| `--btn-split-min-touch-primary` | Primary segment touch area | 44px minimum |
| `--btn-split-min-touch-chevron` | Chevron segment touch area | 44px minimum |

---

### What this spec preserves vs. sacrifices

**Preserved**: keyboard completeness, touch safety, state independence between segments, semantic honesty with assistive technology, and loading-state stability (no reflow).

**Sacrificed**: simplicity of implementation. A split button is architecturally heavier than a single button with a secondary link below it. If the secondary actions ("Save as draft," "Save and close") are equally important to the primary action, a flat button group may be a better fit — because this component visually signals that "Save" is the dominant choice. If that hierarchy is not true, the split button creates a false emphasis.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: primary trigger + chevron trigger + dropdown menu; menu items are external",
    "accessibility_behavior: role=group with two independent buttons, aria-haspopup=menu, aria-expanded on chevron only",
    "state_coverage: default, hover, focus-visible, active, loading, disabled, primary-disabled, menu-open — all defined for both segments",
    "implementation_boundary: positioning engine, mobile sheet vs popover, animation timing, and form integration are outside this spec"
  ],
  "evidence_classes_cited": [
    "wcag_2.1_sc_1.4.11_non_text_contrast",
    "wcag_2.5.5_target_size_44px",
    "aria_haspopup_menu_pattern",
    "aria_disabled_vs_html_disabled_distinction"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the dropdown positioning engine already decided in the design system? That determines whether Floating UI, a sheet, or native anchoring applies.",
    "Should 'Save as draft' and 'Save and close' trigger API calls or form submissions? This affects whether the loading state propagates to menu items."
  ],
  "turn": 1
}
[/SESSION_STATE]