The governing work here is layout reconstruction from an existing artifact, with grid system translation as the output goal. PDF layout integrity is a supporting concern because the source is a scanned or exported guidelines document rather than a live design file.

## What to extract from the 2018 PDF

### Page architecture

Start with the document's own physical structure before touching any diagram.

- Trim size and orientation (likely A4, US Letter, or a custom brand format)
- Margin set: top, bottom, inside, outside — note whether margins are equal or asymmetric, which signals print-aware or presentation-aware design intent
- Whether the document uses a single-page or spread-based layout (spreads suggest the grid was designed for print binding, which affects how you adapt it for screen)

### Grid structure

From the grid diagrams themselves:

- Column count per layout type (it is common for a 2018 brand PDF to show a 12-column web grid, a 3- or 4-column print grid, and a 2-column editorial grid as separate examples)
- Gutter width — stated in millimeters, pixels, or percentage; note the unit because it tells you the target medium
- Whether columns are fixed-width or proportional
- Whether the grid is symmetric or offset (offset grids with a wider first or last column were common in brand books of that era)
- Any bleed or safe-zone markings that sit outside the margin

### Typographic baseline

Grid diagrams from that period often encode a baseline increment even when it is not called out explicitly.

- Look for any vertical rhythm annotations: line-height values, cap-height rulers, or baseline grid overlays
- If you can identify the body text size from the document itself, you can reverse-engineer the baseline increment by measuring the apparent leading visually

### Margin specifications

- Check whether margin values are stated in absolute units (mm, pt, px) or relative units (percentage of page width)
- Identify whether one margin carries more white space intentionally (this is a spatial anchor and usually maps to a key column in the grid)
- Note any stated "content safe area" boundaries separately from the structural margin

### Column examples

The layout examples are the richest source because they show the grid applied rather than just defined.

- Count actual columns used in each example, not just what the grid supports
- Note which column spans appear most often: full-width, half-page, one-third, two-thirds
- Look for a persistent narrow column used for captions, pull quotes, or labels — this is often a structural column that the main grid only implies
- Identify whether headlines break the column grid or respect it

### Color and production notes

Even if you are only targeting layout, note:

- Any print-specific color specifications tied to layout elements (rules, dividers, background fields)
- Registration marks or production notes that signal the document's original medium intent

---

## How to translate the extracted values into a modern layout system

### Step 1: Determine the original medium intent

A 2018 brand PDF is almost always print-first or presentation-first. Translating it to screen requires explicit decisions rather than a direct conversion.

If the grid was specified in millimeters, convert the proportions (not the raw numbers) to a pixel or rem basis. A 210mm wide page with 15mm margins and a 12-column grid has margins at roughly 7.1% of page width. That proportion holds in a responsive grid as a rem-based margin or percentage gutter better than any literal mm-to-px conversion.

### Step 2: Reconstruct the column model

From the extracted column count and gutters, build a modern equivalent:

- If the source was 12-column, map it directly to a 12-column CSS grid or a 12-unit token in your layout system
- If the source was 3- or 4-column print, consider whether you want to match the visual weight (3-column at wide breakpoints, collapsing to 1 or 2 on mobile) or whether you want to expand it to 12 for flexibility
- Convert gutter values: if the original was 6mm gutters on a 210mm page, that is approximately 2.9% of page width — a reasonable proxy for a 16px or 24px gutter at a standard 1280px container

### Step 3: Set the margin rhythm

Rather than copying the raw margin number, set the margin as a multiple of your baseline spacing unit.

If your design system uses an 8px grid:
- A 15mm margin at 96dpi converts roughly to 57px — round to 56px (7 × 8) or 64px (8 × 8) depending on how open the original felt
- Use the same multiple for both horizontal and vertical spacing anchors

If the original had asymmetric margins, decide now whether that asymmetry is meaningful to preserve (a brand signature) or accidental (a print binding allowance that does not translate to screen). Binding margins should not survive the translation.

### Step 4: Define the breakpoint set

The 2018 document will not have breakpoints because it was print-first. You add these now using the column model as your guide.

A reasonable translation for a formerly 12-column brand system:

| Breakpoint | Columns | Margin | Gutter |
|---|---|---|---|
| Mobile (< 600px) | 4 | 16px | 16px |
| Tablet (600–1024px) | 8 | 24px | 24px |
| Desktop (1024–1440px) | 12 | 48px | 24px |
| Wide (> 1440px) | 12 | Auto (max-width container) | 24px |

Adjust margin and gutter values to fit your baseline increment. These are starting values, not universal truth.

### Step 5: Encode the narrow structural column

If the original had a persistent caption or label column, give it a named role in your system rather than treating it as an ad hoc span. In a 12-column grid, this might be 2 columns reserved as a metadata or annotation zone, with content living in the remaining 10. Define this as a named layout template rather than a one-off column-span decision.

### Step 6: Map the typography baseline to your spacing scale

If you recovered a baseline increment from the PDF:
- Use it as the base of your line-height token
- Align your spacing scale to a multiple of this increment
- This preserves the vertical rhythm that gave the original its visual coherence, even if no one called it by that name in 2018

If you could not extract a clean baseline, use 4px or 8px as your increment and accept that the vertical rhythm is your interpretation rather than a direct preservation.

### Step 7: Document what you inferred versus what was stated

Before handing the reconstructed system to template designers, annotate the difference between what came directly from the PDF and what you translated or estimated. This protects against false confidence and makes future audits honest.

Useful annotation categories:
- **Stated**: margin value, column count, gutter width if specified
- **Inferred**: baseline increment, breakpoint behavior, responsive collapse order
- **Assumed**: medium intent, proportion-over-literal conversion rationale
- **Discarded**: binding margins, print production marks, medium-specific bleed values

---

## Tradeoffs to name now

Preserving the proportional feel of the original grid means accepting that exact pixel values will not match the source document — and that is correct, because the source document was not designed for pixels. You gain visual continuity; you sacrifice literal reproduction.

Expanding a 3-column print grid to a 12-column responsive system gives you flexibility, but it means the original grid's strong three-part rhythm only surfaces when you use 4-column spans at desktop, which requires governance to enforce.

Recovering the narrow structural column as a named layout template costs a small governance overhead but prevents that column from being eroded column by column as new templates are created without knowing the original intent.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: column count, margin proportions, structural narrow column, typographic baseline increment",
    "inference_boundary: baseline increment inferred from body text measurement, breakpoints not present in source",
    "reconstruction_order: page architecture → grid structure → margin rhythm → breakpoint set → narrow column → typography baseline → annotation layer",
    "verification_method: annotate stated vs inferred vs assumed vs discarded before handoff"
  ],
  "evidence_classes_cited": [
    "layout_proportion_conversion",
    "grid_column_model",
    "spacing_scale_derivation",
    "breakpoint_model"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the PDF print-quality vector or a scanned raster? Raster PDFs require visual measurement rather than coordinate extraction.",
    "What is the primary output medium for the new templates — screen, print, or both?",
    "Does the brand system need to stay document-compatible (InDesign) or move entirely to a web/code-based grid?"
  ],
  "turn": 1
}
[/SESSION_STATE]