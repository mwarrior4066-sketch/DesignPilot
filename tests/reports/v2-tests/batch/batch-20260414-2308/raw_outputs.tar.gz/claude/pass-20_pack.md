# Backend Architecture Spec: Multi-Tenant Scheduling Platform

**Governing route:** `rt_backend_architecture_spec`
**Supporting skills:** `back-end-systems-architect`, `api-reliability-security-expert`, `back-end-aware-planner`
**Task weight:** compound

---

## Authority model

### Tenant isolation

Every row in every mutable table carries a `tenant_id`. Row-level security (RLS) policies enforce this at the database layer — not only in application code — so that a misconfigured service cannot accidentally read or write across tenant boundaries.

```
tenants (id, slug, plan_tier, created_at)
workspaces (id, tenant_id, name, settings_jsonb)
members (id, workspace_id, user_id, role, invited_at, accepted_at)
```

Tenant resolution happens at the API gateway before any service receives the request. The gateway reads the subdomain or `X-Tenant-ID` header, resolves the tenant record, stamps the request context, and issues an internal JWT that carries `{ tenant_id, workspace_id, user_id, role }`. Downstream services trust that token; they do not re-query tenant identity.

**Why this matters:** without gateway-level resolution, each service must independently trust and validate tenant claims, which creates drift. Centralizing it means one place to audit and one place to fix.

### Role model

```
OWNER    → all actions including billing and tenant deletion
ADMIN    → workspace configuration, member management, webhook management
EDITOR   → create/edit schedules, submit approvals
VIEWER   → read-only; no mutations
WEBHOOK_SVC → internal service principal; outbound only, no inbound mutations
```

Object-level authorization (BOLA check) is required on every schedule, approval, and feed cursor read. Role check alone is insufficient because an EDITOR in workspace A must not reach workspace B records even if both workspaces belong to the same tenant. The check is: `resource.workspace_id = jwt.workspace_id AND resource.tenant_id = jwt.tenant_id`.

---

## Data model

### Schedules and items

```sql
schedules (
  id             uuid primary key,
  tenant_id      uuid not null references tenants(id),
  workspace_id   uuid not null references workspaces(id),
  owner_id       uuid not null references users(id),
  title          text not null,
  status         text not null check (status in ('draft','pending_approval','approved','rejected','published','archived')),
  version        int not null default 1,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null
)

schedule_items (
  id             uuid primary key,
  schedule_id    uuid not null references schedules(id) on delete cascade,
  tenant_id      uuid not null,          -- denormalized for RLS performance
  starts_at      timestamptz not null,
  ends_at        timestamptz,
  payload_jsonb  jsonb not null,
  sequence       int not null            -- ordering within schedule
)
```

**Indexes required:**
- `(tenant_id, workspace_id, status)` on `schedules` — feeds the workspace view
- `(tenant_id, updated_at DESC)` on `schedules` — feeds the activity cursor
- `(schedule_id, sequence)` on `schedule_items` — feeds sorted item reads

### Approval workflow

```sql
approval_requests (
  id              uuid primary key,
  tenant_id       uuid not null,
  schedule_id     uuid not null references schedules(id),
  requested_by    uuid not null references users(id),
  status          text not null check (status in ('pending','approved','rejected','cancelled')),
  required_count  int not null default 1,
  approved_count  int not null default 0,
  created_at      timestamptz not null
)

approval_decisions (
  id              uuid primary key,
  request_id      uuid not null references approval_requests(id),
  tenant_id       uuid not null,
  decided_by      uuid not null references users(id),
  decision        text not null check (decision in ('approved','rejected')),
  note            text,
  decided_at      timestamptz not null
)
```

Approval state is owned by `approval_requests.status` — it is the single source of truth. The `approved_count` is a denormalized counter incremented inside a transaction when a decision row is inserted. If `approved_count >= required_count`, the request transitions to `approved` and the schedule status transitions to `approved` in the same transaction. This is an optimistic write with a row-level lock on `approval_requests` — no eventual consistency for status transitions.

**Why not eventual here:** approval state drives downstream webhook dispatch and the published UI state. A lag between the decision and the status would require compensating reads everywhere. The serialized write costs a small lock duration but eliminates ambiguity.

---

## Consistency stance

| Surface | Model | Rationale |
|---|---|---|
| Schedule status transitions | Serialized write, row-level lock | Drives webhooks and published state; ambiguity is unacceptable |
| Approval decisions | Serialized write, row-level lock | Multi-approver count integrity |
| Activity feed append | Append-only, eventual | Feed is read-after-write with cursor; strong consistency not required |
| Webhook dispatch | At-least-once via job queue | Idempotency key on the receiver; duplicate delivery is safer than missed delivery |
| Member/workspace config | Last-write-wins with updated_at | Low-frequency; conflict probability is negligible |

---

## Cursor-based activity feed

### Feed event schema

```sql
activity_events (
  id             bigserial primary key,    -- monotonically increasing; used as cursor
  tenant_id      uuid not null,
  workspace_id   uuid not null,
  actor_id       uuid,
  event_type     text not null,            -- 'schedule.created', 'approval.requested', etc.
  entity_type    text not null,
  entity_id      uuid not null,
  payload_jsonb  jsonb not null,
  occurred_at    timestamptz not null default now()
)
```

Using a `bigserial` as the cursor anchor means the cursor value is stable, monotonic, and cheap to compare. UUIDs work but require a secondary sort column; `bigserial` eliminates that.

### Pagination contract

```
GET /workspaces/{workspace_id}/feed?after={cursor}&limit={n}

Response:
{
  "events": [...],
  "next_cursor": "8421",
  "has_more": true
}
```

- `after` is inclusive-exclusive: return rows where `id > after`
- Default limit: 25. Maximum limit: 100. Requests above 100 receive a 400 with a problem detail
- When `has_more` is false and the client holds an open connection, it may use a SSE or WebSocket channel for push; polling is always the safe fallback
- Cursor values are opaque to clients but are integers internally — do not encode them as base64 unless you need to hide the sequence shape

**Index:**
```sql
CREATE INDEX idx_feed_workspace_cursor
  ON activity_events (tenant_id, workspace_id, id DESC);
```

This index makes the paginated read a bounded range scan. Without it, the feed query degrades to a full workspace scan at scale.

### Feed write path

Activity events are written by an internal event bus subscriber, not inline in the API handler. The schedule service emits a domain event (`ScheduleStatusChanged`, `ApprovalRequested`, etc.); the feed writer subscribes and appends to `activity_events`. This decouples feed latency from the mutation path and means a slow feed write cannot block a schedule update.

---

## Approval workflow state machine

```
draft
  └─► pending_approval   (EDITOR submits; approval_request created)
        ├─► approved      (all required approvers decide 'approved'; same-tx schedule update)
        │     └─► published  (ADMIN/OWNER explicit publish action)
        └─► rejected      (any approver decides 'rejected'; schedule reverts to draft)

approved
  └─► archived           (OWNER/ADMIN)

published
  └─► archived           (OWNER/ADMIN)
```

**Transition guards:**
- Only an EDITOR or ADMIN may submit for approval; VIEWER may not
- Only an ADMIN or OWNER may approve or reject
- An EDITOR may not approve their own submission (enforced by: `decision.decided_by != request.requested_by`)
- Cancellation is allowed only while status is `pending`; once a decision exists, cancel is blocked

**Why block self-approval:** it eliminates an entire class of audit failures without needing a separate policy engine. The constraint is simple enough to enforce at the data layer.

---

## Outbound webhooks

### Webhook registration

```sql
webhook_endpoints (
  id              uuid primary key,
  tenant_id       uuid not null,
  workspace_id    uuid not null,
  url             text not null,
  secret          text not null,      -- stored encrypted; used for HMAC signing
  event_types     text[] not null,    -- ['schedule.approved', 'schedule.published', ...]
  active          boolean not null default true,
  failure_count   int not null default 0,
  last_failure_at timestamptz,
  created_by      uuid not null references users(id)
)
```

Only ADMIN or OWNER may register or delete webhook endpoints. VIEWER and EDITOR have no access to the webhook registry — the webhook service principal (`WEBHOOK_SVC`) operates entirely through the job queue.

### Dispatch lifecycle

```
schedule event fires
  → webhook_jobs row inserted (status: queued)
  → job worker picks up row
  → signs payload with HMAC-SHA256 using endpoint secret
  → POST to customer URL with headers:
      X-Webhook-ID: {job_id}
      X-Webhook-Timestamp: {unix_epoch}
      X-Hub-Signature-256: sha256={hmac}
      Idempotency-Key: {job_id}
  → customer system returns 2xx → job marked completed
  → customer system returns 4xx (not 429) → job marked failed, no retry (client error)
  → customer system returns 5xx or timeout → exponential backoff with jitter, up to 5 attempts
  → after 5 failures → endpoint.failure_count incremented
  → failure_count >= 10 over 24 hours → endpoint auto-deactivated, ADMIN notified
```

**Retry schedule:**
```
attempt 1: immediate
attempt 2: 30s + jitter(0–10s)
attempt 3: 5m + jitter
attempt 4: 30m + jitter
attempt 5: 2h + jitter
```

After 5 failures, the delivery is marked `dead_lettered`. The payload is retained for 30 days for manual replay. Dead-letter replay is ADMIN-only and reuses the same `job_id` as the idempotency key, so a customer system that correctly implements idempotency will deduplicate the replayed delivery.

### Payload schema

```json
{
  "webhook_id": "uuid",
  "event_type": "schedule.approved",
  "occurred_at": "2025-01-15T14:22:00Z",
  "tenant_id": "uuid",
  "workspace_id": "uuid",
  "data": {
    "schedule_id": "uuid",
    "title": "Q1 Campaign Schedule",
    "approved_by": ["user-uuid-1", "user-uuid-2"],
    "version": 3
  }
}
```

The `tenant_id` is included in the payload so the customer system can route it without keeping a separate mapping. The `webhook_id` is the job ID — this is the idempotency key the customer should store and check.

---

## Data delivery

### Read path

```
Client → API gateway (tenant resolution + JWT stamp)
       → Schedule service
       → Postgres (RLS enforced)
       → Redis read-through cache for hot workspace views (TTL: 60s)
       → Response
```

Cache invalidation: workspace view cache is evicted on any schedule status change within that workspace. The event bus message that triggers the feed writer also triggers cache eviction. This is a targeted invalidation, not a full cache flush — the cost is one additional pub/sub message per mutation.

### Write path

```
Client → API gateway
       → Schedule service
       → Postgres (RLS + row-lock on status transitions)
       → Domain event emitted to internal bus
       → [Feed writer] appends activity_events row
       → [Webhook dispatcher] enqueues webhook_job rows
       → [Cache invalidator] evicts workspace view cache
```

All three downstream handlers are asynchronous. The API returns to the client as soon as the Postgres write and event emission succeed. The client does not wait for feed append, webhook dispatch, or cache eviction.

---

## Observability

Every request and job carries a `trace_id` propagated through all service boundaries. Minimum required instrumentation:

| Signal | What to capture |
|---|---|
| Request traces | `trace_id`, `tenant_id`, `workspace_id`, `route`, `duration_ms`, `status_code` |
| Approval events | `trace_id`, `request_id`, `decision`, `decided_by`, duration from creation to decision |
| Webhook jobs | `trace_id`, `job_id`, `endpoint_id`, attempt number, response code, duration |
| Feed writes | `trace_id`, `event_type`, lag from domain event to feed row insert |
| Auth failures | `trace_id`, `tenant_id`, BOLA check failures logged separately with high severity |

BOLA check failures warrant separate high-severity logs because they may indicate a misconfigured client, a token leak, or an active cross-tenant probe. Rate-limit them at the gateway and alert when the failure rate exceeds threshold.

---

## Blocking constraints

**Must resolve before first production tenant:**

1. **RLS policy coverage** must be verified by integration tests that attempt cross-tenant reads with valid tokens. Policy correctness cannot be assumed from code review alone.

2. **Webhook URL validation** must reject private IP ranges (10.x, 172.16–31.x, 192.168.x, 127.x, 169.254.x) and resolve the URL at registration time, not only at dispatch time. SSRF is the most common misconfiguration in outbound webhook systems.

3. **Approval self-approval guard** must be enforced at the database layer (check constraint or trigger), not only in application code. Application-layer-only enforcement can be bypassed by direct API calls from service accounts.

4. **Cursor index existence** must be verified in the migration. A missing index on `(tenant_id, workspace_id, id DESC)` makes feed pagination degrade from O(log n) to O(n) at workspace scale. Silent at low volume; catastrophic above ~50k events per workspace.

5. **Webhook secret rotation** must have a defined procedure before customer endpoints go live. Rotation requires a dual-signing window (old and new secret both accepted for a short overlap) to prevent delivery failures during rotation.

---

## Architecture tax

This design accepts the following costs knowingly:

- **Row-level locking on approval transitions** adds latency on high-concurrency approval workloads. The tradeoff is: you get exact approval counts and deterministic state without compensating reads. Acceptable for scheduling workflows where approval throughput is measured in tens per minute, not thousands.

- **Append-only activity feed** grows unboundedly. This requires a retention and archival policy (suggested: hot data 90 days in Postgres, cold data in object storage with a separate reader). Skipping this creates a table that becomes unmanageable within 12–18 months for active tenants.

- **At-least-once webhook delivery** means customer systems must implement idempotency. This is a correctness obligation pushed to the customer. Document it explicitly in the webhook integration guide and enforce it by example in the payload design (the `webhook_id` field exists for exactly this reason).

- **Redis as a read-through cache** adds an infrastructure dependency. The system must degrade gracefully to Postgres-direct reads when Redis is unavailable — do not make Redis a hard dependency in the read path. The cache is a latency optimization, not an authority.

---

[SESSION_STATE]
{
  "route": "rt_backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "authority_model: gateway-stamped JWT with tenant_id + workspace_id + role; downstream services trust the token",
    "consistency_stance: serialized row-lock for approval transitions; append-only eventual for activity feed; at-least-once for webhooks",
    "data_delivery: Redis read-through cache TTL 60s; targeted eviction on status change; graceful degradation to Postgres-direct",
    "observability_tax: trace_id on all boundaries; BOLA failures high