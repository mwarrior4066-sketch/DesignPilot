## Onboarding Redesign

**Role:** UX Designer — Research, Wireframing, Prototyping, Engineering Collaboration

---

### The Problem

New users were dropping off before completing setup. Research made the cause clear: the existing flow asked for too much, in the wrong order, before users understood what they were getting in return.

### Research

Interviews and observation sessions surfaced a consistent pattern. Users hit early friction, stalled, and left. The confusion wasn't random — it clustered around specific steps where the product asked for commitment before it had established trust.

### What Changed

The redesign restructured the flow around a single principle: earn the next step before asking for it. Information requests were reordered, low-value gates were removed, and progress cues were added to reduce perceived effort. Wireframes were tested iteratively, with prototypes refined through two rounds of user feedback before engineering handoff.

Collaboration with engineering started early — before visual design was finalized — so technical constraints shaped the solution rather than forcing late-stage compromises.

### Outcome

Conversion through the onboarding flow improved by 40%.

---

### What This Case Demonstrates

The improvement came from diagnosis before redesign: understanding *where* users stalled and *why*, not just that they stalled. The structural fix preceded the visual work, and early engineering involvement meant the shipped product matched the tested design.

---

**A note on evidence:** The 40% figure reflects what was measured. If you have the baseline rate, drop duration, or qualitative session data, those numbers would sharpen the narrative further and close the remaining gap between reported outcome and verified impact.

[SESSION_STATE]
{
  "route": "rt_case_study_rewrite",
  "escalation_level": "standard",
  "decisions_committed": [
    "claim_vs_proof_boundary: 40% figure cited as measured, evidence gap flagged",
    "narrative_order: problem → research → structural fix → outcome → proof note",
    "proxy_vs_measured: qualitative confusion cited as observed pattern, not measured metric",
    "honesty_tradeoff: baseline and session data noted as missing — flagged, not fabricated"
  ],
  "evidence_classes_cited": ["observed_pattern", "measured_outcome"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What is the baseline conversion rate before the redesign?",
    "Do you have session drop-off data by step?",
    "Are there qualitative quotes available from research sessions?"
  ],
  "turn": 1
}
[/SESSION_STATE]