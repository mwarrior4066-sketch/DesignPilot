## Research gap map: B2B project management redesign

### What you actually know

Before mapping gaps, it helps to be precise about what each evidence source proves versus what it suggests.

**3 stakeholder interviews**
Stakeholders describe organizational pain, priority framing, and business constraints. They do not represent task-level user behavior. Their accounts of why users struggle are inferences, not observations.

**2 usability tests on current product**
Two sessions is a directional signal, not a pattern. You can name specific friction points that appeared, but you cannot claim frequency, severity ranking, or representativeness. Treat these as hypothesis generators.

**60% drop-off on project creation flow**
This confirms a behavioral failure is real and localized. It does not explain causation: you do not know whether users are abandoning because the task is too complex, the form is broken, they are blocked by a permission issue, they are simply exploring, or the flow requires information they do not have yet.

---

### Gap map: priority order

#### Gap 1 — Abandonment causation (critical, blocks design decisions)

You have behavioral proof that something is wrong. You have no causal explanation.

Every design decision about the project creation flow is currently a guess. If abandonment is driven by permission confusion, the fix is a different information architecture. If it is driven by required fields the user cannot answer, the fix is progressive disclosure or defaults. If it is driven by the form itself, the fix is UI. These are not the same solution.

**Method:** Exit survey on the abandonment step (one focused question, deployed at drop-off). Pair with 4 to 6 task-based sessions on the creation flow specifically, asking users to think aloud when they stop or hesitate.

**Evidence class this fills:** behavioral causation, not just behavioral fact.

---

#### Gap 2 — Power user workflows and workarounds (high, affects architecture decisions)

B2B tools stratify. A significant portion of your active sessions are likely concentrated in a small percentage of users who have adapted to the current system in ways that standard testing will not surface. These users are also the ones who will resist changes most vocally and whose muscle memory is most at risk from a redesign.

You do not know what they have built on top of the tool, which features they depend on heavily, or which apparent "problems" are actually intentional behaviors they rely on.

**Method:** Recruit 3 to 5 power users through your highest-session-count or longest-tenure cohort. Run contextual inquiry or screen-share observation, not a usability test. You are watching their actual workflow, not testing a task.

**Evidence class this fills:** expert-user mental model, workaround archaeology, risk surface for redesign breakage.

---

#### Gap 3 — Competitive framing and category conventions (moderate, affects positioning and new-user expectations)

B2B project management is a mature category. Users arrive with prior experience of Asana, Jira, Monday, Notion, Linear, or similar tools. Their expectations about what "project creation" means are shaped by those experiences before they touch your product.

Without competitive analysis, you cannot distinguish between product-specific failures and category-level friction. You also cannot identify where differentiation is meaningful versus where deviating from convention creates unnecessary learning cost.

**Method:** Structured teardown of 3 to 4 direct competitors on the project creation flow specifically. Focus on: required fields, default states, template behavior, and permission prompts. This is a desk-research task, not a user research task.

**Evidence class this fills:** category baseline, convention map, differentiation boundary.

---

#### Gap 4 — Role-based task variation (moderate, affects scope of redesign)

B2B tools are almost always used by multiple roles with different goals. A project manager creating a project has different needs than a team member being assigned to one, or an account admin managing project templates. Your current evidence does not distinguish between these.

If the usability tests were run with a homogeneous user type, findings may not generalize. If stakeholder interviews were with decision-makers, they may have overstated admin-level concerns and understated individual-contributor friction.

**Method:** Map your existing user base by role using analytics segmentation. Then run 2 to 3 task-based sessions per primary role. Look for where flows diverge, not just where they fail.

**Evidence class this fills:** role-differentiated mental model, task-flow branching map.

---

#### Gap 5 — Return and reentry behavior (lower priority, but relevant to navigation architecture)

Drop-off does not tell you whether users are abandoning permanently or returning to complete the task later through a different entry point. A 60% drop-off in a single session might actually reflect a workflow where users start, gather information, and return. If that is the case, the redesign priority shifts from reducing friction on a single pass to supporting a resumption pattern.

**Method:** Cohort analysis on users who trigger the creation flow more than once per project. Check whether the same project ID gets completed later, or whether those are distinct project starts.

**Evidence class this fills:** session-level vs. task-level completion distinction.

---

### Research sequence recommendation

Run these in this order, because each one constrains the next:

1. **Abandonment exit survey** (deploy immediately, costs almost nothing, gives you causal signal within 2 weeks)
2. **Power user contextual inquiry** (before any wireframes, because these users define what must not break)
3. **Competitive teardown** (desk research, run in parallel with power user recruitment)
4. **Role-segmented usability sessions** (once you have a draft direction, to validate against role variation)
5. **Session-cohort analysis** (analytics work, run in parallel whenever engineering time is available)

---

### Honest constraint

Your current 2 usability sessions should inform hypothesis generation, not finding validation. If the redesign brief treats those sessions as representative, the gap map above will not help because the design will already be anchored to thin evidence treated as solid ground.

The 60% drop-off is the most honest signal you have. Build the first research sprint around explaining it.

[SESSION_STATE]
{
  "route": "rt_ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": [
    "known_evidence: 3 stakeholder interviews, 2 usability tests, 60% drop-off on project creation",
    "gap_priority: abandonment causation > power user workflows > competitive framing > role variation > reentry behavior",
    "method_mapping: exit survey + think-aloud for gap 1, contextual inquiry for gap 2, desk teardown for gap 3, segmented usability for gap 4, cohort analysis for gap 5",
    "research_sequence: exit survey first, power user inquiry before wireframes, competitive in parallel"
  ],
  "evidence_classes_cited": ["behavioral_fact", "behavioral_causation", "expert_user_mental_model", "category_baseline", "role_differentiated_mental_model"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Were the 2 usability tests run with a homogeneous user type or across roles?",
    "Is the 60% drop-off measured at a single step or across the full creation flow?",
    "Do analytics allow cohort-level segmentation by role or tenure?"
  ],
  "turn": 1
}
[/SESSION_STATE]