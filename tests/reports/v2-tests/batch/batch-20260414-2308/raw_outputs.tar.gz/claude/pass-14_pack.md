This is a compound task: rendering model, state ownership, semantic structure, authorization perimeter, and accessibility behavior all compete for the answer, and getting any one wrong breaks the others. Front-end architecture governs; accessibility and back-end feasibility support.

---

## What the current plan gets wrong, and why it matters

**Client-rendered everything, for a permissions-heavy screen**

A large CSR page means the server sends a shell, the client fetches data, and role visibility is enforced by JS hiding elements after they arrive. That is not a security boundary. It is a cosmetic filter. A determined user can inspect the network response and see rows, columns, or filter options they are not supposed to see. The authorization perimeter must sit at the data layer, not the render layer.

**Separate `isLoading` / `isError` booleans**

Two independent booleans produce four possible states, two of which are incoherent (`isLoading: true` and `isError: true` simultaneously). The real state machine has five named states: `idle`, `loading`, `success`, `error`, `stale`. Booleans cannot represent stale data, partial success, or background revalidation cleanly. This leads to impossible UI states shipping to production.

**Custom div buttons for filter chips**

`<div>` elements do not receive keyboard focus by default, do not announce as interactive to screen readers, and do not fire `click` on `Enter` or `Space` without manual event wiring. Every custom div button is a WCAG 4.1.2 failure (Name, Role, Value) until proven otherwise. Filter chips are `<button>` elements with `aria-pressed` for toggle behavior, or `<input type="checkbox">` with visual styling. There is no safe path through a div-based approach.

**Optimistic updates for recurring schedule edits**

Optimistic updates are safe when a failure only affects one item and rollback is cheap. Recurring edits are neither. Editing a recurring appointment means the server must decide scope (this instance, this and forward, all instances) and then cascade that decision across potentially hundreds of records. If the client applies an optimistic update and the server rejects the scope decision, rollback is destructive: you are reverting UI state across a set of records the user cannot see on screen. The safer contract is a confirmed-commit pattern: send the mutation, show a loading state, commit the UI only on server success.

---

## Recommended architecture

### Rendering and mutation strategy

Use **Partial Prerendering (PPR) with streaming**, or server-rendered pages with client islands if PPR is not available in your stack. The structural shell (chrome, navigation, column headers, filter bar skeleton) renders on the server. Data-bearing regions stream in as server components. Client hydration is scoped to interactive islands only.

The authorization perimeter sits at the data-fetch layer. Role is resolved server-side before any data leaves the API. Columns, rows, and filter options that the current role cannot see are simply not included in the response. The client receives a permission-scoped payload, not a full payload with visibility toggled in JS.

**Rendering boundary map:**

| Region | Rendering model | Reason |
|---|---|---|
| Page shell, nav | Server component | No interactivity needed |
| Table rows | Server component, streamed | Data is role-scoped at source |
| Filter bar | Client island | Toggle state is local interaction |
| Row action menus | Client island | Requires event handling |
| Schedule edit modal | Client island | Form state is local |
| Confirmation dialogs | Client island | User decision, no server data |

This means accepting a slightly more complex component boundary setup in exchange for a genuine authorization boundary and faster first paint.

### State ownership

Replace the boolean pair with a discriminated union. Every component that handles async data should operate on exactly one of these states:

```typescript
type AsyncState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T; staleAt?: number }
  | { status: 'error'; error: AppError; retryable: boolean }
  | { status: 'stale'; data: T; revalidating: boolean };
```

State lives in the server fetch layer, not component local state, for table data. Mutations are owned by server actions or API route handlers. Filter state lives in URL search params, not component state, because it is shareable, bookmarkable, and survives page refresh without a state management layer.

**State ownership map:**

| State | Owns it | Why |
|---|---|---|
| Table data | Server fetch + React cache | Role-scoped, not duplicated client-side |
| Filter selections | URL search params | Shareable, survives refresh |
| Sort order | URL search params | Same reason |
| Pagination cursor | URL search params | Same reason |
| Row action open/closed | Local component state | Ephemeral UI |
| Modal open/closed | Local component state | Ephemeral UI |
| Edit form values | Local form state | Local until submitted |
| Mutation in-flight | Server action state | Not guessed client-side |

### Semantic contract for filter chips and table controls

Filter chips must be `<button>` elements with `aria-pressed="true|false"` for toggle behavior, or `<input type="checkbox">` elements with custom visual styling applied via CSS. The element determines the accessibility contract. There is no shortcut.

Table controls:

- Sortable column headers: `<th>` with `aria-sort="ascending | descending | none"`
- Row checkboxes: `<input type="checkbox">` with an `aria-label` that names the row, not just "select"
- Row action menus: `<button>` as the trigger with `aria-haspopup="menu"` and `aria-expanded`
- The table itself: `<table>` with `<caption>` or `aria-labelledby` pointing to a visible heading

For dense tables, visible column headers must remain associated with cells via `<th scope="col">`. If the table is wider than viewport, it must scroll inside a container with `role="region"` and `aria-label`, not by clipping the page.

### Recurring edit mutation contract

Replace optimistic updates with a confirmed-commit pattern using a scope-resolution dialog:

1. User triggers edit on a recurring event
2. System presents scope choice: this instance / this and forward / all instances
3. User confirms scope
4. Client sends mutation with scope parameter and an idempotency key
5. Server processes, cascades, and responds with `200` plus the affected record set, or `409` if a conflict exists
6. Client commits UI only on server success
7. On error, show the error state with a retry option; do not roll back phantom state

The mutation payload must include a scope field. The server must validate it. The client must not assume the scope was applied correctly.

```typescript
type RecurringEditPayload = {
  scheduleId: string;
  instanceDate: string;
  scope: 'this_instance' | 'this_and_forward' | 'all_instances';
  changes: Partial<ScheduleRecord>;
  idempotencyKey: string; // client-generated, UUID v4
};
```

The server responds with:
- `200 OK` + affected records array on success
- `409 Conflict` + `RFC 9457` problem detail if a scope conflict exists
- `403 Forbidden` if the role does not have permission to edit the requested scope

### Role-based visibility: the actual boundary

Role-scoped data delivery means the API contract must be explicit about what each role receives, not what is hidden after delivery.

```
only [scheduler_admin] may receive filter options for all_locations
only [team_lead] may receive rows for their assigned team
only [viewer] may receive read-only payloads with no action columns
deny by default: if role is not in the permitted set, return 403, not an empty array
```

Returning an empty array instead of a 403 when access is denied is a silent authorization failure. It looks like "no data" to the user and "no error" to the system. Both are wrong.

---

## Risks and safer path

**What you sacrifice:** Optimistic updates are faster-feeling for simple edits. Removing them from recurring edits adds one round-trip confirmation per scope resolution. Users will notice a beat of latency. The tradeoff is that rollback failures for scope-cascade operations are destructive, not recoverable, so the latency is the right cost.

**What you preserve:** Authorization integrity, accessible interaction contracts, coherent state representation, and idempotent mutation safety.

**Migration sequence:**

1. Fix semantic structure first (div buttons → real interactive elements). This is a hard accessibility floor and it does not require any architecture change. It unblocks keyboard users and screen reader users immediately.
2. Move filter state to URL params. This is a low-risk refactor that eliminates a class of state synchronization bugs.
3. Replace boolean state with discriminated unions. Refactor one data region at a time, starting with the table.
4. Move to server components for data-bearing regions. This is the largest change and should follow step 3 so state is already clean.
5. Add the idempotency key and scope contract to recurring edits. Requires a server-side change alongside the client.

Do not attempt the rendering model change before the state model is clean. A poorly shaped state model in a server component architecture produces hydration mismatches that are harder to debug than the original CSR problem.

[SESSION_STATE]
{
  "route": "rt_frontend_architecture",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: PPR with streaming, server components for data regions, client islands for interactive elements",
    "state_ownership: discriminated union AsyncState<T>, filter/sort/pagination in URL params, mutations owned by server actions",
    "boundary_placement: authorization perimeter at data-fetch layer, not render layer",
    "semantic_contract: button with aria-pressed for filter chips, th with aria-sort for sortable columns, table with caption or aria-labelledby",
    "cost_or_degraded_path: optimistic updates removed from recurring edits, confirmed-commit pattern with idempotency key and scope resolution"
  ],
  "evidence_classes_cited": [
    "rendering_model_boundary_table",
    "state_ownership_map",
    "discriminated_union_type_definition",
    "recurring_edit_payload_type",
    "authorization_perimeter_rules",
    "wcag_412_name_role_value",
    "idempotency_key_contract",
    "rfc_9457_problem_detail"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is PPR available in the current stack, or does the team need the CSR-to-server-component migration path instead?",
    "Does the existing API return 403 or empty array on access denial? This determines whether the authorization boundary fix requires a server change.",
    "What is the current role model — are roles flat (viewer/editor/admin) or hierarchical with team-scoped permissions?"
  ],
  "turn": 1
}
[/SESSION_STATE]