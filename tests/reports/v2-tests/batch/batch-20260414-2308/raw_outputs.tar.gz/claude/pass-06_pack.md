## Brand positioning pass

**Audience frame**

Freelancers are not small businesses pretending to be enterprises. They are one-person operations where money failure is personal failure, not a line item. The primary fear is not "my company loses revenue" but "I don't get paid, I can't pay rent." That changes the emotional register entirely. Trust for this audience means "you understand how precarious this is" before it means "you are a regulated institution." Approachability without that understanding reads as condescension, not warmth.

Secondary axis: freelancers are sophisticated enough to resent being talked down to. They have used Stripe, Venmo, and PayPal. They know what a dashboard is. Approachable cannot mean simplified to the point of thin.

**Competitive landscape read**

Stripe owns developer-first infrastructure. It is powerful, respected, and cold. Its brand signals "you are building something serious" but implicitly requires technical comfort and a product mindset. Freelancers who are not builders feel like accidental guests.

Mercury owns the funded-startup aesthetic. Clean, modern, premium, slightly aspirational. It serves founders well and communicates "you are a real company now." That framing excludes people who are not trying to become a company. It also inherits the bank-adjacent register once you are inside the product.

Relay owns the operations layer. It is the most functional of the three, positioned around bill pay, accounts, and cash flow management. Competent, useful, somewhat forgettable as a brand. It does not have a strong identity signal.

None of them are talking to freelancers as freelancers. They are either talking to developers, startup founders, or small business owners. The freelancer is treated as a subset of those categories, not as a primary audience.

**Differentiation frame**

The open territory is: **"financial infrastructure built around the rhythm of freelance work."**

This means the product understands income variability, late client payments, project-based cash flow, quarterly tax obligations, and the fact that separating business and personal money is emotionally hard because they are the same person. No competitor owns this frame with any specificity. They all assume steady income and clean business structures.

Owning this territory requires the brand to demonstrate understanding of the work pattern, not just the account type. The differentiation is empathy toward the specific chaos of freelance finance, rather than generic small business competence.

**Trust logic**

Trust for this audience is earned through three signals in sequence:

1. **Recognition** before credibility. The brand must show it understands freelance reality before it invokes regulatory status, partner banks, or FDIC coverage. Leading with institutional credentials reads as defensive to someone who just wants to know if you get them.

2. **Transparency** over polish. Freelancers are price-sensitive and have been burned by hidden fees. Honest, visible pricing and plain-language explanations of how money moves build more trust than premium visual design. Mercury's design is beautiful and somewhat alienating for this reason.

3. **Reliability signals** that match the actual risk. What they need to believe: payments arrive when expected, tax prep is not a disaster in April, the product will not disappear. These are modest but specific. Do not overclaim.

**Messaging consequence**

The brand should not say "banking for freelancers." That positions it as a bank wearing casual clothes, which is precisely the register to avoid.

It should own something closer to: **"built for how you actually work"** or a territory around cash flow that acknowledges income is irregular and that is normal, not a problem to fix. The tone is peer-level, not paternalistic. You know what you are doing; this just removes the friction.

The cost of this framing: it requires the product to actually deliver on variable-income tooling. If the product is a standard bank account with a friendly logo, the positioning collapses under use. The brand promise and the product capability must be in sync, or the approachability reads as bait.

**Positioning territory to own**

Own: **freelance-native financial operations.** Specifically the intersection of irregular income, client payment tracking, tax withholding, and separation of personal and business money, all designed around project-based work rather than payroll-based work.

Do not try to out-Mercury Mercury on design prestige. Do not try to out-Stripe Stripe on developer credibility. Relay's operational competence is closer to the right direction but lacks the identity signal and audience specificity.

The strongest defensible position is being the product that understands the freelance work cycle at a structural level, not just one that offers a business checking account in a friendlier wrapper.

**What you sacrifice to hold this territory**

You give up the aspirational "you are building a real company" narrative that Mercury uses effectively for founders. Freelancers who want to feel like they are running a startup will find that framing more flattering. You also narrow the addressable market by being specific rather than generic. The tradeoff is that specificity earns stronger loyalty and word-of-mouth from an audience that feels chronically underserved, while generality competes on every axis against better-funded incumbents who already own those broader frames.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: freelancers as one-person operations with personal financial risk, not small business proxies",
    "differentiation_frame: freelance-native financial operations built around irregular income and project-based work cycles",
    "trust_logic: recognition before credibility, transparency over polish, reliability signals matched to actual risk",
    "messaging_consequence: peer-level tone, not bank-in-casual-clothes; product must deliver on variable-income tooling or positioning collapses"
  ],
  "evidence_classes_cited": [
    "competitive_landscape_analysis",
    "audience_frame_constraint",
    "trust_signal_sequence",
    "differentiation_gap_identification"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product currently have variable-income tooling, tax withholding, or client payment tracking, or is it a standard account with a friendlier UX?",
    "Is the primary acquisition channel community/word-of-mouth or paid, since this affects how specific vs broad the initial positioning should be?"
  ],
  "turn": 1
}
[/SESSION_STATE]