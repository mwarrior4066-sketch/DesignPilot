## Backend Feasibility Review: Real-Time Collaboration

Real-time collaboration is one of the most architecturally invasive features you can add to an existing system. The request sounds like a feature addition. It is closer to a partial infrastructure replacement. Here is what you are actually committing to before a single cursor appears on screen.

---

## Hidden System Requirements

**Transport layer replacement**

REST is a request-response protocol. Real-time collaboration requires a persistent bidirectional connection. You need WebSockets (via Socket.io, native WS, or a managed service like Ably or Liveblocks) or server-sent events at minimum. Your existing REST endpoints cannot carry this traffic. This is not a wrapper — it is a new communication surface running alongside your current API.

**Concurrency and conflict resolution model**

Your PostgreSQL tables currently assume one writer at a time per document, or at best optimistic locking with last-write-wins. With simultaneous editors, last-write-wins destroys content. You need a conflict resolution algorithm before you write a single line of collaboration code. Two viable options:

- **Operational Transformation (OT):** mature, used by Google Docs, complex to implement correctly from scratch. Libraries like ShareDB handle this.
- **CRDTs (Conflict-free Replicated Data Types):** more modern, simpler merge semantics, better for offline-first. Yjs and Automerge are production-grade. Yjs in particular has strong React and ProseMirror/Tiptap integration.

Choosing neither and attempting manual merge logic is a blocking constraint. You will produce data corruption under any meaningful concurrency load.

**Presence and ephemeral state infrastructure**

Cursor positions, selection ranges, and user presence (who is online, where they are in the document) are ephemeral — they must not be written to PostgreSQL on every keystroke. At 5 users typing simultaneously, you are looking at hundreds of state updates per second. You need a separate ephemeral layer. Redis with pub/sub is the standard choice. PostgreSQL is the wrong surface for this traffic.

**Session and identity model at the WebSocket layer**

Your current auth is almost certainly stateless JWT or session cookies validated per REST request. WebSocket connections are long-lived and do not re-validate on every message. You need explicit auth at connection time, and you need to propagate user identity into every operation so the collaboration layer knows which user owns which cursor and which operations are authorized. If your current auth does not produce a stable user identity that survives a WebSocket upgrade handshake, that is a blocker.

**Document versioning and persistent state**

OT and CRDT systems maintain an operation log or a document state vector, not just the final content. You need somewhere to store this. Storing only the rendered document output and discarding the operation history means you cannot replay, reconcile, or recover divergent states. Your schema will need new tables or a document store alongside PostgreSQL.

**Horizontal scaling and connection affinity**

If your app runs more than one server instance (or ever will), WebSocket connections must be routed to the same instance for the same document session, or you need a shared presence broker. Sticky sessions at the load balancer are fragile. The correct architecture is a pub/sub broker (Redis, or a managed service) so any server instance can participate in any document session. Without this, you will have split-brain presence and missed operations the moment you scale beyond one node.

**Backpressure and rate limiting**

Users paste large blocks, run find-replace across the whole document, or trigger bulk operations. An uncapped operation pipeline will saturate your broker. You need backpressure handling and per-connection rate limits before production.

---

## Feasibility Assessment

**What is genuinely feasible from your current stack**

PostgreSQL as the persistent document store is fine. You are not replacing it. Your existing REST layer stays intact for everything outside the live editing session: document creation, permissions, exports, comments as first-class records, version history UI. React can use Yjs or a managed client SDK alongside your existing component architecture without rewriting your app.

**Explicit blockers — these must be resolved before the feature can go to production**

- No OT or CRDT library chosen and integrated: data corruption under concurrent edits is guaranteed without one. This is the single most critical architectural decision. You cannot defer it.
- No ephemeral state layer: writing cursor presence to PostgreSQL at keystroke frequency will degrade database performance for your entire application, not just this feature.
- Auth not adapted for long-lived connections: if user identity cannot be verified at WebSocket upgrade time and re-checked on sensitive operations, you have an open authorization perimeter around the collaboration surface.
- No horizontal scaling strategy: a single-instance constraint is acceptable for a prototype but is a deployment blocker for any multi-node production environment.

**What is risky but manageable with planning**

- Schema migration for operation logs and document versioning — this is invasive but planned work, not a surprise.
- Switching from REST-only to a hybrid REST + WebSocket API surface — this is architecturally clean if you treat them as distinct layers rather than mixing patterns.
- React integration of Yjs or a managed SDK — well-documented, lower risk than building the sync layer yourself.

---

## Safer Implementation Path

The mistake most teams make is building all of this simultaneously. The concurrency model, the WebSocket transport, the presence layer, and the persistence strategy are each independently complex. Build them in sequence with a testable gate at each phase.

**Phase 1: Document locking with last-editor-wins (2 to 3 weeks)**

Before you touch real-time sync, upgrade your current model. Add an `editing_lock` to your document schema with owner, timestamp, and expiry. Only one user edits at a time. Others see a read-only view with a visible "locked by" indicator. This is not collaboration, but it prevents data corruption now and gives you the identity and permissions infrastructure you need for phase 2. It is also shippable value without the full collaboration architecture in place.

**Phase 2: Ephemeral presence only (2 to 3 weeks)**

Add WebSocket infrastructure (Socket.io or native WS with a Redis pub/sub broker) and use it only for presence: who is viewing the document, where their cursor is, a color-coded avatar in the toolbar. No document mutations flow over this channel yet. This lets you validate your auth-at-connection-time model, your Redis ephemeral layer, and your horizontal scaling setup under real load before any content is at risk.

**Phase 3: Choose and integrate the CRDT library (3 to 4 weeks)**

Pick Yjs with the appropriate editor binding (Tiptap, ProseMirror, Quill, or Slate depending on your current editor). Integrate Yjs's `y-websocket` provider against your Phase 2 WebSocket infrastructure. Test merge behavior with simulated concurrent edits in a staging environment before any production traffic. Add the operation history table to PostgreSQL now. This phase is where the real engineering complexity lives. Do not compress it.

**Phase 4: Persistence and recovery (2 weeks)**

Implement document state snapshots to PostgreSQL at meaningful intervals (on session end, every N operations, or on a time-based flush). Implement reconnection logic that brings a rejoining client back to current document state without requiring full operation log replay from the beginning. Add an audit trail for compliance or version history use cases.

**Phase 5: Hardening (ongoing)**

Backpressure and per-connection rate limits. Offline edit queuing and resync. Conflict UI for edge cases CRDT cannot merge cleanly (binary content, certain structural operations). Load testing with concurrent sessions. Auth re-validation on reconnect and on sensitive mutations.

---

## What You Sacrifice to Gain This

You gain genuine simultaneous multi-user editing with conflict safety, visible presence, and persistent state. You sacrifice simplicity: your backend now has two communication surfaces (REST and WebSocket), two state stores (PostgreSQL for persistence and Redis for ephemeral), and a new dependency on a CRDT library whose behavior you need to deeply understand before production. Every future document feature — exports, comments, version history, permissions — now has to account for the collaboration layer. Teams that skip Phase 1 and 2 and build everything at once consistently underestimate the debugging cost when concurrent edits produce unexpected document states in production. The phased path is slower by four to six weeks and produces a system you can actually reason about when something goes wrong.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "data_dependency: OT or CRDT library required before any concurrent editing; no safe path without one",
    "permissions_dependency: auth must validate identity at WebSocket upgrade time, not per-message",
    "system_surface_dependency: Redis ephemeral layer required; PostgreSQL cannot absorb keystroke-frequency writes",
    "blocking_constraint: no horizontal scaling strategy = single-node deployment ceiling"
  ],
  "evidence_classes_cited": [
    "system_surface_dependency",
    "authorization_perimeter",
    "idempotency_contract",
    "async_job_model",
    "resilience_strategy"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Which editor library is currently in use in the React app (Tiptap, Quill, Slate, ProseMirror, custom)?",
    "Is the app currently single-instance or horizontally scaled?",
    "What is the current auth mechanism (JWT, session cookie, OAuth)?",
    "Are there compliance or audit requirements that affect operation log retention?"
  ],
  "turn": 1
}
[/SESSION_STATE]