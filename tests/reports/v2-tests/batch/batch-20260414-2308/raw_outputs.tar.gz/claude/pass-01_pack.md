## Pricing Page Audit

### What the page is doing and where it breaks down

The structure follows a conventional B2B SaaS pricing pattern, which is appropriate. The problem is that each section has a localized failure that compounds into a page that looks complete but converts and communicates below its potential.

---

### Hero

**What is failing:** "Everything your team needs" is a category claim, not a decision-support statement. On a pricing page, users have already decided they are interested. They are now deciding between tiers and whether to trust the company enough to pay. The headline is doing the wrong job at the wrong moment.

The CTA is undersized relative to the hero area. A background image with no clear contrast zone behind the button creates a situation where the button may pass contrast in one viewport size and fail in another depending on what part of the image falls behind it.

**What to do:** Reframe the headline toward the decision being made, not the product catalog. Something like "Pick the plan that fits your team" or a value-anchored variant that connects tier choice to a specific outcome.

The CTA needs a fixed-contrast backing, not a floating button on a photographic background. Either add a darkened scrim behind the button zone, pin the button to a solid-color lockup, or move the primary CTA below the hero where contrast is controllable. Size the hit target to at least 44x44px (WCAG 2.5.5) and increase the button's visual weight so it reads as the primary action from a normal reading distance.

**Tradeoff:** A scrim or solid backing reduces the full-bleed visual drama of the hero image. That is the right sacrifice because a CTA that fails contrast or disappears into a busy background does not convert regardless of how good the image looks.

---

### Pricing table

**What is failing:** Color-coding the Pro tier is a sound UX decision for a three-plan layout. The problem is that the implementation is inaccessible. If the Pro tier distinction depends entirely on hue, it fails users with color vision deficiencies and fails WCAG 1.4.1 (Use of Color), which requires that color is not the only visual means of conveying information.

**What to do:** The Pro tier highlight needs a second visual signal that is not color. Options in order of implementation cost:

1. A border or elevated card treatment (shadow, outline, scale) that makes Pro visually distinct from shape and structure alone, not just palette
2. A "Most Popular" or "Recommended" label as a text badge, which is the clearest and most accessible signal
3. A combined approach: elevated card + label + color accent, where removing the color still leaves two independent signals

Check the accent color against its background at the 4.5:1 threshold for any text on the colored surface, and at 3:1 for any non-text UI elements (WCAG 1.4.3, 1.4.11). If the Enterprise tier is styled differently from Starter, verify that those differences also pass.

**Tradeoff:** Adding a border treatment or label adds visual weight to the Pro card. This is the correct tradeoff because accessibility is a floor constraint, not a preference, and the label also reinforces the recommendation signal that the color alone was already trying to communicate.

---

### Feature comparison table

**What is failing:** Feature comparison tables on pricing pages have a known density problem. Without knowing the exact content, the common failures are: too many rows without grouping, checkmark-only cells with no explanatory text for nuanced features, and no sticky header when the table scrolls beyond the viewport. These combine to force the user to scroll back and forth to remember what tier they were comparing.

**What to do:**

- Group features into labeled categories (e.g., Core, Collaboration, Admin and Security, Support) and use a section header row for each group. This reduces apparent density and helps users scan to the features that matter for their tier decision.
- Supplement checkmarks with short qualifiers where the feature has meaningful limits. For example, "Unlimited" versus "Up to 5 users" is more useful than a check versus a cross.
- Add a sticky column header row if the table extends beyond one viewport height. This is a scroll behavior, not a visual design change, but it materially reduces navigation cost.
- Verify that checkmark and cross icons carry accessible text alternatives (aria-label or visually hidden text), not just glyphs.

**Tradeoff:** Grouping and qualifying features lengthens the table visually. The alternative is a shorter table that communicates less, which creates support-cost downstream when buyers do not understand what they purchased. Clarity here pays for itself.

---

### Testimonials strip

**What is failing:** A testimonials strip at the bottom of a pricing page has low credibility leverage if the testimonials are generic. On a pricing page specifically, the user's decision is about cost justification, tier fit, and trust. A testimonial that says "great product" does not address any of those concerns.

**What to do:** Select or commission testimonials that directly address the decision the user is making on this page. Useful types:

- ROI or outcome statements ("Our team saved X hours per month after switching to Pro")
- Team-size or role context ("As a 15-person ops team, Starter was the right fit until we hit the admin limits")
- Trust or vendor concern resolutions ("The onboarding support justified the Enterprise tier for us")

If real testimonials with this specificity do not exist yet, treat this as a content gap, not a design fix. Placeholder-quality testimonials reduce credibility below having no testimonials.

Also verify: if testimonials include attribution with name, role, and company, the strip needs enough contrast on the attribution text (typically light gray on white fails 4.5:1 for body-weight text). This is one of the most common accessibility failures on marketing pages.

**Tradeoff:** More specific testimonials require sourcing work that generic social proof does not. The specificity is the mechanism by which testimonials convert. Generic testimonials are decorative; specific testimonials are functional evidence.

---

### Cross-cutting issues

**CTA repetition:** A single CTA appears only in the hero. On a page of this length, with a feature table and testimonials below the pricing table, there should be a repeated CTA at the logical conversion points: below the pricing table (primary placement) and optionally after testimonials. Users who have read through the comparison should not have to scroll back to act.

**Mobile hierarchy:** A three-column pricing table on mobile is almost always a layout failure. At small viewports, cards should stack vertically, with the Pro tier appearing first or being scrollable-to via a tab or pill selector. The feature comparison table will also need a different treatment at mobile widths, either a tier-selector toggle or a collapsed accordion by feature group.

**Enterprise tier CTA:** "Custom" pricing with no visible starting point or next step creates a dead end for users who might qualify but do not want to commit to a sales call without a rough number. Consider adding a contact or "Get a quote" CTA specific to Enterprise, separate from the Starter and Pro direct-purchase buttons, with different visual weight to signal a different type of action.

---

### Priority order for remediation

1. Fix Pro tier color accessibility (accessibility floor, can be done without a redesign)
2. Resize and anchor the hero CTA (conversion impact, low implementation cost)
3. Add CTA repetition below the pricing table (conversion impact, very low cost)
4. Reframe the hero headline (copy change, no development work)
5. Group and qualify the feature comparison table (clarity and support cost)
6. Audit and replace generic testimonials with specific ones (content work)
7. Fix mobile layout for pricing and comparison tables (requires responsive implementation work)

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "hierarchy_winner: pricing table and CTA placement govern conversion, hero reframe is copy-layer",
    "intervention_order: accessibility fix first, CTA resize second, CTA repetition third",
    "tradeoff_resolution: scrim reduces hero drama but is required for CTA contrast; label adds visual weight but is required for accessible tier distinction",
    "visual_confidence_boundary: audit based on described structure, not visual artifact — no screenshot reviewed"
  ],
  "evidence_classes_cited": [
    "WCAG 1.4.1 Use of Color",
    "WCAG 1.4.3 contrast 4.5:1 text threshold",
    "WCAG 1.4.11 non-text contrast 3:1 threshold",
    "WCAG 2.5.5 target size 44x44px"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What are the exact colors used for the Pro tier highlight — hue, background, and any text on the colored surface?",
    "Does the feature comparison table currently have a sticky header implementation?",
    "What is the mobile breakpoint behavior for the pricing table — does it currently stack or attempt a scrollable three-column layout?"
  ],
  "turn": 1
}
[/SESSION_STATE]