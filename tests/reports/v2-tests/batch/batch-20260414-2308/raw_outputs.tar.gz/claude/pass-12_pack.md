Fintech type systems have a real constraint stack: tabular numerals are non-negotiable, weight range must cover data density and large display simultaneously, and "trustworthy" has a specific meaning in this category — it reads as precise and stable, not playful or editorial. Here is a system built around those constraints.

---

## Governing constraints

**Tabular numerals first.** Every font in the running needs `tnum` OpenType support. Proportional numerals in financial tables cause column misalignment that breaks scannability and signals a lack of craft. This is the first filter, not a nice-to-have.

**Weight range.** The system must span at least Light or Regular through Bold or Black to support: dashboard data (Regular/Medium), marketing hierarchy (Bold/Black), body copy (Regular), and secondary labels (Light or Regular at smaller sizes).

**Three distinct rendering contexts.** Marketing site favors expressive large display. Dashboard favors density and legibility at 12–14 px. Mobile adds touch constraints and smaller viewports that punish complex spacing.

---

## Recommended system

### Primary: Inter

The governing display and body typeface across all three surfaces.

Inter is designed for screen rendering at small sizes with a large x-height, generous apertures, and explicit `tnum` support. It runs Regular through ExtraBold (nine weights in variable-font form), it is open-source with no licensing cost, and it has deep web and mobile ecosystem support including Google Fonts delivery and system font fallback parity on most platforms.

**Why Inter beats common alternatives here:**

- DM Sans feels lighter and more editorial but has narrower `tnum` coverage and less weight range.
- Neue Haas Grotesk performs excellently but carries a licensing cost and does not outperform Inter for UI rendering.
- Manrope has strong aesthetics but less battle-tested tabular-numeral behavior at small sizes.

**Scale decisions:**

| Role | Size | Weight | Notes |
|---|---|---|---|
| Marketing hero | 48–72 px | Bold/ExtraBold | Variable font size axis to match viewport |
| Marketing heading H2 | 32–40 px | Bold | |
| Marketing body | 18–20 px | Regular | 1.5 leading ratio |
| Dashboard heading | 20–24 px | SemiBold | |
| Dashboard body/label | 13–14 px | Regular | Line-height 1.4 |
| Data table cell | 13–14 px | Regular | `tnum` enforced, tabular `lnum` |
| Data table header | 12–13 px | Medium or SemiBold | Uppercase optional with 0.04–0.06 em tracking |
| Tertiary/caption | 11–12 px | Regular | Never below 11 px on web |
| Mobile body | 16 px | Regular | iOS/Android minimum legibility floor |
| Mobile data | 14 px | Regular | `tnum`, reduce column count before reducing size |

---

### Accent / display: Söhne or Geist (conditional)

For marketing only, if the product needs a stronger visual distinction from the dashboard surface, a second display typeface can anchor hero and editorial sections.

**Söhne** (Klim Type Foundry) is the more expensive, higher-craft option. It reads as authoritative and modern, with strong weight contrast. Licensing is per-user, per-project. Justified for Series B+ brands where polish differentiates.

**Geist** (Vercel) is open-source, geometric, and clean. Slightly lower personality but zero cost, strong at large sizes, and consistent with a developer-adjacent fintech aesthetic.

If the marketing site and dashboard share the same typeface (Inter only), the hierarchy must be driven entirely by weight and size, not by a face change. That approach works well and keeps the system simpler. The second face only earns its complexity cost when brand expression on the marketing site genuinely needs more character than Inter provides.

**Recommendation:** Start with Inter only. Add a second display face at the next brand milestone if visual distinction between marketing and product becomes a documented problem.

---

### Mono: JetBrains Mono or iA Writer Mono

Use a monospace face for:
- account numbers, IBANs, routing numbers
- API keys or authentication codes
- transaction IDs or reference strings
- inline code in any developer-facing surface

**JetBrains Mono** has excellent legibility at small sizes, good weight range (Thin through ExtraBold), and open-source licensing.

**iA Writer Mono** is narrower and more compact. Better if column density is extreme.

Do not use the monospace face for standard financial data tables. That is a common mistake that wastes horizontal space and creates an unintended "code readout" aesthetic. Use Inter with `tnum` for tables; reserve mono for identifiers and codes.

---

## OpenType feature requirements

Enforce these at the CSS/token level, not by convention:

```css
/* Financial data tables */
font-feature-settings: "tnum" 1, "lnum" 1;

/* Marketing display — optional ligatures */
font-feature-settings: "liga" 1, "kern" 1;

/* Monospace identifiers */
font-feature-settings: "tnum" 1;
```

`tnum` = tabular numerals (fixed-width columns)
`lnum` = lining numerals (uniform cap-height baseline, no descenders)
`onum` = old-style numerals (acceptable in marketing body copy, not in data)

---

## Fallback stack

```css
font-family: "Inter", "Helvetica Neue", Arial, sans-serif;
```

On iOS, San Francisco will render before Inter if Inter is not loaded. San Francisco has native tabular numeral support, so degradation is acceptable. On Android, Roboto is the fallback, which also has `tnum`. The fallback chain is therefore safe for financial data.

---

## Variable font delivery

Use the variable font build of Inter (`Inter.var.woff2`) rather than individual weight files. This reduces HTTP requests and enables fluid type scaling between breakpoints if needed.

```css
@font-face {
  font-family: "Inter";
  src: url("Inter.var.woff2") format("woff2 supports variations"),
       url("Inter.var.woff2") format("woff2");
  font-weight: 100 900;
  font-display: swap;
}
```

`font-display: swap` is required for marketing performance. On dashboard, `optional` may be preferable to prevent layout shift during font load.

---

## Adoption sequence

1. **Lock Inter as the system typeface.** Configure the variable font, establish the token set (size scale, weight tokens, line-height tokens), and enforce `tnum`/`lnum` in the data layer via CSS or design tokens.
2. **Build the dashboard table pattern first.** This is the highest-constraint surface. If the type system works here, it works everywhere.
3. **Apply the marketing scale.** Use weight and size to drive hierarchy rather than a second typeface at this stage.
4. **Audit mobile at 14 px.** Check tabular numeral alignment on actual devices, not just browser emulation. iOS and Android render Inter slightly differently.
5. **Decide on a second display face at a natural brand milestone**, not as a day-one decision.

---

## Tradeoff summary

You gain a zero-cost, well-supported system with strong tabular numeral behavior and broad weight coverage. You sacrifice some visual distinctiveness on the marketing site relative to custom or premium typefaces. That is the correct tradeoff at most stages: a trustworthy system typeface with rigorous data-layer behavior outperforms a distinctive but less reliable pairing.

If brand differentiation later becomes a competitive concern, Söhne added to Inter for marketing display is a clean upgrade that does not disturb the dashboard or data layer.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: screen-first, three surfaces (marketing, dashboard, mobile)",
    "scale_decision: Inter variable font as primary, mono for identifiers only",
    "pairing_rationale: single-typeface system first, optional display accent at brand milestone",
    "adoption_sequence: lock Inter, build dashboard table pattern, apply marketing scale, audit mobile, decide second face at milestone"
  ],
  "evidence_classes_cited": ["tnum/lnum OpenType standards", "CSS font-feature-settings spec", "font-display behavior", "woff2 variable font format", "WCAG minimum size floor"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there an existing brand typeface that must be preserved or integrated?",
    "Is developer-facing content (API docs, code examples) part of the scope?",
    "What is the current licensing budget — open-source only, or commercial allowed?"
  ],
  "turn": 1
}
[/SESSION_STATE]