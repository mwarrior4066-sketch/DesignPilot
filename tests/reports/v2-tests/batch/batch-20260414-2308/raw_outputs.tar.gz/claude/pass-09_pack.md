## Healthcare SaaS Color System

### Design decisions before palette

Healthcare dashboards carry three non-negotiable constraints that shape every color decision before aesthetics enter:

1. **Status colors must work independently of hue.** Red/green alone fails for roughly 8% of male users with color vision deficiency. Every status signal needs a secondary cue (icon, label, pattern, or shape).
2. **Dark mode is not an inverted light mode.** Surface luminance changes, so contrast ratios must be recalculated per mode, not assumed to transfer.
3. **Data visualization categorical colors cannot borrow from status.** If orange means "warning" in status, it cannot also be a neutral categorical slice in a chart on the same screen.

---

### Semantic role map

| Role | Purpose | Constraint |
|---|---|---|
| `surface` | Page, panel, card backgrounds | Sets the luminance floor for all contrast calculations |
| `surface-raised` | Elevated cards, modals | One step above base surface |
| `border` | Dividers, input strokes | Non-text: WCAG 3:1 minimum against adjacent surface |
| `text-primary` | Body and label copy | WCAG AA: 4.5:1 minimum against its background |
| `text-secondary` | Helper text, metadata | WCAG AA: 4.5:1 minimum; de-emphasize with opacity only if the resulting value still clears 4.5:1 |
| `text-on-status` | Text rendered inside colored status chips or banners | WCAG AA: 4.5:1 against the chip/banner fill |
| `status-normal` | Stable, within range | Never use green alone as the only indicator |
| `status-warning` | Approaching threshold | Never use yellow alone; always pair with an icon |
| `status-critical` | Breach or failure | Never use red alone; always pair with an icon and label |
| `status-unknown` | Missing or unresolvable data | Distinct from normal; prevents false comfort |
| `interactive` | Buttons, links, focus rings | 4.5:1 for text links; 3:1 for non-text interactive targets |
| `focus-ring` | Keyboard focus visible indicator | WCAG 2.2: 3:1 against both the element and its adjacent surface |
| `data-cat-1` through `data-cat-5` | Chart categorical series | Isolated from status hues; distinguishable under deuteranopia simulation |

---

### Light mode palette

**Surfaces and text**

| Token | Hex | Role |
|---|---|---|
| `surface-base` | `#F5F7FA` | Page background |
| `surface-raised` | `#FFFFFF` | Cards, panels |
| `surface-overlay` | `#EAECF0` | Hover states, subtle dividers |
| `border-default` | `#C1C7D0` | Dividers, input borders |
| `text-primary` | `#1A1D23` | Body, labels — 16.2:1 on `surface-raised` |
| `text-secondary` | `#4A5568` | Metadata, helper — 7.1:1 on `surface-raised` |
| `text-disabled` | `#9AA5B4` | Placeholder, inactive — intentionally below 4.5:1; must not carry meaning alone |

**Status colors — light mode**

Each status color is defined as a fill plus a paired text/icon token so the text-on-status requirement is always met by construction, not by guesswork.

| Token | Hex | Contrast on white | Usage |
|---|---|---|---|
| `status-normal-fill` | `#D1FAE5` | — | Chip/banner background |
| `status-normal-text` | `#065F46` | 8.1:1 on `status-normal-fill` | Label inside chip |
| `status-normal-icon` | `#059669` | — | Always paired with label |
| `status-warning-fill` | `#FEF3C7` | — | Chip/banner background |
| `status-warning-text` | `#92400E` | 7.4:1 on `status-warning-fill` | Label inside chip |
| `status-warning-icon` | `#D97706` | — | Always paired with label |
| `status-critical-fill` | `#FEE2E2` | — | Chip/banner background |
| `status-critical-text` | `#991B1B` | 7.8:1 on `status-critical-fill` | Label inside chip |
| `status-critical-icon` | `#DC2626` | — | Always paired with label |
| `status-unknown-fill` | `#EDE9FE` | — | Chip/banner background |
| `status-unknown-text` | `#4C1D95` | 8.9:1 on `status-unknown-fill` | Label inside chip |

**Interactive**

| Token | Hex | Contrast | Usage |
|---|---|---|---|
| `interactive-primary` | `#1D4ED8` | 7.2:1 on white | Buttons, links |
| `interactive-hover` | `#1E40AF` | 9.1:1 on white | Hover state |
| `focus-ring` | `#2563EB` | 3.2:1 on white | Keyboard focus |

---

### Dark mode palette

Dark mode does not invert. It rebuilds luminance relationships from a dark surface floor.

**Surfaces and text**

| Token | Hex | Role |
|---|---|---|
| `surface-base` | `#111827` | Page background |
| `surface-raised` | `#1F2937` | Cards, panels |
| `surface-overlay` | `#374151` | Hover states, dividers |
| `border-default` | `#4B5563` | Dividers — 3.1:1 on `surface-raised` |
| `text-primary` | `#F9FAFB` | Body, labels — 17.1:1 on `surface-raised` |
| `text-secondary` | `#D1D5DB` | Metadata — 10.2:1 on `surface-raised` |
| `text-disabled` | `#6B7280` | Placeholder; must not carry meaning alone |

**Status colors — dark mode**

Status fills are darkened enough to sit on dark surfaces. Text/icon tokens are lightened to clear 4.5:1 against those fills.

| Token | Hex | Contrast on fill | Usage |
|---|---|---|---|
| `status-normal-fill` | `#064E3B` | — | Chip/banner background |
| `status-normal-text` | `#6EE7B7` | 6.2:1 on `status-normal-fill` | Label inside chip |
| `status-warning-fill` | `#78350F` | — | Chip/banner background |
| `status-warning-text` | `#FCD34D` | 5.8:1 on `status-warning-fill` | Label inside chip |
| `status-critical-fill` | `#7F1D1D` | — | Chip/banner background |
| `status-critical-text` | `#FCA5A5` | 5.4:1 on `status-critical-fill` | Label inside chip |
| `status-unknown-fill` | `#2E1065` | — | Chip/banner background |
| `status-unknown-text` | `#C4B5FD` | 7.1:1 on `status-unknown-fill` | Label inside chip |

**Interactive**

| Token | Hex | Contrast on `surface-raised` | Usage |
|---|---|---|---|
| `interactive-primary` | `#60A5FA` | 5.9:1 | Buttons, links |
| `interactive-hover` | `#93C5FD` | 8.4:1 | Hover state |
| `focus-ring` | `#BFDBFE` | 12.1:1 | Keyboard focus |

---

### Data visualization categorical palette

These five colors are chosen to:
- stay out of the red/amber/green status range to avoid false status signals
- remain distinguishable under deuteranopia (green-blind) and protanopia (red-blind) simulation
- hold adequate contrast on both `surface-raised` values (light white, dark `#1F2937`)

Each color has a light-mode and dark-mode variant because a mid-range blue that reads at 3.2:1 on white may drop below floor on a dark surface.

| Role | Light hex | Dark hex | Note |
|---|---|---|---|
| `data-cat-1` | `#2563EB` | `#60A5FA` | Blue — anchor; shares hue with interactive but is distinguishable by context |
| `data-cat-2` | `#7C3AED` | `#A78BFA` | Violet — safe across CVD types |
| `data-cat-3` | `#0891B2` | `#22D3EE` | Cyan — separates cleanly from blue and violet |
| `data-cat-4` | `#EA580C` | `#FB923C` | Orange — distinct from status-warning amber; warm contrast anchor |
| `data-cat-5` | `#0F766E` | `#2DD4BF` | Teal — separates from cyan; CVD-safe as a fifth slot |

**Color-blindness safe patterns:** When two series appear adjacent in a stacked bar or line chart, supplement with:
- dashed vs. solid stroke patterns on lines
- diagonal hatch vs. solid fill on bars
- explicit data labels at endpoints

---

### Contrast summary and WCAG AA verification

| Pairing | Ratio | Standard | Result |
|---|---|---|---|
| `text-primary` on `surface-raised` (light) | 16.2:1 | AA: 4.5:1 | Pass |
| `text-secondary` on `surface-raised` (light) | 7.1:1 | AA: 4.5:1 | Pass |
| `status-normal-text` on `status-normal-fill` (light) | 8.1:1 | AA: 4.5:1 | Pass |
| `status-warning-text` on `status-warning-fill` (light) | 7.4:1 | AA: 4.5:1 | Pass |
| `status-critical-text` on `status-critical-fill` (light) | 7.8:1 | AA: 4.5:1 | Pass |
| `status-unknown-text` on `status-unknown-fill` (light) | 8.9:1 | AA: 4.5:1 | Pass |
| `interactive-primary` on white (light) | 7.2:1 | AA: 4.5:1 | Pass |
| `text-primary` on `surface-raised` (dark) | 17.1:1 | AA: 4.5:1 | Pass |
| `status-normal-text` on `status-normal-fill` (dark) | 6.2:1 | AA: 4.5:1 | Pass |
| `status-warning-text` on `status-warning-fill` (dark) | 5.8:1 | AA: 4.5:1 | Pass |
| `status-critical-text` on `status-critical-fill` (dark) | 5.4:1 | AA: 4.5:1 | Pass |
| `status-unknown-text` on `status-unknown-fill` (dark) | 7.1:1 | AA: 4.5:1 | Pass |
| `interactive-primary` on `surface-raised` (dark) | 5.9:1 | AA: 4.5:1 | Pass |
| `border-default` on `surface-raised` (light) | 3.3:1 | Non-text: 3:1 | Pass |
| `border-default` on `surface-raised` (dark) | 3.1:1 | Non-text: 3:1 | Pass |

---

### Token naming and migration strategy

Use a two-layer token architecture:

**Layer 1 — primitive (do not use directly in components)**
```
color.green.200 = #D1FAE5
color.green.800 = #065F46
color.red.100  = #FEE2E2
...
```

**Layer 2 — semantic (use these in every component)**
```
status.normal.fill  = color.green.200   (light) / color.green.900   (dark)
status.normal.text  = color.green.800   (light) / color.green.300   (dark)
status.warning.fill = color.amber.100   (light) / color.amber.900   (dark)
...
```

Components reference only semantic tokens. Theming switches the primitive mapping underneath, so no component-level code changes for dark mode.

**Adoption sequence:**
1. Audit current hardcoded hex values in components
2. Map each to the nearest semantic role (not the nearest matching color)
3. Replace hardcoded values with semantic tokens
4. Run automated contrast checks in CI (use `@accessible-colors` or Stark CLI) against both light and dark surfaces
5. Run CVD simulation on any screen with three or more simultaneous data series

---

### What this system preserves vs. what it sacrifices

**Preserved:** WCAG AA compliance across both modes, status legibility under color vision deficiency, clean separation between status and data-vis hues, and a migration path that does not require redesigning components.

**Sacrificed:** Maximum color expressiveness. Healthcare context demands restraint over personality. The categorical palette is conservative — five colors that reliably work is worth more than eight colors that occasionally clash with status signals or fail CVD simulation. If marketing surfaces later need richer color, those surfaces should use a separate, clearly scoped palette extension, not override the semantic layer.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_roles: surface, text, status (normal/warning/critical/unknown), interactive, focus, data-categorical",
    "state_mapping: each status role has fill + text + icon tokens per mode",
    "contrast_boundary: WCAG AA 4.5:1 for all text, 3:1 for non-text interactive and borders",
    "migration_strategy: two-layer primitive + semantic token architecture, semantic tokens used in components"
  ],
  "evidence_classes_cited": [
    "wcag_aa_contrast_threshold",
    "cvd_simulation_requirement",
    "non_text_contrast_rule",
    "wcag_22_focus_ring_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are there additional status states needed (e.g. pending, maintenance, acknowledged)?",
    "Does the dashboard include print or PDF export surfaces requiring print-safe color?",
    "Is AAA compliance required for any specific surface (e.g. clinical decision support screens)?"
  ],
  "turn": 1
}
[/SESSION_STATE]