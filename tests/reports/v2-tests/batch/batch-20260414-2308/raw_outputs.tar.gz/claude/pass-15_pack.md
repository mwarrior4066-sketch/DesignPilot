# Backend Architecture Spec: Multi-Tenant Scheduling Platform

---

## Scope and governing constraints

This spec governs the backend system architecture for a multi-tenant scheduling platform that must support team workspaces, cursor-based activity feeds, approval workflows, outbound webhooks, regional data residency, audit trails, and eventually customer-defined automation rules.

The stack starts from: REST APIs, relational database, inconsistent background jobs, no unified eventing. Everything here must be adoptable incrementally — the spec names the target state and the sequencing constraints that make the migration safe.

Governing route: `rt_backend_architecture_spec`
Supporting: `rt_api_reliability_security`, `rt_backend_feasibility_review`

---

## 1. Authority model

The central question for a multi-tenant system is: what is the authoritative boundary for every piece of data?

**Tenant is the root authority boundary.** Every object in the system belongs to exactly one tenant. No cross-tenant read or write is permitted without an explicit, audited delegation grant.

**Workspace is a subdivision of tenant.** A tenant may have multiple workspaces. Workspace membership is a permission scope, not a data isolation boundary — data still lives at the tenant level, workspace just controls who sees what.

**User identity is federated to a tenant.** A user account is created in the context of a tenant. A user who belongs to multiple tenants has separate memberships, not a shared super-identity. This matters for regional data residency: the user record lives in the tenant's home region, not in a global identity store.

```
Tenant
  └── Workspace (1..n per tenant)
       └── User membership (scoped to workspace)
  └── Schedule / resource objects (owned by tenant, scoped to workspace)
  └── Approval workflows (owned by tenant)
  └── Audit log (owned by tenant, region-resident)
  └── Webhook registrations (owned by tenant)
  └── Automation rules (future, owned by tenant)
```

**BOLA check is required at every read and mutation.** The object-level authorization check must verify tenant membership and workspace scope before any query executes, not after. A missing BOLA check is a critical failure, not a soft risk.

---

## 2. Core services

Define services by data ownership and failure isolation boundary, not by feature grouping. The goal is that one service failing does not cascade into unrelated domains.

### 2.1 Identity and Authorization Service

**Owns:** tenant records, user records, workspace membership, role assignments, delegation grants, session tokens.

**Does not own:** business objects (schedules, approvals) — it only vends the claims and checks the permissions those services need.

**Authority contract:**
- Issues short-lived JWT or opaque tokens with tenant ID, user ID, workspace scope, and role claims embedded
- Vends a synchronous `authorize(subject, action, object_id)` check callable by other services
- Emits `membership.changed`, `role.changed`, `tenant.suspended` domain events

**Regional note:** User PII and tenant configuration live in the tenant's home region. The token service may have a thin global presence for session exchange, but it must not store PII outside the home region. Token claims must include `home_region` so downstream services can route storage accordingly.

### 2.2 Scheduling and Resource Service

**Owns:** schedule objects, resource calendars, availability windows, booking states.

**State machine for a schedule object:**
```
draft → pending_approval → approved → active → completed
                        ↘ rejected
draft → approved (if no approval rule applies)
active → cancelled
```

Every state transition is a domain event. The transition itself is the source of truth, not a side-effect-derived status field.

**Consistency stance:** Strong consistency within the tenant's home region for write operations. Eventual consistency is acceptable for read replicas used by activity feeds, as long as the feed cursor system accounts for replication lag (see §4).

### 2.3 Approval Workflow Service

**Owns:** approval workflow definitions, approval instances, reviewer assignments, decision records.

**Does not own:** the schedule object itself. It owns the approval state around it. When a schedule is approved or rejected, the Scheduling Service receives a domain event and updates the schedule state. Neither service reaches into the other's tables.

**Workflow contract:**
- An approval instance has exactly one active step at any time
- Steps are sequential by default; parallel steps are explicitly modeled as a parallel gate node, not implicit
- A decision (approve / reject / escalate) is immutable once recorded
- Escalation timeout is modeled as a first-class event, not a polling job
- Every decision records: actor, timestamp, reason (required for audit), and the authorization claim used to make the decision

**BOLA check:** Only designated reviewers for the workflow step may submit a decision. Reviewer assignment is resolved at step activation time, not at decision time, to prevent assignment races.

### 2.4 Activity Feed Service

**Owns:** the cursor-based feed of events scoped to a tenant/workspace. Does not own the events themselves — it consumes them from the event bus and materializes them into a queryable feed store.

See §4 for full cursor and pagination contract.

### 2.5 Webhook Delivery Service

**Owns:** webhook registrations, delivery attempts, delivery receipts, signing key lifecycle.

See §5 for full webhook contract.

### 2.6 Audit Log Service

**Owns:** the immutable, append-only record of all state-changing actions across the system.

**Contract:**
- Every service emits structured audit events over the internal event bus
- The Audit Log Service consumes and persists them — it does not pull from service databases
- Audit records are never deleted and never updated; a correction is a new record referencing the original
- Audit records include: `tenant_id`, `workspace_id`, `actor_id`, `action`, `object_type`, `object_id`, `before_state` (optional), `after_state`, `timestamp` (microsecond precision), `region`, `request_id`, `authorization_claim`
- Audit log is stored in the tenant's home region; cross-region export requires an explicit audit export job, not live cross-region reads

**Retention contract:** Retention policy is per-tenant configuration, with a system-enforced minimum (suggest 12 months). Deletion of aged records follows a scheduled job that emits its own audit event.

### 2.7 Automation Rules Service (future — define boundary now)

**Owns:** rule definitions, trigger registrations, execution history.

**Architecture boundary to define now:**

Define the event contract and trigger surface now, before this service is built. Automation rules will listen to the same domain events other services already emit. If the event schema is well-defined early, the automation engine is additive — it consumes events without any other service needing to know it exists.

The only change needed now: events must be durable and replayable (see §3). Do not let the current inconsistent job system emit ephemeral events that cannot be replayed when the automation engine is ready.

**Execution model (future):** Rule execution must be isolated from the rule-triggering service. A failing automation rule must not block the triggering domain event. The execution environment must be sandboxed per tenant. Execution history is audited exactly like human actions.

---

## 3. Event bus and background job architecture

This is the root failure in the current stack. Inconsistent jobs and no unified eventing mean: no reliable audit trail, no foundation for webhooks, no path to automation rules, and no safe cursor feeds.

**Required architecture:**

A durable message broker with guaranteed at-least-once delivery and consumer group support. Kafka, Pulsar, or a managed equivalent (e.g., Confluent Cloud, AWS MSK, GCP Pub/Sub with ordering guarantees) are all viable. The choice is less important than the contract.

**Event envelope schema (required for all domain events):**

```json
{
  "event_id": "uuid-v7",
  "event_type": "schedule.state_changed",
  "schema_version": "1",
  "tenant_id": "t_...",
  "workspace_id": "ws_...",
  "actor_id": "u_...",
  "object_type": "schedule",
  "object_id": "sch_...",
  "occurred_at": "ISO-8601 microsecond",
  "region": "eu-west-1",
  "payload": { ... },
  "correlation_id": "req_...",
  "causation_id": "event_id of triggering event or null"
}
```

`causation_id` is required. Without it, you cannot reconstruct the causal chain for audit or debugging — particularly for approval workflow state transitions triggered by other events.

**Consumer design:**
- Each consuming service (Activity Feed, Audit Log, Webhook Delivery, Automation Rules) is an independent consumer group
- Consumers are idempotent: processing the same event twice produces the same result, because the event carries its own `event_id` and each consumer deduplicates on it
- Dead-letter queues are mandatory: events that fail repeatedly are moved to a DLQ with full envelope intact, not discarded
- DLQ alerts must fire within one minute of first DLQ arrival

**Background jobs:**
- All background jobs are triggered by events or explicit job records — not cron loops reading directly from domain tables
- Job records are stored in the database with status: `queued → running → completed | failed`
- A job that fails records the failure reason and retry count; it does not silently disappear
- Exponential backoff with jitter is the default retry strategy; a job that exceeds max retries moves to DLQ
- The job system emits its own events to the audit log; job execution is auditable

---

## 4. Cursor-based activity feed

**Why cursor, not offset pagination:** Offset pagination breaks under insertion. Activity feeds are append-dominant — new events arrive continuously. An offset query returns different rows on each call as new events insert. Cursor pagination anchors to a stable position in the event sequence.

**Cursor design:**

Use an opaque cursor that encodes: `(partition_key, sequence_position, timestamp)`. The cursor is base64-encoded before leaving the service. Clients treat it as a string token, not a decomposable value.

```
GET /workspaces/{workspace_id}/feed?cursor=<opaque>&limit=50
```

Response:
```json
{
  "items": [ ... ],
  "next_cursor": "<opaque or null>",
  "prev_cursor": "<opaque or null>",
  "has_more": true,
  "generated_at": "ISO-8601"
}
```

`next_cursor` is null when the client is at the live edge. `has_more: false` means the client is current and should poll or subscribe to a real-time channel (SSE or WebSocket) rather than continue paginating.

**Replication lag handling:**

The feed is built from the event stream, not from live domain tables. Replication lag means a feed consumer may briefly not see an event that a direct database read would show. Handle this with:

- A per-feed `watermark` that advances only when the replication position is stable
- The cursor encodes the watermark, not wall-clock time
- On the feed endpoint, include `X-Feed-Lag-Ms` header when lag exceeds a threshold (suggest 2s), so clients can display a freshness indicator

**Tenant isolation in the feed:**

The feed store is partitioned by `tenant_id`. A query that does not bind `tenant_id` is rejected at the query layer, not the application layer. This is a defense-in-depth measure — even a buggy query should not cross tenant boundaries at the storage level.

**Cursor invalidation:**

A cursor is valid indefinitely for historical pagination. A cursor may become unresolvable if the feed store is compacted or rebuilt. Clients that receive a `cursor_invalid` error must re-fetch from the beginning of the window they care about, not silently fail. Document this contract explicitly in the API spec.

---

## 5. Outbound webhook contract

**Webhook registration:**

```json
{
  "webhook_id": "wh_...",
  "tenant_id": "t_...",
  "target_url": "https://...",
  "event_types": ["schedule.approved", "approval.decision_recorded"],
  "signing_key_id": "key_...",
  "active": true,
  "created_at": "...",
  "last_delivery_at": "..."
}
```

Tenants register webhooks through the management API. The system validates the target URL format but does not pre-verify reachability at registration time — reachability is verified on the first delivery attempt.

**Signing contract:**

Every webhook payload is signed using HMAC-SHA256 over the raw request body with a per-webhook signing key. The signature is delivered in `X-Signature-256: sha256=<hex>`. The tenant's receiving system verifies the signature before processing. Signing key rotation is a first-class operation: issue a new key, overlap delivery with the old key for a configurable window (suggest 24h), then expire the old key.

**Delivery contract:**

```
202 Accepted on successful enqueue (not on successful delivery)
```

Delivery is asynchronous. The Webhook Delivery Service consumes from the event bus, matches events to registered webhooks, and delivers.

**Retry model:** Exponential backoff with jitter. Suggested schedule: immediate, 30s, 2m, 10m, 1h, 4h, 24h. After 7 attempts, the webhook delivery fails and moves to the DLQ. The tenant receives an alert (if an alert webhook is registered — a deliberate bootstrapping question: what delivers the alert that webhooks are failing?).

**Answer:** Webhook failure alerts are delivered via a separate in-app notification channel, not via the webhook mechanism itself, because the webhook mechanism is what has failed.

**Idempotency contract for receivers:**

Include `X-Webhook-Id` and `X-Event-Id` headers. Receivers use these to deduplicate. The system does not guarantee exactly-once delivery — at-least-once is the contract. Document this explicitly.

**Delivery receipts:**

Every delivery attempt records: `webhook_id`, `event_id`, `attempt_number`, `status_code`, `response_body` (truncated to 1KB), `latency_ms`, `delivered_at`. These records are tenant-visible through the management API and included in the audit log.

**Circuit breaker:**

If a webhook endpoint returns 5xx or times out for N consecutive attempts across a window (suggest 10 failures in 30 minutes), the webhook is automatically suspended. The tenant receives an in-app notification. Resumption requires explicit tenant action, not automatic re-enable, because the receiving system may have structural problems that silent re-enable would mask.

---

## 6. Regional data residency

**Model:** each tenant is provisioned in a home region at account creation. This choice is permanent unless the tenant requests a formal data migration. The API layer may be global, but all data storage and processing for a tenant happens in that tenant's home region.

**Enforcement layers:**

1. **Routing layer:** API gateway routes requests by `tenant_id` to the regional control plane. The routing table is global; the data is regional.
2. **Database layer:** Each region has its own database cluster. There is no global database that holds business objects. Cross-region queries do not exist for business data.
3. **Event bus:** The event bus is regional. Events for a tenant are produced and consumed within the tenant's home region.
4. **Audit log:** Audit records are stored in the tenant's home region. Cross-region audit export is a controlled operation, not a default behavior.
5. **Webhook delivery:** Outbound webhook delivery is initiated from the tenant's home region. The network egress point is regional to satisfy data residency rules that prohibit data transiting foreign jurisdictions.

**Global surfaces (permitted):**

- Authentication token exchange (no PII in flight, only opaque tokens)
- Tenant-to-region routing table (maps tenant ID to region, contains no business data)
- Billing and subscription management (governed by separate data agreements)

**Regional failure handling:**

If a region is unavailable, tenants in that region are degraded — they see read-only mode or a maintenance page, depending on the failure class. Cross-region failover is not automatic because it would violate data residency. Failover requires an explicit operator decision and tenant notification.

---

## 7. Consistency stance

| Domain | Consistency model | Rationale |
|---|---|---|
| Scheduling state transitions | Strong (serializable) | State machine correctness; double-booking and duplicate approvals must be impossible |
| Approval decisions | Strong (serializable) | A decision is immutable once made; concurrent decision race must be prevented |
| Activity feed reads | Eventual (bounded lag) | Feed consumers tolerate slight delay; strong reads here impose unnecessary lock contention |
| Audit log writes | At-least-once via event bus, deduplicated at write | Audit records must not be lost; duplicate detection is cheaper than strong distributed coordination |
| Webhook delivery | At-least-once | Delivery guarantees are externalized to the receiver via idempotency headers |
| Automation rule execution (future) | At-least-once, sandboxed | Rules must not block domain events; execution is independent |