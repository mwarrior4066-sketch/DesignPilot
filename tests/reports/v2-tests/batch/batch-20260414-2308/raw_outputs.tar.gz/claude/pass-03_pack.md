## Dashboard audit

### What this view is failing to do

A first view should answer one question before the user moves: *is the business healthy right now?* This layout collects three signals, a chart, and twelve navigation choices, but delivers none of them conclusively. Every element requires the user to supply the context the interface is withholding.

---

### KPI row

**What is broken and why.**
DAU, MRR, and churn rate as bare numbers with trend arrows have no interpretive value on their own. A trend arrow tells you direction. It does not tell you whether that direction is good, expected, or alarming. Without a target, a prior-period baseline, or a threshold band, the user cannot act on or even read the metric correctly.

MRR and churn rate are not the same category of urgency. Churn rate is a leading signal with direct retention implications. DAU is an engagement proxy. Displaying them at identical visual weight implies identical priority, which forces the user to impose their own hierarchy every time they load the view.

**What to fix.**
Each KPI needs a reference anchor: a target, a prior-period comparison, or a threshold. The format is small but load-bearing — something like "+4.2% vs last 30 days" or "Target: 3.0%" gives the number meaning.

Churn rate should carry higher visual priority than DAU in a SaaS context, because churn directly affects the revenue trajectory shown by MRR. You can do this through position (leftmost with a heavier label weight) or through a threshold rule (churn above a defined level triggers a color state). You sacrifice visual symmetry in the KPI row to gain interpretive clarity, which is the correct tradeoff here.

---

### 30-day line chart

**What is broken and why.**
The Y-axis has no label, so the values on that axis are unidentifiable without external context. Four segment lines without a visible legend require the user to either memorize the color-to-segment mapping or scroll before they can interpret any trend. A chart that requires scrolling before it becomes readable is not a dashboard chart — it is a deferred chart.

Four lines at equal visual weight create a perceptual competition. If all four segments are genuinely equal priority, the chart may be appropriate but the legend problem still kills it. If some segments matter more than others, the chart should encode that through line weight or opacity, not leave the user to resolve it.

**What to fix.**
Move the legend into the chart body: either as labeled endpoints at the right edge of each line, or as a compact inline legend positioned inside the chart area above the data region. Below-the-fold placement is not acceptable when the legend is required to read the chart.

Add a Y-axis label. This is not optional. Without it, the axis values are numerically present but semantically absent.

If segment priority is unequal, encode it. Use a heavier line weight or stronger opacity for the primary segment, and thinner or more muted rendering for supporting segments. This means accepting that the chart becomes less visually symmetric, but the tradeoff is that the user can scan it correctly in under five seconds.

Consider whether four segment lines belong on the first view at all. If the job of this screen is health monitoring rather than segment analysis, a single aggregate line with a drill-down path may serve better. The segment breakdown is likely more useful one level deeper.

---

### Left sidebar navigation

**What is broken and why.**
Twelve ungrouped nav items present a flat list that the user must read sequentially to locate anything. At twelve items, the cognitive load is measurable: the user cannot hold the full list in working memory as a spatial map, so every navigation task becomes a search task. This cost is paid on every session, not just the first.

There is also a priority failure. An analytics dashboard typically has a small number of high-frequency destinations (the current dashboard view, reports, alerts) and a larger number of lower-frequency ones (settings, billing, user management, integrations). Flat display treats all twelve as equally likely destinations, which is almost certainly wrong.

**What to fix.**
Group the twelve items into three to four labeled sections by frequency of use and functional role. A common and defensible structure for a SaaS analytics tool:

- **Monitor** — the dashboard, alerts, and any real-time views
- **Analyze** — reports, cohorts, funnels, and segment tools
- **Manage** — users, settings, billing, integrations

This structure does not need to be exactly this. It needs to be grounded in how your users actually navigate, which means checking usage data before committing to a grouping. You sacrifice flexibility in item placement to gain faster wayfinding, which is the right tradeoff at twelve items.

Sections with low visit frequency can be collapsed by default, reducing visible items to the five or six that matter most in normal use.

---

### Intervention order

Fix these in sequence because each one changes what the next fix needs to do.

1. **KPI reference anchors first.** Without these, the rest of the view is context-free regardless of how well the chart or nav is structured. This is also the fastest fix.

2. **Legend placement second.** A chart with an inaccessible legend actively misleads. Fix this before addressing line weight or chart-type decisions.

3. **Y-axis label alongside legend.** These are both chart legibility failures and belong in the same pass.

4. **Nav grouping third.** The nav is a consistent friction cost but it does not block the core health-monitoring job the dashboard is supposed to do. Prioritize it after the chart is readable.

5. **KPI hierarchy and segment-line priority last.** These require decisions about what the dashboard's actual job is — health monitoring, segment comparison, or both — and those decisions should be grounded in usage evidence rather than made at the same time as the legibility fixes.

---

### What this audit is not claiming

The four segment lines may be deliberately equal priority. The churn threshold that warrants a color state depends on your business model and benchmarks. The nav grouping proposed above is a pattern, not a prescription. Each of these decisions requires knowledge of your actual user behavior and business context that is not visible in a layout description.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_role: health monitoring first view",
    "kpi_failure: no reference anchors, no targets, equal visual weight",
    "chart_failure: legend below fold, no Y-axis label, four equal-weight lines",
    "density_or_navigation_decision: 12 ungrouped nav items require grouping into 3-4 labeled sections"
  ],
  "evidence_classes_cited": [
    "wcag_threshold_implicit",
    "working_memory_constraint",
    "kpi_hierarchy_rule",
    "chart_legibility_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is this dashboard primarily a health-monitoring view or a segment-analysis view? This affects whether four segment lines belong on the first view.",
    "What is the target or threshold for churn rate in this context?",
    "Is nav grouping structure available from usage data or must it be inferred from product structure?"
  ],
  "turn": 1
}
[/SESSION_STATE]