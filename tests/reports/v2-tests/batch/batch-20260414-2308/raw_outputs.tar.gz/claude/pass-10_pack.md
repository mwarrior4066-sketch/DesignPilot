The structure has a sequencing problem before it has a style problem. Here is what is broken and how to fix it.

## What the hierarchy is actually saying

The current read order is: title → nothing → logo (buried mid-visual-noise) → date (hidden).

The audience encounters the most specific information (the event name) before they have the orienting frame (what kind of event, who it is for, when it is). This forces them to reverse-engineer meaning from a name they may not recognize.

A conference poster has one job at distance: stop the right person, establish relevance, give them a reason to look closer. This one fails the first two.

## Structural failures

**Logo in the center of a full-bleed photo** is a contrast trap. White on a city skyline produces unpredictable legibility across every print and digital context because the sky varies by image crop, time of day in the photo, and reproduction conditions. The logo is also occupying prime visual real estate while doing orientation work that belongs to a category line or event type label. You sacrifice legibility reliability to gain a centered, "premium" placement that only works when the photo cooperates.

**Date in small gray text in the bottom corner** is a priority inversion. For an event poster, the date is arguably the second most important piece of information after category. A potential attendee who cannot immediately find the date will not go hunting for it. Small gray text at the edge of a busy photo background compounds the contrast problem.

**Decorative typeface for the title** may be a fine choice for identity purposes, but decorative typefaces typically trade legibility range for character. At the sizes and viewing distances a poster must work at, a decorative face needs to justify its illegibility cost. If it is not readable at 3 meters, or does not reproduce cleanly at small digital sizes, it is doing aesthetic work at the expense of communication.

**No category or context anchor** is the root sequencing failure. Nothing in the described layout tells a stranger this is a design conference, who it is for, or why they should care, before asking them to process a proper noun.

## Rebuild priorities

**1. Add a category anchor and move it above or adjacent to the title.**
Something like "Design Conference" or a more specific descriptor ("UX + Product Design Summit") should appear before or immediately alongside the event name. This is the orienting frame the reader needs. It can be small, but it must come first in the read order.

**2. Relocate and enlarge the date.**
The date belongs in a zone with guaranteed contrast and a type size that reads at a glance. Bottom-corner small text fails at distance and in thumbnails. If the poster uses a footer band or a color block beneath the image, the date anchors there with full legibility.

**3. Solve the logo contrast problem properly.**
Either place the logo in a zone with a controlled background (a solid strip, a semi-transparent band, or a cropped photo section with a predictably light or dark value), or relocate it out of the center entirely. The logo's job is identification, not orientation. It does not need to be centered to do that job. You sacrifice compositional symmetry to gain reliable legibility across all reproduction contexts.

**4. Evaluate whether the decorative typeface earns its place.**
Test it: print it at A3, stand 3 meters away, read the title in 2 seconds. If it fails that test, the decorative choice is an identity indulgence, not a communication tool. A pairing of a distinctive display face for the title with a clean, highly legible secondary for the supporting information often serves the poster better than a fully decorative title face.

**5. Reconsider the full-bleed photo as the background.**
A city skyline is generic to every city and visually competes with every layer placed on top of it. If the photo has no specific conceptual relationship to this conference, it is adding visual weight without adding meaning. A controlled color field, a textured abstraction, or a photo with a clear focal-point strategy will give the typography a fighting chance.

## What to preserve

The instinct toward a strong full-bleed visual and a bold title is correct for the genre. The ambition is right. The execution sequence is wrong. Fix the read order, solve the contrast architecture, and the visual boldness can stay.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "communication_goal: stop the right person, establish relevance, invite closer reading",
    "hierarchy_failure: title before context anchor; date deprioritized; logo in contrast trap",
    "rebuild_move: add category anchor, relocate date, solve logo contrast, evaluate decorative face, reconsider photo strategy",
    "distance_tradeoff: decorative typeface trades legibility range for character; costs communication at distance"
  ],
  "evidence_classes_cited": [
    "contrast_threshold",
    "distance_legibility_test",
    "read_order_analysis",
    "hierarchy_sequencing"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the decorative typeface have a specific identity rationale, or is it a default stylistic choice?",
    "Is the city skyline photo conceptually tied to the conference location or theme?",
    "What reproduction contexts must the poster survive: print, digital, social thumbnail?"
  ],
  "turn": 1
}
[/SESSION_STATE]