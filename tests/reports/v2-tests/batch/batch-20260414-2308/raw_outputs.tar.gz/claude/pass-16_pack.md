# API Audit: POST /exports — PDF Report Generation

## Summary

Five structural failures. Every one of them is a production incident waiting to happen. The synchronous block is the architectural root; the others compound it. I'll address all four required areas in order of failure severity.

---

## Failure semantics and error contract

**Current state:** HTTP 200 for all responses including errors.

This is the most basic contract violation possible. A caller cannot distinguish success from failure without parsing the body, which means every retry strategy, circuit breaker, monitoring alert, and load balancer in the chain is blind. They will all treat a failed export as a successful one.

**Required fix:** HTTP status codes must carry semantic weight.

| Condition | Correct status |
|---|---|
| Export accepted (async) | 202 Accepted |
| Validation failure | 400 Bad Request |
| Auth failure | 401 / 403 |
| Resource not found | 404 |
| Duplicate request | 409 Conflict |
| Server fault | 500 |
| Upstream timeout | 503 or 504 |

Error bodies must conform to RFC 9457 (Problem Details). The current design leaks internal enum values in error messages, which both reveals implementation internals and produces unstable error contracts that break clients when the enum changes.

**RFC 9457 compliant error shape:**

```json
{
  "type": "https://api.example.com/problems/export-unavailable",
  "title": "Export service temporarily unavailable",
  "status": 503,
  "detail": "The PDF rendering service did not respond within the allowed window.",
  "instance": "/exports/req_abc123",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736"
}
```

`trace_id` on all errors is not optional here. Without it, correlating a 503 in the client log to the corresponding server trace is a manual grep exercise across distributed logs.

What you sacrifice: callers who currently check `response.status === 200 && body.error` will break. That is the correct tradeoff. A clean status contract costs one migration; a broken one costs every incident response forever.

---

## Authorization and resource protection

**Current state:** Not described, which means unverified.

For an export endpoint generating PDF reports, the authorization perimeter must be explicit before anything ships.

**Required decisions:**

**Object-level authorization.** Only the session owner (or a role explicitly granted access) may request an export for a given resource. BOLA (Broken Object Level Authorization) is the most common API vulnerability class. A check that validates the caller's identity at the route level but not against the specific report resource is insufficient. The check must be: does this caller own or have read permission on the underlying data being exported?

```
deny by default
only [report_owner | org_admin | export_role] may call POST /exports
object-level check: caller.org_id === report.org_id AND caller has read on report_id
```

**Rate limiting and quota.** PDF generation is compute-heavy. Without a rate limit, a single authenticated caller can saturate the renderer. The constraint is: rate limit + quota must be enforced per caller identity, not per IP. IP-based limits are trivially bypassed behind shared infrastructure.

**Export scope.** The request body must explicitly declare what is being exported, and the server must validate that the declared scope matches what the caller is authorized to see. Inferred scope from session state is a common source of data leakage when sessions are shared, federated, or elevated.

What you sacrifice: simpler authorization middleware that only checks authentication. You gain defense against the failure mode where an authenticated but unauthorized caller exports another tenant's data.

---

## Idempotency and async lifecycle

**Current state:** Synchronous, blocks up to 3 minutes, no idempotency key.

This is the architectural root failure. Three minutes is not a request-response window. It is a background job dressed up as a synchronous call. The consequences stack:

- The client TCP connection must stay open for 3 minutes or it times out and the caller cannot know if the export completed
- Every retry on timeout creates a duplicate export job because there is no idempotency contract
- Mobile clients, load balancers, and API gateways all have default timeout ceilings well below 3 minutes
- Without an idempotency key header, the server cannot detect a retry from a new request

**Required architecture: 202 Accepted + job lifecycle**

```
POST /exports
  -> validate request
  -> 409 on duplicate (idempotency-key header match)
  -> enqueue job
  -> 202 Accepted + { "job_id": "job_xyz", "status_url": "/exports/job_xyz/status" }

GET /exports/{job_id}/status
  -> terminal states: queued -> running -> completed | failed
  -> completed: { "status": "completed", "download_url": "...", "expires_at": "..." }
  -> failed: { "status": "failed", "error": { RFC 9457 block } }
```

**Idempotency contract.** The caller sends an `Idempotency-Key` header on POST. The server stores the key against the job. A second POST with the same key within the deduplication window returns 409 on duplicate with the original job reference. This means a retry on network failure is safe: the second call returns 409 Conflict and the job reference, the caller resolves to the in-flight job, and no duplicate is created.

The idempotency window must be explicit (24 hours is a reasonable default for export jobs). After expiry, the same key may generate a new job. Document this in the API spec, because callers will depend on it.

**Polling interval.** Return a `Retry-After` header on the 202 response and on intermediate status responses. Without it, callers will poll at whatever interval they choose, ranging from once per second to never. The constraint is: the server controls the polling cadence, not the client.

What you sacrifice: the simplicity of a single synchronous call and an immediate result. You gain a contract that survives network interruptions, gateway timeouts, client restarts, and safe retries, which is required at the 3-minute generation window.

---

## Resilience and observability

**Current state:** No retry-safe contract, no described failure handling.

**Resilience requirements:**

The PDF renderer is an upstream dependency. Without circuit breaker behavior, a renderer outage causes every POST /exports call to hang for up to 3 minutes before timing out, saturating the connection pool and cascading into the broader API surface.

Required patterns:
- **Circuit breaker** on the renderer client: open on N consecutive failures, return 503 with `Retry-After` immediately while open, probe with a single request before closing
- **Exponential backoff with jitter** on renderer retries: without jitter, retry storms are guaranteed under load because all callers retry at the same interval
- **Graceful degradation**: if the renderer is unavailable, the job must transition to `failed` with a structured error, not hang in `running` indefinitely. Define a maximum job TTL after which a stuck job is marked failed and the caller is notified via status endpoint

**Observability requirements:**

`trace_id on all errors` is necessary but not sufficient. For an async job system, the required telemetry surface is:

| Signal | What it enables |
|---|---|
| `trace_id` on every response | Correlation from client log to server trace |
| Job state transition events | Alerting on jobs stuck in `running` beyond TTL |
| Renderer latency histogram | Distinguishing normal slow generation from pathological hangs |
| Queue depth metric | Early warning before timeout cascade |
| Per-caller export rate metric | Quota enforcement and abuse detection |

Without job state transition events specifically, a job that enters `running` and never leaves is invisible until a user files a support ticket. The fix is: every state transition emits a structured event with `job_id`, `from_state`, `to_state`, `timestamp`, and `trace_id`. Alert when `running` duration exceeds the P95 generation time.

What you sacrifice: the operational simplicity of a synchronous endpoint where a 500 is the only failure mode to monitor. You gain a system where failures are observable, attributable, and recoverable without manual intervention.

---

## Audit summary

| Area | Severity | Root fix |
|---|---|---|
| Error contract (200 for all) | Critical | RFC 9457 + correct HTTP status codes |
| Internal enum leakage | High | Stable problem type URIs, no internal values in `detail` |
| Authorization perimeter | Critical | Object-level check + deny by default + rate limit per identity |
| Synchronous 3-minute block | Critical | 202 Accepted + async job lifecycle |
| No idempotency key | High | `Idempotency-Key` header + 409 on duplicate |
| No circuit breaker | High | Circuit breaker on renderer + exponential backoff with jitter |
| No observability surface | High | trace_id + job state events + queue depth + latency histogram |

The synchronous block and the error contract are the two changes that unblock the rest. The async job model fixes idempotency, timeout safety, and retry-safe contracts in one architectural move. The RFC 9457 contract fixes error semantics, enum leakage, and traceability in one structural move. Ship those two first.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "problem_details_contract: RFC 9457 with stable problem type URIs",
    "authorization_perimeter: object-level BOLA check + deny by default + per-identity rate limit",
    "idempotency_contract: Idempotency-Key header + 409 on duplicate within 24h window",
    "async_job_model: 202 Accepted + terminal states queued -> running -> completed | failed",
    "resilience_strategy: circuit breaker on renderer + exponential backoff with jitter + job TTL"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "BOLA authorization pattern",
    "idempotency-key header contract",
    "202 Accepted + status URL pattern",
    "circuit breaker pattern",
    "exponential backoff with jitter",
    "job state transition telemetry"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What is the expected PDF generation P95 latency — needed to set job TTL and circuit breaker thresholds?",
    "Is there an existing auth middleware that supports object-level checks, or does this require new infrastructure?",
    "What is the deduplication window policy for the idempotency key — 24h assumed but should be confirmed?"
  ],
  "turn": 1
}
[/SESSION_STATE]