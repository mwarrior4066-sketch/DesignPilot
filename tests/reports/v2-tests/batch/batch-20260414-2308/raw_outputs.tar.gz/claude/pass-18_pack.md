## API Review: POST /api/v1/projects/{id}/members

---

### 1. Status code on successful creation

**Governing decision:** Return `201 Created`, not `200 OK`, when a resource is created.

`200` signals a successful operation on an existing resource. Adding a member creates a new membership resource. The correct code is `201`, with a `Location` header pointing to the new membership if the API supports individual member retrieval. Returning `200` here is not wrong enough to break clients, but it misrepresents the operation semantics and will confuse clients that distinguish creation from update.

---

### 2. Response body returns the full member list

**Governing decision:** The response body should represent the created resource, not a derived aggregate.

Returning the full updated member list couples the creation response to a list query. This has two costs. First, on large projects the response payload grows without bound. Second, clients that only care about the new membership are forced to parse a collection to confirm their operation succeeded. Return the created membership object. Clients that need the full list should call `GET /api/v1/projects/{id}/members` explicitly.

---

### 3. No idempotency key

**Governing decision:** Mutating POST endpoints that create resources must support an `Idempotency-Key` header to make retries safe.

Without an idempotency contract, a client that retries after a timeout cannot know whether the first request succeeded. The result is either a duplicate membership, a confusing error, or a silent no-op depending on how the server handles it — none of which is explicitly signaled. Add an `Idempotency-Key` header. On duplicate key receipt within the deduplication window, return `200` with the original response body rather than processing the request again. Return `409 Conflict` only if the key is reused with a different payload.

---

### 4. Error response is a plain string

**Governing decision:** Error responses must follow RFC 9457 (Problem Details for HTTP APIs).

A plain string is unstructured and unactionable for programmatic clients. RFC 9457 requires at minimum:

```json
{
  "type": "https://example.com/problems/member-already-exists",
  "title": "Member already exists",
  "status": 409,
  "detail": "User 42 is already a member of project 7.",
  "instance": "/api/v1/projects/7/members"
}
```

This gives clients a stable `type` URI to match against, a human-readable `title`, and a specific `detail`. Add a `trace_id` field as an extension for support and observability. Without this, error handling in clients degrades to string matching, which breaks on any copy change.

---

### 5. Authorization checks authentication but not project-level permission

**Governing decision:** Object-level authorization must be enforced at the resource boundary, not at the session boundary.

Checking that the caller is logged in is authentication, not authorization. Any authenticated user can currently add members to any project they can name an ID for. This is a BOLA (Broken Object-Level Authorization) vulnerability — the most common class of API authorization failure.

The fix has two layers:

**Role check:** Only users with the `project:admin` or `project:owner` role on this specific project may add members. A user who is authenticated but not an admin of project `{id}` must receive `403 Forbidden`, not `404` and not `401`.

**Response code discipline:** Return `403` when the user is authenticated but lacks permission. Return `401` when the request carries no valid session at all. Do not collapse these into a single code — clients need to distinguish "you are not logged in" from "you are logged in but not allowed here."

The authorization check must be object-level: membership in the system is not sufficient. Membership with the right role on this project is the requirement.

---

### 6. No explicit conflict handling for duplicate membership

**Governing decision:** Idempotent-safe creation endpoints must define behavior when the resource already exists.

This is adjacent to the idempotency gap but distinct. Even with an idempotency key, a second intentional request to add the same user should receive a defined response. Options:

- `409 Conflict` with a Problem Details body naming the duplicate, or
- `200 OK` treating the operation as a no-op if the membership is already active (only if this is deliberate policy)

Leaving this undefined means server behavior is determined by database constraint errors leaking through as 500s or silent duplicates. Define the policy explicitly and encode it in the Problem Details `type` URI.

---

### Priority order for fixes

| Priority | Issue | Risk |
|---|---|---|
| Critical | BOLA authorization gap | Any authenticated user can add members to any project |
| Critical | No idempotency contract | Retries produce unpredictable state |
| High | Plain string errors | Programmatic error handling degrades to fragile string matching |
| High | Wrong status code (200 vs 201) | Misrepresents operation semantics |
| Medium | Response body is full member list | Unbounded payload, couples creation to listing |
| Medium | Undefined duplicate behavior | 500s or silent duplicates on conflict |

[SESSION_STATE]
{
  "route": "api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "status_code: 201 Created for resource creation",
    "idempotency_contract: Idempotency-Key header required",
    "error_contract: RFC 9457 Problem Details",
    "authorization_perimeter: object-level, project:admin role required",
    "response_body: created resource not derived aggregate",
    "conflict_behavior: 409 with Problem Details body"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "idempotency-key header",
    "409 on duplicate",
    "BOLA check",
    "object-level authorization",
    "deny by default",
    "trace_id on all errors",
    "authorization perimeter"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the API support individual membership retrieval (needed for Location header on 201)?",
    "What is the deduplication window for idempotency keys?",
    "Is project:admin a distinct role or derived from project ownership?"
  ],
  "turn": 1
}
[/SESSION_STATE]