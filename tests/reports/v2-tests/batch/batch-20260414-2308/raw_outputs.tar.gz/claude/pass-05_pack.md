## PDF Accessibility Remediation Plan

**Governing route:** PDF remediation (semantic failure and extraction fidelity at risk) + Document accessibility (tagging, reading order, artifact handling)

---

## What's actually broken

Before prescribing fixes, here is what you are dealing with across four failure classes:

**Structural tagging failures**
InDesign exports a tag tree, but two-column layouts frequently produce a linearized reading order that follows the physical frame sequence on the page rather than the intended left-to-right, top-to-bottom column flow. This means a screen reader may read the first paragraph of column one, then jump to the first paragraph of column two, then back to column one's second paragraph, depending on how InDesign threaded the text frames. The tag tree needs to reflect the intended reading sequence, not frame draw order.

**Pull quote contamination**
Pull quotes are repetitions of body content. When tagged as `<P>` or `<Quote>` elements inside the main reading order, a screen reader reads the content twice — once in the body and once when it hits the pull quote frame. Pull quotes must be marked as `<Artifact>` so assistive technology ignores them. They carry no unique information; they are a print design device.

**Decorative images**
Untagged decorative images are a soft barrier. In Acrobat's tag tree they may appear as `<Figure>` with no `Alt` attribute, or they may be absent from the tag tree entirely but present as content objects. Either state is a failure: missing alt text on a content image fails WCAG 1.1.1, and an untagged decorative image can surface as a skip in the reading order or trigger a "Figure has no alternate text" flag in PAC 3 or CommonLook. Decorative images need to be explicitly tagged as `<Artifact>` with an artifact type of `Layout` or `Page`, not left as untagged orphans.

**Broken TOC links**
InDesign's TOC generates hyperlink annotations pointing to named destinations inside the PDF. These break in three common ways: the named destination was not exported (InDesign's "Create PDF Bookmarks" and "Export Tags as PDF Bookmarks" options interact in non-obvious ways), the hyperlink annotation exists but the `<Link>` tag in the tag tree has no `<OBJR>` child connecting it to the annotation object, or the link tag exists and the annotation exists but they are not associated, so Acrobat treats the annotation as untagged. The fix requires both a live annotation and a properly structured `<Link><OBJR>` tag pair.

---

## Remediation order

Work in this sequence. Each step depends on the one before it.

### Step 1 — Correct the tag tree structure before fixing anything else

Open the Tags panel in Acrobat Pro. The document root should have a `<Document>` tag containing `<Part>` or `<Sect>` containers for each page or section, then `<P>`, `<H1>` through `<H6>`, `<L>` for lists, `<Table>` for tables, and so on. If InDesign exported a flat list of `<P>` tags directly under `<Document>` with no sectioning, that is not necessarily a hard failure, but it is a missed opportunity for logical grouping and will make the next steps harder.

Check the order of tags in the Tags panel against the intended reading order. In Acrobat Pro, you can use the Reading Order tool (Touch Up Reading Order) to view the order numbers overlaid on the page. If column two content appears before column one content completes, you need to reorder the tags. Do this by dragging tags in the Tags panel, not by modifying the visible page content. This is purely a logical structure change.

*Why this comes first:* every other fix — pull quote artifacting, image tagging, link structure — requires a stable tag tree to insert into. Reordering tags after you have made surgical fixes can displace the elements you already repaired.

### Step 2 — Artifact pull quotes

In the Tags panel, locate each pull quote. They will appear as `<P>` or possibly `<BlockQuote>` tags. Right-click and choose "Change Tag to Artifact," or delete the tag and mark the underlying content objects as Artifacts through Edit > Preflight > Acrobat Pro's Artifact tool. Set the artifact type to `Layout`.

Verify: after artifacting, run the reading order view again and confirm the pull quote content no longer appears in the numbered sequence. If it does, the underlying content stream still has the object in the marked-content sequence, and you need to mark it as an artifact at the content stream level using the Content panel, not just remove the tag.

### Step 3 — Tag decorative images correctly

Open the Content panel (not the Tags panel). Find image objects that are either untagged or tagged as `<Figure>` with no alt text. For each decorative image:

1. If it is in the tag tree as `<Figure>` with no alt text, right-click the tag, choose Properties, and mark it as a background artifact. Remove the `<Figure>` tag.
2. If it is untagged in the tag tree but present in the Content panel, right-click in the Content panel and choose "Mark as Artifact," type "Layout."
3. If an image is informational (carries meaning a sighted user would use), it must keep a `<Figure>` tag and you must add alt text via the tag's Object Properties dialog.

The distinction between decorative and informational matters here. You sacrifice the ability to mark something as "just decoration" later if you assign alt text now and users or validators start depending on it.

### Step 4 — Repair TOC links

For each broken TOC entry:

**Check whether the named destination exists.** Use Acrobat's Advanced > Document Processing > Manage Embedded Index, or use the Destinations panel if available in your version. If destinations are missing entirely, you need to go back to InDesign, enable "Bookmarks" or "Hyperlinks" in the PDF export dialog (the exact option depends on InDesign version — look for "Include Bookmarks" and "Create PDF Bookmarks" under the General tab of Export PDF), and re-export. Re-exporting is less expensive than manually recreating all named destinations in Acrobat.

**If the destinations exist but the links are broken in the tag tree**, the `<Link>` tags need `<OBJR>` children. In the Tags panel, find each TOC `<Link>` tag, expand it, and confirm it has a child `<OBJR>` that references the annotation object. If the `<OBJR>` is missing, this is the hard part: Acrobat Pro does not expose a simple "reattach annotation to tag" button. You will need to use Acrobat's accessibility repair tools or, in complex cases, use a PDF processing library (Apache PDFBox, iText, or PDF.co) to programmatically associate the annotation with the tag. For a one-off document, re-exporting from InDesign with correct settings is almost always faster and more reliable than manual surgical repair.

**If you cannot re-export**, the fastest Acrobat-only workaround is to delete the broken link annotations, delete the broken `<Link>` tags, and recreate the hyperlinks manually using Acrobat's Link tool. When you create a hyperlink annotation with Acrobat's tool and the document already has valid named destinations, Acrobat will create the annotation and you can then associate it with a new `<Link>` tag in the tag tree.

---

## Verification before you ship

Run these checks in order. Each one covers what the previous one misses.

**PAC 3 or PAC 2024** (PDF Accessibility Checker, free): machine checks against PDF/UA-1. This will surface missing alt text, broken tag structure, role map errors, and untagged content. It will not catch reading order problems or pull quote logic errors — those require human review.

**NVDA + Chrome or JAWS + Edge**: read through the document with a screen reader from start to finish. Confirm the column reading order is correct, confirm pull quotes are skipped, confirm decorative images produce no announcement, and confirm TOC links navigate correctly when activated with Enter.

**Acrobat's built-in Accessibility Checker** (Tools > Accessibility > Full Check): useful for a first pass but less strict than PAC 3. Use both, because they flag different edge cases.

**Check the reading order view one final time** in Acrobat Pro's Touch Up Reading Order tool. Every content block should have a number. Pull quotes and decorative images should have no number.

---

## Shortcuts that will break the document

Do not use these approaches even though they appear in tutorials:

- **"Fix reading order" auto-repair in Acrobat**: this regenerates the tag tree from the content stream in PDF paint order, which for a two-column InDesign document is exactly wrong. It destroys the careful column-reading sequence you set in Step 1.
- **Re-running InDesign's "Export Tags as Bookmarks" without reviewing the source tag assignments first**: InDesign maps paragraph styles to PDF tags. If your pull quote paragraph style is not mapped to "Artifact" in the InDesign Styles panel's Export Tagging settings, every export will reproduce the same pull quote contamination.
- **Adding alt text to decorative images instead of artifacting them**: alt text on a decorative image forces a screen reader to announce it. Artifacting removes it from the accessibility tree entirely. The goal for decoration is silence.

---

## If you are going to re-export from InDesign

Fix the source before exporting again. In InDesign:

- Open the Paragraph Styles panel for each pull quote style. Go to Style > Edit Style > Export Tagging. Set the PDF tag to "Artifact." This will artifact all pull quotes on export without requiring Acrobat post-processing.
- For decorative images, select each frame, go to Object > Object Export Options, and set the Alt Text source to "Custom" with an empty string — no, wait: empty alt text is not the same as artifact. Instead, check "Tag as Artifact" in the Object Export Options dialog if your InDesign version supports it. In older versions (pre-CC 2019 or so), you will need to artifact these in Acrobat after export regardless.
- For the TOC, confirm that both "Create PDF Bookmarks" and "Hyperlinks" are checked in the PDF export dialog. Ensure paragraph styles in the TOC are mapped correctly to PDF heading tags so the logical structure supports the navigation.
- After export, you will still need to verify reading order in Acrobat — InDesign does not guarantee column threading produces a correct linear tag sequence even with correct style mapping.

---

## What you are preserving versus sacrificing

You preserve full semantic document structure, correct assistive technology behavior, compliance with PDF/UA-1 and WCAG 2.1 Level AA, and the ability to extract clean text programmatically.

You sacrifice some speed: the correct path here is partly a round-trip to InDesign to fix the source, not a pure Acrobat post-processing fix. Doing it entirely in Acrobat is possible but fragile — the next export from the same InDesign file will reproduce the same failures unless the source is corrected.

[SESSION_STATE]
{
  "route": "rt_pdf_remediation + rt_document_accessibility",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_failure: tag tree column reading order does not match intended column sequence",
    "semantic_failure: pull quotes tagged as readable content, not artifacts",
    "semantic_failure: decorative images untagged or tagged Figure with no alt text",
    "semantic_failure: TOC link annotations not associated with Link+OBJR tag pairs",
    "reading_order_or_extraction: reorder tags in Tags panel before all other fixes",
    "verification_method: PAC 3 + NVDA screen reader full read-through + Acrobat Full Check",
    "destructive_shortcut_rejected: Acrobat auto-repair reading order fix",
    "destructive_shortcut_rejected: adding alt text to decorative images instead of artifacting"
  ],
  "evidence_classes_cited": [
    "wcag_1_1_1_alt_text_requirement",
    "pdf_ua_1_tag_structure",
    "link_objr_association_requirement",
    "artifact_type_layout_page",
    "pac3_validator",
    "indesign_export_tagging_paragraph_style_mapping"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Which InDesign version is in use — Object Export Options artifact support varies by version",
    "Are any images informational rather than decorative — these require alt text, not artifacting",
    "Is re-export from InDesign possible, or must all remediation happen in Acrobat only"
  ],
  "turn": 1
}
[/SESSION_STATE]