## Functional tier

Think of your app's state like notes passed between coworkers.

Local state is a sticky note you keep at your own desk. Only you see it. A form input that tracks what you've typed, a dropdown that tracks whether it's open -- these are sticky notes. They belong to the component that needs them, and nobody else should care.

Context is a shared whiteboard in the room. Anyone can read it. Good for things like "who is logged in" or "is dark mode on" -- information that many components need but that does not change often or quickly.

Redux (or a global state manager like Zustand or Jotai) is a filing cabinet with a strict intake process. Every change goes through a documented procedure. That strictness costs setup time and ongoing effort, but it means you can always reconstruct exactly what happened and when.

The problem with reaching for the filing cabinet too early is that you end up writing formal intake forms for sticky notes. That overhead is real. Small apps with one or two developers accumulate Redux boilerplate faster than they accumulate the complexity that boilerplate was meant to solve.

Where local-plus-context genuinely breaks down is when multiple unrelated parts of the app need to read and write the same data at the same time, especially data that changes frequently. At that point, passing state through context starts to cause the whole subtree to re-render on every update, and you lose the ability to trace where a change came from.

The signal to reach for a global manager is not app size. It is coordination cost: when you spend more time debugging why the wrong version of the data appeared in the wrong place than you spend building features, you have crossed the line.

**Governing recommendation:** Start with local component state and context for clearly scoped data; reach for a global state manager only when you can point to a specific coordination or re-render problem you cannot solve by restructuring your component tree.

---

## Integrative tier

The choice is not really between Redux and context. It is between two different models of state ownership, and the wrong ownership model causes pain that looks like a styling problem or a performance problem but is actually an architecture problem.

**Local state** carries a hard scope contract: this data is owned here, mutated here, and dies when this component unmounts. That contract is cheap to enforce and cheap to reason about. It also makes testing straightforward because the component is self-contained.

**Context** lifts that ownership to a shared ancestor, which is appropriate for low-frequency global values (theme, locale, current user, feature flags). Context becomes expensive when you use it for high-frequency or high-cardinality data, because React re-renders every consumer in the subtree on every context value change. You can partially mitigate this with context splitting and memoization, but at some point you are doing manual work that a proper state manager would handle for you.

**Global state managers** (Redux Toolkit, Zustand, Jotai, Recoil) solve coordination problems, not just storage problems. The real value of Redux is not the store. It is the strict unidirectional data flow, the predictability of actions and reducers, and the ability to use middleware for side effects in a controlled way. Zustand and Jotai trade some of that strictness for less boilerplate, which is often the right call for mid-sized apps that do not need time-travel debugging or complex middleware chains.

**The architectural decision point** is whether your state has cross-cutting writes. If component A writes and component B reads from the same slice of state, and they are not in the same subtree, context will work but will cause re-render pressure. A global store handles that coordination without the re-render cascade, because consumers subscribe to slices, not the entire store.

A secondary consideration is server state. If a significant portion of what you are managing is fetched data (API responses, paginated lists, cached queries), a server-state library like React Query or SWR solves a different problem than Redux does. Mixing a global client-state manager with a server-state manager and context for UI state is a valid three-layer approach, and it avoids loading Redux with work it was not designed for.

**Governing recommendation:** Use local state for component-scoped concerns, context for low-frequency global values, a dedicated server-state library (React Query or SWR) for fetched data, and add a global client-state manager only when you have identified concrete cross-cutting write coordination that cannot be resolved by restructuring the component tree.

---

## Strategic tier

The framing of "Redux vs. context" is usually a proxy for a deeper question: where does state authority live, and how is mutation propagated?

**State ownership taxonomy for this decision:**

- **Ephemeral UI state** (open/closed, hover, input value mid-edit): always local. No global manager should touch this.
- **Shared UI state** (theme, locale, auth identity, modal stack): context is the correct primitive if mutation frequency is low. If it is high, context re-render cost makes a lightweight atom-based store (Zustand, Jotai) the cheaper architecture.
- **Server-derived state** (API data, paginated collections, cached responses): this is not client state and should not be in Redux. React Query or SWR with stale-while-revalidate semantics handles cache invalidation, background refetch, and loading/error state in ways Redux cannot without significant middleware overhead.
- **Cross-cutting client state** (multi-step form state shared across routes, optimistic mutations, undo/redo, collaborative editing buffers): this is Redux's actual domain. Unidirectional flow, action traceability, and middleware composition are load-bearing here.

**Re-render cost is the forcing function, not app size.** An app with 30 components and one piece of frequently-mutated global state will suffer more from context than an app with 300 components and well-scoped local state. Profile before you architect around a problem you have not measured.

**The Redux overhead tax is real and asymmetric.** RTK (Redux Toolkit) reduces boilerplate meaningfully, but the conceptual overhead of actions, reducers, selectors, and middleware is fixed. Teams pay that tax on day one. The benefit (traceability, DevTools, middleware control) accrues slowly as the app grows. For teams that will not need time-travel debugging, complex async orchestration, or cross-team state contracts, Zustand delivers 80% of the value at roughly 20% of the surface area.

**Migration cost is typically underestimated.** Starting with context and migrating to a global store later is feasible but requires refactoring consumption patterns across the codebase. If there is strong evidence the app will reach coordination-heavy state within the first two quarters, the cost of starting with Zustand or RTK is lower than the cost of the later migration.

**Governing recommendation:** Adopt a four-layer state model -- local state for ephemeral UI concerns, context for low-frequency global values, React Query or SWR for server-derived state, and Zustand (or RTK if middleware composition or DevTools traceability are organizational requirements) for cross-cutting client state -- because conflating these layers into a single global store produces correctness and performance problems that are expensive to untangle under delivery pressure.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "state_ownership: four-layer model -- local / context / server-state library / global client store",
    "global_store_trigger: cross-cutting write coordination, not app size",
    "server_state_tool: React Query or SWR, not Redux",
    "global_store_choice: Zustand as default; RTK when middleware composition or DevTools traceability are required"
  ],
  "evidence_classes_cited": [
    "rendering_model",
    "state_ownership",
    "boundary_placement",
    "cost_or_degraded_path"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the team have an existing Redux dependency or org-wide state management standard?",
    "What proportion of state is server-derived vs. client-only?",
    "Is time-travel debugging or cross-team state contract enforcement a real requirement?"
  ],
  "turn": 1
}
[/SESSION_STATE]