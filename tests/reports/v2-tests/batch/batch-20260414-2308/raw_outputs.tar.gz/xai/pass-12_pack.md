I’ll recommend a type system for your fintech product that works across a marketing site, web app dashboard, and mobile, balancing modernity, trust, and functionality for financial data. Below, I’ve outlined the choices, rationale, and deployment strategy.

### Typeface Selection
- **Primary Typeface: Inter**
  - **Why**: Inter is a modern sans-serif designed for digital interfaces, with excellent readability at small sizes—crucial for dashboards and mobile. Its neutral yet confident tone conveys trust without feeling overly corporate or dated. It supports multiple weights (from Thin to Black), enabling clear hierarchy across platforms. Inter also has tailored figures for tabular data, with consistent width across weights to prevent layout shifts in financial tables.
  - **Context Fit**: For marketing, its clean and approachable style feels contemporary. For dashboards, its legibility and monospaced figures ensure data clarity. On mobile, its optimized hinting prevents rendering issues at smaller scales.
  - **Licensing**: Open-source under the SIL Open Font License, free for commercial use across all platforms.

- **Fallback Stack**: If Inter isn’t viable due to rendering or licensing concerns, consider **IBM Plex Sans** (also open-source) for a similar balance of modernity and trust, with strong tabular figure support. As a last resort, system fonts like **-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif** ensure broad compatibility with a neutral tone.

### Weight and Role Mapping
To establish hierarchy across platforms, assign specific weights to roles:
- **Display (Headings, Marketing Hero Text)**: Inter Bold (700) or Extra Bold (800) for impact on marketing pages and key dashboard titles. Size range: 24-48px on desktop, 20-36px on mobile.
- **Subheadings (Section Titles, Dashboard Panels)**: Inter SemiBold (600) for secondary emphasis. Size range: 18-24px on desktop, 16-20px on mobile.
- **Body Text (Paragraphs, Marketing Content)**: Inter Regular (400) for readability in longer content. Size: 16px on desktop, 14-16px on mobile.
- **Interface Text (Buttons, Labels, Navigation)**: Inter Medium (500) for subtle distinction from body text. Size: 14-16px on desktop, 12-14px on mobile.
- **Data and Tabular Text (Financial Figures, Charts)**: Inter Regular (400) with tabular figures enabled for alignment in tables. Size: 12-14px on desktop, 11-13px on mobile.
- **Captions and Fine Print (Footnotes, Disclaimers)**: Inter Light (300) for less emphasis. Size: 12px on desktop, 10-11px on mobile.

### Scale and Readability Rules
- **Base Size**: Start with 16px body text on desktop for accessibility (WCAG 2.1 recommends legible base sizes). Scale down to 14px on mobile only if space constraints demand it, ensuring contrast ratios meet at least 4.5:1 for normal text.
- **Line Length**: Target 45-75 characters per line for marketing and body content to optimize readability. For dashboards, prioritize data density over strict line length, but avoid crowding (aim for 1.5x leading).
- **Leading (Line Spacing)**: Use a 1.5 ratio for body text (24px leading for 16px text) on marketing content for breathing room. For dashboards and mobile, tighten to 1.25-1.3 (18-20px leading for 14-16px text) to fit more data without sacrificing clarity.
- **Variable Font Use**: If your stack supports variable fonts, use Inter’s variable version to fine-tune weights dynamically (e.g., slightly heavier for low-contrast screens), reducing asset load compared to discrete weight files.

### Platform-Specific Adjustments
- **Marketing Site**: Emphasize display weights (Bold/Extra Bold) for headlines to grab attention and build trust through confident typography. Use generous spacing (1.6 leading) for body copy to feel polished and approachable.
- **Web App Dashboard**: Prioritize Regular and Medium weights for dense financial data and UI labels. Enable tabular figures to align numbers in tables—crucial for balance sheets or transaction lists. Keep type sizes smaller (12-14px) for data density, but ensure contrast and touch targets meet accessibility thresholds.
- **Mobile**: Scale down sizes (e.g., body text at 14px, headings at 20-24px) to fit smaller viewports, but maintain at least 1.3 leading to prevent visual clutter. Use Medium weight for key actions or navigation to ensure tap areas are legible. Test rendering on iOS and Android to confirm no aliasing or weight distortion occurs.

### Adoption Sequence
1. **Asset Integration**: Source Inter from Google Fonts or download the variable font from rsms.me/inter for self-hosting (reduces latency and privacy concerns for fintech). Include only the weights you need (Regular, Medium, SemiBold, Bold) to minimize load times—typically under 100KB total if subsetted.
2. **CSS Implementation**: Define font roles in your design system with explicit weight and size mappings. Use `font-variation-settings` for variable fonts if supported, falling back to discrete weights. Enable `font-feature-settings: 'tnum'` for tabular figures in financial data contexts.
3. **Testing**: Validate readability on low-density displays (e.g., older Android devices) and high-density Retina screens. Check contrast with tools like Stark or WebAIM against your color palette. Confirm tabular alignment in dashboards by testing with real financial data.
4. **Fallbacks**: Implement the fallback stack in CSS to ensure graceful degradation on unsupported devices or browsers, prioritizing system fonts for performance over aesthetic perfection.

### Tradeoff
By choosing Inter, you gain modernity, readability, and data clarity at the cost of a less distinctive brand personality compared to a custom or premium typeface. This sacrifice prioritizes user trust and functional clarity—key for fintech—over unique stylistic flair. If brand differentiation becomes a higher priority, a secondary typeface (e.g., a serif like Playfair Display for marketing headlines) could be introduced sparingly for contrast, at the expense of added complexity and load time.

This system should serve your fintech product’s needs across all platforms. If you’d like me to adjust for a specific aesthetic (e.g., more traditional or playful) or test against your color palette for contrast, let me know.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": ["reading_context: fintech across marketing, dashboard, mobile", "scale_decision: 16px base desktop, 14px mobile", "pairing_rationale: single typeface for consistency and load efficiency", "adoption_sequence: asset integration, CSS mapping, testing, fallbacks"],
  "evidence_classes_cited": ["threshold", "standard_reference"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]