## API Design Audit for POST /exports

I'm auditing the design of your `POST /exports` endpoint, which generates a PDF report. My focus is on reliability and security across failure semantics, authorization, idempotency, async lifecycle, resilience, and observability. Below, I’ll diagnose the issues and provide specific recommendations, naming tradeoffs and constraints.

### 1. Failure Semantics and Error Contract
**Diagnosis**: The current design returns HTTP 200 for all responses, including errors, and leaks internal enum values in error messages. This violates RESTful principles and obscures client-side error handling. Clients cannot distinguish success from failure programmatically, and exposing internal enums risks revealing implementation details that could aid attackers.

**Recommendation**: Adopt a structured error contract per RFC 9457 (Problem Details for HTTP APIs). Use appropriate HTTP status codes to signal outcomes—200 for success, 400 for client errors (e.g., invalid input), 429 for rate limiting, 500 for server errors, and 503 for temporary unavailability. Define a JSON error payload with a `type` (a URI identifying the error), `title` (a short summary), `status` (HTTP code), `detail` (human-readable explanation), and `instance` (request-specific identifier). Do not include internal enum values or stack traces in responses; log them server-side instead.

**Tradeoff**: You sacrifice simpler response parsing (single 200 status) to gain proper error semantics. This requires clients to handle multiple status codes but ensures clarity and safety.

**Constraint**: Without this, clients may misinterpret failures as successes, leading to data corruption or incorrect user feedback.

### 2. Authorization and Resource Protection
**Diagnosis**: The design does not specify authorization mechanisms or resource protection. Without explicit checks, unauthorized users could trigger expensive PDF generation or access sensitive data embedded in reports.

**Recommendation**: Implement an object-level authorization perimeter. Require a valid session or token (e.g., OAuth 2.0 bearer token) with role-based access control (RBAC). Only users with a specific role (e.g., `report_generator`) may invoke this endpoint. Additionally, validate that the requesting user owns or has permission to access the data being exported to prevent data leakage. Use a deny-by-default policy—requests without valid credentials or permissions return 401 (Unauthorized) or 403 (Forbidden).

**Tradeoff**: You sacrifice ease of access for tighter security. This adds latency from auth checks but protects against unauthorized resource use.

**Constraint**: Without this, you risk exposing sensitive data or allowing resource abuse (e.g., denial-of-service via unauthenticated requests).

### 3. Idempotency and Async Lifecycle
**Diagnosis**: The endpoint lacks an idempotency key, runs synchronously for up to 3 minutes, and has no retry-safe contract. Synchronous blocking for long durations risks client timeouts and server resource exhaustion. Without idempotency, retries or duplicate requests could generate multiple PDFs, wasting resources or confusing users.

**Recommendation**: Redesign this as an asynchronous job with a clear lifecycle. Return HTTP 202 Accepted immediately with a status URL (e.g., `/exports/{job_id}/status`) in the `Location` header. Define terminal states: `queued → running → completed | failed`. Clients poll the status URL for updates. Require an `idempotency-key` header to prevent duplicate jobs—return HTTP 409 Conflict if a key is reused for a different request. Store the key and response hash for a reasonable window (e.g., 24 hours). This ensures retry safety and prevents resource duplication.

**Tradeoff**: You sacrifice immediate response delivery for scalability and reliability. Clients must implement polling, but server load is reduced, and duplicates are prevented.

**Constraint**: Synchronous blocking for 3 minutes is unsustainable at scale; async processing is required to handle load spikes without degrading performance.

### 4. Resilience and Observability
**Diagnosis**: The design has no retry-safe contract, rate limiting, or observability mechanisms. Without resilience patterns, failures during PDF generation (e.g., timeouts, resource exhaustion) leave clients guessing. Lack of observability hides operational issues from maintainers.

**Recommendation**: Implement resilience strategies: add a circuit breaker to halt requests to failing downstream services (e.g., PDF renderer), use exponential backoff with jitter for retries on transient failures, and define a graceful degradation path (e.g., return a partial report or error if full rendering fails). Enforce rate limits and quotas per user or tenant (e.g., 10 requests per minute), returning HTTP 429 Too Many Requests when exceeded. For observability, include a `trace_id` in all responses and logs, correlating requests across services. Log job duration, failure reasons, and resource usage for monitoring.

**Tradeoff**: You sacrifice unrestricted access for controlled resource usage. Rate limiting may frustrate heavy users, but it protects the system from overload. Observability adds overhead but enables debugging and performance tuning.

**Constraint**: Without resilience, transient failures cascade into user-visible outages. Without observability, you cannot diagnose bottlenecks or abuse patterns.

### Summary of Key Fixes
- **Error Contract**: Use RFC 9457 problem details and proper HTTP status codes instead of universal 200 responses. Hide internal enums.
- **Authorization**: Enforce object-level checks and deny-by-default access to protect resources.
- **Async Lifecycle**: Move to async processing with HTTP 202 Accepted and a status URL. Define clear job states.
- **Idempotency**: Require an `idempotency-key` header for retry safety, returning 409 on duplicates.
- **Resilience**: Add circuit breakers, backoff retries, rate limits, and graceful degradation.
- **Observability**: Include `trace_id` in responses and logs, track job metrics.

### Next Steps
I can refine this into a formal API specification with exact JSON schemas for requests, responses, and error payloads. Alternatively, I can draft a client-side integration guide to handle async job polling and error states. Let me know which direction to take next.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "standard",
  "decisions_committed": ["problem_details_contract: RFC 9457 with typed errors", "authorization_perimeter: object-level with deny-by-default", "idempotency_contract: idempotency-key header with 409 on duplicate", "async_job_model: 202 Accepted + status URL", "resilience_strategy: circuit breaker + backoff + rate limits"],
  "evidence_classes_cited": ["RFC 9457", "HTTP status semantics", "async job lifecycle", "idempotency contract", "resilience patterns"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]