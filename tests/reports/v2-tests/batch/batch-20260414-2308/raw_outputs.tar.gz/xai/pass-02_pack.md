## Split Button Component Spec

I'm defining a split button component with a primary action ("Save") and a dropdown trigger for secondary actions ("Save as draft", "Save and close"). This spec ensures accessibility, state handling, and mobile compatibility.

### Component Boundary
- **Purpose**: A split button combines a primary action with a secondary action menu, allowing users to choose between immediate execution or alternative options.
- **Scope**: This component includes two distinct interaction areas: a primary button for the default action ("Save") and a separate dropdown trigger (typically an arrow icon) that reveals a menu with secondary actions.
- **Usage Context**: Used in forms, editors, or workflows where a primary save action is paired with save-related variants, ensuring clear hierarchy and discoverability.

### Visual and Structural Design
- **Layout**: The component is a horizontal container with two parts:
  - Primary button (left): Displays "Save" with a filled background (e.g., primary color like blue).
  - Dropdown trigger (right): Displays a downward arrow icon, visually distinct with a subtle border or background separation (e.g., lighter shade or outline).
- **Size**: Minimum touch target of 44x44 pixels per WCAG 2.1 for mobile compatibility. Default height of 36px for desktop, scaling to 48px on touch devices.
- **Spacing**: 8px internal padding for the primary button; 4px separation between primary and dropdown trigger to prevent accidental taps.
- **Typography**: Text size of 16px for readability, using a medium or semi-bold weight for the primary action to emphasize hierarchy.
- **Icon**: Dropdown trigger uses a 16px chevron-down icon, centered in its touch area.

### State Coverage
- **Normal State**: Primary button shows "Save" with a solid primary color background (e.g., #007BFF); dropdown trigger shows an arrow with a neutral background (e.g., #F1F1F1) or outline.
- **Hover State**: Primary button lightens by 10% (e.g., #008CFF); dropdown trigger background darkens slightly (e.g., #E1E1E1) or outline thickens.
- **Focus State**: Both areas display a 2px blue focus ring (e.g., #007BFF) with a 2px offset to meet WCAG contrast requirements (at least 3:1 against background).
- **Disabled State**: Both areas are grayed out (e.g., background #CCCCCC, text/icon opacity 50%), with pointer events disabled and no focus ring. Label remains "Save" for clarity.
- **Loading State**: Primary button replaces "Save" with a spinning loader icon (16px, centered) and dims background by 20% (e.g., #99C7FF); dropdown trigger remains inactive but visible. Optional text "Saving..." can appear if space allows.
- **Active State (Dropdown Open)**: Dropdown trigger rotates arrow upward (180 degrees) and may highlight (e.g., background #E1E1E1); menu appears below with secondary actions ("Save as draft", "Save and close") in a 200px wide container.

### Accessibility Behavior
- **Keyboard Support**: 
  - Tab navigation: Primary button and dropdown trigger are separate focusable elements (tabindex="0").
  - Enter/Space on primary button: Triggers "Save" action.
  - Enter/Space on dropdown trigger: Opens/closes the menu.
  - Arrow keys: Navigate menu items when open (Up/Down), with Enter to select an item.
  - Escape: Closes menu if open, returning focus to dropdown trigger.
- **ARIA Attributes**:
  - Primary button: `role="button"`, `aria-label="Save"`.
  - Dropdown trigger: `role="button"`, `aria-haspopup="menu"`, `aria-expanded="true|false"`, `aria-label="More save options"`.
  - Menu: `role="menu"`, with each item as `role="menuitem"`.
- **Focus Management**: Focus remains on dropdown trigger when menu closes unless an action is selected, then focus shifts to the primary button or a relevant form element.
- **Touch Targets**: Both primary and dropdown areas meet 44x44px minimum per WCAG 2.1, with no overlap to prevent mis-taps on mobile.
- **Motion Safety**: No animations by default for dropdown reveal; if used, respect `prefers-reduced-motion` with a static fade or no transition.

### Interaction Behavior
- **Click/Tap**: 
  - Primary button: Executes "Save" immediately.
  - Dropdown trigger: Toggles menu visibility, showing "Save as draft" and "Save and close" as selectable options.
- **Menu Positioning**: Appears below the button, aligned to the right edge of the dropdown trigger, with a 4px offset to avoid overlap. Adjusts upward if viewport bottom is clipped (mobile consideration).
- **Menu Dismissal**: Closes on outside click, Escape key, or selection of a menu item.
- **Mobile Considerations**: Larger touch targets (48px height) and menu width (full viewport width minus 16px padding if needed) for small screens.

### Implementation Boundary
- **HTML Structure**:
  ```html
  <div class="split-button">
    <button type="button" class="split-button-primary" aria-label="Save">Save</button>
    <button type="button" class="split-button-trigger" aria-haspopup="menu" aria-expanded="false" aria-label="More save options">
      <svg aria-hidden="true"><!-- chevron-down icon --></svg>
    </button>
    <div class="split-button-menu" role="menu" hidden>
      <button type="button" role="menuitem">Save as draft</button>
      <button type="button" role="menuitem">Save and close</button>
    </div>
  </div>
  ```
- **CSS Considerations**: Use flexbox for layout (`display: flex`), with `min-width` and `min-height` for touch targets. Style focus rings with `:focus-visible` for modern browsers, falling back to `:focus` with a no-outline suppression for non-keyboard users.
- **JS Requirements**: Handle menu toggle, keyboard navigation, focus trapping within menu, and outside-click dismissal. Ensure loading state disables interactions without breaking visual feedback.
- **Framework Notes**: If using React, manage state with `useState` for menu visibility and loading; in Vue, use `v-model` for state binding. Ensure event listeners clean up on unmount.
- **Performance**: Avoid heavy re-renders during loading state; use CSS animations for loader if possible instead of DOM updates.

### Tradeoffs and Rationale
- **Preserved**: Accessibility and mobile usability with distinct touch targets and keyboard navigation, ensuring WCAG compliance over visual compactness.
- **Sacrificed**: A fully unified button appearance (single visual unit) is sacrificed for clarity of separate actions, reducing accidental activations especially on touch devices.
- **Reasoning**: The split design prioritizes user intent clarity (primary vs. secondary action) and accessibility (focusable areas) because mis-clicks or inaccessible controls risk data loss or frustration in save workflows.

This spec provides a robust foundation for a split button that works across devices and user needs. If you need a visual mockup, CSS snippet, or specific framework implementation, let me know.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: split button with primary and secondary actions", "state_coverage: normal, hover, focus, disabled, loading, active", "accessibility_behavior: keyboard support, ARIA roles, touch targets", "implementation_boundary: HTML structure, CSS and JS requirements"],
  "evidence_classes_cited": ["touch_target_threshold", "wcag_compliance"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]