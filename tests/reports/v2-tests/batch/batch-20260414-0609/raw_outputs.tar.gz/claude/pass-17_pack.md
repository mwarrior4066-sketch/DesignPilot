Three explanations of the same decision, calibrated for different explanation depths.

---

## Functional tier

When your app needs to remember something, that information has to live *somewhere*. The question is where.

**Local state** means each component keeps its own memory. A dropdown remembers whether it's open. A form remembers what you typed. When the component disappears, the memory disappears with it. This works well and is easy to reason about.

**Context** is a way to share a piece of information with many components at once, without passing it down manually through every layer. Think of it like a shared noticeboard. Any component that needs the value can read it. Useful for things like "is the user logged in?" or "what's the current theme?"

**Redux** (and similar tools) adds a more formal structure on top of this. All shared state lives in one place. Every change goes through a defined process. You can replay changes, inspect history, and trace exactly what happened when. The tradeoff: more setup, more files, more concepts to learn.

For most React apps that are small to medium in size, local state and context will cover the majority of what you need. Redux becomes worth the overhead when multiple unrelated parts of your app need to react to the same changes, or when you're debugging complex interactions and need that history and traceability.

**Governing decision:** Use local state and context unless you can point to a specific problem they cannot solve; do not add Redux in advance of that problem appearing.

---

## Integrative tier

The choice hinges on two things: how far state needs to travel, and how often it changes.

**Local state** is the default. It's collocated with the component that owns the behavior, which makes the data flow visible and the component independently testable. React's own model strongly favors this.

**Context** solves the prop-drilling problem for slow-moving, broadly-shared values: auth status, theme, locale, feature flags. It is not well-suited to high-frequency updates. Every consumer of a context re-renders when that context value changes, so putting rapidly-updating data in context creates a performance problem that is non-trivial to fix without memoization work.

**Redux** (or Zustand, Jotai, etc.) earns its cost when you have state that is genuinely cross-cutting, changes frequently, and needs either predictable update semantics or dev-tooling visibility. The real value of Redux isn't the store; it's the constraint that state transitions are explicit, named, and inspectable. That constraint pays off in large teams and complex update chains. It adds boilerplate and architectural ceremony that is dead weight in simpler apps.

The common failure mode is adding Redux because the app *might* grow, or because a previous project used it. State complexity is easier to migrate toward than away from. Starting with local state and extracting to a shared store only when a real coordination problem emerges is the lower-risk path.

**Governing decision:** Use local state for component-owned behavior and context for slow-changing cross-cutting values; introduce a dedicated state manager only when you have a concrete coordination or traceability problem that context cannot handle safely.

---

## Strategic tier

The decision is about state ownership boundaries, not tooling preference.

Redux's actual contribution is not the store. It's the enforcement of an explicit update contract: state transitions are named, centralized, and reproducible. That constraint is valuable when multiple disconnected subsystems must react to the same event, when update chains need to be auditable, or when a large team needs shared conventions to avoid implicit coupling.

Context is not a state manager. It's a dependency injection mechanism. Treating it as one creates a re-render surface that grows with subscriber count and update frequency. That's acceptable for slow-moving values (auth, theme, locale) but becomes a correctness and performance liability for anything that changes at interaction speed.

Local state remains the correct default because it makes ownership explicit and keeps components independently composable and testable. The cost of migrating upward from local state is low. The cost of migrating downward from over-centralized Redux is high.

The inversion-of-control failure mode: teams add Redux to handle one prop-drilling problem, then route everything through the store because the infrastructure already exists. This produces a system where the store owns behavior it has no reason to own, making component boundaries meaningless and testing harder.

For a React app without a demonstrated cross-subsystem coordination problem, Redux is premature architecture. The correct intervention is clear state ownership by default, with a state manager introduced at the boundary where context update semantics break down or where named, inspectable transitions become a real operational need.

**Governing decision:** Default to local state with context for genuinely shared slow-changing values; add a state manager only at the demonstrated boundary where context's re-render semantics or lack of explicit update contracts creates a real coordination or reliability failure.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: client-side React component state",
    "state_ownership: local state default, context for slow-changing cross-cutting values, dedicated state manager only when coordination or traceability failure is demonstrated",
    "boundary_placement: state ownership boundary determined by update frequency and cross-subsystem reach, not tooling preference",
    "semantic_contract: explicit named state transitions as the primary value of Redux, not the store itself",
    "cost_or_degraded_path: migration cost is asymmetric -- local to centralized is low cost, centralized to local is high cost"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "implementation_constraint",
    "rendering_boundary_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]