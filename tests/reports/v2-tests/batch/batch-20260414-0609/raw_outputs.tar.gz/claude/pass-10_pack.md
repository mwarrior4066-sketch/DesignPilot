## Poster Critique

**Communication goal:** A conference poster must answer three questions fast — what is this, when is it, and why should I care. At scan distance, these questions need to resolve in roughly that order or the poster loses the audience before they engage.

---

### Composition failures

**The logo is doing work the eye hasn't earned yet.** Placing the white logo center-frame makes it the visual anchor of the composition, but a logo only pays off when the viewer already knows what it represents. For a new or first-time viewer at distance, a centered white mark on a photo reads as decoration, not identity. It wins the visual hierarchy at the wrong moment.

**The title is first, but context is last.** The decorative typeface at the top will pull the eye, but a title without a category line beneath it asks the audience to do interpretive work. "What kind of event is this?" remains unanswered until the viewer scans past the logo and hunts for the date — which is small, gray, and in the corner. That's a three-step parse for something that should resolve in one.

**The date is buried.** Small gray text in a bottom corner competes with the photo background and sits below natural scan gravity. Dates carry urgency; urgency should not hide.

**The background photo is ambient, not argumentative.** A city skyline is atmospheric, but it isn't doing specific communicative work. It fills space without earning it. More concretely, it creates a contrast problem: white logo over a photo of variable brightness is a fragile pairing that breaks on print and at thumbnail scale.

---

### Rebuild moves

1. **Establish a category line directly under the title** — a short descriptor like "Annual Design Conference" or the event's edition/year. This costs almost no space and closes the context gap immediately.

2. **Demote the logo or reposition it as an anchor signature.** Move it to a corner, ideally bottom-left or bottom-right, paired with the date. The logo becomes a closing credential rather than an interruption. The date gains a visual companion and escapes the corner trap.

3. **Give the date genuine visual weight.** Same color family as the title, larger body, not gray-on-photo. Even a modest size increase with a clean light or dark panel behind it changes the urgency signal completely.

4. **Interrogate the photo's role.** If the skyline represents the host city, make that argument explicit — crop it more deliberately, or pair it with a location line. If it is purely atmospheric, a flat color field or geometric treatment will give the title and hierarchy more room to work and survive print and small-format reproduction better.

---

### Distance and emphasis tradeoff

The decorative title can remain dominant — that's the right instinct. But the hierarchy underneath it needs to be reordered: **category context first, event name (already prominent), date with real weight, logo as a closing credential.** What recedes is the photo's visual dominance and the logo's center-frame presence. Both can survive as supporting elements; neither should be the composition's structural load-bearer.

At thumbnail scale, the current layout reads as: decorative text, blurry skyline, white shape, invisible date. The rebuilt version should read as: event name, what it is, when, who.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "focal_winner: decorative title at top",
    "distance_legibility: thumbnail and print fragility flagged",
    "composition_rule: logo repositioned as closing credential, date elevated",
    "emphasis_tradeoff: photo and logo demoted, category context and date elevated"
  ],
  "evidence_classes_cited": [
    "visual_structure_rule",
    "comparison_artifact",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the skyline represent a specific host city, or is it purely atmospheric?"
  ],
  "turn": 1
}
[/SESSION_STATE]