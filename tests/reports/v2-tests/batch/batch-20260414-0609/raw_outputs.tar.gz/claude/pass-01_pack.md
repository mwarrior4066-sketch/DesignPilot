## Pricing Page Audit

**Route:** `rt_ui_structure_critique` governing, `rt_dashboard_audit` supporting for pricing table hierarchy, `accessibility_feedback_audit` supporting for color and interaction failures.

---

### Problem Framing

A B2B SaaS pricing page has one job: move a qualified visitor from consideration to a conversion action. The current layout distributes attention across several competing elements without establishing a clear scan sequence. The hero headline competes with the pricing table rather than handing off to it. The CTA is undersized relative to its importance. The Pro tier color-coding carries semantic weight it cannot reliably deliver.

---

### Findings

**1. Hero-to-pricing handoff is broken**

The headline "Everything your team needs" reads as a brand statement, not a conversion primer. It does not orient the visitor toward a tier decision. The CTA is the primary action in the hero and it is undersized relative to the background image mass. A small button against a busy image background loses contrast and physical weight simultaneously. Visitors who land ready to compare plans have no hierarchy signal telling them to scroll.

**2. Pricing table: Pro tier emphasis is color-only**

Color-coding alone to signal the recommended tier fails two ways. First, it violates WCAG 1.4.1 (use of color): status or emphasis must not rely on color as the only distinguishing visual channel. Second, if the colors used do not meet 3:1 non-text contrast against their neighboring cells, the visual distinction collapses entirely for users with low vision or in poor lighting conditions. The table currently has no secondary indicator, such as a badge, border, scale, elevation shadow, or typographic distinction, to carry the Pro signal without color.

**3. Feature comparison table: scan cost is too high**

A full feature comparison table immediately below the pricing table doubles the cognitive load at the moment of decision. B2B buyers use feature tables to resolve uncertainty once a tier has already attracted interest. Placing it at full prominence treats all visitors as in the research phase, which buries the decision trigger for visitors already leaning toward a tier.

**4. Testimonials strip: wrong placement for B2B pricing**

Social proof works best when it addresses the specific hesitation a buyer feels. A generic testimonials strip after a full feature comparison table arrives too late to reduce friction and is too shallow to close doubt. At this position it competes with the CTA rather than feeding it.

**5. No empty or error state handling is visible**

The Enterprise tier with a "custom pricing" label needs a clear next action, either a contact CTA or a form trigger. "Custom" without an action path is a dead end in the conversion flow.

---

### Accessibility Failures

| Failure | Standard | Severity |
|---|---|---|
| Color-only Pro tier differentiation | WCAG 1.4.1 | Hard block |
| CTA button contrast against background image | WCAG 1.4.3 (4.5:1 text) | Likely hard block |
| Non-text UI elements in pricing table | WCAG 1.4.11 (3:1 non-text) | Likely hard block |
| Feature table keyboard navigability | WCAG 2.1.1 | Needs verification |

The background image behind the CTA is the highest compound risk: unless there is a solid overlay with sufficient opacity, text contrast is unverifiable from a description alone. This must be checked at the pixel level, not assumed.

---

### Recommendations

**Fix first: CTA size and contrast**

Increase the button size to a minimum 44x44 px touch target and a visual size proportional to the hero. Add a solid color backing or a semi-transparent scrim behind it so contrast is verifiable. This is structural, not cosmetic, and it unblocks the conversion entry point.

**Fix second: Pro tier non-color indicator**

Add a badge ("Most popular" or "Recommended"), a heavier border (2px at minimum for the tier column), or a modest card elevation to the Pro column. Keep color as a supporting layer, not the only layer. Verify the color pair itself against WCAG 1.4.11 (3:1 non-text contrast). If the current palette fails, it must change regardless of the badge.

**Fix third: Reorder the hero message**

Change the headline posture from a generic brand statement to a tier-decision framing. Options depend on your segment, but the structure should answer "which plan fits you" rather than "we have everything." This makes the scroll into the pricing table purposeful.

**Fix fourth: Progressive feature comparison**

Move the full feature comparison table behind a disclosure pattern. A collapsed or accordion-style comparison, or a "Compare all features" toggle, keeps the tier decision surface clean and lets research-mode visitors opt into depth without overwhelming decision-mode visitors.

**Fix fifth: Enterprise dead end**

Replace the "custom" label pattern with an explicit action: a "Talk to sales" button or a form trigger inline in the tier card. Custom pricing without a next step loses the most valuable buyer segment.

**Fix sixth: Testimonial placement and targeting**

Either move testimonials above the pricing table as a hesitation-reducer, or replace the generic strip with tier-specific social proof adjacent to each column. A quote from an Enterprise customer adjacent to the Enterprise card does more conversion work than a strip of undifferentiated testimonials below the feature table.

---

### Tradeoffs

Keeping full feature comparison visible at all times preserves SEO value and serves research-mode visitors. Progressive disclosure trades that surface exposure for a cleaner conversion path for decision-ready visitors. For B2B SaaS where average deal values justify a sales-assisted flow, the conversion path should win. The feature content does not disappear; it moves behind one interaction.

Removing color as the only Pro signal requires either a palette adjustment or adding a structural indicator. Both have minor implementation cost. Neither is optional if WCAG 1.4.1 compliance is required.

---

### Intervention Order

1. CTA contrast and size (unblocks the primary conversion action)
2. Pro tier non-color indicator (unblocks accessibility and removes legal risk)
3. Verify all color pairs against WCAG 1.4.3 and 1.4.11 with a contrast tool
4. Hero headline reframe (improves qualified visitor handoff)
5. Progressive feature comparison (reduces scan cost at decision point)
6. Enterprise CTA repair (closes the conversion dead end)
7. Testimonial repositioning (increases social proof efficiency)

---

**Verification steps:** Run the color pairs through a contrast checker such as Colour Contrast Analyser or Stark. Test the pricing table with keyboard-only navigation. Test the CTA button with a screen reader on a background-image hero. Confirm the Pro badge or border reads without color using a grayscale simulation.

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "compound",
  "decisions_committed": [
    "structural_failure: hero-to-pricing handoff broken, CTA undersized, Pro tier color-only",
    "hierarchy_winner: CTA and tier decision frame should win first scan",
    "intervention_order: CTA contrast > Pro non-color indicator > contrast verification > headline reframe > progressive comparison > Enterprise CTA > testimonial repositioning",
    "tradeoff_resolution: conversion path wins over full-feature surface exposure; non-color indicator required over color-only differentiation"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "implementation_constraint",
    "comparison_artifact",
    "standards_reference",
    "visual_structure_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are the specific color values for the Pro tier known? Contrast verification cannot be completed without them.",
    "Does the background image have a solid overlay or scrim? CTA contrast is unverifiable without this.",
    "Is keyboard navigation currently implemented for the feature comparison table?"
  ],
  "turn": 1
}
[/SESSION_STATE]