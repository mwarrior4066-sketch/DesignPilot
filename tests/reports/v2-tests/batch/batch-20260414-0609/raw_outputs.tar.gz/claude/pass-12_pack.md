## Type System Recommendation: Fintech Cross-Platform

### Reading context

Three distinct reading environments, all connected:

- **Marketing site** - persuasive, moderate text density, desktop and mobile, display sizes matter
- **Web app dashboard** - high density, tabular data, small labels, numerical alignment, scan-first
- **Mobile app** - limited width, touch targets, shorter reading bursts, body at larger minimum

The dashboard is the hardest constraint. A typeface that handles 11px numeric labels in tight table cells without falling apart will hold up everywhere else. That constraint governs the primary selection.

---

### Scale and role map

**Primary recommendation: Inter (variable, Latin) + optional editorial pairing**

Inter is the governing choice. Reasons specific to this context:

- Designed for screen legibility at small sizes, including tabular figures by default
- Includes a full variable axis (weight and optical size on newer versions), useful across three environments
- Tabular figures (`tnum`) are a first-class OpenType feature, not a workaround
- Wide weight range (100-900) supports a full hierarchy without a secondary face
- Broadly licensed (SIL OFL), no per-seat cost, available on Google Fonts and bundles well

**Optional marketing-layer pairing:** A geometric serif or refined grotesque for display headings on the marketing site only. Candidates: Instrument Serif (editorial warmth, OFL), Fraunces (variable, strong personality, OFL), or a licensed option like Söhne if budget allows. Keep this strictly above 28px and out of the app entirely.

| Role | Typeface | Weight | Size range | Notes |
|---|---|---|---|---|
| Marketing display | Instrument Serif or Inter | 700-800 | 40-72px | Serif pairing optional; Inter alone works |
| Marketing body | Inter | 400 | 16-18px | 65-75 char line length target |
| App heading (H1-H2) | Inter | 600-700 | 20-28px | Moderate weight; avoid heavy in dense screens |
| Section label / subhead | Inter | 500-600 | 13-14px | Uppercase with modest tracking (+0.04em max) |
| Body / prose (app) | Inter | 400 | 15-16px | Dashboard prose is rare; favor 15px |
| Table data / numbers | Inter | 400-500 | 12-14px | `font-feature-settings: "tnum"` required |
| Table header | Inter | 600 | 12-13px | Tight columns: 12px + 500 weight |
| Micro-label / metadata | Inter | 400 | 11-12px | Floor at 11px; below this, remove or abbreviate |
| Mobile body | Inter | 400 | 16px min | Respect platform minimum; iOS default is 17px |
| Mobile label | Inter | 500 | 13px min | Do not go below 13px on mobile |

---

### Readability rules

**Line length.** Marketing body: 65-75 characters. App prose: 55-70 characters. Tables span columns, so line-length rules don't apply there, but label truncation should be handled with `text-overflow: ellipsis` and a visible tooltip, not silent clipping.

**Leading.** Marketing body: 1.6 line-height. App body: 1.5. Table rows: 1.3-1.4 (tighter packs more data without becoming unreadable at 13px+). Display headings on the marketing site: 1.1-1.2.

**Tabular figures.** This is non-negotiable for fintech. Apply `font-feature-settings: "tnum" 1` to every column containing numbers, amounts, percentages, dates, or IDs. Proportional figures in a financial table cause visible column drift.

**Contrast.** Primary text on the dashboard must meet WCAG 4.5:1 at all sizes including 12px labels. At 11px, 4.5:1 is a hard requirement (it is below the 18.66px threshold where 3:1 becomes allowable for large text). Do not use mid-gray label text without checking: `#767676` on white barely passes; anything lighter fails.

**Optical sizing.** If you use Inter variable with `font-optical-sizing: auto`, the font will adjust stroke contrast at small sizes. This is worth keeping on for table labels. Turn it off for display headings where manual weight control is preferred.

**Weight as the primary hierarchy signal.** In high-density environments, weight differences read faster than size differences. A 500/600/700 weight ladder in a compact size range communicates hierarchy without inflating row height.

---

### Adoption guidance

**Phase 1 - Dashboard first.** Lock the table and label styles. Define the `tnum` rule as a CSS utility class or a design token. Get sign-off on 12px minimum before anything else ships in the app. This is the hardest environment to fix later.

**Phase 2 - App heading and body.** Set the variable font range, define the scale as tokens (`--text-sm`, `--text-base`, `--text-lg`, etc.), and wire them to component states. Heading weight at 600, not 700, keeps density manageable.

**Phase 3 - Mobile.** Audit every label against 13px minimum. Increase touch target padding before reducing font size. Mobile users lose the most when table labels get squeezed.

**Phase 4 - Marketing site.** Either extend the Inter-only system with a display weight variation, or add the editorial pairing strictly above 28px. Do not let the marketing typeface bleed into the app; maintain a hard boundary at the component-library level.

**Tokens to define early:**
- `--font-mono`: a monospace fallback for code or account numbers (JetBrains Mono or system-ui monospace)
- `--tnum-feature`: `"tnum" 1` as a composable utility
- `--font-family-base`: Inter with a safe system fallback stack (`Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`)

---

### Tradeoffs named

Inter is utilitarian. On the marketing site it can read as workmanlike if set without care. The optional display pairing solves this at the headline level without touching the app. If the brand wants more personality across the whole product, Neue Haas Grotesk or GT Walsheim are licensed alternatives with more warmth, but both require a paid license and neither improves on Inter's tabular figure quality at small sizes. The tradeoff is expressiveness on the marketing side versus cost and system complexity. Inter alone is the defensible baseline; a display pairing is an enhancement, not a requirement.

[SESSION_STATE]
{
  "route": "type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing site / web app dashboard / mobile with dashboard as governing constraint",
    "role_hierarchy: display, heading, section-label, body, table-data, table-header, micro-label, mobile-body, mobile-label",
    "readability_boundary: tnum required for all numeric columns, 11px floor, 4.5:1 contrast floor, 65-75 char line length for marketing body",
    "adoption_sequence: dashboard first, app heading/body second, mobile third, marketing site last"
  ],
  "evidence_classes_cited": [
    "visual_structure_rule",
    "measurable_threshold",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is a licensed display typeface on the marketing site in scope, or is OFL-only a hard constraint?",
    "Is variable font support confirmed across the target browser/device baseline?"
  ],
  "turn": 1
}
[/SESSION_STATE]