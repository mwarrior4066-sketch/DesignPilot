## API Reliability and Security Review: POST /api/v1/projects/{id}/members

---

### Failure Semantics

**Governing decision:** Replace the plain string error response with RFC 9457 Problem Details (`application/problem+json`).

The plain string gives the client nothing to reason about programmatically. It cannot distinguish a permission failure from a validation failure from a server fault. RFC 9457 fixes this with a typed envelope:

```json
{
  "type": "https://api.example.com/problems/forbidden",
  "title": "Insufficient permissions",
  "status": 403,
  "detail": "Caller must be a project admin to add members.",
  "instance": "/api/v1/projects/abc123/members"
}
```

Every failure path needs this contract: 403 for authorization failures, 409 for duplicate membership conflicts, 422 for invalid input, 500 for server faults. The `type` URI is the machine-readable discriminator. The client switches on that, not on parsed string text.

---

### Authorization and Resource Protection

**Governing decision:** The authorization check must enforce object-level permission (project admin), not just authentication (logged in). The current design has a BFLA vulnerability.

Checking "is the caller logged in" is authentication, not authorization. Any authenticated user can currently add members to any project they did not create and are not an admin of. This is a broken function-level access control failure (BFLA in OWASP API Top 10).

The fix requires two checks in sequence, both enforced server-side before the mutation runs:

1. Is the caller authenticated? (Already present.)
2. Does the caller hold the admin role on this specific project? (Missing.)

The second check must be object-level: the caller's role on project `{id}`, not a global admin flag. A user who is an admin on project A must not be able to add members to project B.

Deny by default. If the role check cannot be confirmed, return 403 before touching any data.

---

### Idempotency and Mutation Safety

**Governing decision:** This endpoint needs an idempotency key. Returning 200 on re-submission of an already-existing membership is not safe without one.

Without an idempotency key, a network retry or double-submit creates two problems depending on your data model: either a duplicate membership record is created, or the endpoint silently succeeds and the client cannot tell whether it is seeing a fresh add or a repeated one.

The correct contract:

- Client generates a stable `Idempotency-Key` header per intent (not per retry).
- Server stores the key with a TTL (24 hours is a common default).
- On first receipt: process and store the response.
- On re-receipt within TTL: return the stored response without re-executing the mutation.
- If the key was received but the original request is still in-flight: return 409 Conflict.

The status code for a successful add should be **201 Created** with the new membership resource, not 200 with the full member list. 200 implies the resource already existed. 201 gives the client a precise signal and allows a `Location` header pointing to the new membership record.

---

### Response Shape

**Governing decision:** Return the created membership resource at 201, not the full member list at 200.

Returning the full member list on every add has two costs:

1. **Payload size.** On a large project, this is unbounded. The list grows with the project.
2. **Semantic incorrectness.** The operation created one resource. The response should confirm that resource, not dump a collection.

Correct shape:

```
HTTP/1.1 201 Created
Location: /api/v1/projects/{id}/members/{member_id}
Idempotency-Key: <echoed>

{
  "member_id": "...",
  "user_id": "...",
  "project_id": "...",
  "role": "member",
  "added_at": "..."
}
```

If the caller needs the updated list, that is a separate GET. Do not bundle collection reads into mutation responses.

---

### Resilience and Observability

**Governing decision:** Every request needs a `trace_id` in the response and in the error envelope. The endpoint needs quota enforcement before it is production-viable.

Without a trace identifier, a 500 is a dead end. The client has no handle to pass to support. The server has no way to correlate the failure across logs, the auth layer, and the database write.

Add `trace_id` to every response, including error envelopes:

```json
{
  "type": "https://api.example.com/problems/internal-error",
  "status": 500,
  "trace_id": "01HXYZ..."
}
```

Quota enforcement: adding members is a write mutation. Without a rate limit, a single caller can flood the endpoint. Set a per-caller rate limit with a `Retry-After` header on 429 responses. The limit does not need to be aggressive, but it must exist before the endpoint is public.

---

### Ranked Fix Order

These are not equivalent in severity:

1. **BFLA authorization check** (critical, blocks safe release)
2. **RFC 9457 error envelope** (high, blocks reliable client integration)
3. **Idempotency key + 201 status** (high, blocks retry safety)
4. **Response shape: membership resource, not full list** (medium, correctness and performance)
5. **trace_id in all responses** (medium, operational necessity)
6. **Rate limiting** (medium, must exist before public exposure)

Items 1 through 3 are not safe to ship without. Items 4 through 6 are required before the endpoint is production-viable but are lower blast-radius if temporarily absent in a controlled environment.

[SESSION_STATE]
{
  "route": "api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "problem_details_contract: RFC 9457 application/problem+json required on all failure paths",
    "authorization_perimeter: object-level project-admin check required, BFLA present in current design",
    "idempotency_contract: Idempotency-Key header required, 24h TTL, 409 on in-flight collision",
    "async_job_model: synchronous mutation with 201 Created + Location header",
    "resilience_strategy: trace_id in all responses, per-caller rate limit with Retry-After on 429"
  ],
  "evidence_classes_cited": [
    "failure_semantics_rule",
    "permission_rule",
    "async_lifecycle_rule",
    "resilience_rule",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]