## Dashboard Audit

**Dashboard role:** Operational/monitoring overview — the design implies a "check in on performance daily" job, but the execution forces high-effort interpretation before any signal can be read confidently.

---

### Key failures

**1. KPIs without reference values are display artifacts, not signals**

DAU, MRR, and churn as large standalone numbers tell the reader nothing actionable. A number needs a target, a baseline, or a prior-period comparison before it becomes a performance signal. A trend arrow compounds the problem: up is not always good (churn trending up is a crisis; DAU trending up may mask segment collapse). Without a reference value, the arrow is decorative.

Observed: three KPI cards, numeric values visible, directional arrows present.
Inferred: no targets, no baselines, no comparison period displayed — confidence high based on described layout.

**2. Four-series line chart with an orphaned legend is unreadable**

A chart with four segments cannot be interpreted if the legend is below the fold on first load. The reader sees four colored lines and cannot assign meaning to any of them. The 30-day window is reasonable for trend detection, but the missing Y-axis label removes the scale — the reader cannot determine whether they are looking at user counts, revenue, percentages, or something else entirely. Color is carrying the full identification burden for segment differentiation, which also fails for colorblind users.

Observed: single chart area, four lines, no Y-axis label, legend placement below fold.
Inferred: segment identity not recoverable on first view — confidence high.

**3. Twelve ungrouped nav items is a task-switching tax**

At 12 flat items, the sidebar provides no orientation to the space. A user cannot determine section ownership, importance ordering, or the relationship between items without reading all of them. Cognitive cost accumulates before any task begins.

---

### Evidence and rationale

The KPI design violates the minimum viable metric contract: a metric is only a signal when it is anchored to something. Target-relative or prior-period-relative display is the floor, not a premium feature. Studies on operational dashboards consistently show that users make faster and more accurate assessments from sparklines with a visible reference band than from standalone large numerals.

The chart's legend-below-fold failure is an information dependency error: the visual element (lines) is presented before the key that makes it parseable. This is structurally equivalent to labeling a graph after the test. Color-only segment encoding also fails WCAG 1.4.1, which requires that color is not the sole means of conveying information — patterns, labels, or direct annotation are required.

A flat 12-item nav without grouping exceeds the practical working-memory load for fast section selection. Navigation taxonomies above 7 to 9 items typically require chunking into meaningful groups to remain scannable.

---

### Recommended rebuild path

**First: Fix the KPIs**

Add a reference value beneath or beside each number. For MRR and DAU, show the prior-period value or a target. For churn, show the acceptable threshold. Replace bare trend arrows with directional language tied to the reference — "+3% vs last 30 days" or "12% above target" — so the arrow and the number read together.

Consider replacing one or more standalone KPI numerals with a sparkline-plus-number pairing. This gives the user both the current value and the shape of change in the same glance cost.

**Second: Fix the chart**

Move the legend above or beside the chart — never below fold. Add a Y-axis label or an inline unit. For four segments, consider direct labeling at the right end of each line, which eliminates the lookup entirely and works for color-deficient users. If four simultaneous trends are genuinely needed, evaluate whether a small-multiples layout (four smaller charts, one per segment) reduces false comparison and improves selective reading.

**Third: Group the nav**

Reduce cognitive load by grouping the 12 items into 3 to 5 named clusters based on functional relationship — for example: Overview, Analytics, Configuration, and Admin. Add a visual separator or section header. This converts a flat list into a navigable taxonomy.

---

### Rebuild order

1. KPI reference values — highest interpretation risk, lowest implementation cost
2. Chart legend placement and Y-axis label — immediate readability fix
3. Color-only encoding fallback — accessibility requirement, not enhancement
4. Nav grouping — structure improvement with moderate information architecture work
5. Sparkline or small-multiples evaluation — higher-effort redesign, validate after the floor is stable

---

**Tradeoffs to hold:** Adding reference values and baselines requires that the system surface target data or historical comparisons — this is a data dependency, not only a UI decision. If targets do not exist in the data model, a prior-period delta is the safer first step. Moving to direct-label lines removes the legend entirely, which saves space but commits to a specific line-end layout that may break at narrow viewports.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_type: operational/monitoring",
    "kpi_priority: KPIs are first-scan elements but currently lack reference values making them non-actionable",
    "density_strategy: legend moved above fold, nav grouped into 3-5 clusters, sparklines evaluated as KPI enhancement",
    "drilldown_or_filter_logic: four-segment line chart should evaluate direct labeling or small-multiples over color-only encoding",
    "visual_confidence_boundary: KPI absence of targets inferred high-confidence from description; legend below-fold confirmed from description"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "measurable_threshold",
    "comparison_artifact",
    "visual_structure_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Do targets or historical baselines exist in the data model, or is prior-period delta the only feasible KPI reference?",
    "Are the four chart segments equally important to daily users, or should one be the primary view with others filterable?",
    "Is the nav taxonomy user-defined or system-defined — does grouping require IA research or is a functional grouping available now?"
  ],
  "turn": 1
}
[/SESSION_STATE]