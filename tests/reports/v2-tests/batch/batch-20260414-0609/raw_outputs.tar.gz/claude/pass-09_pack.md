## Color System: Healthcare SaaS Dashboard

---

### Role Model

The system is built on semantic roles, not a raw palette. Every color is assigned a job before it gets a value.

| Role family | Roles |
|---|---|
| **Surface** | `surface-base`, `surface-raised`, `surface-overlay`, `surface-sidebar` |
| **Text** | `text-primary`, `text-secondary`, `text-disabled`, `text-inverse` |
| **Action** | `action-primary`, `action-primary-hover`, `action-primary-disabled` |
| **Status** | `status-normal`, `status-warning`, `status-critical`, `status-info` |
| **Status surface** | `status-normal-bg`, `status-warning-bg`, `status-critical-bg`, `status-info-bg` |
| **Data visualization** | `chart-1` through `chart-6` |
| **Border / divider** | `border-default`, `border-strong`, `border-status-*` |

Status is a role family, not a single color. Each status has a foreground, background, and border token so it works in badges, banners, and row highlights without relying on color alone.

---

### Token Map

#### Light mode base values

| Token | Hex | Usage |
|---|---|---|
| `surface-base` | `#F5F7FA` | Page background |
| `surface-raised` | `#FFFFFF` | Cards, panels |
| `surface-overlay` | `#ECEEF2` | Hover surfaces, collapsed rows |
| `surface-sidebar` | `#1C2B3A` | Dark sidebar (inverted zone) |
| `text-primary` | `#111827` | Body, headings |
| `text-secondary` | `#4B5563` | Labels, metadata |
| `text-disabled` | `#9CA3AF` | Disabled controls |
| `text-inverse` | `#FFFFFF` | Text on dark sidebar |
| `action-primary` | `#0062CC` | Buttons, links |
| `action-primary-hover` | `#0050A8` | Hover state |
| `status-normal` | `#166534` | Normal label text |
| `status-normal-bg` | `#DCFCE7` | Normal badge/row tint |
| `status-warning` | `#92400E` | Warning label text |
| `status-warning-bg` | `#FEF3C7` | Warning badge/row tint |
| `status-critical` | `#991B1B` | Critical label text |
| `status-critical-bg` | `#FEE2E2` | Critical badge/row tint |
| `status-info` | `#1E3A5F` | Info label text |
| `status-info-bg` | `#DBEAFE` | Info badge/row tint |
| `border-default` | `#D1D5DB` | Table rows, card edges |
| `border-strong` | `#9CA3AF` | Inputs, dividers |

#### Dark mode overrides

| Token | Light value | Dark value |
|---|---|---|
| `surface-base` | `#F5F7FA` | `#0F1724` |
| `surface-raised` | `#FFFFFF` | `#1A2535` |
| `surface-overlay` | `#ECEEF2` | `#243044` |
| `surface-sidebar` | `#1C2B3A` | `#111827` |
| `text-primary` | `#111827` | `#F9FAFB` |
| `text-secondary` | `#4B5563` | `#9CA3AF` |
| `text-disabled` | `#9CA3AF` | `#4B5563` |
| `action-primary` | `#0062CC` | `#3B93F7` |
| `status-normal` | `#166534` | `#6EE7A0` |
| `status-normal-bg` | `#DCFCE7` | `#052E16` |
| `status-warning` | `#92400E` | `#FCD34D` |
| `status-warning-bg` | `#FEF3C7` | `#2D1A00` |
| `status-critical` | `#991B1B` | `#FCA5A5` |
| `status-critical-bg` | `#FEE2E2` | `#2D0A0A` |
| `status-info` | `#1E3A5F` | `#93C5FD` |
| `status-info-bg` | `#DBEAFE` | `#0D1F35` |
| `border-default` | `#D1D5DB` | `#2E3D52` |

The dark mode status foreground colors are lightened significantly so they read against dark backgrounds at WCAG AA. The status backgrounds become deep-tinted darks so they preserve the semantic hue without overwhelming dark-adapted vision.

---

### Data Visualization Palette

Six categorical colors chosen to:
- avoid overlap with status hues (no red, amber, or green that could be misread as critical/warning/normal)
- maintain distinguishability for common color-vision deficiencies (deuteranopia and protanopia)
- pass 3:1 non-text contrast against both `surface-base` (light) and dark-mode `surface-raised`

| Token | Light hex | Dark hex | Hue family |
|---|---|---|---|
| `chart-1` | `#0062CC` | `#3B93F7` | Blue (primary) |
| `chart-2` | `#7C3AED` | `#A78BFA` | Violet |
| `chart-3` | `#0891B2` | `#22D3EE` | Cyan |
| `chart-4` | `#D97706` | `#FBBF24` | Amber (distinct from warning amber by use context) |
| `chart-5` | `#BE185D` | `#F472B6` | Rose |
| `chart-6` | `#059669` | `#34D399` | Teal (distinct from status-normal green by hue distance) |

**Color-vision safety note.** Chart-1 (blue) and chart-6 (teal) are distinguishable in deuteranopia simulations. Chart-2 (violet) and chart-5 (rose) diverge on lightness, not hue alone, so they separate in grayscale. Always pair chart categories with a label, pattern fill, or shape encoding as a redundant channel. Do not rely on color as the only differentiator in any chart.

**Context boundary.** `chart-4` (amber) and `status-warning` share the amber family. Separate them by never using a chart color directly in a status badge, and never using status tokens in chart legends. The roles are adjacent in hue but must not be mixed in the same visual element.

---

### Contrast and State Rules

**WCAG AA text thresholds (minimum)**

| Pairing | Required ratio | Notes |
|---|---|---|
| `text-primary` on `surface-base` | 4.5:1 | `#111827` on `#F5F7FA` = 16.8:1. Passes by wide margin. |
| `text-secondary` on `surface-base` | 4.5:1 | `#4B5563` on `#F5F7FA` = 7.2:1. Passes. |
| `text-disabled` on `surface-base` | Intentionally below 4.5:1 | Disabled elements are exempt under WCAG 1.4.3. Do not use disabled text for meaningful content. |
| `status-normal` on `status-normal-bg` | 4.5:1 | `#166534` on `#DCFCE7` = 7.6:1. Passes. |
| `status-warning` on `status-warning-bg` | 4.5:1 | `#92400E` on `#FEF3C7