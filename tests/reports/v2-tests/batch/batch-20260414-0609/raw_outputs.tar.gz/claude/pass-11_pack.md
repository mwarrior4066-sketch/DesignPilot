Good task for layout reconstruction. The PDF is the source artifact, and the job is evidence extraction followed by systematic translation, not a redesign.

Here is how I would work through it.

---

## What to extract from the 2018 PDF

### Grid structure
- Column count per format (A4/letter, landscape, any presentation sizes)
- Column width in points, mm, or as a percentage of the live area
- Gutter width between columns
- Whether gutters are equal or whether some are wider (optical or editorial gutters)
- Outer margin values: top, bottom, left, right, and whether they differ (asymmetric margins suggest a binding allowance or a deliberate visual hierarchy)
- Whether the grid is a fixed-width manuscript, a true multicolumn grid, or a modular grid with both row and column divisions

### Baseline grid and vertical rhythm
- Body text size, which usually implies the baseline increment (a 10pt body typically runs on a 14pt leading, giving you a 14pt or 7pt grid module)
- Any explicit baseline grid specification in the document
- Whether headlines, captions, and folios align to the same grid or use a looser vertical system

### Typography-as-layout cue
- Text frame insets, if visible
- Column-spanning behavior for headlines and pull quotes
- Side-column or margin-note zones

### Color and spatial zones
- Any recurring header band, footer band, or sidebar zone with explicit dimensions
- Page number and folio placement (these are reliable anchors for margin depth)
- Logo safe zone or clear space rules, which often define the minimum outer margin

### Format inventory
- Page sizes listed or implied by diagram annotations
- Any explicit bleed or trim marks
- Slide or presentation format variants if included

---

## How to read the PDF evidence honestly

Mark each finding as one of three confidence levels.

**Observed** -- directly legible in text, annotation, or diagram label. Trust these.

**Inferred** -- read from a diagram without explicit labels. A column diagram without a number attached still gives you a column ratio. Flag the inference.

**Unverified** -- things that look consistent across pages but are never stated. For example, a margin that appears identical on every spread but is never specified in writing. Treat these as working assumptions until you measure them.

Do not carry inferred values forward as fact when they affect something irreversible like a print bleed or a legal safe zone.

---

## Translation to a modern layout system

### Step 1: Convert units to your working system

2018 brand guidelines often spec in points or millimetres for print. If the new templates are digital-first, convert to pixels or rems. If they are still print-facing, stay in mm. If both, make a dual-spec table now rather than converting ad hoc later.

Typical conversion reference: 1pt = 0.353mm = ~1.333px at 96dpi.

### Step 2: Reconstruct the column model

From the extracted column count, gutter, and live-area width, express the grid as a formal column model:

- `live area = page width - (left margin + right margin)`
- `column width = (live area - (gutters × (columns - 1))) / columns`

Cross-check this against any example layouts in the PDF. If body text columns don't fit your calculation, your gutter or margin inference is off. Adjust and note the discrepancy.

### Step 3: Establish the baseline module

Take the body text leading value as the primary vertical module. All spacing decisions should be multiples or half-multiples of this value. If the document used 10pt body on 14pt leading, your module is 14pt. Section breaks, image margins, and heading clearance should map to 14, 28, 42, or 7pt increments.

If the original had no explicit baseline grid, infer it from consistent caption-to-image distances or header-band heights visible in the diagrams.

### Step 4: Define span logic

Name how elements span the column structure:

- body text: 1 column or fixed text-measure columns
- subheadings: same span as body, or spanning a defined subset
- headlines: typically full live-area or a defined wide-column span
- images: anchored to column boundaries or bleeding to trim
- captions: usually one column or set in a narrower side column

This span logic is what makes new templates feel like they belong to the same system, rather than just using the same margins.

### Step 5: Document what cannot be recovered

Some things in a 2018 PDF will not be recoverable with confidence:

- precise CMYK or Pantone references from an RGB screen preview
- exact type sizes when text is in an image layer rather than live text
- gutter values when diagrams lack dimension labels

Log these explicitly as open gaps. They need to be resolved before the system is treated as complete.

---

## Output for the new system

Structure the reconstructed system as a specification with three sections:

**Confirmed values** -- extracted directly, with source reference (page number or diagram ID in the original PDF)

**Working assumptions** -- inferred from visual evidence, flagged with confidence level and measurement method

**Open gaps** -- cannot be reliably extracted; list what is needed and from whom

This structure protects the person building the new templates from treating an assumption as a spec, and gives whoever owns the original source material a clear list of what to verify.

---

If you can share the PDF, I can apply this directly rather than describing it in the abstract, and I will flag inference boundaries as I go through the actual diagrams.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: column count, gutter, margin, baseline module from source PDF",
    "inference_boundary: observed vs inferred vs unverified confidence model applied",
    "reconstruction_order: extract > convert units > rebuild column model > establish baseline > define span logic > document gaps",
    "verification_method: cross-check column calculation against example layouts in PDF; log unresolvable gaps explicitly"
  ],
  "evidence_classes_cited": [
    "implementation_constraint",
    "comparison_artifact",
    "verification_method",
    "visual_structure_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are the new templates print-facing, digital-first, or both? Unit conversion depends on this.",
    "Is the PDF a live-text document or image-based? Affects extraction confidence significantly.",
    "Does the 2018 system include presentation or slide formats, or only document/print formats?"
  ],
  "turn": 1
}
[/SESSION_STATE]