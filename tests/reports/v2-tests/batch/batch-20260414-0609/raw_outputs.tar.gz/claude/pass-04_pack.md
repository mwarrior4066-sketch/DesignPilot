## Back-End Feasibility Review: Real-Time Collaboration on a REST/PostgreSQL Stack

---

### Requested Capability

Add Google Docs-style simultaneous editing to an existing React/REST/PostgreSQL app, with visible cursor presence, conflict resolution, and persistent state.

The visible ask is a UI feature. The hidden ask is a full concurrency and delivery architecture replacement for the document layer.

---

### Hidden System Requirements

Real-time collaboration is not an API feature you add on top of REST. It requires a different transport, a different consistency model, and a different conflict strategy. Here is what actually needs to exist before the visible behavior is possible.

**Persistent connection layer**

REST is request-response. Real-time collaboration requires a long-lived connection per client: WebSocket (most common), Server-Sent Events (broadcast-only, simpler), or a managed layer like Liveblocks, PartyKit, or Supabase Realtime. Each option carries different infrastructure cost and operational responsibility.

**Conflict resolution algorithm**

Without a conflict model, two simultaneous edits to the same document position produce data loss or corruption. The three main approaches differ sharply in complexity and reversibility:

- **Operational Transformation (OT)** - each operation is transformed against concurrent operations before applying. Google Docs uses OT. Correct OT implementation is notoriously difficult to write from scratch and carries significant bug surface.
- **CRDTs (Conflict-Free Replicated Data Types)** - data structures that merge by design without coordination. Libraries like Yjs and Automerge implement this. Lower implementation risk than hand-rolled OT, usable with PostgreSQL or a dedicated sync store.
- **Last-write-wins** - not suitable here. It produces silent data loss under concurrent edits and cannot be safely patched later without a full redesign.

**Presence and awareness model**

Cursor positions, user avatars, and selection ranges are ephemeral state. They must not be stored in the same table as the document body. They need a fast ephemeral layer (Redis pub/sub or a managed presence service) that does not write to PostgreSQL on every cursor move. Naively routing presence through your existing REST endpoints will produce an unworkable write load.

**Operational log or event store**

Conflict resolution requires knowing what happened and in what order, not just the current document state. Your PostgreSQL schema currently stores a document as a value. You need an operation log, a CRDT document store, or a version vector attached to every edit. This is a schema migration, not a new column.

**Data model changes**

Your current schema almost certainly stores document content as a text or JSON column. That model does not support concurrent edits without replacement. Depending on your conflict strategy, you need one of:

- An append-only operations table with sequence numbers and author IDs
- A CRDT binary or JSON document type per document (Yjs stores a binary update log)
- A hybrid: CRDT in memory and Redis, with periodic snapshot to PostgreSQL

**Auth and session scope**

Real-time sessions are not stateless. You need to know which authenticated user owns which WebSocket connection, and you need to enforce document-level access control on connection open, not just on REST endpoints. If your current auth is purely token-per-request, connection-level auth needs to be designed separately.

**Scalability boundary**

A single Node/WebSocket server can handle a bounded number of concurrent connections before you need horizontal scaling, sticky sessions, or a coordination layer (Redis pub/sub or a message broker). If you are currently stateless REST behind a load balancer, you will need infrastructure changes to avoid split-brain presence and dropped operation broadcasts.

---

### Feasibility Assessment

**Can you build this on the existing stack?** Yes, but not by adding to it. Several things must be replaced or extended before the first concurrent edit is safe.

| Constraint | Severity | Notes |
|---|---|---|
| REST-only transport | Hard blocker | Must add WebSocket or managed layer before any real-time behavior is possible |
| Document stored as a mutable value | Hard blocker | Schema must migrate to support ordered operations or CRDT updates |
| No ephemeral presence layer | Hard blocker | Cursor/selection data cannot route through REST/PostgreSQL without catastrophic write volume |
| Connection-level auth | Significant gap | Token-per-request auth does not map directly to persistent connections |
| Load balancer statefulness | Infrastructure risk | Horizontal scaling requires sticky sessions or pub/sub coordination; current setup likely does neither |
| Hand-rolled OT | High implementation risk | Correct OT is a research-grade problem; use a library or avoid it entirely |
| Last-write-wins as interim | Data-loss risk | Do not use LWW as a stopgap even temporarily; corruption is expensive to reverse |

The most dangerous shortcut is treating this as a frontend problem. Adding a WebSocket connection without a conflict model produces a race-condition store. Users will silently overwrite each other.

---

### Safer Implementation Path

Build in phases. Each phase must be stable and production-safe before the next begins. Do not unlock the next phase under schedule pressure without verifying the prior one.

**Phase 1: Transport and presence only (no concurrent editing yet)**

- Add a WebSocket server (or adopt a managed layer such as Liveblocks or Supabase Realtime)
- Implement connection-level auth: verify the user's document access permission on WebSocket open, reject the connection if they lack access
- Add a Redis pub/sub or in-memory presence layer for cursor positions and user avatars
- Show remote cursors and user presence in the UI without allowing concurrent document edits
- Documents remain single-writer (optimistic lock: only one user edits at a time, others see read-only)

This phase proves the transport and auth model without taking on conflict resolution yet. It is shippable, visibly useful, and fully reversible.

**Phase 2: Choose and integrate a CRDT library**

- Evaluate Yjs (more production-proven, larger ecosystem) or Automerge (simpler API, newer)
- Migrate the document storage model: keep the current PostgreSQL column as a snapshot target, add an operations or update log table alongside it
- Replace the document write path with CRDT merge operations; the REST save endpoint becomes a CRDT snapshot flush
- Add document-level version tokens to all read and write paths so stale reads are detectable

Do not write custom OT. The library handles merge correctness. Your job is the storage model and the flush strategy.

**Phase 3: Persistent state and recovery**

- Define the snapshot policy: how often does an in-memory or Redis CRDT state flush to PostgreSQL, and what triggers it (time, operation count, user disconnect)?
- Add a recovery path: if the WebSocket server restarts, clients must be able to reconnect and rehydrate from the last PostgreSQL snapshot plus any pending operation log
- Add operational observability: WebSocket connection count, operation queue lag, conflict merge errors, and failed flushes must be visible in your monitoring before this goes to production

**Phase 4: Horizontal scale readiness**

- Move pub/sub coordination to Redis Cluster or a managed pub/sub service so multiple WebSocket server instances share presence and operation broadcast
- Add sticky session routing at the load balancer, or confirm your pub/sub layer makes stickiness unnecessary
- Load-test with concurrent edit sessions before general availability

---

### What is preserved and what must change

**Preserved:** PostgreSQL as the durable document store, your existing REST API for non-document-editing reads, your auth token model (extended to cover connections), your React frontend (WebSocket client layer added, not replaced).

**Must change:** Document schema (value-column model replaced with operation log or CRDT snapshot), write path (REST PUT replaced with CRDT merge for document edits), infrastructure (WebSocket server, Redis presence layer, connection-aware load balancing).

**Expensive to reverse if skipped:** The conflict resolution choice in Phase 2. If you ship multi-user editing with no merge algorithm and later try to add one, you are migrating a live document corpus and potentially explaining data loss to users. Pick the model before enabling concurrent writes.

[SESSION_STATE]
{
  "route": "backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "data_dependency: document schema must migrate from value-column to operation log or CRDT snapshot model",
    "permissions_dependency: connection-level auth required; token-per-request does not map to persistent WebSocket connections",
    "system_surface_dependency: REST transport must be extended with WebSocket or managed real-time layer; Redis required for ephemeral presence",
    "blocking_constraint: last-write-wins