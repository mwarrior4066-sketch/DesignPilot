# API Reliability and Security Review: POST /exports

## Failure Semantics and Error Contract

The current design collapses all outcomes into HTTP 200, which destroys the client's ability to reason about what happened. A client that receives 200 cannot distinguish between a successful export, a quota failure, an authorization rejection, or a downstream rendering crash. Every retry, circuit breaker, and alerting rule downstream becomes unreliable because the signal is gone.

**Internal enum leakage** compounds this. When error messages expose values like `EXPORT_STATE_RENDER_FAILED` or `JOB_TYPE_PDF_BULK`, you hand attackers a partial map of your system's internal state machine. Enumerated job types, pipeline stages, and internal status codes are reconnaissance material.

**Required contract:**

Adopt RFC 9457 (`application/problem+json`) as the error envelope for all non-success outcomes.

```http
HTTP/1.1 422 Unprocessable Entity
Content-Type: application/problem+json

{
  "type": "https://api.example.com/problems/export-invalid-parameters",
  "title": "Export request could not be processed",
  "status": 422,
  "detail": "The requested date range exceeds the maximum allowed span.",
  "instance": "/exports/req_01HZ..."
}
```

Status code mapping:

| Condition | Correct status |
|---|---|
| Invalid parameters | 422 |
| Unauthorized | 401 |
| Forbidden (BOLA/BFLA) | 403 |
| Idempotency key conflict | 409 |
| Quota exceeded | 429 |
| Server-side failure | 500 or 503 |
| Job accepted (async) | 202 |

The `type` URI should be stable and human-readable, but it must not leak internal enum names. Map your internal codes to public-facing problem types at the serialization layer.

---

## Authorization and Resource Protection

A POST /exports endpoint carries significant BOLA and BFLA exposure.

**BOLA (object-level):** If the export request accepts a resource identifier (report ID, dataset ID, tenant ID), the server must verify that the authenticated principal owns or has been explicitly granted access to that specific object, not just that they hold a valid session token. An authenticated user from tenant A must not be able to trigger an export of tenant B's data by supplying tenant B's identifiers.

**BFLA (function-level):** Export generation is a privileged action. Not every authenticated user should be permitted to invoke it. Role or permission checks must gate the action itself, separate from the object ownership check.

**Deny by default:** Any missing or ambiguous permission state must resolve to a 403, not a fallthrough to processing. The authorization check must happen before any expensive rendering work begins.

**Recommended authorization sequence:**

1. Authenticate the caller (session, token, API key).
2. Check function-level permission: is this principal allowed to generate exports at all?
3. Check object-level permission: does this principal own or have explicit access to every resource ID referenced in the request body?
4. Reject with 403 if either check fails, before touching the render pipeline.

Do not rely on the obscurity of resource identifiers. A UUID is not an authorization boundary.

---

## Idempotency and Async Lifecycle

This is the most structurally broken area of the current design. Both problems must be fixed together.

**Problem 1: 3-minute synchronous block.** Holding an HTTP connection open for up to 3 minutes is not safe for production. Load balancers, proxies, mobile clients, and serverless runtimes all carry timeout defaults well below 3 minutes. The client has no safe way to retry, and the server has no way to signal progress. A single network hiccup produces an orphaned job with no recovery path.

**Problem 2: No idempotency contract.** Without an idempotency key, a client that times out and retries will trigger a second export job. If the first job completed silently, you now have duplicate exports. If the first job is still running, you have two concurrent renders of the same report competing for resources.

**Required changes:**

Move to an async job model. The endpoint accepts the request, enqueues the job, and immediately returns 202 Accepted with a status URL.

```http
HTTP/1.1 202 Accepted
Content-Type: application/json
Location: /exports/job_01HZ.../status

{
  "job_id": "job_01HZ...",
  "status": "queued",
  "status_url": "https://api.example.com/exports/job_01HZ.../status"
}
```

Job lifecycle states: `queued` -> `running` -> `completed` | `failed`.

The status endpoint returns the current state. On `completed`, it includes a time-limited download URL or delivery reference. On `failed`, it returns an RFC 9457 problem body with a public-facing error type.

**Idempotency key contract:**

Require `Idempotency-Key` as a header on every POST /exports request.

- Client generates a stable key per logical export intent (UUID or deterministic hash of the request parameters).
- Server stores the key with a TTL (24 to 72 hours is common, match your export retention window).
- If the same key arrives again while the job is running: return the existing 202 response.
- If the same key arrives after completion: return the completed job response or a 409 with a pointer to the original result.
- If the key is absent: return 400 with an RFC 9457 problem body explaining the requirement.

This makes every retry safe. The client can retry on timeout without triggering a second render.

---

## Resilience and Observability

**Timeouts and circuit breaking.** The render pipeline itself must have an internal timeout shorter than any client-facing timeout. If rendering exceeds your SLA threshold (say 90 seconds internal), the job transitions to `failed` with a structured error rather than hanging indefinitely. Upstream callers should implement circuit breaking with exponential backoff and jitter if they poll the status endpoint repeatedly.

**Quota and rate limiting.** Export generation is resource-intensive. Apply per-tenant and per-user quotas at the function level before enqueuing. Return 429 with a `Retry-After` header when the quota is exceeded. This prevents a single tenant from exhausting render capacity.

**Observability requirements.** Every export job must carry a `trace_id` from the moment the request arrives to the moment the job reaches a terminal state.

Minimum instrumentation surface:

| Signal | What to capture |
|---|---|
| Request trace | `trace_id` attached at ingress, propagated through queue and render worker |
| Job queue lag | time between enqueue and render start; alert on sustained lag |
| Render duration | p50, p95, p99 per report type or parameter class |
| Terminal failure rate | failures per unit time, broken out by error type |
| Authorization rejection rate | 401 and 403 counts; spikes may indicate probing |

**Degraded mode.** If the render service is unavailable, the queue should accept the job and hold it rather than rejecting at ingress. Return 202 with status `queued`. Let the status endpoint reflect the delay honestly rather than producing a false failure at submission time.

---

## Summary of Required Changes

| Area | Current state | Required change |
|---|---|---|
| Error contract | 200 for everything, enum leakage | RFC 9457 envelope, public-facing error types, correct status codes |
| Authorization | Unspecified | Deny-by-default, function-level + object-level checks before render |
| Idempotency | None | Required `Idempotency-Key` header, server-side key store with TTL |
| Execution model | 3-minute synchronous block | Async job with 202 + status URL, terminal states, download link |
| Resilience | None visible | Internal render timeout, per-tenant quota, 429 + `Retry-After` |
| Observability | None visible | `trace_id` propagation, queue lag, render duration, failure rate metrics |

None of these are optional polish. The synchronous block and missing idempotency contract together make the endpoint unsafe to retry. The 200-for-errors contract makes it impossible to build reliable clients. The missing authorization perimeter makes it a BOLA/BFLA risk. Address them in the order listed in the summary: error contract first (lowest