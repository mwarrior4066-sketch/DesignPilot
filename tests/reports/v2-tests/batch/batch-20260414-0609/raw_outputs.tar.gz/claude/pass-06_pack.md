## Brand Positioning Pass

### Audience and Problem

**Segment:** Independent freelancers (1–5 person, often solo) who earn irregularly, juggle multiple clients, and manage their own financial administration with no CFO, no finance team, and no institutional support.

**Perception gap:** Stripe feels like infrastructure for developers. Mercury and Relay feel like serious business banking for funded companies. None of them speak to the psychological reality of freelancing: income uncertainty, client dependency, the exhaustion of being your own accounts department, and the low-grade anxiety that comes with not knowing if this month is okay.

"Trustworthy but approachable" is a brand feeling, not a position. The positioning question is: trustworthy *compared to what*, and approachable *for whom*? Those answers determine the territory.

---

### Positioning Frame

**Category:** Not "a better bank." The category should be something closer to *financial clarity for independent workers* -- a tighter frame that excludes the startup ecosystem Mercury and Relay court, and excludes the developer-API territory Stripe owns.

**Wedge:** The competitors are built for companies. Freelancers are people first, businesses second. They don't think in terms of treasury management or payment infrastructure. They think: *will I make rent this month, did that invoice clear, and what do I actually owe in taxes?*

**Positioning territory to own:** "The first financial tool that treats your income like it actually works" -- irregular, client-dependent, variable, and occasionally stressful. Not a bank that tolerates freelancers. A product designed around how freelancers actually earn.

This means the differentiation is less about features and more about *mental model*. The product's job is to make irregular income feel legible and manageable, not to normalize the freelancer's situation into a standard business-account experience.

**Against:** Position explicitly against the "pretend you're a startup" framing that Mercury and Relay use. Freelancers are not pre-revenue seed companies. They have real income and real tax exposure today.

---

### Trust and Proof Burden

"Trustworthy" for freelancers means something specific: *it won't misunderstand my situation and cause me a problem I didn't ask for.*

The trust signals that actually matter here:
- Visible handling of irregular income (no penalties for uneven months, clear communication when something looks off)
- Tax-awareness built in, not bolted on (freelancers have quarterly estimated payments; a product that ignores this isn't built for them)
- Transparent fee logic (freelancers are sensitive to fees because margins are often thin)
- Plain language everywhere, no institutional jargon

The proof burden: "approachable" will ring hollow unless the product surface, copy, and error states are all written for someone who is not a finance person. That is a content and product design commitment, not just a brand tone decision.

**Gap to close:** None of this positioning holds if the product has a standard business-account onboarding flow, uses terms like "entity type" without explanation, or presents a dashboard built for multi-person teams. Brand cannot carry a product that misunderstands the user.

---

### Messaging Consequences

**Should sound like:** A knowledgeable friend who understands irregular income and doesn't judge it. Direct, clear, occasionally warm -- not clinical, not cheerful-fintech-startup, not corporate reassurance.

**Should not sound like:** Aspirational startup language ("build your empire"), generic trust language ("your money is safe with us"), or the hollow approachability of big-bank rebrand campaigns ("we get it, we really do").

**Tone constraint:** Avoid performing ease. Freelancing is genuinely stressful; a product that pretends the financial side is simple will feel patronizing. The brand voice should acknowledge the real situation and then show competence, not minimize the problem and claim magic.

**Language consequence:** Favor verbs over nouns. "See exactly where you stand" beats "Financial visibility for independents." The copy should model the behavior of the product: clear, direct, no unnecessary complexity.

**Tradeoff:** This positioning deliberately narrows the addressable market. It excludes small agencies, dev shops, and funded companies who might also use the product. That is the correct tradeoff -- a broad fintech position competes directly with Mercury and Relay on their strongest ground. The freelancer-specific frame is defensible territory they have not claimed.

[SESSION_STATE]
{
  "route": "brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: independent freelancers with irregular income, no finance support, perception gap vs. startup-facing competitors",
    "differentiation_frame: positioned against Mercury/Relay startup framing and Stripe developer-infrastructure framing; category is financial clarity for independent workers",
    "trust_logic: trust signals are irregular-income handling, tax-awareness, transparent fees, plain language -- not generic security claims",
    "messaging_consequence: knowledgeable-friend tone, verb-forward copy, acknowledge real stress then show competence; avoid performing ease"
  ],
  "evidence_classes_cited": [
    "comparison_artifact",
    "implementation_constraint",
    "file_backed_receipt"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product currently have tax-awareness features, or is that a roadmap item? Brand promise must match product reality.",
    "What is the intended revenue model? Fee structure affects how trust messaging can be substantiated."
  ],
  "turn": 1
}
[/SESSION_STATE]