## UX Research Gap Map

**Route:** `ux_research_gap_map` | **Weight:** standard

---

### Known Evidence

Three stakeholder interviews establish internal priorities and pain points from the business side. Two usability tests on the current product surface observable friction in task completion. The 60% drop-off on project creation is a strong behavioral signal: something in that flow is broken or misaligned with user expectations at a meaningful rate.

What the existing evidence cannot tell you: why users make the choices they make, what they need that the tool does not offer, and whether the flow problem is structural, conceptual, or just copy and labeling.

---

### Critical Gaps

**Gap 1: Abandonment intent in the project creation flow (highest priority)**
The 60% drop-off is your most urgent signal, but you have no qualitative data explaining it. You cannot redesign that flow responsibly without knowing whether users abandon because the flow asks for information they do not have yet, because the mental model of "project" does not match how they work, or because the friction is purely mechanical. These require different fixes.

**Gap 2: Power user workflows and workarounds**
No research on power users means the redesign is likely optimized for onboarding legibility at the cost of the people who use the tool daily and drive renewal. Power users often build workarounds that reveal unmet needs the product has never formally addressed. Missing this segment is a retention risk.

**Gap 3: Competitive and category context**
Without competitive analysis, you cannot know whether your creation flow is failing by absolute standard or because users arrive with expectations shaped by other tools. B2B project management is a crowded category with established interaction conventions. Knowing where you deviate intentionally versus accidentally matters before locking in a new direction.

**Gap 4: Decision-maker vs. executor distinction**
Stakeholder interviews give you organizational priorities, but B2B tools typically serve two distinct populations: the people who set up and administrate projects, and the people who execute work inside them. Your usability tests may have only captured one. If the redesign conflates these roles, it risks optimizing the wrong flow.

---

### Research Plan

**Study 1: Abandonment exit interviews + session replay analysis**
Method: 6 to 8 exit interviews with users who recently abandoned the creation flow, combined with a structured review of session replay footage (Hotjar, FullStory, or equivalent).
Sample: Recent product users who did not complete project creation, recruited from the analytics cohort or an in-product prompt.
Output: A ranked list of abandonment reasons classified by category (information gap, mental model mismatch, mechanical friction, or motivational failure).
Decision unlocked: This determines whether the creation flow needs structural rearchitecting, a progressive disclosure pass, or primarily copy and labeling work. Those are three different scopes.

**Study 2: Power user contextual interviews or diary study**
Method: 5 to 7 contextual interviews with users who create more than X projects per month (define threshold from your analytics). A short diary study works if scheduling is difficult: ask participants to document one full project setup cycle.
Sample: High-frequency internal users or customers identified through usage data.
Output: A workflow map showing current workarounds, integration dependencies, naming conventions, and the information they need at project creation that the current flow does not capture well.
Decision unlocked: This determines what the creation flow must support structurally for retention, not just first-time legibility. It also de-risks template or bulk-creation features if those keep appearing in workarounds.

**Study 3: Competitive benchmarking and convention audit**
Method: Structured walkthrough of 4 to 6 competitor and analogous product creation flows (Asana, Linear, Monday, Notion, Basecamp, and one outside the category). Score against a shared rubric: steps to first save, required vs. optional fields, progressive disclosure patterns, and defaults used.
Sample: Product team internal exercise, not user-facing.
Output: A convention map showing where your flow aligns with category norms and where it deviates, with a hypothesis for each deviation about whether the deviation is a feature or a liability.
Decision unlocked: This sets the bar for what counts as "better" and flags whether you are fighting category convention or just executing poorly within it.

**Study 4: Role segmentation validation**
Method: A survey sent to existing users (target 80 to 120 responses) with role-based screener questions, followed by 3 to 4 follow-up interviews to add texture.
Sample: Current active users, stratified by self-reported role.
Output: A role map with distinct job-to-be-done framing for project administrators vs. project contributors, including what each role needs from the creation flow.
Decision unlocked: This determines whether the redesign needs a single optimized flow or a branching or role-aware entry path. Running one creation flow for both segments is a common failure mode in B2B.

---

### Decision Impact Summary

| Study | Primary decision it unlocks |
|---|---|
| Abandonment exits + replay | Creation flow scope: structural, disclosure, or copy |
| Power user contextual research | What the flow must support for retention and daily use |
| Competitive benchmarking | Where to align with convention vs. where to intentionally deviate |
| Role segmentation | Whether one flow serves all users or the entry needs branching |

The abandonment study should run first. It directly determines redesign scope, and starting layout or flow work before that data exists risks building a solution for the wrong diagnosis.

---

**Proof boundaries:** The 60% drop-off is a measured behavioral signal. Abandonment reasons, power user needs, and role distinctions are currently assumptions. Competitive benchmarking produces proxy evidence. The studies above would move the first three from assumption to measured or at minimum supported by direct user evidence. No external validation exists yet for any redesign direction.

[SESSION_STATE]
{
  "route": "ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": [
    "known_vs_unknown: stakeholder interviews + usability tests + 60pct dropoff are known; abandonment reasons, power user needs, competitive context, and role segmentation are assumption",
    "gap_priority: abandonment exit research is highest priority because it determines redesign scope",
    "method_mapping: exit interviews + session replay, contextual interviews + diary, competitive benchmarking, role-segmentation survey",
    "decision_linkage: each study mapped to the product or scope decision it unlocks"
  ],
  "evidence_classes_cited": [
    "research_artifact",
    "comparison_artifact",
    "narrative_proof_boundary"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What is the threshold for 'power user' in your analytics (projects per month or another proxy)?",
    "Do you have session replay tools already in place, or does that need to be instrumented first?",
    "Is the role distinction (admin vs. executor) already captured in your user data, or does it need to be surfaced through the survey?"
  ],
  "turn": 1
}
[/SESSION_STATE]