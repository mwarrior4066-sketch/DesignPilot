## Split Button — Component Specification

---

### Purpose and Scope

The Split Button exposes one primary action (Save) alongside a dropdown trigger that reveals secondary save variants (Save as draft, Save and close). It exists where a default action is strongly preferred but secondary paths must remain accessible without additional navigation.

The component owns: the primary button, the dropdown trigger, the dropdown panel, and all shared states across those parts.

The component does not own: the form submit logic, page routing after save, or the overlay backdrop (that belongs to the modal/overlay system).

---

### Anatomy

| Part | Element | Token reference |
|---|---|---|
| Primary button | `<button type="button">` | `color.action.primary`, `space.inset.md` |
| Divider | `<span aria-hidden="true">` | `color.border.action`, `1px` width |
| Dropdown trigger | `<button type="button">` | same surface as primary, `space.inset.sm` |
| Dropdown panel | `<ul role="menu">` | `color.surface.overlay`, `shadow.md` |
| Menu item | `<li role="menuitem">` | `color.text.primary`, `space.inset.md` |

The two buttons share a single visual container but are **two distinct focusable elements** with separate labels.

---

### State Matrix

| State | Primary button | Dropdown trigger | Dropdown panel | Notes |
|---|---|---|---|---|
| Default | active | active | hidden | Normal resting state |
| Primary hover | `color.action.primary.hover` | unchanged | hidden | Hover applies to primary only |
| Trigger hover | unchanged | `color.action.primary.hover` | hidden | Hover applies to trigger only |
| Dropdown open | unchanged | `aria-expanded="true"` | visible | Trigger pressed, panel appears |
| Item hover/focus | unchanged | unchanged | item highlighted | `menuitem` receives focus, not the panel |
| Loading | spinner + visually hidden "Saving…" | disabled, `aria-disabled="true"` | hidden, remains closed | Triggered by primary action submit |
| Disabled (full) | `aria-disabled="true"`, muted surface | `aria-disabled="true"`, muted surface | unreachable | Both parts disabled together |
| Disabled (trigger only) | active | `aria-disabled="true"` | unreachable | Rare: secondary actions temporarily unavailable |
| Error recovery | primary returns to default | trigger returns to default | closed | Error state is owned upstream by the form |

**Loading notes.** When the primary action fires, replace button label with a spinner and the visually hidden text "Saving…" so screen readers announce progress. Disable the trigger during loading. Do not close a pre-open dropdown mid-load; instead close it before the loading state begins.

---

### Keyboard support

| Key | Context | Behavior |
|---|---|---|
| `Tab` | Any | Moves focus to primary button, then dropdown trigger, then out |
| `Enter` or `Space` | Primary button focused | Fires Save action |
| `Enter` or `Space` | Trigger focused, panel closed | Opens dropdown panel, moves focus to first menu item |
| `Escape` | Panel open | Closes panel, returns focus to dropdown trigger |
| `ArrowDown` | Panel open | Moves focus to next menu item, wraps to first |
| `ArrowUp` | Panel open | Moves focus to previous menu item, wraps to last |
| `Enter` or `Space` | Menu item focused | Fires that secondary action, closes panel |
| `Tab` | Panel open | Closes panel, moves focus forward (does not navigate within panel) |

The panel does not trap focus. Tab closes it and moves on. Arrow keys navigate inside it.

---

### Accessibility and implementation notes

**ARIA contract.**
The dropdown trigger needs `aria-haspopup="menu"` and `aria-expanded="true|false"`.
The primary button needs a clear label: `aria-label="Save"` if the visible label alone is ambiguous in context.
The dropdown trigger needs `aria-label="More save options"` — its visible label is a chevron icon alone.
The panel is `role="menu"` with `id` referenced by `aria-controls` on the trigger.
Each item is `role="menuitem"`.

**Disabled state.**** Use `aria-disabled="true"` rather than the native `disabled` attribute on both buttons when the full component is disabled. This keeps both elements focusable so screen reader users can discover them and understand why they are unavailable. Pair with a tooltip or a visible reason when disabling is not self-evident.

**Loading announcement.** The "Saving…" visually hidden text inside the loading state button is sufficient for screen readers during a short operation. For operations over ~3 seconds, add an `aria-live="polite"` region outside the button to announce completion or failure. The button itself should not carry a live region permanently — that adds noise on every render.

**Touch targets.** The primary button target height is 44px minimum. The dropdown trigger minimum width is 44px. On mobile, the divider between them is purely visual — both tap areas extend to the full 44px height. Do not reduce the trigger width to a thin sliver on small screens; if space is critically constrained, collapse the split button into a single button with the dropdown arrow incorporated into its trailing edge, maintaining the 44px minimum.

**Token constraints.** Do not hardcode colors, spacing, or border-radius. Pull from the design token system. The divider color must maintain 3:1 contrast against the button surface (non-text contrast, WCAG 1.4.11) so the visual boundary between the two parts is perceivable.

**Do not use a `<select>` element** as the secondary action trigger. It does not support the required keyboard pattern, cannot be styled to spec, and breaks the ARIA menu contract.

**Prop surface (minimum viable).**

```ts
interface SplitButtonProps {
  primaryLabel: string;
  onPrimaryAction: () => void;
  secondaryActions: Array<{ label: string; onAction: () => void; disabled?: boolean }>;
  isLoading?: boolean;
  disabled?: boolean;
  loadingLabel?: string; // default: "Saving…"
}
```

Variants are controlled by props, not by hardcoded string matching. The loading and disabled states are passed in, not inferred from internal state.

---

### Tradeoffs and constraints

**Reusability boundary.** This spec assumes a Save context by example. The component is reusable for any split-action pattern as long as `primaryLabel` and `secondaryActions` are injected — do not bake "Save" into the component logic.

**Mobile collapse rule.** The split form is preferred on medium and large viewports. On viewports below 360px effective width, or when the component is inside a constrained container, the collapsed single-button variant is the safer default. Document this as a layout-aware variant, not a separate component.

**Disabled vs. hidden.** Prefer `aria-disabled` over hiding the component when actions are temporarily unavailable. Hidden controls give users no signal that the action exists. Disabled with a reason is almost always the better UX choice here.

[SESSION_STATE]
{
  "route": "component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: primary button + trigger + panel + shared states; excludes form logic, routing, overlay backdrop",
    "state_coverage: default, hover, dropdown-open, item-focus, loading, disabled-full, disabled-trigger-only, error-recovery",
    "accessibility_behavior: aria-haspopup=menu, aria-expanded, aria-label on trigger, role=menu/menuitem, aria-disabled over native disabled, live region for long ops",
    "implementation_boundary: token-driven props, no hardcoded strings, collapsed variant below 360px"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "implementation_constraint",
    "standards_reference"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]