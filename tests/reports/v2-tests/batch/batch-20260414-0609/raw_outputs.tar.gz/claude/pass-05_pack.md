## PDF Remediation Plan

This is a compound task. PDF/document remediation governs. Document accessibility supports.

---

### Current failure state

The PDF has several layered problems that compound each other. The structure tree is either absent or mis-sequenced from the InDesign export defaults. The two-column layout almost certainly exported with column 2 following column 1 in visual Z-order rather than reading order, meaning screen reader users get half of column 1, then all of column 2, then the second half of column 1. Pull quotes are likely tagged as body text or untagged, creating duplicate content in the reading sequence. Decorative images are untagged or tagged as figures without alt text, which triggers false reading events. The broken TOC links mean the PDF's named destinations or cross-reference hyperlinks were not exported correctly from InDesign's interactive PDF settings.

The document is semantically broken in at least four independent ways. None of them are fixed by visual cleanup.

---

### Remediation sequence

Work in this order. Skipping steps creates cascading errors.

**Step 1: Set document metadata and viewer preferences**

Open the document in Acrobat Pro (or PAC 3 plus a PDF editor). Before touching structure:
- Set language in Document Properties > Advanced (ISO language code, e.g. `en-US`)
- Set title in Initial View so the title, not the filename, is announced
- Set reading direction in Document Properties if it is not already set

**Step 2: Audit the existing tag tree before editing it**

Open the Tags panel in Acrobat Pro. Do not begin retagging until you have mapped what exists.

Look for:
- Whether columns are interleaved in reading order (this is the most common InDesign two-column export failure)
- Pull quotes appearing mid-article as `<P>` tags or figure captions
- Decorative images tagged as `<Figure>` with no alt text, or not tagged at all
- Tables of contents that are tagged as paragraphs with no link structure

Capture the current state. You need this as a before-state so you can verify each fix.

**Step 3: Fix reading order for the two-column layout**

This is the highest-risk operation. Do not flatten, rasterize, or use OCR to work around it.

In Acrobat Pro, use the Reading Order tool (Accessibility panel) to re-sequence the content:
- Column 1 content should run from top to bottom before column 2 begins
- Use the Order panel (View > Show/Hide > Navigation Panes > Order) to drag the reading order blocks into correct sequence
- Verify by running Read Out Loud (View > Read Out Loud > Read This Page Only) and listening for correct column order

If InDesign source files are available, the safer path is to fix the export settings directly:
- In InDesign, set the article order via the Articles panel (Window > Articles) before re-exporting as an interactive or accessible PDF
- Assign each story frame in the correct reading order using the Articles panel
- Export with "Create Tagged PDF" and "Use Structure for Tab Order" enabled in the Export PDF dialog

Re-exporting from a corrected Articles panel is the more durable fix and should be done when source access is available. Acrobat post-processing alone is fragile if the document is ever re-exported.

**Step 4: Remediate pull quotes**

Pull quotes duplicate body content by design. In the tag tree they create false reading events: the reader encounters the same content twice, or the quote interrupts the surrounding paragraph.

For each pull quote:
- Tag it as an artifact if it is purely decorative and the content appears verbatim elsewhere in the body
- If it must remain in the reading experience (editorial choice), tag it as `<BlockQuote>` and ensure it appears after the paragraph it derives from, not in the middle of it
- Do not leave pull quotes as generic `<P>` tags inside the body flow

**Step 5: Handle decorative and informational images**

For each image, make a binary decision:
- Decorative: no informational content, could be removed without meaning loss. Tag as artifact using the artifact action in the Tags panel. Do not assign alt text to a decorative image since a blank alt attribute is the correct signal.
- Informational: conveys meaning the text does not fully provide. Tag as `<Figure>`. Add meaningful alt text via the alternate text field in the image's tag properties. Alt text should describe the image's communicative function, not its visual appearance generically.

Do not mark informational images as artifacts to avoid writing alt text. That is a semantic shortcut that breaks assistive-technology users.

**Step 6: Rebuild the TOC hyperlinks**

Broken TOC links in InDesign-exported PDFs usually trace to one of three causes:
- Named destinations were not created during export
- Hyperlinks were not included in the export settings
- The PDF was flattened or resaved in a way that stripped destinations

Check the fix path:

*If source files are available:* Re-export with "Hyperlinks" and "Bookmarks" enabled in the Export PDF dialog. Ensure TOC entries were generated using InDesign's automatic TOC feature (Layout > Table of Contents) rather than manually typed, because manual TOC entries do not generate named destinations automatically.

*If only the PDF is available:* In Acrobat Pro, open Tools > Edit PDF > Link. Create new link annotations for each TOC entry, pointing to the correct named destination or page number. For each TOC entry, also ensure it is tagged as a `<Link>` with a child `<Link-OBJR>` and a link annotation, not just a styled paragraph.

Also create bookmarks (View > Navigation Panels > Bookmarks) for all heading levels. These serve both as navigation for sighted keyboard users and as a structural navigation layer for screen reader users who use the document outline.

---

### Verification checks

Do not mark any step complete without a verification gate.

| Step | Verification method |
|---|---|
| Reading order | Run Read Out Loud in Acrobat. Listen for correct column sequence. Run a screen reader (NVDA or JAWS) and navigate by paragraph. |
| Pull quotes | Navigate the document with a screen reader using paragraph navigation. Pull quotes should not appear mid-sentence in the body flow. |
| Decorative images | Run axe PDF or PAC 3. Zero errors for missing alt text on decorative images. Informational figures should have non-empty alt text. |
| TOC links | Tab through the PDF. Each TOC entry should receive focus as a link. Activating each link should move focus to the correct heading. |
| Tag tree | Run PAC 3 (PDF Accessibility Checker). Aim for zero failures on reading order and tagging. Review warnings for artifact coverage. |
| Language | Open document properties and confirm language code is set. A screen reader should announce the language correctly on document open. |

PAC 3 is the verification standard reference here (aligned with PDF/UA-1, ISO 14289-1). Passing PAC 3 does not guarantee perfect accessibility, but failing it confirms real problems. Use it at the start to audit and at the end to confirm closure.

---

### Risk controls

These constraints prevent the most common destructive repair errors.

**Do not flatten the PDF.** Flattening destroys the tag tree and all named destinations. If you flatten to resolve a transparency issue, you lose everything built in steps 2 through 6 and have to start over.

**Do not rasterize pages.** Rasterizing converts the page to an image. The result has no text layer, no tags, and is not extractable. OCR added afterward creates an approximation, not a semantic document. If a page must be rasterized for print reasons, keep a separate accessible copy.

**Do not use OCR as the primary remediation path.** OCR is a recovery tool for documents that have no text layer (scanned originals). This document was exported from InDesign and has a real text layer. Applying OCR to a live-text PDF will create duplicate text artifacts and corrupt the extraction order.

**Do not copy-paste the tag tree from a different document.** Tag structures are document-specific. Borrowing another document's tag structure and applying it here creates mismatched parent-child relationships in the structure tree.

**Save as PDF/A or PDF/UA when complete,** not as a standard PDF save. Use Acrobat's Save As > PDF/X or File > Save As Other > Optimized PDF with accessibility preservation enabled. Saving as a regular PDF with full compression can strip accessibility metadata.

---

### Governing tradeoff

The two-column reading order fix involves a real tradeoff. Fixing it properly