## Front-End Architecture Review: Permissions-Heavy Scheduling Dashboard

**Route:** `frontend_implementation_review` | **Escalation:** compound
**Supporting:** `accessibility-feedback-expert`, `back-end-aware-planner`, `front-end-handoff-expert`

---

### Architectural Framing

The core problem is not "client rendering is slow." It is that the proposed architecture lets the client own decisions it is not equipped to make safely.

Role-based visibility means the server holds the authority model. Shipping a large client-rendered page transfers rendering responsibility to a surface that can be inspected, manipulated, and does not know the permission state at hydration time. Server-driven filters mean the filter state belongs to the server's query model, not a local boolean. Optimistic updates for recurring edits create a mutation surface where the undo cost is extremely high: a recurring edit applied optimistically could silently propagate to every occurrence before the server rejects it.

The proposal also carries two structural liabilities that compound these risks: boolean loading/error state that cannot express intermediate conditions, and custom `div` buttons that remove native semantics before the first user interaction.

---

### Boundary and State Model

**Server/client boundary placement**

The scheduling dashboard should be a Server Component tree by default, with Client Component islands only where live interaction is unavoidable.

```
SchedulingDashboardPage       // Server Component
├── PermissionGate            // Server Component - reads session/role
├── FilterBar                 // Client Component island - interactive
├── ScheduleTable             // Server Component - renders rows
│   ├── RecurringEditModal    // Client Component island - mutation surface
│   └── TableRow              // Server Component
└── StatusBanner              // Server Component
```

Why this boundary works:
- Role-based visibility is resolved server-side before any HTML reaches the client. A viewer role never receives the editor controls in the payload.
- The table is rendered server-side, which means filter changes are real navigations or fetches against server state, not client array transformations.
- Client Component islands are narrow: the filter bar (interactive), the recurring-edit modal (mutation), and any real-time status widget you add later.

**State ownership**

Replace separate boolean flags with a discriminated union. Booleans cannot express the full status space and they create impossible combinations (`isLoading: true, isError: true`).

```typescript
type FetchState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T }
  | { status: 'error'; error: Error; retryable: boolean };
```

For the filter bar, treat filter state as URL search params, not component state. This gives you shareable links, server-readable filter values on navigation, and free back-button support.

```typescript
// Filter changes become navigations, not setState calls
const router = useRouter();
const handleFilterChange = (key: string, value: string) => {
  const params = new URLSearchParams(searchParams);
  params.set(key, value);
  router.push(`?${params.toString()}`);
};
```

For mutation state inside the recurring-edit modal, use `useActionState` (React 19 / Next.js 15) rather than manual loading booleans. The mutation lifecycle becomes a named state machine.

---

### Rendering and Mutation Strategy

**Rendering model: PPR (Partial Prerendering) where available, otherwise static shell + streaming**

The schedule table can be static-shell-rendered with a Suspense boundary wrapping the data-dependent rows. The filter bar hydrates as a Client Component island. This means first paint is fast even when the data fetch is slow, and the permission gate runs server-side before content appears.

```tsx
// Page-level Suspense shell
export default function SchedulingPage() {
  return (
    <PermissionGate requiredRole="viewer">
      <FilterBar />
      <Suspense fallback={<TableSkeleton />}>
        <ScheduleTable />
      </Suspense>
    </PermissionGate>
  );
}
```

**Recurring edits: drop optimistic updates**

This is the highest-risk item in the proposal. Optimistic updates are appropriate when the cost of being wrong is low and reverting is cheap. Recurring edits fail both tests.

A safer mutation path:

1. User opens the recurring-edit modal and selects scope: this occurrence, following occurrences, or all occurrences.
2. On submit, the server action validates the scope against the user's role and the recurrence rule.
3. The UI shows a loading state (pending via `useFormStatus`) while the server processes.
4. On success, the router refreshes the server-rendered table.
5. On failure, the modal stays open with an inline error. The table is untouched.

```typescript
// Server action - scope validation happens server-side
async function updateRecurringEvent(formData: FormData) {
  'use server';
  const scope = formData.get('scope'); // 'this' | 'following' | 'all'
  const userId = await getSessionUser();
  
  if (!canEditRecurring(userId, scope)) {
    return { status: 'error', message: 'Insufficient permissions for this scope' };
  }
  
  await db.updateRecurring({ scope, data: parseFormData(formData) });
  revalidatePath('/scheduling');
}
```

No optimistic state. The table only updates after the server confirms. The cost of showing a spinner for 300ms is immeasurably lower than the cost of rolling back a silently propagated recurring edit.

---

### Accessibility and Semantic Contract

**Filter chips: replace `div` buttons with native elements**

A `div` with an `onClick` handler is not a button. It has no keyboard activation, no `role`, no implicit `tabindex`, no focus behavior, and no announcement to assistive technology. The fix is not `role="button"` on a div. The fix is a `<button>` element.

```tsx
// Replace this
<div onClick={() => setFilter(value)} className="chip">
  {label}
</div>

// With this
<button
  type="button"
  onClick={() => handleFilterChange(key, value)}
  aria-pressed={activeFilters.includes(value)}
  className={cn('chip', activeFilters.includes(value) && 'chip--active')}
>
  {label}
</button>
```

`aria-pressed` makes the toggle state machine-readable. Screen readers will announce "Unassigned, toggle button, pressed" or "pressed" state without extra work.

**Table accessibility**

A table-heavy screen needs explicit semantic table markup. No `div` grid for tabular comparison data.

```tsx
<table>
  <caption className="sr-only">Schedule for {dateRange}</caption>
  <thead>
    <tr>
      <th scope="col">Event</th>
      <th scope="col">Time</th>
      <th scope="col">Assignee</th>
      {canEdit && <th scope="col">Actions</th>}  {/* conditional column, server-gated */}
    </tr>
  </thead>
  <tbody>
    {rows.map(row => <ScheduleRow key={row.id} row={row} />)}
  </tbody>
</table>
```

The `Actions` column is conditionally rendered server-side based on role. A viewer never receives the column markup, so there is nothing to hide with CSS and nothing to expose if client-side auth is bypassed.

**Modal focus management**

The recurring-edit modal needs:
- Focus moved to the modal heading or first interactive element on open
- Focus trapped inside while open
- Focus returned to the trigger button on close
- `role="dialog"` with `aria-labelledby` pointing to the modal heading
- `aria-modal="true"` to hide background content from assistive technology

```tsx
<dialog
  ref={dialogRef}
  aria-labelledby="recurring-edit-title"
  aria-modal="true"
  onClose={() => triggerRef.current?.focus()}
>
  <h2 id="recurring-edit-title">Edit Recurring Event</h2>
  {/* ... */}
</dialog>
```

Using the native `<dialog>` element gives you focus trapping, `Escape` to close, and backdrop semantics without