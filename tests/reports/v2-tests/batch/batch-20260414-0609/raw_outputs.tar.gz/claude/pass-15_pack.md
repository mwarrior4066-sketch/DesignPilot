# Backend Architecture Spec: Multi-Tenant Scheduling Platform

**Route:** `backend_architecture_spec`
**Skills:** `back-end-systems-architect.md`, `back-end-aware-planner.md`, `api-reliability-security-expert.md`
**Escalation:** compound

---

## 1. System Framing

This spec covers a multi-tenant scheduling platform with team workspaces, approval workflows, activity feeds, outbound webhooks, regional data residency, audit trails, and a future automation rules engine. The existing foundation is REST APIs on a relational database, with inconsistent background jobs and no formal eventing layer.

The architectural work here is not additive. The inconsistent job and eventing layer is a system-integrity problem: without a durable, auditable event spine, the activity feed, audit trail, webhooks, and future automation rules all become independently brittle. The core decision is to build a shared transactional outbox as the single authority for state-change propagation, rather than letting each domain emit side effects opportunistically.

**Actors and resources:**

| Actor | Resources owned | Key actions |
|---|---|---|
| Platform operator | Tenants, regions, billing | Provision, suspend, enforce residency |
| Workspace admin | Workspace settings, members, policies | Invite, revoke, configure approval rules |
| Workspace member | Schedules, submissions, approvals | Create, submit, approve, cancel |
| Automation engine (future) | Triggers, rule definitions, actions | Evaluate conditions, emit actions |
| Webhook subscriber | Webhook endpoints, delivery logs | Register, receive, replay |

---

## 2. Core Services and Boundaries

Define six service domains with hard ownership boundaries. These are logical domains first; whether they run as microservices or modules in a monolith is a deployment decision that should not be forced now.

### 2.1 Tenant and Identity Service

**Owns:** tenant records, workspace memberships, roles, regional assignments, feature flags.

**Source of truth for:** who exists, what workspace they belong to, what role they carry.

The tenant record holds the `region_code` that governs data residency routing. All writes to tenant-scoped data must be rejected at the API layer if the originating request is not routed to the correct regional deployment. This is not an application hint — it is an enforcement boundary.

Authorization model: **ReBAC (relationship-based access control).** Roles are not flat strings on a user record. Permission evaluation must traverse the membership graph: a user is an admin of workspace W because they hold the `workspace_admin` edge, not because a boolean flag is true. This matters for approval workflows and automation rules, both of which must check effective permission at the point of action, not at the point of invitation.

```
tenant
  ├── id, region_code, plan_tier, suspended_at
  └── workspace
        ├── id, tenant_id, settings, created_at
        └── workspace_member
              ├── user_id, workspace_id, role, invited_by, revoked_at
```

Soft-delete and revocation must be time-stamped and immutable. Revocation does not delete records — it sets `revoked_at`. The audit trail depends on this.

### 2.2 Scheduling Core

**Owns:** schedule definitions, slots, submissions, recurrence rules.

**Source of truth for:** what was scheduled, who submitted, what state a submission is in.

State machine per submission:

```
draft → submitted → pending_approval → approved → confirmed
                  ↘ rejected
                  ↘ withdrawn
```

State transitions are the only write surface for submissions. No direct field patches. Each transition is recorded as an immutable event via the outbox (see section 3). This matters for the audit trail: the audit trail is not a separate observer — it is derived from the transition log.

Recurrence rules follow iCalendar RRULE semantics. Do not implement a custom recurrence language. Expansion is lazy: store the rule, expand the next N occurrences on demand, materialize only confirmed instances.

### 2.3 Approval Workflow Service

**Owns:** approval policy definitions, approval chain state, approval decisions.

**Source of truth for:** what approvals are required before a submission moves to confirmed.

Approval policies are workspace-scoped and versioned. A policy version is immutable once any submission references it. If a workspace admin changes the approval chain, pending submissions continue under the policy version they started with. This is not optional — it is the correctness invariant for audit.

Approval chain example:
```
policy_v2:
  steps:
    - step: 1, requires: any_of [role: team_lead], ttl: 48h
    - step: 2, requires: any_of [role: workspace_admin], ttl: 24h
  on_ttl_expiry: escalate | auto_approve | cancel  ← must be defined per policy
```

TTL expiry transitions must be driven by the scheduler (section 3.4), not by a lazy check on read. A submission should not discover it has expired; the system should have already transitioned it.

### 2.4 Activity Feed Service

**Owns:** per-workspace activity records, cursor state.

**Source of truth for:** what happened in this workspace and in what order.

The feed is a projection of the outbox event stream, not a primary write surface. Feed records are append-only and keyed by a monotonic `feed_sequence` per workspace. Do not use timestamps as sort keys — clock skew across replicas makes timestamp ordering unsafe for a consistent cursor.

Cursor-based pagination contract:

```
GET /workspaces/{id}/feed?after={cursor}&limit={n}
→ { items: [...], next_cursor: "...", has_more: bool }
```

`cursor` encodes the last `feed_sequence` seen, not a page number or timestamp. The feed must be stable under concurrent writes — a client polling with the same cursor must always get the same results for already-committed events.

**Fan-out strategy:** the outbox worker writes to the workspace feed table after the event commits. Do not write to the feed inside the originating transaction — feed fan-out is an eventually-consistent projection. Latency target for feed visibility should be defined explicitly (e.g., p99 < 2s) and monitored, not assumed.

### 2.5 Webhook Delivery Service

**Owns:** webhook endpoint registrations, delivery jobs, delivery logs, retry state.

**Source of truth for:** what was sent to customer systems, when, and whether it succeeded.

Webhook delivery is decoupled from event creation. The outbox worker reads committed events, hydrates a payload, and enqueues a delivery job. The delivery job owns retry semantics independently of the originating event.

Delivery contract per webhook:

```
POST {customer_url}
Headers:
  X-Webhook-Signature: hmac-sha256({payload}, {signing_key})
  X-Idempotency-Key: {event_id}:{endpoint_id}:{attempt_number}
  X-Trace-ID: {trace_id}
Body: application/json (typed payload per event_type)
```

**Retry posture:** exponential backoff with jitter, max 5 attempts, TTL 24h. After final failure, mark endpoint as `degraded` and notify workspace admin. Do not silently discard. Do not retry infinitely — that is an operational liability.

**Replay:** support manual replay of a delivery window by event type and time range. Replay must reuse the original `event_id` and set a new `attempt_number`. Replay does not re-run the originating event — it re-sends the already-committed payload.

**Signing key rotation:** workspace admins rotate keys. Old key remains valid for a 15-minute grace window to allow in-flight deliveries to complete. Both keys are simultaneously valid during rotation.

### 2.6 Audit Trail Service

**Owns:** immutable audit records per tenant.

**Source of truth for:** the authoritative log of who did what, when, under which policy version.

The audit trail is a compliance artifact. It must not be writable from application code after initial creation. The write path is the outbox worker only. Application code emits events to the outbox; the audit trail derives from those events.

Audit record shape:

```json
{
  "audit_id": "...",
  "tenant_id": "...",
  "workspace_id": "...",
  "actor_id": "...",
  "actor_role_snapshot": "team_lead",
  