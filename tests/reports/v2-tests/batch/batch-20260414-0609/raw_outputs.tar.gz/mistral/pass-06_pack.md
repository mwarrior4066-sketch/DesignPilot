**Mode:** STRATEGY | **Phase:** brand | **Route:** `brand_positioning_pass`
**Supporting Skills:** brand-strategy-expert, content-and-case-study-expert

---

### **Audience & Problem**
Freelancers (1099 workers) need banking that *feels* like it’s built for them—not shoehorned into a corporate product. They distrust traditional banks (slow, opaque, penalizing) but also fear fintech "innovation" that’s just slick marketing without real protections. **Core tension:** They want a partner who *gets* their irregular cash flow and tax headaches, not a faceless institution or a trendy app that disappears when things get messy.

---

### **Positioning Territory: "The Freelancer-First Back Office"**
**Frame of reference:** Not a bank, not a "neobank"—a *back office* that handles the financial grunt work so freelancers can focus on their craft.

**Wedge against competitors:**
- **Stripe/Mercury:** Built for startups/scale-ups. Freelancers feel like an afterthought (e.g., no granular tax tools, rigid cash flow assumptions).
- **Relay:** "Small business banking" is too broad. Freelancers don’t see themselves as "businesses"—they’re individuals with unique needs (e.g., quarterly taxes, unpredictable income).
- **Traditional banks:** Slow, opaque, and designed for W-2 employees. Freelancers associate them with frustration (e.g., holds on deposits, hidden fees).

**Why this works:**
- **Trust signal:** "Back office" implies reliability, structure, and expertise—without the coldness of "bank."
- **Approachability:** Positions the startup as a *partner* (like a virtual CFO or accountant) rather than a service provider.
- **Differentiation:** Freelancers *already* think of their finances as a "back office" problem. This reframes banking as a *solution* to that pain, not another tool to manage.

---

### **Trust & Proof Burden**
**Claim:** "We’re the only banking platform built *exclusively* for freelancers—by people who’ve been there."
**Proof required:**
1. **Freelancer DNA:** Founders/team are freelancers (or ex-freelancers). Product decisions are shaped by real user pain (e.g., tax withholding, invoice tracking).
2. **No B.S. Transparency:** Clear pricing (no hidden fees), real-time cash flow insights, and proactive alerts (e.g., "You’re on track for quarterly taxes").
3. **Defensible Features:**
   - **Tax Engine:** Auto-calculates quarterly taxes, suggests withholdings, and integrates with accounting tools (e.g., QuickBooks, Wave).
   - **Cash Flow Buffer:** Predicts lean months and suggests savings goals (e.g., "Set aside 30% for taxes this month").
   - **Freelancer-Focused Support:** Live chat with *actual* freelancers (not scripted reps), plus a community forum for peer advice.

**Avoid:**
- Generic "neobank" claims (e.g., "better than your bank").
- Over-indexing on "cool" design (freelancers care more about *function* than aesthetics).
- Assuming all freelancers are the same (e.g., designers vs. developers vs. consultants have different needs).

---

### **Messaging Consequences**
**Tone:** *Practical, no-nonsense, but warm.* Like a trusted colleague who’s been through the freelance grind.
**Language guardrails:**
- **Do:**
  - "We handle the financial stuff so you can focus on your work."
  - "No corporate jargon. No hidden fees. Just banking that *gets* freelancers."
  - "Built for the way you work—not the way banks *wish* you worked."
- **Don’t:**
  - "Revolutionizing banking" (too vague).
  - "The future of money" (too Silicon Valley).
  - "Banking, but better" (too generic).

**Tagline options:**
- *"The back office your freelance business deserves."*
- *"Banking that works as hard as you do."*
- *"Freelancers first. Banks never."*

---

### **Tradeoffs**
**Preserve:**
- **Trustworthiness:** No gimmicks (e.g., crypto, flashy rewards). Focus on reliability and transparency.
- **Freelancer specificity:** Avoid diluting the product for "small businesses" or startups.

**Sacrifice:**
- **Mass appeal:** This isn’t for W-2 employees or corporations. Lean into the niche.
- **Trendy features:** No "social banking" or gamification. Freelancers want *utility*, not distractions.

---

### **Next Steps**
1. **Validate the wedge:** Test the "back office" framing with freelancers (e.g., "Does this resonate more than ‘banking’?").
2. **Sharpen the proof:** Highlight 1–2 "hero features" that competitors can’t easily copy (e.g., tax engine, cash flow buffer).
3. **Refine the voice:** Audit all touchpoints (website, emails, support) to ensure they sound like a *partner*, not a bank.