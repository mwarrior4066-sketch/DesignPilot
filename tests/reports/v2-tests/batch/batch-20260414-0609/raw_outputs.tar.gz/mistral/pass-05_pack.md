Here’s a **PDF Remediation Plan** that preserves the two-column layout while fixing screen-reader accessibility, reading order, and export fidelity.

---

### **Current Failure State**
- **Reading order**: Pull quotes and decorative images interrupt the logical flow, breaking screen-reader navigation.
- **Tagging**: Missing semantic tags (`<H1>`, `<P>`, `<Figure>`, `<Caption>`) and decorative images are not marked as artifacts.
- **Table of contents (TOC)**: Hyperlinks are broken, likely due to incorrect anchor tags or export settings.
- **Export fidelity**: Text extraction fails due to ligatures, missing Unicode mappings, or incorrect OCR layers.

---

### **Remediation Sequence**
*(Ordered to preserve layout while fixing semantics)*

1. **Tagging Pass**
   - **Headers**: Retag all headings (`<H1>`–`<H6>`) to match visual hierarchy.
   - **Body text**: Ensure `<P>` tags wrap paragraphs; split columns into separate `<Span>` groups if needed.
   - **Pull quotes**: Tag as `<Quote>` with `aria-label="pull quote"` to distinguish from body text.
   - **Decorative images**: Mark as artifacts (`<Artifact>`) to exclude from reading order.
   - **Figures/captions**: Tag images with `<Figure>` and `<Caption>`; add alt text for informative images.

2. **Reading Order Repair**
   - **Two-column flow**: Use the **Order Panel** in Adobe Acrobat to reorder content left-to-right, top-to-bottom (not column-by-column).
   - **Pull quotes**: Move them *after* the paragraph they reference in the reading order (or use `aria-flowto` to link them).
   - **TOC links**: Rebuild hyperlinks by:
     - Verifying anchor tags in InDesign (or re-exporting with "Create Tagged PDF" enabled).
     - Manually fixing broken links in Acrobat’s **Link Tool**.

3. **Text Layer Validation**
   - **Unicode check**: Ensure ligatures (e.g., "ﬁ") are mapped to standard characters.
   - **OCR layer**: If present, remove it (OCR can corrupt text extraction).
   - **Copy-paste test**: Verify extracted text matches the visual layout.

4. **TOC and Navigation**
   - **Bookmarks**: Add bookmarks for all headings to enable screen-reader navigation.
   - **Link validation**: Test all TOC links in Acrobat’s **Navigation Pane**.

5. **Final Verification**
   - **Screen-reader test**: Use NVDA/JAWS to confirm logical reading order.
   - **Accessibility check**: Run Acrobat’s **Full Check** (WCAG 2.1 AA) and fix flagged issues.
   - **Export test**: Copy-paste text into a plain document to verify fidelity.

---

### **Risk Controls**
- **Preserve layout**: Avoid flattening or rasterizing the PDF (this destroys semantics).
- **No OCR-first shortcuts**: OCR should only be used if the text layer is missing (not for remediation).
- **Backup**: Save a copy of the original PDF before making structural changes.

---

### **Verification Checklist**
| Task                          | Tool/Method                          | Pass/Fail |
|-------------------------------|--------------------------------------|-----------|
| Reading order                 | Acrobat Order Panel + Screen Reader  | ✅/❌      |
| Tagging accuracy              | Acrobat Tags Panel                   | ✅/❌      |
| TOC links                     | Acrobat Link Tool                    | ✅/❌      |
| Text extraction               | Copy-paste test                      | ✅/❌      |
| Decorative images             | Marked as artifacts                  | ✅/❌      |
| WCAG compliance               | Acrobat Full Check                   | ✅/❌      |

---

### **Tradeoffs**
- **Preserved**: Two-column layout, visual hierarchy, and pull-quote styling.
- **Sacrificed**: Decorative images are hidden from screen readers (required for accessibility).
- **Flexible**: Pull-quote placement in reading order (can be adjusted based on user testing).

---

### **Next Steps**
1. **Quick fix**: Use Acrobat’s **Auto-Tag** tool, then manually correct reading order and TOC links.
2. **InDesign re-export**: If possible, regenerate the PDF from InDesign with "Create Tagged PDF" enabled and verify anchor tags.
3. **Professional remediation**: For large documents, use a tool like [CommonLook](https://commonlook.com/) or [axesPDF](https://www.axes4.com/).