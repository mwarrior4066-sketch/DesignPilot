Mode: REBUILD | Phase: implementation | Route: `layout_reconstruction_plan`

---

### **Source Constraints (What Must Be Preserved)**
From the 2018 PDF, we’ll treat these as *non-negotiable* geometry:
- **Margins**: Left/right/top/bottom values (e.g., "20mm margins on all sides").
- **Columns**: Number of columns (e.g., 12-column grid) and gutter width (e.g., "8mm gutters").
- **Baseline grid**: If specified (e.g., "4mm baseline increment"), this will anchor vertical rhythm.
- **Safe zones**: Any marked "live areas" or bleed boundaries for print/digital.
- **Breakpoints**: If the PDF includes responsive examples (e.g., "mobile: 8 columns, desktop: 12 columns"), these are preserved as *inferred* breakpoints.

**Confidence note**: Grid diagrams in PDFs are *observed* evidence, but column behavior (e.g., span rules) may be *inferred* unless explicitly labeled.

---

### **Reconstruction Assumptions (What We’ll Infer)**
1. **Span logic**:
   - If the PDF shows examples of components spanning 4/6/12 columns, we’ll assume a proportional span system (e.g., "spans must align to 1/3 or 1/2 of the grid").
   - *Confidence*: Medium (visible in examples but not always documented).

2. **Responsive behavior**:
   - If the PDF lacks breakpoint specs, we’ll default to:
     - **Desktop**: 12 columns (preserved from the PDF).
     - **Tablet**: 8 columns (common convention unless contradicted).
     - **Mobile**: 4 columns (stacked or fluid).
   - *Confidence*: Low (assumed unless the PDF proves otherwise).

3. **Vertical rhythm**:
   - If no baseline grid is specified, we’ll derive one from:
     - Body text leading (e.g., 1.5× font size).
     - Common denominator of spacing units (e.g., "all spacing multiples of 4px").
   - *Confidence*: Medium (inferred from typography examples).

4. **Legacy-to-modern translation**:
   - **Print → Digital**: Replace fixed mm/inch units with `rem`/`px` (e.g., "20mm margin → 32px at 16px base").
   - **Static → Dynamic**: Add fluid constraints (e.g., "max-width: 1200px") to prevent over-expansion.

---

### **Rebuild Sequence (Ordered Plan)**
1. **Extract geometry**:
   - Measure margins, columns, and gutters from the PDF using a ruler or digital tool (e.g., Adobe Acrobat’s measurement tool).
   - Document values in a *normalized spec* (e.g., "Desktop: 12 columns, 8mm gutters, 20mm margins").

2. **Define the grid system**:
   - **CSS Grid/Figma**: Recreate the 12-column layout with:
     ```css
     .container {
       display: grid;
       grid-template-columns: repeat(12, 1fr);
       gap: 16px; /* 8mm gutter → 16px */
       padding: 32px; /* 20mm margin → 32px */
       max-width: 1200px;
     }
     ```
   - **Breakpoints**: Add media queries for tablet/mobile if inferred.

3. **Test span logic**:
   - Rebuild 2–3 example layouts from the PDF (e.g., a hero section spanning 12 columns, a 3-column card grid).
   - Verify alignment with the original.

4. **Vertical rhythm**:
   - Set a baseline grid (e.g., `line-height: 1.5;`) and align all spacing to it.
   - Example:
     ```css
     :root {
       --spacing-unit: 1rem; /* 16px */
       --baseline: calc(var(--spacing-unit) * 1.5);
     }
     ```

5. **Validation checkpoints**:
   - **Overlay test**: Superimpose the new grid on the PDF examples to check alignment.
   - **Edge cases**: Test extreme widths (e.g., 300px vs. 1920px) to ensure the system holds.
   - **Accessibility**: Confirm gutters meet minimum touch-target sizes (e.g., ≥ 8px).

---

### **Risk Controls (Avoiding Drift)**
- **Destructive edits**: Do not flatten/rasterize the PDF—preserve vector paths for measurement.
- **Copy-paste damage**: Rebuild the grid in code/design tools *from scratch* to avoid inheriting PDF artifacts (e.g., hidden layers, incorrect DPI).
- **Silent geometry errors**: Use a *grid overlay tool* (e.g., Figma’s grid overlay, CSS `outline`) to visualize the system during rebuild.

---

### **Evidence Artifacts**
| Class | Example |
|-------|---------|
| **Implementation constraint** | "Margins must remain 20mm (32px) to preserve live area." |
| **Comparison artifact** | "Original PDF shows a 12-column hero; rebuilt version matches at 1200px width." |
| **Verification method** | "Overlay test confirms column alignment within ±1px tolerance." |
| **Visual structure rule** | "All components must align to the 4px baseline grid." |

---

### **Next Steps**
1. **Share the PDF**: Upload it for precise measurement (or provide screenshots of the grid diagrams).
2. **Clarify priorities**:
   - Should the new system prioritize *exact fidelity* to the PDF or *flexibility* for modern use cases (e.g., fluid typography)?
   - Are there legacy components (e.g., headers, footers) that must be preserved?
3. **Output format**:
   - **Code**: CSS/SCSS variables for the grid system.
   - **Design**: Figma/Adobe XD template with the reconstructed grid.
   - **Spec**: A markdown doc with measurements, assumptions, and validation rules.