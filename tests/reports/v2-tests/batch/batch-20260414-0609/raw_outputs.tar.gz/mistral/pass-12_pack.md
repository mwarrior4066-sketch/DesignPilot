Mode: **REBUILD** | Phase: **tokens** | Route: **type_system_recommendation**
Loaded skills: `type-system-expert`, `accessibility-feedback-expert`, `ui-system-expert`

---

### **Reading Context**
- **Marketing site**: long-form, trust-building, conversion-focused
- **Web app dashboard**: dense financial tables, KPIs, filters, real-time updates
- **Mobile**: small screens, touch targets, glanceable data
- **Trust & modernity**: must feel authoritative yet approachable, avoiding both sterile corporate stiffness and trendy over-friendliness

---

### **Scale & Role Map**
| Role               | Desktop Size | Mobile Size | Weight | Line Height | Use Case                                                                 |
|--------------------|--------------|-------------|--------|-------------|--------------------------------------------------------------------------|
| **Display**        | 48–64px      | 32–40px     | 700    | 1.1         | Hero headlines, key metrics (e.g., "$12,456.78")                        |
| **Heading 1**      | 32px         | 24px        | 600    | 1.2         | Section titles (e.g., "Accounts Overview")                              |
| **Heading 2**      | 24px         | 20px        | 500    | 1.3         | Sub-sections (e.g., "Recent Transactions")                              |
| **Heading 3**      | 20px         | 18px        | 500    | 1.4         | Table headers, card titles                                              |
| **Body**           | 16px         | 16px        | 400    | 1.5         | Default text, descriptions, tooltips                                    |
| **Label**          | 14px         | 14px        | 500    | 1.4         | Form labels, button text, tab labels                                    |
| **Meta**           | 12px         | 12px        | 400    | 1.4         | Timestamps, footnotes, legal disclaimers                                |
| **Data (Table)**   | 15px         | 15px        | 400    | 1.4         | Table cells (optimized for readability in dense grids)                  |
| **Data (Highlight)** | 18px       | 16px        | 600    | 1.3         | Key figures (e.g., account balances, % changes)                         |

---

### **Readability Rules**
1. **Line Length**:
   - Body: 45–75 characters (desktop), 35–55 characters (mobile).
   - Tables: Fixed-width columns to prevent text wrapping in financial data.
2. **Contrast**:
   - Body/Headings: ≥4.5:1 (WCAG AA) against backgrounds.
   - Meta/Legal: ≥3:1 (WCAG AA for non-text).
3. **Tracking**:
   - Body: +5 tracking for all-caps labels (e.g., "ACCOUNT NUMBER").
   - Data: -5 tracking for numeric strings (e.g., "1234567890") to improve scanability.
4. **Emphasis**:
   - **Bold (600)**: Key metrics, warnings, or interactive elements (e.g., buttons).
   - **Regular (400)**: Default text; avoid overusing bold in dense tables.
   - **Italics**: *Only* for legal disclaimers or secondary notes (not for emphasis).

---

### **Typeface Recommendations**
#### **Primary System: [Inter](https://rsms.me/inter/) (Variable)**
- **Why**:
  - Designed for UI/dashboards; excellent legibility at small sizes.
  - Open-source, free for commercial use.
  - Supports `opsz` (optical sizing) for better readability across sizes.
  - Multiple weights (300–900) for hierarchy.
  - Neutral yet modern; avoids "banker font" clichés.
- **Fallback Stack**:
  ```css
  font-family: 'Inter var', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  ```
- **Variable Font Setup**:
  ```css
  @font-face {
    font-family: 'Inter var';
    src: url('Inter.var.woff2') format('woff2-variations');
    font-weight: 100 900;
    font-display: swap;
  }
  body {
    font-variation-settings: 'opsz' 14; /* Optical size for body text */
  }
  ```

#### **Alternative: [IBM Plex Sans](https://www.ibm.com/plex/) (Variable)**
- **Why**:
  - Trustworthy, corporate-friendly, but not stiff.
  - Strong tabular numbers (critical for financial data).
  - Supports `opsz` and multiple weights.
- **Fallback Stack**:
  ```css
  font-family: 'IBM Plex Sans var', 'Helvetica Neue', Arial, sans-serif;
  ```

#### **Display Option: [Manrope](https://manropefont.com/) (Variable)**
- **Why**:
  - More contemporary feel; good for marketing headlines.
  - Rounded terminals soften the "finance" aesthetic.
  - Pair well with Inter for a modern contrast (e.g., Manrope for headlines, Inter for body).

---

### **Adoption Guidance**
1. **Phase 1 (Tokens)**:
   - Define CSS variables for sizes, weights, and line heights (e.g., `--text-body`, `--text-data-highlight`).
   - Use `rem` units for scalability (e.g., `1rem = 16px`).
2. **Phase 2 (Typography Components)**:
   - Create reusable components for headings, body text, and data tables.
   - Example:
     ```jsx
     <Text variant="heading2" as="h2">Recent Transactions</Text>
     <DataTable>
       <DataCell variant="highlight">$1,234.56</DataCell>
     </DataTable>
     ```
3. **Phase 3 (Dark Mode)**:
   - Test contrast ratios in dark mode (e.g., `#E0E0E0` for body text on `#121212`).
   - Use `prefers-color-scheme` media queries or a theme toggle.
4. **Phase 4 (Mobile Optimization)**:
   - Increase touch targets for labels/buttons (e.g., `min-height: 48px`).
   - Reduce font sizes for mobile *only* where necessary (e.g., table headers).

---

### **Trust & Modernity Enhancements**
1. **Hierarchy**:
   - Use **weight (600)** for key metrics (e.g., account balances) to draw attention without color reliance.
   - Reserve **color** for status (e.g., red for negative values, green for positive) but *always* pair with weight.
2. **Data Readability**:
   - Tabular numbers: Use `font-variant-numeric: tabular-nums` for alignment in tables.
   - Example:
     ```css
     .financial-data {
       font-variant-numeric: tabular-nums;
     }
     ```
3. **Legal Text**:
   - Use **12px meta text** with +10% tracking for disclaimers to improve scanability.
   - Example:
     ```css
     .legal-text {
       font-size: 0.75rem;
       letter-spacing: 0.05em;
       line-height: 1.4;
     }
     ```
4. **Micro-Interactions**:
   - Subtle weight changes on hover/focus (e.g., `400 → 500`) for interactive elements.

---

### **Verification Checklist**
| Check                | Method                                                                 |
|----------------------|------------------------------------------------------------------------|
| Contrast             | [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/) |
| Line Length          | Measure characters in browser dev tools.                              |
| Tabular Numbers      | Test alignment in a dense financial table.                            |
| Mobile Legibility    | Simulate iPhone/Android screens in Chrome DevTools.                   |
| Dark Mode            | Toggle system preference or theme switcher.                           |
| Variable Font        | Test `opsz` and weight ranges in [Axis-Praxis](https://www.axis-praxis.org/). |

---

### **Tradeoffs**
- **Preserved**:
  - Trustworthiness (via neutral typefaces like Inter/IBM Plex).
  - Data readability (tabular numbers, contrast, tracking).
- **Sacrificed**:
  - "Trendy" aesthetics (e.g., rounded fonts like Manrope are used sparingly).
  - Overly decorative weights (e.g., 900 weight reserved for rare display use).

---

### **Example Code Snippets**
#### CSS Variables:
```css
:root {
  --text-display: 3rem;
  --text-h1: 2rem;
  --text-h2: