Mode: REBUILD | Phase: tokens | Route: `color_system_spec`
Loaded skills: `color-system-expert`, `accessibility-feedback-expert`

---

### **Healthcare SaaS Dashboard Color System**
**Reading context**: Dense-data dashboard (tables, charts, KPIs) with status-critical workflows. Must support:
- **Status roles**: Normal, warning, critical (semantic, not decorative).
- **Dark mode**: Full WCAG AA compliance for text and non-text contrast.
- **Data visualization**: 5+ categorical colors (distinct, non-status-conflicting).
- **Print awareness**: Optional grayscale fallback for reports.

---

### **1. Role Model (Semantic Roles)**
| Role               | Token Alias          | Usage Example                          | WCAG AA Target       |
|--------------------|----------------------|----------------------------------------|----------------------|
| **Surface**        | `--color-surface`   | Backgrounds, cards, modals             | ≥ 3:1 (non-text)     |
| **Surface (dark)** | `--color-surface-d` | Dark mode backgrounds                  | ≥ 3:1 (non-text)     |
| **Text (primary)** | `--color-text`      | Body text, labels, KPIs                | ≥ 4.5:1 (text)       |
| **Text (secondary)** | `--color-text-s`  | Meta text, hints, placeholders         | ≥ 4.5:1 (text)       |
| **Action**         | `--color-action`    | Primary buttons, CTAs                  | ≥ 4.5:1 (text)       |
| **Action (hover)** | `--color-action-h`  | Hover/focus states                     | ≥ 4.5:1 (text)       |
| **Status (normal)** | `--color-status-n` | Healthy metrics, "on track" indicators | ≥ 3:1 (non-text)     |
| **Status (warning)** | `--color-status-w` | At-risk metrics, attention flags       | ≥ 3:1 (non-text)     |
| **Status (critical)** | `--color-status-c` | Alerts, errors, urgent interventions   | ≥ 4.5:1 (text)       |
| **Chart (cat 1)**  | `--color-chart-1`   | Categorical data (e.g., "Admissions")  | ≥ 3:1 (non-text)     |
| **Chart (cat 2)**  | `--color-chart-2`   | Categorical data (e.g., "Discharges")  | ≥ 3:1 (non-text)     |
| **Chart (cat 3)**  | `--color-chart-3`   | Categorical data (e.g., "Readmissions")| ≥ 3:1 (non-text)     |
| **Chart (cat 4)**  | `--color-chart-4`   | Categorical data (e.g., "ER Visits")   | ≥ 3:1 (non-text)     |
| **Chart (cat 5)**  | `--color-chart-5`   | Categorical data (e.g., "ICU Days")    | ≥ 3:1 (non-text)     |
| **Border**         | `--color-border`    | Dividers, input borders                | ≥ 3:1 (non-text)     |

---

### **2. Token Map (Light/Dark Mode)**
#### **Base Palette (HSL for flexibility)**
| Role               | Light Mode (HSL)       | Dark Mode (HSL)        | Notes                                  |
|--------------------|------------------------|------------------------|----------------------------------------|
| **Surface**        | `0°, 0%, 98%` (white)  | `220°, 30%, 12%` (dark blue-gray) | Avoids pure black/white for eye strain. |
| **Surface (alt)**  | `0°, 0%, 95%` (off-white) | `220°, 25%, 15%`     | Subtle contrast for nested surfaces.   |
| **Text (primary)** | `220°, 15%, 20%` (dark gray) | `0°, 0%, 95%` (off-white) | Reduces glare in dark mode.            |
| **Text (secondary)** | `220°, 8%, 45%`      | `0°, 0%, 70%` (light gray) | Meets 4.5:1 with surfaces.             |
| **Action**         | `210°, 90%, 45%` (blue) | `210°, 90%, 60%` (brighter blue) | WCAG AA compliant on surfaces.         |
| **Status (normal)** | `120°, 60%, 40%` (green) | `120°, 50%, 50%` (brighter green) | "Healthy" semantic role.               |
| **Status (warning)** | `30°, 90%, 50%` (orange) | `30°, 90%, 65%` (brighter orange) | Distinct from red/critical.            |
| **Status (critical)** | `0°, 85%, 55%` (red)  | `0°, 90%, 65%` (brighter red) | High contrast for urgency.             |
| **Chart (cat 1)**  | `240°, 70%, 60%` (indigo) | `240°, 70%, 70%`     | Distinct from status colors.           |
| **Chart (cat 2)**  | `180°, 60%, 50%` (teal)  | `180°, 60%, 60%`     |                                        |
| **Chart (cat 3)**  | `300°, 60%, 60%` (purple) | `300°, 60%, 70%`    |                                        |
| **Chart (cat 4)**  | `30°, 70%, 60%` (coral)  | `30°, 70%, 70%`     |                                        |
| **Chart (cat 5)**  | `150°, 60%, 50%` (mint)  | `150°, 60%, 60%`     |                                        |
| **Border**         | `220°, 10%, 80%` (light gray) | `220°, 10%, 30%` (dark gray) | Subtle but visible.                   |

#### **State Mappings**
| State          | Token Override               | Example Use Case               |
|----------------|------------------------------|--------------------------------|
| **Hover**      | `--color-action-h` (lighter) | Button hover/focus.            |
| **Disabled**   | `--color-text-s` (50% opacity) | Disabled buttons/inputs.       |
| **Selected**   | `--color-action` (darker)    | Active tab, selected row.      |
| **Error**      | `--color-status-c`           | Form validation errors.        |
| **Success**    | `--color-status-n`           | Confirmation messages.         |

---

### **3. Contrast and State Rules**
#### **WCAG AA Compliance**
- **Text**: All text roles meet **≥ 4.5:1** against their backgrounds (e.g., `--color-text` on `--color-surface`).
- **Non-text**: Status indicators, charts, and borders meet **≥ 3:1** against surfaces.
- **Dark mode**: Brightness-adjusted to maintain contrast (e.g., `--color-status-c` at 65% lightness in dark mode vs. 55% in light mode).

#### **Non-Color Fallbacks**
- **Status roles**: Pair colors with **icons** (✓, ⚠, ✗) and **labels** ("Normal", "Warning", "Critical").
- **Charts**: Use **patterns** (stripes, dots) or **textures** for grayscale printing.
- **Data viz**: Add **tooltips** with values to ensure readability without color.

#### **Print Awareness**
- **Grayscale fallback**: Test charts in grayscale; adjust saturation if colors blend.
- **Report mode**: Optional high-contrast theme for printed reports (e.g., `--color-status-c` → pure red at 80% opacity).

---

### **4. Migration Notes**
#### **From Current Palette**
| Current Color       | Migration Path                     | Rationale                          |
|---------------------|------------------------------------|------------------------------------|
| `#FF0000` (red)     | `--color-status-c` (semantic)     | Avoids hardcoded colors; supports dark mode. |
| `#00FF00` (green)   | `--color-status-n` (semantic)     | Meets WCAG AA; distinct from charts. |
| `#FFA500` (orange) 