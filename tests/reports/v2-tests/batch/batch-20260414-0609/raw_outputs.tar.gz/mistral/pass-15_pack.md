```text
Mode: STRUCTURE | Phase: specs | Route: backend_architecture_spec
```

# Backend Architecture Spec: Multi-Tenant Scheduling Platform

## System Framing
**Actors & Resources**
- Tenants (organizations) own workspaces, schedules, and approval policies
- Users (team members) act within tenant workspaces with role-based permissions
- Resources: schedules, events, approvals, activity feeds, webhooks, audit logs

**Why Architecture is Needed**
The current REST/relational stack lacks:
- Clear tenant isolation boundaries
- Reliable background job processing
- Event-driven consistency for feeds/webhooks
- Regional data residency controls
- Audit trail immutability
- Extensible automation foundation

## Core Model & Authority Boundaries

### Tenant Isolation Model
- **Source of Truth**: Tenant ID (`tenant_id`) as partition key in all tables
- **Authorization**: ReBAC (Relationship-Based Access Control) with:
  - Tenant memberships (`tenant_users`)
  - Workspace roles (`workspace_roles`)
  - Approval policy rules (`approval_policies`)
- **Data Residency**: Regional routing via `tenant_region` column (values: `us`, `eu`, `apac`)
  - All tenant data (including audit logs) physically stored in designated region
  - Cross-region queries prohibited by middleware

### Domain Boundaries
| Service          | Ownership Scope                          | Key Contracts                          |
|------------------|------------------------------------------|----------------------------------------|
| Scheduling       | Events, schedules, availability          | `POST /schedules`, `GET /availability` |
| Approval         | Approval policies, requests, decisions   | `POST /approvals`, `GET /decisions`   |
| Activity Feed    | Cursor-paginated events                  | `GET /feeds?cursor=...`                |
| Webhooks         | Outbound event delivery                  | `POST /webhooks/subscriptions`         |
| Audit            | Immutable logs                           | `GET /audit?filter=...`                |
| Automation*      | Customer-defined rules (future)          | `POST /automation/rules`               |

*Automation service marked for future implementation but designed for extensibility

## Data, Consistency & Delivery Design

### Consistency Model
- **Scheduling**: Linearizable for same-tenant operations (e.g., conflicting bookings)
- **Activity Feed**: Bounded staleness (≤5s) with revision tokens
- **Webhooks**: At-least-once delivery with idempotency keys
- **Audit**: Strict serializability (append-only)

### Delivery Patterns
1. **Cursor-Based Feeds**
   - `GET /feeds?cursor={opaque_token}&limit=50`
   - Opaque cursor encodes `(tenant_id, event_id, timestamp)`
   - Backward-compatible with future filtering

2. **Webhook Events**
   - Outbox pattern with transactional writes:
     ```sql
     BEGIN;
     INSERT INTO events (tenant_id, event_type, payload) VALUES (...);
     INSERT INTO outbox (event_id, destination_url, status) VALUES (...);
     COMMIT;
     ```
   - Status: `queued` → `delivered` (with retry policy)
   - Idempotency: Client-provided `Idempotency-Key` header

3. **Approval Workflows**
   - State machine with explicit transitions:
     ```
     draft → pending_approval → approved/rejected → scheduled/canceled
     ```
   - Server-side enforcement of tenant-specific policies

### Regional Data Residency
- **Routing**: `tenant_region` column in all tables
- **Middleware**: Region-aware connection pooling
- **Constraints**:
  - No cross-region joins
  - Audit logs co-located with tenant data
  - Webhook delivery respects tenant region

## Observability & Failure Posture

### Operational Tax
| Concern               | Implementation                          | Metrics                          |
|-----------------------|-----------------------------------------|----------------------------------|
| Tenant Isolation      | Row-level security policies             | `tenant_isolation_violations`    |
| Webhook Delivery      | Outbox + retry queue                    | `webhook_delivery_latency`       |
| Approval Latency      | State machine timeouts                  | `approval_decision_latency`      |
| Audit Trail           | Immutable append-only table             | `audit_log_append_failures`      |
| Regional Compliance   | Connection pool routing                 | `cross_region_query_attempts`    |

### Failure Modes & Degradation
1. **Webhook Failures**
   - Retry policy: Exponential backoff (1s → 5m max)
   - Circuit breaker: Open after 5 consecutive failures
   - Fallback: Tenant-configurable dead-letter queue (DLQ)

2. **Approval Timeouts**
   - Default: 48h timeout → auto-reject
   - Tenant override: Configurable per policy

3. **Regional Outages**
   - Read replicas in secondary regions (async replication)
   - Degraded mode: Read-only access to stale data

## Implementation Constraints
- **Database**: PostgreSQL (row-level security for tenant isolation)
- **Background Jobs**: Temporal.io (durable workflows for approvals/webhooks)
- **Eventing**: Kafka (tenant-partitioned topics for feeds/webhooks)
- **Audit Trail**: Immutable append-only table + WAL shipping to cold storage

## Migration Strategy
1. **Phase 1**: Add `tenant_id` and `tenant_region` to all tables
2. **Phase 2**: Deploy outbox pattern for webhooks
3. **Phase 3**: Implement cursor-based feeds with revision tokens
4. **Phase 4**: Enable regional routing middleware

## Open Questions
1. Should automation rules be tenant-scoped or workspace-scoped?
2. How to handle tenant migration between regions (data residency changes)?
3. What’s the acceptable staleness window for cross-region read replicas?

---
**Next Steps**:
1. Review authority boundaries with security team
2. Prototype outbox pattern with Temporal.io
3. Define audit log schema with immutability guarantees