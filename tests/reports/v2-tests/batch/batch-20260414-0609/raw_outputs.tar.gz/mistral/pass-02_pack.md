```text
Mode: REBUILD | Phase: specs | Route: component_spec
```

# Split Button Component Specification

## Purpose and Scope
The split button component provides a primary action (`Save`) and a dropdown menu for secondary actions (`Save as draft`, `Save and close`). It must maintain accessibility, state visibility, and touch target compliance across desktop and mobile.

**Owns:**
- Primary action button
- Dropdown trigger button
- Dropdown menu and its items
- State management (default, hover, focus, disabled, loading)

**Does not own:**
- Modal or dialog behavior triggered by menu items
- Form validation logic
- Backend API calls

---

## Anatomy

1. **Primary Button**
   - Label: `Save` (default)
   - Icon: None (text-only)
   - Action: Triggers the primary `Save` action

2. **Dropdown Trigger Button**
   - Icon: Chevron down (▼)
   - Action: Opens the dropdown menu
   - Aria-label: "More save options"

3. **Dropdown Menu**
   - Items: `Save as draft`, `Save and close`
   - Separator: None (flat list)
   - Keyboard navigation: Arrow keys, `Esc` to close

---

## State Matrix

| State               | Primary Button                     | Dropdown Trigger Button           | Dropdown Menu       |
|---------------------|------------------------------------|-----------------------------------|---------------------|
| **Default**         | Enabled, idle                      | Enabled, idle                     | Closed              |
| **Hover**           | Background: `--color-action-hover` | Background: `--color-action-hover`| N/A                 |
| **Focus**           | Outline: `--color-focus`           | Outline: `--color-focus`          | N/A                 |
| **Disabled**        | Opacity: 50%, cursor: `not-allowed`| Opacity: 50%, cursor: `not-allowed`| N/A                 |
| **Loading**         | Spinner + "Saving..."              | Disabled                          | Closed              |
| **Dropdown Open**   | Enabled                            | Background: `--color-action-active`| Visible             |

---

## Accessibility and Implementation Notes

### Keyboard Support
- **Tab order**: Primary button → Dropdown trigger button.
- **Primary button**:
  - `Enter`/`Space`: Triggers `Save`.
- **Dropdown trigger button**:
  - `Enter`/`Space`: Opens dropdown.
  - `Down Arrow`: Opens dropdown and focuses first menu item.
- **Dropdown menu**:
  - `Arrow keys`: Navigate items.
  - `Enter`: Selects focused item.
  - `Esc`: Closes menu.

### Touch Targets
- Minimum size: **48x48px** for both buttons (WCAG 2.5.5).
- Spacing: **8px** between buttons to prevent accidental taps.

### ARIA Attributes
- **Primary button**: `aria-label="Save"` (redundant for clarity).
- **Dropdown trigger button**: `aria-haspopup="menu"`, `aria-expanded="false"` (toggles to `true` when open).
- **Dropdown menu**: `role="menu"`, `aria-labelledby="[trigger-button-id]"`.
- **Menu items**: `role="menuitem"`.

### Tokens
- **Colors**:
  - `--color-action`: Primary button background.
  - `--color-action-hover`: Hover state.
  - `--color-action-active`: Active state (dropdown open).
  - `--color-focus`: Focus outline.
- **Spacing**:
  - `--spacing-button-group`: `8px` (gap between buttons).
- **Typography**:
  - `--font-button`: Inherits from system.

### Implementation Constraints
- **State ownership**: Use `useActionState` (React) or equivalent to manage loading/error states.
- **Dropdown positioning**: Use `popover="auto"` (or equivalent) to ensure it stays within viewport on mobile.
- **Disabled logic**: Disable both buttons when the parent form is invalid or during loading.

---

## Migration Notes
- Replace existing `ButtonGroup` + `Dropdown` patterns with this component.
- Deprecate standalone "Save" buttons in favor of this split button where secondary actions exist.
- Ensure all `Save`-related actions are consolidated under this component for consistency.

---

## Verification Checklist
1. **Keyboard**: Test tab order, `Enter`/`Space`, arrow navigation, and `Esc`.
2. **Touch**: Verify 48x48px targets and 8px spacing on mobile.
3. **States**: Confirm disabled/loading states disable both buttons.
4. **ARIA**: Validate screen reader announces "Save, button" and "More save options, button" with expanded state.
5. **Tokens**: Ensure colors and spacing match design system.