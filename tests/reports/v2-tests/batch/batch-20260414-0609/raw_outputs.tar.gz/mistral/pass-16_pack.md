Here’s the **API Reliability and Security Review** for `POST /exports`, structured under the governing route `api_reliability_security_review` with supporting evidence classes and required decisions:

---

### **Failure Semantics and Error Contract**
**Problem**: The endpoint uses HTTP 200 for *all* responses (success/failure) and leaks internal enum values in error messages, violating [RFC 9457 (Problem Details)](https://datatracker.ietf.org/doc/html/rfc9457). Clients cannot distinguish transient failures from permanent errors or parse structured diagnostics.
**Required Fix**:
- **Adopt Problem Details**: Return `application/problem+json` with:
  - `type`: URI reference to error documentation (e.g., `/errors/export-timeout`).
  - `title`: Human-readable summary (e.g., "Export generation timed out").
  - `status`: Matching HTTP status code (e.g., `408 Request Timeout`, `429 Too Many Requests`, `500 Internal Server Error`).
  - `detail`: Specific failure reason (e.g., "PDF generation exceeded 3-minute limit").
  - `instance`: Unique request ID for tracing.
- **Example**:
  ```json
  {
    "type": "/errors/export-timeout",
    "title": "Export generation timed out",
    "status": 408,
    "detail": "PDF generation exceeded 3-minute limit. Retry with a smaller dataset or contact support.",
    "instance": "req_12345"
  }
  ```
**Evidence Class**: `failure_semantics_rule` (RFC 9457 compliance).

---

### **Authorization and Resource Protection**
**Problem**: The endpoint lacks explicit resource-level authorization, risking **BOLA (Broken Object Level Authorization)** if exports reference sensitive data (e.g., user reports, financial data).
**Required Fix**:
- **Enforce Object-Level Permissions**:
  - Validate the requesting user’s access to the *source data* (e.g., `user_id` in the export request must match the user’s session or RBAC role).
  - Example: If `/exports` generates a report for `user_id=123`, verify the requester is `user_id=123` or an admin.
- **Deny by Default**: Reject requests for data the user cannot access (e.g., return `403 Forbidden` with Problem Details).
**Evidence Class**: `permission_rule` (BOLA prevention).

---

### **Idempotency and Async Lifecycle**
**Problem**: The endpoint is synchronous (blocks for 3 minutes), has no idempotency key, and lacks a retry-safe contract. Clients may duplicate exports or fail silently.
**Required Fix**:
1. **Async Job Pattern**:
   - Return `202 Accepted` immediately with:
     ```json
     {
       "status_url": "/exports/status/req_12345",
       "idempotency_key": "client-generated-uuid"  // Client-provided
     }
     ```
   - Process the PDF in the background (e.g., queue + worker).
2. **Idempotency Key**:
   - Require clients to send a `Idempotency-Key: <uuid>` header.
   - Reject duplicate requests with `409 Conflict` if the key is reused.
3. **Status Endpoint**:
   - `GET /exports/status/{request_id}` returns:
     ```json
     {
       "status": "queued|running|completed|failed",
       "download_url": "/exports/download/req_12345",  // If completed
       "problem": { ... }  // If failed (Problem Details)
     }
     ```
**Evidence Class**: `async_lifecycle_rule` (retry safety).

---

### **Resilience and Observability**
**Problem**: No resilience mechanisms (e.g., retries, circuit breakers) or observability (e.g., tracing, metrics) exist. Failures are opaque and may cascade.
**Required Fix**:
1. **Resilience**:
   - **Circuit Breaker**: Fail fast if the export service is degraded (e.g., return `503 Service Unavailable`).
   - **Retry Policy**: Clients should retry `408/429/503` with exponential backoff (e.g., 1s, 2s, 4s).
   - **Quota**: Limit concurrent exports per user (e.g., 3 requests/minute).
2. **Observability**:
   - **Trace ID**: Include `trace_id` in all responses (e.g., `req_12345`).
   - **Metrics**: Track:
     - Export success/failure rates.
     - Duration percentiles (p50, p90, p99).
     - Queue depth (if async).
   - **Logs**: Structured logs for debugging (e.g., `{"request_id": "req_12345", "status": "failed", "error": "timeout"}`).
**Evidence Class**: `resilience_rule` (operational safety).

---

### **Summary of Required Decisions**
| Decision ID               | Resolution                                                                 |
|---------------------------|----------------------------------------------------------------------------|
| `problem_details_contract` | Adopt RFC 9457 with `type`, `title`, `status`, `detail`, and `instance`.   |
| `authorization_perimeter`  | Enforce object-level permissions (e.g., `user_id` validation).             |
| `idempotency_contract`     | Require `Idempotency-Key` header; return `202 Accepted` + status endpoint. |
| `async_job_model`          | Move PDF generation to a background queue; provide status endpoint.       |
| `resilience_strategy`      | Add circuit breaker, retry policy, quotas, and observability.             |

---

### **Rebuild Path**
1. **Phase 1**: Async + Idempotency
   - Implement `202 Accepted` + status endpoint.
   - Add `Idempotency-Key` header validation.
2. **Phase 2**: Failure Semantics
   - Replace HTTP 200 errors with Problem Details.
   - Document error types (e.g., `/errors/export-timeout`).
3. **Phase 3**: Authorization
   - Validate `user_id` access to source data.
   - Return `403 Forbidden` for unauthorized requests.
4. **Phase 4**: Resilience
   - Add circuit breaker, retry policy, and metrics.

**Tradeoff**: Async processing adds complexity but improves reliability and user experience. Idempotency keys prevent duplicate exports.

---

### **Verification Method**
- **Test Cases**:
  - Verify `408/429/500` errors return Problem Details.
  - Confirm `Idempotency-Key` rejects duplicates.
  - Check `403 Forbidden` for unauthorized data access.
- **Observability**:
  - Monitor `trace_id` propagation in logs.
  - Validate metrics for export duration and failure rates.

---

### **Evidence Classes Cited**
- `failure_semantics_rule` (RFC 9457).
- `permission_rule` (BOLA prevention).
- `async_lifecycle_rule` (retry safety).
- `resilience_rule` (circuit breaker, metrics).

**Route**: `api_reliability_security_review` (governing).
**Supporting Skills**: `api-reliability-security-expert.md`, `back-end-systems-architect.md`.