Mode: AUDIT | Phase: strategy | Route: `backend_feasibility_review`
Loaded skills: `back-end-aware-planner.md`, `front-end-handoff-expert.md`, `api-reliability-security-expert.md`

---

### **Requested Capability**
Add real-time collaborative editing (Google Docs–style) to a React app currently using REST APIs and PostgreSQL. Requirements:
- Simultaneous multi-user editing with visible cursor positions
- Conflict resolution for concurrent edits
- Persistent document state

---

### **Hidden System Requirements**
1. **Data Model & Ownership**
   - **Document fragments**: Need atomic, versioned units (e.g., characters, paragraphs) to track edits.
   - **User presence**: Track active users, cursors, and selections (ephemeral state).
   - **Ownership boundaries**: Clarify who can edit which parts of a document (e.g., permissions, locks).

2. **Permissions & Auth**
   - **Real-time access control**: Validate edit permissions *per operation* (not just at load time).
   - **Session management**: Authenticate WebSocket connections and tie them to user sessions.

3. **System Surfaces**
   - **WebSocket API**: Replace REST for live updates (requires connection management, reconnection logic).
   - **Operational Transform (OT) or CRDTs**: Conflict resolution for concurrent edits (PostgreSQL lacks native support).
   - **Event sourcing**: Persist edit history for undo/redo and audit trails.
   - **Background jobs**: Clean up stale presence data, merge conflicts, or compact history.

4. **Degraded Modes**
   - **Offline support**: Queue edits locally and sync when reconnected.
   - **Fallback to REST**: If WebSockets fail, allow read-only or single-user editing.

---

### **Feasibility Assessment**
#### **Blockers**
| Blocker | Impact | Mitigation |
|---------|--------|------------|
| **PostgreSQL’s lack of OT/CRDT support** | Concurrent edits may corrupt data. | Use a dedicated collaboration service (e.g., [Yjs](https://github.com/yjs/yjs), [Automerge](https://automerge.org/)) or implement OT/CRDTs in the app layer. |
| **WebSocket scalability** | REST APIs are stateless; WebSockets require persistent connections. | Use a scalable WebSocket server (e.g., [Pusher](https://pusher.com/), [Ably](https://ably.com/)) or a managed service like Firebase. |
| **Conflict resolution complexity** | OT/CRDTs require careful implementation to avoid data loss. | Start with a proven library (e.g., Yjs) and limit scope to text editing first. |
| **Presence state management** | Cursors/selections are ephemeral and high-volume. | Store presence data in Redis (TTL-based) or a dedicated service. |
| **Permission validation latency** | Real-time edits require sub-100ms auth checks. | Cache permissions in Redis or use JWTs with short expiry. |

#### **Assumptions**
- **Document size**: Small to medium (e.g., <100KB). Large documents may require chunking.
- **Concurrency**: <50 simultaneous editors per document. Higher loads need sharding.
- **Latency tolerance**: <200ms for edits to propagate (critical for UX).

---

### **Safer Implementation Path**
#### **Phase 1: Foundation (MVP)**
1. **Data Model**
   - Add a `documents` table with `id`, `content` (JSON for OT/CRDT), and `version`.
   - Add a `document_edits` table (event sourcing) with `document_id`, `user_id`, `operation`, `timestamp`, and `version`.
   - Use Redis for ephemeral presence data (e.g., `{ document_id: { user_id: { cursor: { x, y }, selection: { start, end } } } }`).

2. **API Layer**
   - **WebSocket server**: Use [Socket.IO](https://socket.io/) or [ws](https://github.com/websockets/ws) for bidirectional communication.
   - **Endpoints**:
     - `GET /documents/:id`: Load document (REST fallback).
     - `WS /documents/:id/edit`: Handle real-time edits.
     - `WS /documents/:id/presence`: Broadcast cursor/selection updates.

3. **Conflict Resolution**
   - Integrate Yjs or Automerge for OT/CRDTs. Example:
     ```javascript
     // Pseudocode for Yjs integration
     const yDoc = new Y.Doc();
     const yText = yDoc.getText('content');
     yDoc.on('update', (update) => {
       // Broadcast update to other clients via WebSocket
     });
     ```

4. **Permissions**
   - Validate edits against cached permissions (Redis) or JWTs on WebSocket connection.

5. **Degraded Mode**
   - Fall back to REST for read-only access if WebSockets fail.

#### **Phase 2: Scalability**
1. **WebSocket Load Balancing**
   - Use Redis adapter for Socket.IO to share state across servers.
   - Consider a managed service (e.g., Ably) for global scaling.

2. **Conflict Resolution Optimization**
   - Implement server-side OT/CRDT merging to reduce client load.
   - Add debouncing for high-frequency edits (e.g., cursor movements).

3. **Presence Cleanup**
   - Use Redis TTL to auto-expire stale presence data.

#### **Phase 3: Advanced Features**
1. **Offline Support**
   - Use IndexedDB to queue edits locally and sync on reconnect.

2. **History & Undo/Redo**
   - Persist edit history in PostgreSQL for audit trails.

3. **Large Document Support**
   - Chunk documents into smaller OT/CRDT units.

---

### **Tradeoffs**
| Preserved | Sacrificed | Why |
|-----------|------------|-----|
| REST compatibility | Real-time latency | Phase 1 keeps REST as a fallback. |
| PostgreSQL simplicity | Native OT/CRDT support | Use Yjs/Automerge instead of custom DB logic. |
| Permission granularity | Performance | Cache permissions in Redis to avoid DB lookups. |
| Conflict-free UX | Implementation complexity | OT/CRDTs are complex but necessary for correctness. |

---

### **Verification Checklist**
1. **Data Integrity**
   - Test concurrent edits with 10+ users to ensure no corruption.
   - Verify event sourcing logs match document state.

2. **Performance**
   - Measure WebSocket latency (<200ms) and DB load under concurrent edits.

3. **Permissions**
   - Test edge cases (e.g., revoked permissions mid-edit).

4. **Degraded Mode**
   - Simulate WebSocket failure and verify REST fallback works.

---

### **Next Steps**
1. **Prototype Phase 1** with Yjs + Socket.IO.
2. **Benchmark** latency and DB load with simulated users.
3. **Design the WebSocket API** (e.g., message formats for edits/presence).
4. **Plan Phase 2** based on prototype metrics.