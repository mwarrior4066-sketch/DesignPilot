Here’s a type system recommendation tailored for a fintech product spanning a marketing site, web app dashboard, and mobile. The goal is to unify visual tone and enable functional clarity across varied surfaces, while handling dense tabular data and multi-weight hierarchy.

---

**Reading Context**

This type system covers:
- Marketing site: large headings, eye-catching CTAs, wider line-lengths;
- Web app dashboard: dense tables, filters, data summaries, charts;
- Mobile: smaller display, tighter spacing, variable user focus.

All environments require legible typography under high information density, with accessible contrast and robust numeric rendering for financial data.

---

**Scale and Role Map**

**Primary Typeface Recommendation:**  
**Inter** (variable font, open-source, proven for UI/financial applications).  
_Fallbacks_: system-ui on web, San Francisco (Apple), Roboto (Android).

- **Display/Headline:**  
  - Weight: 700–900 (Bold/ExtraBold)  
  - Size: 32–48px web/marketing, 22–28px mobile
- **Section Heading:**  
  - Weight: 600–700  
  - Size: 24–32px web/app, 18–22px mobile
- **Table Header:**  
  - Weight: 600  
  - Size: 14–16px web/app, 13–15px mobile  
  - Letter spacing: +1–2%
- **Body/Text:**  
  - Weight: 400–500  
  - Size: 16px web/app, 15–16px mobile  
  - Line height: 1.5–1.6  
  - Max line length: ~68 characters for marketing, ~48–60 for web/app
- **Meta/Label/Captions:**  
  - Weight: 400–500  
  - Size: 12–14px  
  - Uppercase styling option for meta  
  - Letter spacing: +2–4%

**Numerals:**  
- Use tabular/lining figure features for numeric columns (OpenType: `tnum`, `lnum`).

---

**Readability Rules**

- All roles must meet WCAG AA contrast against backgrounds.
- For data tables, use minimum 14px, regular or medium weight; avoid below 12px even for captions.
- Restrict line length in dashboards for scanning: ideally 48–60 characters.
- Use clear weight jumps to create hierarchy, not just increased size.
- Enable contextual alternates (`calt`) for smoother numbers where appropriate, but tabular figures as default for financial columns.

---

**Adoption Guidance**

- Begin with Inter variable on all platforms for consistency; fallback to system fonts where embedding isn’t feasible.
- For dense tables, explicitly enable tabular figures via CSS (`font-feature-settings: "tnum" 1, "lnum" 1;`).
- Audit legacy content for contrast, size, and line length compliance before migration.
- Roll out headings and navigation updates first, then main body text and tabular data.

---

**Type System Rationale**

- **Inter** is widely used in fintech, with proven legibility, clarity at small sizes, and robust OpenType feature support (including tabular numbers critical for financial apps).
- System supports all major weights for clear hierarchy.
- Variable font allows for adaptive tuning across surfaces (web, mobile, app).
- Contrast and spacing guidelines future-proof accessibility and maintain trustworthiness.
- Tabular figures ensure numbers align perfectly, aiding rapid scan and audit—a necessity for finance.

**Tradeoff:**  
Inter is neutral and functional, not highly branded—if your visual identity requires more differentiation, consider pairing Inter for UI/data with a more expressive secondary font for large marketing headlines. However, consistency and clarity should win for trust in fintech contexts.

---

**Next Step:**  
Review how current content appears with Inter at recommended roles/sizes, adjust heading/body scaling for your brand’s tone, and test tabular numeric clarity in key dashboard screens before full rollout.

---

Let me know if you want example CSS/token specs or tailored pairings for a secondary display font.
