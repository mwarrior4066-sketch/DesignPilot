Here is a pragmatic color system design for a healthcare SaaS dashboard, addressing your scenario requirements:

---

**Role Model**

A color system for a healthcare dashboard should encode semantic roles: surfaces (backgrounds), text, interactive elements (buttons, links), status (normal, warning, critical), and data categories. All roles must remain visually clear, accessible (WCAG AA for text), and functional in both light and dark mode. For status, color cannot be the only indicator—icons or messaging should also be present, but this color spec focuses on palette and role mapping.

---

**Token Map**

Below, I assign sample tokens. Actual HEX values can be tuned, but the mapping fulfills intended roles:

| Token                | Light Mode         | Dark Mode           | Usage                                 |
|----------------------|--------------------|---------------------|---------------------------------------|
| Surface / BG         | #FFFFFF            | #15181D             | Dashboard background                  |
| Card / Elevated      | #F8FAFC            | #1F2328             | Cards, modules                        |
| Text Primary         | #23272E            | #F8FAFC             | Body, headings                        |
| Text Secondary       | #475168            | #C3CEE4             | Lower emphasis text                   |
| Border/Subtle        | #E4E8EF            | #283041             | Card dividers, inputs                 |
| Action Primary       | #1361E7            | #5BAAFF             | Main CTAs, links                      |
| Action Hover         | #224DCA            | #70B5FE             | CTA hover                             |
| Status Normal        | #13AE72            | #4FDA9F              | Success states, active badges         |
| Status Warning       | #FFB547            | #FFCB80              | Warnings, pending, moderate risks     |
| Status Critical      | #E02145            | #FE6C8F              | Errors, severe alerts, critical state |
| Status Icons (Normal)| #13AE72            | #4FDA9F              | Use alongside shape or icon           |
| Status Icons (Warn)  | #FFB547            | #FFCB80              | As above                              |
| Status Icons (Crit.) | #E02145            | #FE6C8F              | As above                              |
| Data Category 1      | #2874DD            | #88B0EC              | For charts - categorical 1            |
| Data Category 2      | #2F8F50            | #6CF29F              | For charts - categorical 2            |
| Data Category 3      | #775CAF            | #B4B6FA              | For charts - categorical 3            |
| Data Category 4      | #E37723            | #FFBC78              | For charts - categorical 4            |
| Data Category 5      | #C03041            | #FB8281              | For charts - categorical 5            |
| Data Category 6+     | #18ADC5            | #52D6EA              | For extra categories                  |

_(You may expand data categories as needed for your primary visualization palette.)_

---

**Contrast and State Rules**

- **Text:** In both modes, ensure all body and icon colors over backgrounds have a contrast ratio of **at least 4.5:1** (preferably 7:1 for body on surfaces in dashboards).
    - E.g., #23272E on #FFFFFF and #F8FAFC on #1F2328 both meet AA.
- **Buttons/CTAs:** Main action colors (primary/hover) must meet 4.5:1 ratio against surface and card backgrounds in both modes.
- **Status Colors:** Use the above palette for indicators, but always pair with labels/icons—not color alone—for critical communications (especially for color vision deficiency). The status hues given are chosen to remain identifiable in colorblind-safe palettes and to avoid red/green confusion.
- **Data Visualization:** All categorical palette hues must remain distinguishable in both modes, including for users with the most common color vision deficiencies. Increase the difference in lightness and chroma between adjacent colors to improve separation.
- **Tokens and Variables:** Implement via semantic tokens, not hard-coded colors. Example: `color-status-critical`, `color-dataviz-3`.

---

**Migration Notes**

- Conduct an audit to map any existing palette tokens to the above roles.
- Do not directly substitute brand colors for status/semantic roles; always check for contrast compliance and cross-mode fidelity.
- Where previous usage rested on color alone, pair new status colors with an icon, shape, or concise label for clarity.
- For visualizations, add a legend with shape, line, or pattern support if more than 5 categories are used, to preserve accessibility.
- Adjust HEX values as needed to maintain WCAG AA compliance as you test in real code/components. Consider periodic automated contrast testing as part of the build pipeline.

---

**References & Evidence**

- [WCAG 2.2 Contrast guidelines](https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum.html): AAA for body text is strongly recommended for SaaS dashboards.
- [ColorBrewer](https://colorbrewer2.org/): Inspiration for categorical, colorblind-safe palettes.
- [Accessible Palette](https://accessiblepalette.com/): Tool to tune roles/tokens for contrast in light/dark mode.
- Example status color standards: [Material Design](https://m3.material.io/styles/color/the-color-system) and [IBM Carbon](https://carbondesignsystem.com/guidelines/color/overview/).

---

**Key Tradeoffs**

- The need for clear status communication (especially critical alerts) must win over pure brand expression. Some brand colors may be rejected or repurposed.
- Color is never the only signal for status – critical content is paired with icons, labels, or alert regions.
- In charts, some subtlety may be sacrificed for color distinguishability and accessibility.

---

**Summary Table: Required Semantic Color Tokens**

| Token                    | Description               | Light Mode | Dark Mode | Contrast (min) | Usage                          |
|--------------------------|--------------------------|------------|-----------|----------------|-------------------------------|
| color-surface            | BG surface               | #FFFFFF    | #15181D   | —              | dashboard or main area         |
| color-card               | Raised/elevated sections | #F8FAFC    | #1F2328   | —              | cards, panels                  |
| color-text-primary       | Main text                | #23272E    | #F8FAFC   | ≥4.5:1         | headings, body                 |
| color-status-normal      | Info/success             | #13AE72    | #4FDA9F   | ≥4.5:1 icon/bg | success, ok                    |
| color-status-warning     | Warnings                 | #FFB547    | #FFCB80   | ≥4.5:1 icon/bg | warn, moderate alert           |
| color-status-critical    | Critical/error           | #E02145    | #FE6C8F   | ≥4.5:1 icon/bg | error, high alert              |
| color-dataviz-1~5+       | Chart series colors      | see above  | see above | —              | data visualization categories  |

---

**Next Steps**
- Review the proposed semantic tokens in your context.
- Adjust HEX values as necessary for your chosen font weights, UI library, and lighting environment.
- Validate with automated and manual accessibility checks.
- Document mapping in your design system, with clear relationships between token, usage, and state.

---

If you'd like, I can provide a Figma palette, a design token JSON, or further implementation notes aligned with your stack.