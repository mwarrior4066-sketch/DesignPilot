## Component Specification: Split Button

### Purpose and Scope

The Split Button component is a compound control that combines a primary action ("Save") with a dropdown trigger for related secondary actions ("Save as draft", "Save and close"). It is used where users need quick access to both a default action and alternative options from a single, compact interface. The component must provide complete keyboard accessibility, touch support (including mobile), robust state handling (disabled, loading), and explicit implementation boundaries to ensure consistency across platforms.

---

### Anatomy

- **Primary Button**: Executes the default action ("Save"):
  - Displays action label (localized if needed).
  - Can show a loading indicator and be disabled independently.
- **Dropdown Trigger**: Positioned adjacent to the primary button:
  - Shows a downward caret or relevant icon.
  - Opens an action menu on press/click/keyboard interaction.
  - Has a touch target area ≥ 44x44px on mobile.
- **Dropdown Menu**: Contains secondary actions:
  - "Save as draft"
  - "Save and close"
  - Each item has its own label, disabled state (if required), and click/keyboard handler.

---

### State Matrix

| State         | Primary Button          | Dropdown Trigger          | Dropdown Menu             |
|---------------|------------------------|--------------------------|---------------------------|
| Default       | Enabled, standard      | Enabled, shows caret     | Hidden                    |
| Loading       | Shows loader, disabled | Enabled                  | Hidden                    |
| Disabled      | Disabled (no action)   | Disabled                 | Hidden                    |
| Open (Menu)   | Active/focus style     | Focused/active style     | Visible (list of actions) |
| Menu item     | -                      | -                        | Highlighted on hover/focus|

- **Keyboard navigation**:  
  - Tab focuses each segment; Enter/Space activates button or opens menu.
  - Arrow keys and/or Tab (per ARIA menu spec) to navigate options.
  - Escape closes menu, returns focus.
  - Enter/Space triggers selected secondary action.
- **Touch support**:  
  - Each hit area meets 44x44px minimum.
  - Touching outside closes menu.

---

### Accessibility and Implementation Notes

- **ARIA Roles**:  
  - Primary button: `role="button"`, use `aria-disabled="true"` when needed.
  - Dropdown trigger: `aria-haspopup="menu"`, `aria-expanded` reflects menu state.
  - Menu: `role="menu"`, menu items: `role="menuitem"`, proper labeling.
- **Focus Management**:  
  - Shift/focus moves between primary and trigger segments.
  - When menu opens, focus is placed on the first menu item.
- **Screen Reader Support**:  
  - Announce button group, action labels, and expanded/collapsed state.
  - Proper labeling of menu and menu items.
- **Tokens/Props**:  
  - Props for states: `loading`, `disabled`, `open`, `menuItems` array.
  - Tokenize spacing, colors, focus ring, and min touch targets.
- **Do not hardcode action labels**; accept props and enforce testing with different label lengths and localizations.
- **Avoid popover positioning drift on mobile**:  
  - Menu aligns to trigger, ensures visible area within viewport.

---

### State Coverage

- Default, disabled, loading, open (menu visible), error/aria-live (for async failures, if required).
- All states must be demoed in storybook or preview.

---

**Summary of Key Boundaries**
- The split button owns: state transitions, menu open/close logic, all accessibility handling, keyboard and touch navigation, and structural boundaries between primary and secondary actions.
- It does **not own**: alignment in unrelated parent components, business logic of each menu item, or notification of save success—those are handled by consumers via callbacks.

---

**[SESSION_STATE]**
{
  "route": "component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: split button owns dual action logic and accessibility; parent manages business rules",
    "state_coverage: default, disabled, loading, open (menu), per-item disabled possible",
    "accessibility_behavior: explicit ARIA, roles, focus handling, keyboard and touch support, 44x44 touch targets",
    "implementation_boundary: all state/props tokenized; labels, actions, and menu configurable externally"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "implementation_constraint",
    "standards_reference"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]