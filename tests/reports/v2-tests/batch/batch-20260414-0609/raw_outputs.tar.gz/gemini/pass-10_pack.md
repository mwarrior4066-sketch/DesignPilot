Okay, I can help you critique that poster design for a design conference. This task falls under the `graphic_critique` route, supported by skills in graphic design and typography, focusing on composition, visual hierarchy, and legibility.

Here's an assessment of the poster based on your description:

### Problem Framing

The core issue is a misalignment in visual hierarchy, where a decorative title is presented as the dominant element before the audience has essential context about the event