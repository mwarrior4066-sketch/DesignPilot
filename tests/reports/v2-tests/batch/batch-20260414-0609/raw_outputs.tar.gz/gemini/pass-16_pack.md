Mode: Compound | Phase: Audit | Route: api_reliability_security_review

This API audit identifies critical reliability and security issues with the `POST /exports` endpoint. The current synchronous design, opaque error handling, and lack of idempotency introduce significant risks related to data integrity, operational stability, and secure access.

### Failure Semantics and Error Contract

The `POST /exports