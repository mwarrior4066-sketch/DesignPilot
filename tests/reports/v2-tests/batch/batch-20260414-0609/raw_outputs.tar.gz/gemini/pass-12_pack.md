To recommend a type system for your fintech product, I'll structure the advice around its varied contexts—marketing, web app, and mobile—while ensuring it feels modern and trustworthy, handles tabular data, and supports hierarchical weighting.

## Type System Recommendation for Fintech Product

### Reading Context & Objectives
Your product spans three primary reading contexts, each with distinct needs:
-   **Marketing Site