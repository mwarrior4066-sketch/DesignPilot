Here is a color system specification for your healthcare SaaS dashboard, designed for clarity, accessibility, dark mode support, and data visualization.

### Role Model: Semantic Color Foundation

The core of this color system defines **semantic roles** rather than a raw palette. Each color serves a specific purpose, ensuring consistency and adaptability across light and dark modes. This prevents arbitrary color choices and supports maintainability. Key roles include: primary surfaces, textual content, interactive elements, distinct status indicators (normal, warning, critical), and a set of categorical colors for data visualization. This structured approach directly addresses the need for clear status communication and dark mode compatibility by defining how each role manifests in different themes.

### Token Map: Roles to Implementation

These semantic roles are mapped to design tokens, ensuring implementation consistency and easy theming. Each role has distinct values for light and dark modes.

**Surface & Backgrounds:**
*   `--surface-primary-light` (e.g., `#FFFFFF`)
*   `--surface-secondary-light` (e.g., `#F8F9FA`)
*   `--surface-primary-dark` (e.g., `#1A1A1A`)
*   `--surface-secondary-dark` (e.g., `#2C2C2C`)

**Text:**
*   `--text-primary-light` (e.g., `#212529`)
*   `--text-secondary-light` (e.g., `#6C757D`)
*   `--text-primary-dark` (e.g., `#F8F9FA`)
*   `--text-secondary-dark` (e.g., `#AEB6BE`)

**Status Indicators:**
*   `--status-normal-light` (e.g., `#28A745` - Green)
*   `--status-warning-light` (e.g., `#FFC107` - Yellow)
*   `--status-critical-light` (e.g., `#DC3545` - Red)
*   `--status-normal-dark` (e.g., `#2ED060` - Green)
*   `--status-warning-dark` (e.g., `#FFD54F` - Yellow)
*   `--status-critical-dark` (e.g., `#EF5350` - Red)

**Data Visualization (Categorical - minimum 5):**
*   `--data-cat-1-light` / `--data-cat-1-dark` (e.g., Blue)
*   `--data-cat-2-light` / `--data-cat-2-dark` (e.g., Purple)
*   `--data-cat-3-light` / `--data-cat-3-dark` (e.g., Teal)
*   `--data-cat-4-