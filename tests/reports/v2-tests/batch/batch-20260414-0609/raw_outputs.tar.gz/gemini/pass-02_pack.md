The request is for a component specification for a split button, including keyboard support, disabled/loading states, and mobile touch targets. This aligns with the `component_spec` governing route.

Mode: REBUILD | Phase: specs | Route: component_spec | Supporting Skills: component-systems-expert, front-end-handoff-expert, accessibility-feedback-expert

# Component