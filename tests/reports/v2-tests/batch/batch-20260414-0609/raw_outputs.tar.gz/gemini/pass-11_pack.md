To reconstruct your layout system from the 2018 brand guidelines PDF for new templates, I will extract the explicit and inferred layout rules, then translate them into a modern, flexible system.

This approach ensures the new templates maintain the original brand's structural integrity while adapting to current design and development practices.

### Current Failure State (Problem Framing)

The task is to systematically reconstruct