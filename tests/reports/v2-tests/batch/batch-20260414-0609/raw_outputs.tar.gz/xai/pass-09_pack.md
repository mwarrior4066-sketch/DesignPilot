### Color System for Healthcare SaaS Dashboard

Below is a tailored color system for a healthcare SaaS dashboard, designed to meet your requirements for status communication, dark mode support, data visualization, and WCAG AA compliance for text accessibility.

#### Role Model
This color system is built around semantic roles rather than a loose palette. Roles are defined to ensure clarity in a healthcare context, where status must be unambiguous, and data visualization must avoid confusion. The roles include:
- **Surface**: Backgrounds for cards, panels, and canvas areas.
- **Text**: Primary and secondary text for readability.
- **Action**: Interactive elements like buttons and links.
- **Status**: Indicators for normal (safe), warning (attention), and critical (urgent) states.
- **Chart**: Categorical colors for data visualization, ensuring distinction in graphs.

#### Token Map
Each role maps to specific tokens with light and dark mode values. These tokens are named for clarity and reuse across the dashboard:
- **Surface**:
  - Light: `#FFFFFF` (white, base canvas)
  - Dark: `#1A1C1E` (near-black, dark canvas)
- **Text**:
  - Primary Light: `#1A1C1E` (near-black, high contrast)
  - Primary Dark: `#F5F5F5` (off-white, high contrast)
  - Secondary Light: `#5A5C5E` (mid-gray, softer contrast)
  - Secondary Dark: `#A0A2A4` (light-gray, softer contrast)
- **Action**:
  - Default: `#007BFF` (blue, inviting and interactive)
  - Hover: `#0056B3` (darker blue, clear state change)
  - Dark Default: `#4DA6FF` (lighter blue, adjusted for dark mode contrast)
  - Dark Hover: `#66B3FF` (subtle lift for visibility)
- **Status**:
  - Normal: `#2CA089` (teal-green, safe and calming)
  - Warning: `#FFB800` (yellow, attention without panic)
  - Critical: `#D14343` (red, urgent and alarming)
  - Dark Normal: `#4CC9A9` (lighter teal-green for contrast)
  - Dark Warning: `#FFD12E` (brighter yellow for visibility)
  - Dark Critical: `#E66C6C` (softer red to avoid glare)
- **Chart (Categorical for Data Vis)**:
  - Cat1: `#007BFF` (blue, reused from action for consistency)
  - Cat2: `#2CA089` (teal-green, reused from normal status)
  - Cat3: `#FFB800` (yellow, reused from warning)
  - Cat4: `#A37CFF` (purple, distinct for data differentiation)
  - Cat5: `#FF7B9C` (pink, distinct and accessible)
  - Dark Cat1: `#4DA6FF` (lighter blue)
  - Dark Cat2: `#4CC9A9` (lighter teal-green)
  - Dark Cat3: `#FFD12E` (brighter yellow)
  - Dark Cat4: `#C4A6FF` (lighter purple)
  - Dark Cat5: `#FF9CB8` (lighter pink)

#### Contrast and State Rules
Accessibility is non-negotiable for a healthcare dashboard, where users must trust the interface under stress. All text meets WCAG AA thresholds:
- Primary text-to-surface contrast exceeds 4.5:1 (e.g., `#1A1C1E` on `#FFFFFF` is 18.5:1; `#F5F5F5` on `#1A1C1E` is 15.2:1).
- Secondary text also clears 4.5:1 for smaller sizes (e.g., `#5A5C5E` on `#FFFFFF` is 5.9:1).
- Status indicators avoid color-only semantics; they must pair with icons or labels (e.g., a critical red dot must have a “Critical” label or exclamation icon).
- Action states (hover, focus) maintain contrast and include non-color cues like underlines or borders.
- Chart colors are tested for colorblind distinction (using tools like Coblis) and maintain at least 3:1 contrast against backgrounds for non-text elements, per WCAG AA.

#### Migration Notes
To integrate this color system into an existing dashboard:
- Start by mapping surface and text roles to replace generic backgrounds and type colors, ensuring contrast compliance first.
- Then apply status colors to alerts and health indicators, pairing with labels/icons to avoid color-only reliance.
- Update action colors for buttons and links, preserving state changes.
- Finally, phase chart colors into data visualizations, testing for distinction in graphs.
- Deprecate any hardcoded hex values in favor of these named tokens to prevent drift over time.

This system prioritizes clarity for healthcare users, supports dark mode for low-light environments (common in clinical settings), provides distinct categorical colors for data trends, and ensures accessibility compliance. If you’d like me to adjust any specific color for brand alignment or test a particular pairing, let me know.