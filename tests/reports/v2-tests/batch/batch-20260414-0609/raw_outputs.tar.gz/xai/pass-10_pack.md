Mode: AUDIT | Phase: COMMUNICATION | Route: graphic_critique

### Communication Goal
The primary goal of this poster is to announce a design conference and attract attendees by conveying key event details quickly, especially at a distance or in a busy environment.

### Composition Failures
The current hierarchy prioritizes the decorative title over essential context, which risks losing the audience before they understand the event's purpose. Placing the date in small gray text in the bottom corner diminishes its visibility, making it hard to scan at a distance. The full-bleed city skyline photo, while visually striking, competes with the overlaid white conference logo in the center, diluting the focal point. The logo, intended as a key identifier, struggles to stand out against the busy background, reducing brand recognition. Additionally, the decorative typeface for the title may compromise legibility, especially at smaller scales or from afar, undermining the poster's effectiveness in environments like conference halls or street displays.

### Rebuild Moves
1. **Reframe the Hierarchy**: Lead with the conference logo or a clear event descriptor (e.g., "Design Conference 2023") as the dominant focal point at the top or center to establish context immediately. Follow with the title in a supporting role, using a typeface optimized for legibility over decoration.
2. **Elevate the Date**: Move the date to a more prominent position, such as directly below the title or logo, and increase its size and contrast (e.g., black or a bold color instead of gray) to ensure it’s scannable.
3. **Simplify the Background**: Crop or overlay a semi-transparent scrim on the city skyline photo to reduce visual noise, ensuring the logo and text elements pop against it. Alternatively, consider a simpler background that doesn’t fight for attention.
4. **Balance Composition**: Use alignment and grouping to create a clear visual path—logo or event descriptor first, title second, date third. Adjust scale and spacing to guide the eye naturally, ensuring the poster works at both close and distant reads.

### Distance and Emphasis Tradeoff
Preserve the logo or event descriptor as the primary focal winner to anchor the viewer’s understanding of what this is before diving into details like the title. Sacrifice the decorative flair of the title typeface if it risks legibility, and allow the background photo to recede as a secondary element rather than competing with critical information. This ensures the poster communicates effectively at a glance, prioritizing clarity over aesthetic complexity in a conference promotion context.