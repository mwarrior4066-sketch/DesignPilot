I'm glad to help with a type system for your fintech product that spans a marketing site, web app dashboard, and mobile interfaces. Let's design a solution that balances modernity, trustworthiness, and functional hierarchy while handling dense financial data effectively.

### Reading Context
Your fintech product operates across multiple platforms with distinct reading contexts: a marketing site for broad appeal and trust-building, a web app dashboard for dense tabular data and quick scans, and mobile interfaces for constrained space and on-the-go readability. The type system must support varied densities—long-form on the marketing site, data-heavy on the dashboard, and compact on mobile—while maintaining a cohesive, professional feel.

### Scale and Role Map
I recommend a type system built around **Inter** as the primary typeface. Inter is a modern sans-serif designed for screen readability, with a neutral yet confident tone that conveys trustworthiness—key for fintech. It offers a wide range of weights (from Thin to Black) and variable font support, allowing fine-tuned hierarchy across platforms. Here's the role mapping:

- **Display (Headlines, Hero Text)**: Inter Black or Extra Bold at 36px (marketing site hero), 28px (dashboard titles), and 24px (mobile headers), with tight tracking (-0.02em) for impact.
- **Heading 1 (Section Titles)**: Inter Bold at 24px (marketing), 20px (dashboard), 18px (mobile) for primary section breaks.
- **Heading 2 (Sub-sections)**: Inter Semi-Bold at 18px (marketing), 16px (dashboard), 14px (mobile) for secondary hierarchy.
- **Body (Paragraphs, Descriptions)**: Inter Regular at 16px (marketing and dashboard on desktop), 14px (mobile) for readable long-form and descriptions.
- **Label (UI Elements, Captions)**: Inter Medium at 14px (desktop), 12px (mobile) for buttons, form labels, and chart annotations.
- **Meta (Fine Print, Footnotes)**: Inter Regular at 12px (desktop), 10px (mobile) for disclaimers and secondary data.
- **Tabular Data (Dashboard Tables)**: Inter Regular at 14px (desktop), 12px (mobile), with Medium for emphasized cells (e.g., totals), optimized for dense financial grids.

This scale ensures hierarchy through weight and size contrast, while Inter’s open apertures and clear numerals enhance readability of financial data in tables.

### Readability Rules
To ensure the type system performs across contexts, I’ve set these boundaries:
- **Line Length**: Target 45-75 characters per line for body text on the marketing site (readable paragraphs) and limit dashboard descriptive text to 50-60 characters to avoid clutter.
- **Line-Height**: Use a 1.5 ratio for body text (24px leading for 16px text) on marketing and dashboard, tightening to 1.4 on mobile (19.6px for 14px text) for compactness.
- **Contrast**: Ensure a minimum 4.5:1 contrast ratio for normal text against backgrounds (WCAG AA), critical for dashboard data and mobile readability under varied lighting.
- **Tracking for Dense Data**: Add slight positive tracking (+0.01em) to tabular data text at 12-14px to prevent visual merging of numbers in tight grids.
- **No Sub-10px Text**: Avoid text smaller than 10px even on mobile to maintain legibility of fine print and meta data.

These rules prioritize clarity in dense financial contexts while keeping a modern, airy feel through balanced spacing.

### Adoption Guidance
To implement this type system cohesively:
- **Start with the Dashboard**: Deploy Inter across tabular data and UI labels first, as this is the most constrained and data-critical context. Use variable fonts if supported to optimize load times.
- **Extend to Marketing Site**: Apply the larger display and heading sizes for impact, maintaining the same weight logic for consistency. Keep existing body text sizes if they’re already larger for accessibility.
- **Adjust for Mobile**: Scale down sizes as outlined, prioritizing body and label readability over aggressive compression. Test meta text at 10px for disclaimers.
- **Fallback Stack**: Use system fonts as fallback (e.g., -apple-system, BlinkMacSystemFont, Segoe UI, Roboto) to ensure graceful degradation if Inter fails to load, maintaining a neutral sans-serif feel.

This phased approach ensures the type system integrates without disrupting existing layouts, starting with the highest-risk area (dashboard data) and scaling out.

I’ve chosen Inter for its modern geometry and trustworthiness—its clean lines avoid the coldness of older sans-serifs like Helvetica, while its range of weights supports nuanced hierarchy. It’s also free and open-source, aligning with practical fintech needs. If you have a specific brand direction or licensing budget for a premium typeface, I can explore alternatives like IBM Plex Sans or a custom pairing.

Would you like me to refine this further with specific token names for a design system, or test it against a sample dashboard layout?