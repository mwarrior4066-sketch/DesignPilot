### Split Button Component Specification

**Mode:** REBUILD | **Phase:** specs | **Route:** component_spec

#### Purpose and Scope
The Split Button component is designed to combine a primary action with a set of related secondary actions in a compact UI element. It is used when a user needs to choose between a default action (e.g., "Save") and alternative actions (e.g., "Save as draft" or "Save and close") without cluttering the interface. This component applies to forms, editors, and workflows where space is constrained and action hierarchy must be clear. It does not own unrelated actions or navigation outside its immediate context.

#### Anatomy
The Split Button consists of two distinct, adjacent interactive elements within a single container:
- **Primary Action Button**: Displays the default action ("Save") and triggers the most common or critical outcome.
- **Dropdown Trigger Button**: Displays a downward chevron icon or similar visual cue, revealing a menu of secondary actions ("Save as draft", "Save and close") when activated.
- **Container**: Wraps both buttons to ensure visual and functional cohesion, maintaining alignment and spacing.
- **Dropdown Menu**: Appears on interaction with the trigger, listing secondary actions. It is visually attached to the trigger button but does not overlap the primary action.

Visual separation (e.g., a subtle divider line or border radius distinction) between the primary and dropdown trigger ensures users perceive them as distinct targets despite their proximity.

#### State Matrix
The Split Button must handle multiple states to ensure clarity and usability across interactions:
- **Default (Idle)**: Both buttons are active and clickable/tappable. Primary action shows "Save", and dropdown trigger shows a chevron icon.
- **Hover (Primary)**: On desktop, hovering over the primary button highlights it (e.g., background color shift) to indicate clickability, while the dropdown trigger remains idle unless hovered separately.
- **Hover (Dropdown Trigger)**: Hovering over the trigger highlights it independently, signaling it opens a menu.
- **Focus (Primary)**: When focused via keyboard (Tab key), the primary button shows a visible focus ring (e.g., 2px outline) to indicate it has focus for activation via Enter or Space.
- **Focus (Dropdown Trigger)**: When focused, the trigger shows a focus ring, activatable via Enter or Space to open the menu.
- **Active (Dropdown Open)**: When the dropdown trigger is clicked or activated, the menu appears below (or above, based on viewport space), and the trigger may show a pressed state (e.g., inverted chevron or subtle inset effect).
- **Disabled (Entire Component)**: Both buttons are grayed out, non-interactive, and visually distinct (e.g., reduced opacity, no hover/focus states). ARIA `disabled="true"` is applied to both.
- **Disabled (Primary Only)**: Primary action is disabled (grayed out, non-interactive), while dropdown trigger remains active for secondary options.
- **Loading (Primary)**: During the primary action’s processing (e.g., saving), a spinner icon replaces the "Save" text or appears alongside it, and the button is non-interactive until completion. Dropdown trigger remains active unless contextually inappropriate.
- **Loading (Secondary Action)**: If a secondary action is processing, the dropdown menu item may show a spinner, and the primary button remains unaffected unless tied to the same process.

#### Accessibility and Implementation Notes
- **Keyboard Navigation**: The primary button and dropdown trigger must be independently focusable via Tab key in logical order (primary first, then trigger). Both must activate on Enter and Space keys. When the dropdown menu opens, focus should shift to the first menu item, navigable via Up/Down arrows, with Escape closing the menu and returning focus to the trigger.
- **ARIA Attributes**: The primary button uses a standard `<button>` with `aria-label="Save"` if text alone is insufficient. The dropdown trigger uses `aria-expanded="true/false"` to indicate menu state, `aria-controls` to reference the menu ID, and `aria-label="More save options"` for clarity. Menu items are `<li>` elements with `role="menuitem"` inside a `<ul>` with `role="menu"`.
- **Touch Targets**: Both buttons must meet a minimum touch target size of 44x44 pixels (per WCAG 2.1) on mobile, with adequate spacing or padding to prevent accidental taps. Consider increasing to 48x48 pixels for better usability.
- **Screen Reader Support**: Ensure screen readers announce both buttons distinctly (e.g., "Save, button" and "More save options, button, collapsed/expanded"). Menu items should announce their action (e.g., "Save as draft, menu item").
- **Implementation Constraints**: Use design tokens for colors, spacing, and typography to maintain system coherence. Do not hardcode values like background colors or padding; instead, reference tokens (e.g., `color-primary-base`, `spacing-xs`). The dropdown menu should use a portal or similar technique to ensure it renders outside the container’s overflow boundaries if needed. Avoid inline styles for states; use CSS classes or props for variants (e.g., `is-disabled`, `is-loading`).
- **Mobile Considerations**: On smaller screens, ensure the dropdown menu does not overflow the viewport (e.g., adjust positioning dynamically or use a bottom-sheet style if appropriate). Test tap accuracy under real mobile conditions.

This specification ensures the Split Button is usable, accessible, and implementation-ready across platforms and interaction modes. If further customization is needed (e.g., additional states or theming), extend this spec with variant-specific details.