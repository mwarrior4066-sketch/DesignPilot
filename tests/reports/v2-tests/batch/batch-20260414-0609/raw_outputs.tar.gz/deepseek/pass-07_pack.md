I’ll rewrite this case study for a design portfolio, structuring it to show problem, process, solution, and outcome with clear evidence and narrative flow.

---

## **Redesigning Onboarding to Reduce Confusion and Increase Conversion**

### **Problem**
The existing onboarding flow had a 65% drop-off rate before users reached the core product. Internal data showed that most users abandoned during the account-creation step, and support tickets repeatedly cited “confusing steps” and “unclear value.” The business needed to improve activation—not just aesthetics—while maintaining security and data-collection requirements.

### **Process**
- **Research synthesis** – I led moderated usability tests with 8 new users, analyzed 150+ support tickets, and ran an unmoderated survey (N=300) to isolate the biggest friction points. The core finding: users didn’t understand why certain fields were required, feared “hidden costs,” and felt the flow was longer than promised.
- **Wireframing & prototyping** – I created a step-by-step wireframe set that separated “why we ask” from “what we ask,” introduced progressive disclosure for optional fields, and added a persistent progress tracker. I built a high-fidelity prototype in Figma with interactive states for validation errors and help tooltips.
- **Collaboration & iteration** – I worked with engineering to ensure the new flow could reuse existing backend validation and met accessibility standards (keyboard navigation, screen‑reader labels). We ran an internal dogfooding session and a small beta (50 users) to confirm the interaction model held up.

### **Solution**
The redesigned onboarding:
1. **Added a clear value frame** – Before each step, a short headline explained what the user would get after completing it.
2. **Chunked inputs into logical groups** – Contact info, preferences, and security settings were separated with clear section headings.
3. **Provided inline help** – Small “?” icons linked to concise explanations of why data was needed.
4. **Introduced a progress tracker** – A visual indicator showed how many steps remained, reducing anxiety about length.
5. **Improved error states** – Real‑time validation with plain‑language messages replaced generic “invalid input” alerts.

### **Outcome**
- **40% increase in completed onboarding** (measured over 30 days post‑launch, statistically significant).
- **Support tickets related to onboarding confusion dropped by 70%.**
- **Qualitative feedback** from user interviews noted the flow felt “transparent” and “less stressful.”

### **What I Learned**
- **Evidence beats assumption** – The research finding that users feared hidden costs wasn’t obvious from analytics alone; direct conversation revealed it.
- **Engineering collaboration is a force multiplier** – Involving devs early ensured that the progressive‑disclosure model was built with maintainable state logic.
- **Clarity is a system** – It wasn’t about adding more words; it was about placing the right words at the right moment in the interaction.

---

**Portfolio-ready notes:**  
- Lead with the business and user problem, not your role.  
- Show concrete methods (moderated tests, ticket analysis, beta).  
- Separate what you did from what the solution contained.  
- Include both quantitative and qualitative outcomes.  
- End with reflective learnings that show professional growth.

Would you like me to adjust the tone for a specific audience (e.g., startup vs. enterprise), or add a visual mockup caption for portfolio presentation?