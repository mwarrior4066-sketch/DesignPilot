I’ll audit this API design for reliability and security using the `api_reliability_security_review` route.

**Mode:** AUDIT  
**Phase:** implementation  
**Route:** `rt_api_reliability_security_review`  
**Supporting skills:** `api-reliability-security-expert.md`, `back-end-systems-architect.md`, `back-end-aware-planner.md`

---

## API Reliability & Security Review  
**POST /exports – PDF report generation endpoint**

### 1. Failure semantics and error contract
**Current failure posture:**  
- Returns HTTP 200 for all responses, including errors.  
- Leaks internal enum values in error messages.  
- No structured error envelope.

**Failure semantics required:**  
- **RFC 9457 (Problem Details)** must be adopted.  
  - Use `application/problem+json` for errors.  
  - Include `type`, `title`, `status`, `detail`, `instance`.  
  - Keep `detail` user-safe; do not expose internal enums, stack traces, or system paths.  
- **Status code discipline:**  
  - 200 only for successful PDF delivery.  
  - 400 for malformed request (missing parameters, invalid format).  
  - 401/403 for authorization failures.  
  - 422 for semantic validation failures (e.g., report template not found).  
  - 429 for rate limit exceeded.  
  - 500 for internal server errors (with generic `detail`).  
  - 503 if downstream services (PDF renderer, storage) are unavailable.

**Why this matters:**  
Clients cannot programmatically distinguish success from failure when everything returns 200. Internal enum leaks become reconnaissance vectors. RFC 9457 gives clients a consistent, safe envelope for handling errors.

---

### 2. Authorization and resource protection
**Current gaps:**  
- No explicit authorization model described.  
- Synchronous 3‑minute runtime increases risk of denial-of-service via parallel requests.

**Authorization perimeter required:**  
- **BOLA/BFLA guard:**  
  - Validate that the requesting user has `read` access to every resource referenced in the export request (e.g., projects, data ranges, templates).  
  - Use object‑level authorization (e.g., “can user U read report template T?”) not just role‑based checks.  
- **Tenant isolation:**  
  - If multi‑tenant, enforce tenant‑boundary checks before generating the PDF.  
- **Rate limiting & quotas:**  
  - Limit per‑user concurrent exports to 1 or 2.  
  - Implement request quotas per day/hour (e.g., 50 PDFs/day/user).  
  - Return 429 with `Retry-After` when limits are hit.

**Why this matters:**  
A 3‑minute synchronous endpoint is trivial to abuse. Without object‑level authorization, users may export data they shouldn’t see. Rate limiting protects backend resources (PDF renderer, database) from exhaustion.

---

### 3. Idempotency and async lifecycle
**Current gaps:**  
- No idempotency key.  
- Synchronous blocking for up to 3 minutes.  
- No retry‑safe contract.

**Required changes:**  
- **Switch to async pattern:**  
  - POST /exports returns `202 Accepted` immediately with a `Location` header pointing to a status endpoint (e.g., `/exports/{job_id}`).  
  - Job status endpoint returns `200` with progress (`pending`, `running`, `completed`, `failed`) and, when complete, a `download_url` for the PDF.  
  - Webhook optional for notification on completion/failure.  
- **Idempotency contract:**  
  - Accept `Idempotency-Key` header (client‑generated, e.g., UUID).  
  - Store key with TTL (e.g., 24 hours).  
  - Duplicate request with same key returns `409 Conflict` with a link to the existing job status.  
- **Retry safety:**  
  - Idempotent creation via idempotency key.  
  - GET on status endpoint is always safe and idempotent.  
  - Download URL is time‑limited signed URL (e.g., 5‑minute expiry).

**Why this matters:**  
Synchronous 3‑minute calls cause timeouts, broken connections, and duplicate submissions. Without idempotency, network retries create duplicate reports. Async + idempotency makes the endpoint resilient to network flakiness and client retries.

---

### 4. Resilience and observability
**Current gaps:**  
- No observability described.  
- Long‑running synchronous process with no cancellation, timeout control, or degradation path.

**Resilience posture required:**  
- **Timeouts and circuit breakers:**  
  - Set upstream timeout (e.g., 30 seconds) for the initial request; async processing continues in background.  
  - Circuit breaker on PDF renderer service to fail fast if it’s down.  
- **Observability tax:**  
  - Emit structured logs with `trace_id`, `job_id`, `user_id`, `duration`, `outcome`.  
  - Metrics: export request rate, success/failure counts, PDF generation latency (p95, p99), queue depth (if using a queue).  
  - Distributed tracing across renderer, storage, and auth services.  
- **Degradation path:**  
  - If PDF renderer is degraded, return `503` with `Retry-After` and a fallback CSV export option if business‑appropriate.  
  - If storage is full, fail job with clear problem detail (do not hang).

**Why this matters:**  
A 3‑minute synchronous call without observability is a black box. When it fails, you won’t know why. Without timeouts and circuit breakers, a downstream failure can tie up all worker threads and take down the service.

---

## Summary of required changes

1. **Adopt RFC 9457** for all error responses; stop returning 200 for errors.
2. **Implement object‑level authorization** (BOLA/BFLA) and per‑user rate limits.
3. **Convert to async** (202 Accepted + status polling) with idempotency‑key support.
4. **Add observability** with tracing, metrics, and structured logs.
5. **Introduce timeouts, circuit breakers, and a degradation fallback.**

These changes move the endpoint from a fragile, insecure synchronous call to a production‑ready, resilient, and secure async API.

---

**Evidence classes cited:**  
- `failure_semantics_rule` – RFC 9457, status code discipline.  
- `permission_rule` – BOLA/BFLA, tenant isolation, rate limiting.  
- `async_lifecycle_rule` – 202 Accepted, idempotency‑key, status polling.  
- `resilience_rule` – timeouts, circuit breakers, observability tax, degradation path.

**Decisions committed:**  
- `problem_details_contract`: RFC 9457 with safe detail field.  
- `authorization_perimeter`: Object‑level auth (BOLA/BFLA) + rate limits.  
- `idempotency_contract`: Idempotency‑key with 409 Conflict for duplicates.  
- `async_job_model`: 202 Accepted + status endpoint polling.  
- `resilience_strategy`: Timeouts, circuit breakers, structured logs, fallback option.

**Tradeoffs named:**  
- Async adds complexity (status polling, job storage) but eliminates timeout risks and enables idempotency.  
- Strict authorization and rate limits may reject some legitimate high‑volume users; quota increases can be managed via admin settings.  
- Removing internal enum leaks improves security but may reduce debugging detail; keep internal error codes in server logs only.

---

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": ["problem_details_contract: RFC 9457 with safe detail field", "authorization_perimeter: Object‑level auth (BOLA/BFLA) + rate limits", "idempotency_contract: Idempotency‑key with 409 Conflict for duplicates", "async_job_model: 202 Accepted + status endpoint polling", "resilience_strategy: Timeouts, circuit breakers, structured logs, fallback option"],
  "evidence_classes_cited": ["failure_semantics_rule", "permission_rule", "async_lifecycle_rule", "resilience_rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]