I’ll recommend a type system for a fintech product that works across marketing site, web app dashboard, and mobile—balancing modern trustworthiness, tabular data clarity, and clear hierarchy.

---

## Recommended Type System

**Primary font:** **Inter** (open-source, variable font, excellent readability at small sizes, strong tabular figures)  
**Secondary/display option:** **Source Serif Pro** (for editorial/marketing warmth, optional)  
**Fallback stack:** `Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif`

---

### Why Inter for fintech

- **Trust + neutrality:** Geometric but humanist, avoids overly expressive or techy flair.  
- **Variable font:** Single file with weight axis 100–900, reduces HTTP requests, enables fluid weight adjustments.  
- **Tabular figures built-in:** Essential for financial tables—numbers align vertically in `font-variant-numeric: tabular-nums`.  
- **Screen performance:** Highly legible at 12–14px, with open counters and clear distinction between `1`, `l`, `I`.  
- **Free + widely supported:** No licensing friction, works in all modern browsers and mobile OS.

---

### Type Scale & Roles

| Role | Size (rem) | Weight | Line height | Use case |
|------|------------|--------|-------------|----------|
| Display | 3.0–4.0 | 700 | 1.1 | Marketing headlines |
| Heading 1 | 2.25 | 600 | 1.2 | Page titles |
| Heading 2 | 1.875 | 600 | 1.25 | Section headers |
| Heading 3 | 1.5 | 600 | 1.3 | Subsection headers |
| Body large | 1.125 | 400 | 1.5 | Lead paragraphs |
| Body | 1.0 (16px) | 400 | 1.5 | Main UI text |
| Small / Label | 0.875 | 500 | 1.4 | Labels, captions, table headers |
| Micro | 0.75 | 600 | 1.3 | Timestamps, tags, fine print |

**Mobile adjustments:** Reduce display/heading sizes by ~15%, keep body at 16px for tap target safety.

---

### Tabular Data Rules

- **Font feature:** `font-variant-numeric: tabular-nums;` on all table cells, KPIs, currency displays.  
- **Monospaced option:** Use `'Roboto Mono'` or `'SF Mono'` only for code snippets or transaction IDs, not for main tables (Inter’s tabular figures are sufficient).  
- **Alignment:** Right-align currency, left-align labels, center-align status badges.  
- **Density:** Use weight 500 for column headers, 400 for data; zebra striping optional but keep contrast ≥ 4.5:1.

---

### Hierarchy & Weight Strategy

Inter’s variable axis allows fine weight tuning:

- **Light (300):** Avoid in UI—low contrast risk.  
- **Regular (400):** Body, table data.  
- **Medium (500):** Labels, buttons, interactive elements.  
- **Semibold (600):** Headings, important metrics.  
- **Bold (700):** Display, primary CTAs, key totals.  

**Rule:** Never use more than 3 weights per screen to avoid visual noise.

---

### Dark Mode & Accessibility

- **Contrast:** Ensure text meets WCAG 2.1 AA (≥ 4.5:1 for body, ≥ 3:1 for large text).  
- **Dark mode:** Slightly reduce weight (e.g., 500 → 400) to avoid halo effect on dark backgrounds.  
- **Motion:** Respect `prefers-reduced-motion` for any animated numbers (count-ups).

---

### Implementation Steps

1. **Load Inter** from Google Fonts or self-host variable font file.  
2. **Set CSS custom properties** for scale, weight, line-height.  
3. **Apply tabular figures** globally to tables, dashboards, financial widgets.  
4. **Test** on marketing pages (large display), dense dashboard tables, and mobile viewports.  
5. **Document** the scale and usage rules in your design token system.

---

### If You Need a Serif Pairing

**Source Serif Pro** (also open-source, variable) for marketing storytelling:

- Use for hero quotes, feature descriptions, long-form articles.  
- Keep Inter for all UI, tables, forms, navigation.  
- Don’t mix serif into dashboard or transactional screens—stay with Inter for consistency.

---

### Fallback Considerations

- **Windows:** Segoe UI renders numeric tables cleanly.  
- **macOS:** San Francisco blends well.  
- **Mobile:** System fonts in the stack ensure performance and familiarity.

---

### Quick Check Before Adoption

- Verify tabular figures work in your stack (`font-feature-settings: "tnum"`).  
- Test financial tables at 12px with decimal alignment.  
- Confirm variable font loading doesn’t block rendering.  
- Check bold weights don’t blur on Windows ClearType.

This system balances modern aesthetics, financial data rigor, and cross-platform reliability without licensing cost or complexity.