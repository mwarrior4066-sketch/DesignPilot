**Mode:** AUDIT | **Phase:** brand | **Route:** graphic_critique

---

### Communication goal
This poster needs to communicate that a design conference is happening, when and where, and why someone should attend. The current layout puts decorative title before context, which risks confusing the viewer before they understand what the event is.

### Composition failures
- **Focal winner is unclear:** The decorative title dominates the first read, but it doesn’t tell the viewer *what* the event is. The conference logo is visually secondary despite being the key identifier.
- **Distance legibility risk:** At poster distance, the small gray date in the corner will disappear. The date/location are critical for action but are demoted to footnote treatment.
- **Hierarchy inversion:** The title (which is likely the conference name or theme) comes before the category (“design conference”). This forces the viewer to decode before they understand.
- **Photo competes with logo:** A full-bleed city skyline can feel generic and may visually compete with the overlaid logo, reducing logo clarity and memorability.

### Rebuild moves
1. **Lead with the category or logo** – make “Design Conference” or the event logo the first read, so the viewer knows what they’re looking at.
2. **Promote date/location** – move date, venue, and city out of the corner and closer to the primary message, using size and contrast that survives distance.
3. **Simplify the background** – consider muting, cropping, or overlaying the skyline photo so it supports rather than competes with the typography.
4. **Reorder the headline stack** – if the decorative title is the conference theme, place it *after* the event name, not before.

### Distance and emphasis tradeoff
To make the poster work at a glance:
- **Sacrifice** some of the decorative title’s dominance so the event identity and key details can win.
- **Preserve** the visual energy of the photo and typeface, but rebalance the hierarchy so the viewer knows *what, when, where* before they appreciate the stylistic treatment.

---

**Next useful move:**  
If you have the source file, I can map these changes to a specific layout grid and type scale so the poster remains visually striking but communicates faster.