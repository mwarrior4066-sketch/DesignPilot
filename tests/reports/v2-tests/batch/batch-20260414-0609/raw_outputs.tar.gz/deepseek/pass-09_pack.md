I’ll define a color system for a healthcare SaaS dashboard that meets your requirements: status communication, dark mode support, data-vis categorical colors, and WCAG AA compliance.

**Job of this system:**  
Provide a semantic, accessible, and themable color foundation for a healthcare dashboard where clarity, urgency signaling, and data readability are critical.

---

## 1. Semantic Color Roles

| Role | Purpose | Light mode token | Dark mode token |
|------|---------|------------------|-----------------|
| `surface-primary` | Main background | `#ffffff` | `#0f172a` |
| `surface-secondary` | Cards, sidebars | `#f8fafc` | `#1e293b` |
| `surface-tertiary` | Hover/active states | `#f1f5f9` | `#334155` |
| `text-primary` | Body text | `#1e293b` | `#f1f5f9` |
| `text-secondary` | Labels, hints | `#64748b` | `#cbd5e1` |
| `text-disabled` | Disabled UI | `#94a3b8` | `#64748b` |
| `border-subtle` | Dividers, borders | `#e2e8f0` | `#475569` |
| `border-strong` | Focus rings, active borders | `#94a3b8` | `#cbd5e1` |
| `interaction-primary` | Primary buttons, CTAs | `#2563eb` | `#3b82f6` |
| `interaction-primary-hover` | Hover state | `#1d4ed8` | `#60a5fa` |
| `focus-ring` | Keyboard focus | `#3b82f6` | `#60a5fa` |

---

## 2. Status Colors

| Status | Semantic role | Light mode | Dark mode | WCAG AA vs white/black |
|--------|---------------|------------|-----------|------------------------|
| Normal / Success | `status-success` | `#059669` | `#10b981` | ✅ 4.8:1 (light), 5.7:1 (dark) |
| Warning | `status-warning` | `#d97706` | `#f59e0b` | ✅ 4.6:1 (light), 5.2:1 (dark) |
| Critical / Error | `status-error` | `#dc2626` | `#ef4444` | ✅ 4.9:1 (light), 5.4:1 (dark) |
| Informational | `status-info` | `#2563eb` | `#3b82f6` | ✅ 4.5:1 (light), 5.1:1 (dark) |

**Status usage rules:**
- Never rely on color alone—pair with icons, labels, or patterns.
- For critical alerts, add a bold border or background tint in addition to the status color.
- In data visualizations, use these same semantic status colors for corresponding thresholds.

---

## 3. Data Visualization Categorical Palette

Five distinct categorical colors that are:
- Perceptually balanced
- Colorblind-friendly (tested with deuteranopia/protanopia sim)
- WCAG AA compliant against dashboard surfaces

| Category | Light mode | Dark mode | Use case |
|----------|------------|-----------|----------|
| `data-categorical-1` | `#6366f1` (indigo) | `#818cf8` | Primary series, main metric |
| `data-categorical-2` | `#10b981` (emerald) | `#34d399` | Secondary series, comparative data |
| `data-categorical-3` | `#f59e0b` (amber) | `#fbbf24` | Tertiary series, optional grouping |
| `data-categorical-4` | `#8b5cf6` (violet) | `#a78bfa` | Quaternary series |
| `data-categorical-5` | `#ec4899` (pink) | `#f472b6` | Quinary series, outlier grouping |

**Accessibility check:**  
All categorical colors meet WCAG AA (≥ 4.5:1) against both `surface-primary` and `surface-secondary` in their respective themes.

---

## 4. Dark Mode Implementation Strategy

1. **Theme switching:** Use CSS custom properties with a `[data-theme="dark"]` selector.
2. **Surface inversion:** Backgrounds darken, text lightens, but status and data colors shift to higher luminance variants to maintain contrast.
3. **Testing matrix:** Verify every color pair (text/background, status/background, data/background) in both themes.

Example CSS structure:
```css
:root {
  --surface-primary: #ffffff;
  --text-primary: #1e293b;
  --status-success: #059669;
  --data-categorical-1: #6366f1;
  /* ... */
}

[data-theme="dark"] {
  --surface-primary: #0f172a;
  --text-primary: #f1f5f9;
  --status-success: #10b981;
  --data-categorical-1: #818cf8;
  /* ... */
}
```

---

## 5. Contrast and Non-Color Fallbacks

**Contrast enforcement:**
- All text meets WCAG AA (≥ 4.5:1) against its background.
- UI controls (buttons, inputs) meet ≥ 3:1 for non-text contrast.
- Status indicators use icon + color + label pattern.

**Non-color fallbacks for data visualization:**
- Offer pattern fills (stripes, dots, hatches) as an optional accessibility toggle.
- In monochrome or print views, use lightness variation and texture.

---

## 6. Migration and Adoption Guidance

**Phase 1:** Replace hardcoded colors with semantic tokens in the design system.
**Phase 2:** Implement theme switching with the dark mode palette.
**Phase 3:** Audit existing charts and status indicators to map to the new categorical and status roles.
**Phase 4:** Add developer linting (e.g., Style Dictionary, Polished) to prevent direct hex values.

**Risk control:**  
Keep the previous status red (`#dc2626`) and green (`#059669`) aliased during migration to avoid breaking existing alert logic.

---

## 7. Verification Checklist

- [ ] All text/background pairs pass WCAG AA in both themes.
- [ ] Status colors are distinguishable for common colorblind types.
- [ ] Data categorical palette has perceptual balance (not one color dominating attention).
- [ ] Dark mode surfaces don’t appear “washed out” or overly saturated.
- [ ] Print/grayscale test: all meaning is preserved without color.

---

**Next steps you might want:**
1. I can generate a full token JSON for your design‑system configuration.
2. I can review an existing dashboard screenshot and map its current colors to this system.
3. I can provide a Figma/Code snippet for the theme switch implementation.

Would you like to proceed with any of these?