I’ll reconstruct the layout system from your 2018 brand‑guidelines PDF and translate it into a modern, reusable layout system.

---

## **1. What I’d extract from the PDF**

From the diagrams and specs, I’d capture:

| Element | What to look for | Why it matters |
|---------|------------------|----------------|
| **Grid type** | Manuscript, column‑grid, modular, baseline‑grid, or hybrid. | Determines the underlying layout logic. |
| **Margins** | Outer margins (left/right/top/bottom), gutter widths, column count. | Defines the live‑area boundary and column spacing. |
| **Column logic** | Fixed vs. fluid columns, column‑span rules, breakpoints if shown. | Governs how content can be arranged. |
| **Baseline rhythm** | Vertical spacing unit (e.g., 8 px, 12 px, 1.5× line‑height). | Ensures vertical alignment and visual rhythm. |
| **Content zones** | Header/footer regions, sidebars, content‑well boundaries. | Shows where fixed vs. flexible content lives. |
| **Scale increments** | Type‑size steps, spacing multiples (e.g., 8 px, 16 px, 24 px). | Keeps proportions consistent. |
| **Artifact examples** | How the grid is applied in real pages (e.g., title page, body text, data tables). | Reveals practical exceptions and patterns. |

**Confidence note:** I’d treat measurements as *observed* if they’re labeled in the PDF, and *inferred* if I’m estimating from diagrams. I’d flag any mismatch between described rules and visible examples.

---

## **2. How I’d translate it into a modern layout system**

### **Step 1 – Classify the original grid**
- If it’s a **manuscript grid** (single column with wide margins), I’d preserve the margins and baseline rhythm but add a responsive column‑grid overlay for modern web/app use.
- If it’s a **modular grid** (rows + columns), I’d extract the module size and gutter ratio, then adapt it to CSS Grid or Flexbox with the same proportions.
- If it’s a **column‑grid only**, I’d keep the column count and gutter logic but make it fluid across breakpoints.

### **Step 2 – Define the responsive adaptation**
| Original (2018) | Modern translation |
|-----------------|---------------------|
| Fixed‑width columns | Fluid columns (`fr` units or `%`) with a max‑width container. |
| Static breakpoints | Mobile‑first breakpoints (≥640 px, ≥1024 px, ≥1440 px). |
| Print‑focused margins | Viewport‑relative margins (`max(2rem, 5vw)`) for screens. |
| Baseline grid in points | Convert to rem/px with a vertical‑rhythm CSS custom property (e.g., `--baseline: 0.5rem`). |

### **Step 3 – Create the layout tokens**
```css
/* Layout tokens derived from the PDF */
:root {
  /* Margins */
  --margin-outer: clamp(1rem, 5vw, 3rem);
  --margin-inner: 1.5rem;
  
  /* Grid */
  --grid-columns: 12;
  --grid-gutter: 1.5rem;
  --grid-max-width: 1200px;
  
  /* Baseline rhythm */
  --baseline: 0.5rem; /* 8px equivalent */
  --spacing-unit: calc(var(--baseline) * 2); /* 16px */
  
  /* Content zones */
  --header-height: 4rem;
  --sidebar-width: 16rem;
}
```

### **Step 4 – Build the layout components**
1. **Container** – Max‑width wrapper with outer margins.
2. **Grid wrapper** – CSS Grid with `repeat(var(--grid-columns), 1fr)` and gap set to `--grid-gutter`.
3. **Column spans** – Utility classes like `.span-4`, `.span-8` that respect the column count.
4. **Baseline alignment** – A `vertical-rhythm` class that sets `margin‑bottom` and `line‑height` in multiples of `--baseline`.
5. **Breakpoint‑specific overrides** – Reduce columns, adjust gutters, or collapse sidebars on smaller screens.

### **Step 5 – Document the system**
A one‑page layout guide that shows:
- The original PDF grid diagram (for reference).
- The new token map.
- Example layouts (title block, two‑column text, card grid) in both the original and modern versions.
- A “migration note” explaining what changed (e.g., fluid vs. fixed, added responsiveness) and what was preserved (e.g., margin ratio, baseline rhythm).

---

## **3. Verification steps**
- **Overlay test**: Place the original PDF page next to a modern implementation and check alignment of key elements.
- **Extract check**: Copy text from the PDF and paste into the new layout—ensure reading order and line breaks feel consistent.
- **Responsive sweep**: Test the new grid at mobile, tablet, and desktop widths to confirm the adapted logic holds.

---

## **4. What I’d deliver**
1. **A layout‑specification document** with:
   - Extracted measurements (observed vs. inferred).
   - Token definitions.
   - CSS/SCSS code snippets.
   - Visual comparison (original vs. modern).
2. **A starter HTML/CSS template** that implements the new grid.
3. **A checklist** for applying the system to new templates (e.g., “Set container max‑width,” “Use baseline multiples for vertical spacing”).

---

**Next move:** If you share the PDF (or a few key pages), I can extract the exact grid numbers and produce a tailored layout spec and code template. Would you like to proceed?