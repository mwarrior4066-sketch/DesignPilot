I’ll write a backend architecture spec for a multi-tenant scheduling platform with the requested capabilities.  
I’ll follow the `backend_architecture_spec` contract, which requires explicit decisions about actors/resources, source-of-truth, authorization, consistency, delivery patterns, and observability.

---

## Backend Architecture Spec: Multi‑Tenant Scheduling Platform

### 1. System Framing
**Product:** A scheduling platform where teams (workspaces) coordinate calendars, manage approvals, and trigger customer‑side automations.  
**Why architecture is needed:** The existing REST‑and‑relational stack is inconsistent on background jobs and eventing; we must add multi‑tenant isolation, regional data residency, audit trails, activity feeds, approval workflows, and outbound webhooks without breaking scale or operational sanity.

### 2. Core Model and Authority Boundaries

#### Actors, Resources, Actions
- **Actors:** End‑user (member), Workspace Admin, System‑service (background jobs), Customer‑system (webhook consumer).
- **Resources:**  
  - `Workspace` – tenant container, owns regional data‑location policy.  
  - `Member` – belongs to a workspace, has role (member, admin).  
  - `Calendar` – belongs to a workspace, holds events.  
  - `Event` – scheduled item, references calendar, optional approval‑flow.  
  - `ApprovalFlow` – defines steps, approvers, timeout.  
  - `Approval` – instance of a flow for a specific event.  
  - `ActivityEvent` – immutable record of a change (event created, approved, etc.).  
  - `WebhookSubscription` – workspace‑defined endpoint + event‑types.  
  - `AutomationRule` – customer‑defined condition‑action pair (future).
- **Source‑of‑truth ownership:**  
  - `Workspace` is the root tenant boundary—all child resources are owned by a workspace.  
  - `ActivityEvent` is append‑only, immutable; its writer is the system service that observed the change.  
  - `Approval` is owned by the `Event`; its state transitions are linearizable within the workspace.
- **Authorization model:** ReBAC (Relationship‑Based Access Control).  
  - Every resource carries a `workspace_id`.  
  - Permissions are derived from relationships: `Member` → `Workspace` → `Calendar` → `Event`.  
  - Workspace‑admin can manage members, calendars, webhooks, automation rules.  
  - Object‑level authorization is enforced by a central policy engine that evaluates `actor`, `resource`, `action` against the relationship graph.

### 3. Data, Consistency, and Delivery Design

#### Consistency Stance
- **Primary data:** Event, Calendar, Approval – linearizable within a workspace (read‑your‑writes). Achieved via workspace‑affinitized database shard.  
- **Activity feed:** Bounded staleness (≤500ms) acceptable; feed is built from `ActivityEvent` table, which is written synchronously with the business mutation (same transaction) but may be read via a separate read‑replica.  
- **Audit trails:** Immutable, linearizable—appended in the same transaction as the change that triggered them.

#### Delivery Patterns
- **Activity feed pagination:** Keyset‑based (`cursor: {timestamp, id}`) using the `ActivityEvent` table’s `(workspace_id, occurred_at, id)` index.  
- **Approval‑workflow notifications:** In‑app feed + optional email. Use an internal message queue (e.g., Redis Streams) to decouple notification delivery from the approval state transition.  
- **Outbound webhooks:**  
  - Webhook events are placed in a regional, workspace‑scoped outbox table (`webhook_outbox`) in the same transaction as the business event.  
  - A regional background processor reads the outbox, delivers to customer endpoints with retry‑and‑backoff, moves to dead‑letter after N failures.  
  - Delivery order per‑workspace is preserved; cross‑workspace order is not required.  
- **Background jobs:**  
  - Recurring (e.g., approval‑timeout checks) are scheduled via a `scheduled_jobs` table, polled by a regional scheduler service.  
  - Ad‑hoc jobs (e.g., “recompute feed for workspace”) are pushed to a workspace‑specific queue.  
- **Customer‑defined automation rules (future):**  
  - Rules are stored as `AutomationRule` resources.  
  - A rule‑engine service evaluates incoming `ActivityEvent` streams against registered rules, executes actions (e.g., “create a follow‑up event”, “call a webhook”) via the same outbox pattern.

### 4. Observability and Failure Posture

#### Operational Tax
- **Metrics per workspace:** API request rate, approval‑cycle time, webhook delivery latency, error rates.  
- **Tracing:** Every request and background job carries a `trace_id` that flows through database calls, queue messages, and outbound webhooks.  
- **Logs:** Structured logs include `workspace_id`, `resource_id`, `actor_id`, `trace_id`.  
- **Audit trail:** Immutable `AuditLog` table records who did what, when, from which IP, with which parameters—separate from `ActivityEvent` (which is for user‑facing feed).

#### Resilience and Degradation
- **Webhook delivery:** Circuit‑breaker per endpoint; if an endpoint fails repeatedly, pause deliveries and alert workspace‑admin.  
- **Database regional failover:** Each region has a primary shard; failover is manual, with downtime, because data‑residency requirements forbid cross‑region replication of primary data.  
- **Activity‑feed read‑replica lag:** If lag exceeds threshold, serve feed from primary with a cost‑warning header.  
- **Approval‑timeout processor:** If the processor fails, timeouts will be delayed until it recovers—acceptable because timeout is a safety net, not a real‑time guarantee.

---

### Required Decisions Made Explicit

1. **Actor‑Resource‑Action model** – defined above; every resource belongs to a workspace.  
2. **Source‑of‑truth ownership** – workspace‑rooted; activity events are immutable, append‑only.  
3. **Authorization model** – ReBAC, evaluated by a central policy engine.  
4. **Consistency stance** – linearizable for primary data, bounded staleness for feeds.  
5. **Delivery patterns** – keyset pagination for feeds, outbox for webhooks, scheduled‑jobs table for recurring work.  
6. **Observability tax** – metrics, tracing, structured logs, immutable audit table.

### Evidence Classes Covered
- **Data‑model dependency** – workspace‑id on every resource, sharding strategy.  
- **Permission rule** – ReBAC, central policy engine.  
- **Consistency model** – linearizable vs. bounded staleness, outbox pattern.  
- **Implementation constraint** – regional data residency forbids cross‑region replication, manual failover.

### Risks and Safer Path
- **Risk:** Outbox processor becomes a bottleneck.  
  **Mitigation:** Shard outbox by workspace‑id, scale processors per region.  
- **Risk:** Customer‑defined rules could create infinite loops.  
  **Mitigation:** Rule‑engine evaluates rules in a sandbox with cycle detection and rate‑limits per workspace.  
- **Safer build order:**  
  1. Solidify workspace‑boundary and ReBAC policy engine.  
  2. Implement activity‑feed and audit‑log writing in same transaction.  
  3. Add outbox‑based webhooks.  
  4. Add approval‑workflow state machine.  
  5. Finally, plug‑in customer‑defined automation rules.

---

**Next practical move:**  
Translate this spec into a concrete service‑boundary diagram and a phased rollout plan that starts with the data‑model changes and policy engine.