I’ll write a component spec for a split button with primary action, dropdown trigger, keyboard support, disabled states, loading states, and mobile touch targets.

---

## Split Button Component Specification

**Purpose and scope**  
A split button combines a primary action button with a dropdown trigger for secondary actions. It’s used when one action is dominant but related alternatives exist (e.g., Save + Save as draft). The component owns the visual grouping, interaction logic, keyboard navigation, dropdown positioning, and state handling for the button pair. It does not own the dropdown menu content styling—that belongs to a separate Menu component.

**Anatomy**  
- **Primary button**: clickable area for the dominant action.  
- **Divider**: visual separator between primary button and trigger.  
- **Dropdown trigger**: icon button that opens/closes the secondary actions menu.  
- **Dropdown menu**: positioned below the trigger, contains secondary action items.  
- **Container**: groups primary button and trigger into a single interactive unit.

**State matrix**  
- **Default**: primary and trigger are enabled, menu closed.  
- **Hover**: visual feedback on hovered segment only.  
- **Focus**: keyboard focus moves through primary → trigger → menu items; focus ring visible on focused element.  
- **Active/pressed**: pressed state on click/tap.  
- **Disabled**: entire split button disabled, or primary disabled while trigger remains active for “Save disabled but Save as draft allowed” scenarios.  
- **Loading**: primary button shows spinner, disables interaction while async action processes; trigger remains disabled during load unless async action is trigger-based.  
- **Menu open**: trigger is “active” styled, menu positioned below (or above if space constrained).

**Accessibility and implementation notes**  
- **Keyboard**: Tab moves to primary button, then trigger. Arrow down/up opens menu and moves focus into menu items. Escape closes menu. Enter/space activates focused item.  
- **Screen reader**: aria-label on trigger (“More save options”), aria-expanded on trigger, aria-haspopup=“menu”. Menu items use role=“menuitem”.  
- **Touch targets**: minimum 44×44px for each segment on mobile. Divider must not be interactive.  
- **Focus management**: when menu opens, focus moves to first menu item. When menu closes, focus returns to trigger.  
- **Error states**: not part of core component; validation errors should be communicated at form level, not on the split button itself.  
- **Tokens**: use existing button tokens for size, color, spacing. Variant prop: “primary”, “secondary”, “ghost”. Size prop: “sm”, “md”, “lg”.  
- **Do not hardcode** “Save” or specific actions—these are passed as props or slots.

**Props interface**  
```tsx
interface SplitButtonProps {
  primaryAction: {
    label: string;
    onClick: () => void;
    disabled?: boolean;
    loading?: boolean;
  };
  secondaryActions: Array<{
    label: string;
    onClick: () => void;
    disabled?: boolean;
  }>;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  menuPlacement?: 'bottom' | 'top';
  'aria-label'?: string;
}
```

**Visual spec**  
- Divider: 1px vertical line, matching button border color, non-interactive.  
- Spacing: 4px gap between primary button and trigger.  
- Icons: primary button has no icon by default; trigger uses chevron-down.  
- Loading: spinner replaces primary button text, button width preserved.

**Responsive behavior**  
- Mobile: entire component may collapse into a single dropdown button if width < 320px.  
- Touch: press-and-hold on trigger could be used as a long-press shortcut for first secondary action (optional).

**Usage example**  
```tsx
<SplitButton
  primaryAction={{
    label: 'Save',
    onClick: handleSave,
    loading: isSaving
  }}
  secondaryActions={[
    { label: 'Save as draft', onClick: saveDraft },
    { label: 'Save and close', onClick: saveAndClose }
  ]}
  variant="primary"
  size="md"
/>
```

**Why this component exists**  
It prevents action sprawl in UI while keeping secondary actions discoverable. It’s more compact than a button group, more scannable than a standalone menu button, and maintains interaction parity across mouse, keyboard, and touch.