**Route:** `api_reliability_security_review` (compound)  
**Mode:** AUDIT  
**Phase:** implementation  

---

## API Reliability & Security Review

### 1. Failure Semantics
**Governing decision:** The API must adopt RFC 9457 (Problem Details) for structured error responses.  
**Why:** Plain‑string errors hide actionable debugging information, prevent client‑side recovery logic, and make observability harder. A `400 Bad Request` with a plain‑string body does not tell the client whether the error is retryable, whether it’s a validation failure, or whether the request can be corrected.  
**Required fix:** Return `application/problem+json` with `type`, `title`, `status`, `detail`, and `instance` fields.

### 2. Authorization Perimeter
**Governing decision:** The endpoint must enforce object‑level authorization (BOLA/BFLA) before performing the mutation.  
**Why:** Checking only that the caller is logged in allows any authenticated user to add members to any project—a classic Broken Object Level Authorization (BOLA) vulnerability.  
**Required fix:** Add a server‑side check that the caller is a project admin (or has equivalent `project:write` permission). Deny by default; do not rely on the UI to hide the endpoint.

### 3. Idempotency Contract
**Governing decision:** The endpoint must support idempotency keys for safe retries.  
**Why:** Without idempotency, a network timeout or client retry can add the same user multiple times. A `POST` that modifies membership is not idempotent by default.  
**Required fix:** Accept an `Idempotency‑Key` header (or a `idempotency_key` field). Store the key with a TTL; on a duplicate request within the window, return `409 Conflict` with a `problem+json` payload that references the original response.

### 4. Async Job Lifecycle (if needed)
**Governing decision:** If adding a member triggers side‑effects (emails, notifications, audit logs) that could delay the response, the endpoint must shift to an async model.  
**Why:** Long‑running side‑effects inside a synchronous `POST` risk timeouts, repeated work on retry, and opaque failure states.  
**Required fix:** If side‑effects exceed ~100 ms, return `202 Accepted` with a `Location` header pointing to a job‑status endpoint. The client polls for completion.

### 5. Resilience & Observability
**Governing decision:** The endpoint must emit a `trace_id` and structured logs for debugging membership changes.  
**Why:** When a user is added incorrectly, operators need to see who made the request, which project was targeted, and what authorization check passed or failed. Plain‑string errors disappear in aggregators.  
**Required fix:** Include a `trace_id` header in the response and log the full request context (caller ID, project ID, idempotency key, authorization result) as structured JSON.

---

## Summary of Required Changes

| Concern | Current Design | Required Fix |
|---------|----------------|--------------|
| Error envelope | Plain string | RFC 9457 `application/problem+json` |
| Authorization | Logged‑in only | Object‑level check: caller must be project admin |
| Idempotency | None | `Idempotency‑Key` header with `409 Conflict` on replay |
| Side‑effects | Synchronous | If heavy, `202 Accepted` + job‑status endpoint |
| Observability | Unstructured logs | `trace_id` + structured logging of request context |

**Next step:** Update the API spec to reflect these contracts before implementation begins. Each fix should be accompanied by a test that verifies the failure case (e.g., a non‑admin receives a `403 Forbidden` with a problem‑details object).