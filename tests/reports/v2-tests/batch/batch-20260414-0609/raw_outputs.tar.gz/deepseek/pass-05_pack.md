I’ll analyze this as a PDF remediation task. The user is describing a PDF exported from InDesign with accessibility and document integrity issues: broken reading order, missing tagging, broken TOC links, and pull quotes that disrupt the flow.

**Governing route:** `pdf_remediation_plan`  
**Supporting skills:** `document-accessibility-expert.md`, `pdf-layout-expert.md`  
**Task weight:** compound (high-risk, semantics at stake)  
**Visual input:** none, but the description is specific enough to proceed.

---

## PDF Remediation Plan

### Current failure state
This InDesign‑exported PDF is semantically broken:  
- Reading order is likely based on visual layout (two‑column, pull quotes) rather than logical sequence.  
- Images lack alt text and are marked decorative incorrectly.  
- Table‑of‑contents links are broken (likely missing or mismatched destinations).  
- Pull quotes interrupt the reading flow because they’re placed as floating elements without proper tagging.

### Remediation sequence
1. **Open the PDF in Adobe Acrobat Pro** (or a comparable remediation tool like PAC 2024, axe‑pdf, or PDF‑UA Checker).  
2. **Run an accessibility check** to generate a baseline report.  
3. **Fix the tag tree first**:
   - Use the **Reading Order tool** to rebuild the logical reading order.  
   - Ensure the two‑column layout is tagged as a single continuous flow, not as parallel columns.  
   - Re‑tag pull quotes as `<Quote>` or `<Aside>` and place them *after* the paragraph they reference in the tag tree (so they don’t break the flow).  
   - Mark decorative images as “Artifact” (remove them from the tag tree entirely).  
   - Add alt text to meaningful images using the “Set Alternate Text” dialog.  
4. **Repair the table of contents**:
   - In the Tags panel, locate the TOC entries.  
   - Use the **Create Link** tool to link each entry to its corresponding heading’s destination.  
   - Verify that destinations are correctly named and that zoom settings are appropriate (e.g., “Fit Page”).  
5. **Verify reading order** with the Read Out Loud feature or a screen‑reader emulator (NVDA, VoiceOver).  
6. **Run a final compliance check** (PDF/UA or WCAG 2.1 Level AA) and note any remaining warnings.

### Verification checks
- **Copy‑paste test**: Select all text and paste into a plain‑text editor. The pasted text should follow a logical, uninterrupted sequence.  
- **Screen‑reader test**: Use NVDA or VoiceOver to navigate the PDF. Headings, links, and images should announce correctly.  
- **Link test**: Click every TOC entry; it should jump to the correct section.  
- **Accessibility checker**: No critical errors (tags missing, reading order, contrast) should remain.

### Risk controls
- **Do not flatten or rasterize** the PDF—this destroys text layers and tagging.  
- **Preserve the original InDesign file** as the source of truth; re‑export if major structural changes are needed.  
- **Back up the original PDF** before editing, and save incremental versions.  
- **If the tag tree is too corrupted**, consider re‑exporting from InDesign with “Tagged PDF” enabled and “Use Structure for Tab Order” checked, then re‑apply alt text and links in Acrobat.

### Next steps
If you can share the PDF (or a representative screenshot of its structure), I can give more specific tagging instructions. If you’re working in a team, ensure the designer re‑exports from InDesign with accessibility settings enabled to reduce remediation time.

---

[SESSION_STATE]
{
  "route": "pdf_remediation_plan",
  "escalation_level": "compound",
  "decisions_committed": ["semantic_failure: reading order broken, images untagged, TOC links broken", "verification_method: copy‑paste, screen‑reader, link, accessibility checker", "destructive_shortcut_rejected: do not flatten or rasterize"],
  "evidence_classes_cited": ["standards_reference", "verification_method", "implementation_constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": ["Can you share the PDF or a screenshot of its structure for more specific tagging guidance?"],
  "turn": 1
}
[/SESSION_STATE]