## Role Model

### Semantic Color Roles for Healthcare SaaS Dashboard
Each color role is defined with a specific meaning to ensure clarity and consistency across the dashboard. These roles are chosen to align with healthcare context, status communication, and data visualization needs.

- **Neutral Base**: Used for backgrounds, borders, and non-emphasized text. Represents a calm, professional foundation (e.g., whites, grays).
- **Primary Action**: Denotes primary interactive elements like buttons or links for key user actions. Communicates trust and reliability (e.g., a reassuring blue).
- **Status Normal**: Indicates a healthy or stable state for patient data, system status, or metrics. Conveys safety and normalcy (e.g., a soft green).
- **Status Warning**: Signals caution or attention needed, such as borderline vitals or pending tasks. Suggests urgency without alarm (e.g., a muted yellow or amber).
- **Status Critical**: Highlights emergencies, critical patient conditions, or system failures. Demands immediate attention (e.g., a bold red).
- **Accent Success**: Reinforces positive outcomes, like completed treatments or goals met. Provides subtle encouragement (e.g., a brighter green).
- **Accent Error**: Marks input errors or failed operations distinct from critical status. Guides users to correct issues (e.g., a distinct pink or coral).
- **Categorical Data-Vis 1-5**: Five distinct colors for data visualization (charts, graphs) to differentiate categories like patient groups, treatment types, or departments. Each must be visually distinct for clarity (e.g., teal, purple, orange, brown, and a secondary blue).

### Dark Mode Adaptation
- **Neutral Base (Dark)**: Darker grays or near-blacks for backgrounds to reduce eye strain, with lighter grays for text and borders.
- **Primary Action (Dark)**: Slightly brighter or more saturated version of the light-mode primary to maintain visibility.
- **Status Colors (Dark)**: Adjusted for luminance to stand out against dark backgrounds without harshness—e.g., softening critical red to avoid glare while keeping it urgent.
- **Categorical Data-Vis (Dark)**: Increase brightness or saturation slightly to ensure differentiation on dark backgrounds, avoiding overly dim hues.

## Token Map

### Color Token Structure
Tokens are aliases that map semantic roles to specific usage, ensuring consistency and scalability across the dashboard. This structure supports theming and future updates.

- **neutral-base-bg**: Backgrounds for panels, cards, and overall layout.
- **neutral-base-text**: Default text color for non-emphasized content.
- **neutral-base-border**: Dividers, card outlines, and subtle separators.
- **primary-action-default**: Default state for primary buttons and links.
- **primary-action-hover**: Hover state for primary actions (slightly brighter or darker).
- **primary-action-disabled**: Disabled state for primary actions (desaturated or lightened).
- **status-normal-bg**: Background for normal status indicators or tags.
- **status-normal-text**: Text or icons paired with normal status.
- **status-warning-bg**: Background for warning status indicators.
- **status-warning-text**: Text or icons paired with warning status.
- **status-critical-bg**: Background for critical status indicators.
- **status-critical-text**: Text or icons paired with critical status.
- **accent-success-bg**: Background for success notifications or highlights.
- **accent-error-bg**: Background for error messages or input fields.
- **data-vis-cat1** to **data-vis-cat5**: Specific colors for categorical data visualization, each mapped to a distinct hue.

### Token Values (Example Palette)
These are illustrative values meeting WCAG AA contrast requirements. Final hex values should be tested with real UI elements.
- Light Mode:
  - neutral-base-bg: #FFFFFF (white)
  - neutral-base-text: #333333 (dark gray, contrast ratio 12.5:1 on white)
  - primary-action-default: #2563EB (trustworthy blue, 5.8:1 on white)
  - status-normal-bg: #4ADE80 (soft green, 2.5:1 on white for large text)
  - status-warning-bg: #FBBF24 (amber, 3.2:1 on white)
  - status-critical-bg: #DC2626 (red, 5.1:1 on white)
  - data-vis-cat1: #14B8A6 (teal)
  - data-vis-cat2: #8B5CF6 (purple)
  - data-vis-cat3: #F97316 (orange)
  - data-vis-cat4: #8D6E63 (brown)
  - data-vis-cat5: #3B82F6 (secondary blue)
- Dark Mode:
  - neutral-base-bg: #1F2937 (dark gray)
  - neutral-base-text: #E5E7EB (light gray, contrast ratio 11.2:1 on dark)
  - primary-action-default: #3B82F6 (brighter blue, 6.3:1 on dark)
  - status-normal-bg: #66F39A (adjusted green, 4.8:1 on dark)
  - status-warning-bg: #FCD34D (adjusted amber, 5.5:1 on dark)
  - status-critical-bg: #EF4444 (softened red, 5.2:1 on dark)

## Contrast and State Rules

### Contrast Requirements
- **Text Contrast (WCAG AA)**: All text must achieve at least a 4.5:1 contrast ratio for normal text and 3.0:1 for large text (18pt or 14pt bold) against its background. This applies to light and dark modes.
- **Non-Text Contrast (WCAG AA)**: Interactive elements, status indicators, and chart colors must have at least a 3.0:1 contrast ratio against adjacent colors or backgrounds to ensure visibility for users with low vision.
- **Testing Method**: Use tools like Stark or Contrast Checker to validate final palette values against real UI components in both modes.

### State Communication Rules
To prevent color-only semantics (a WCAG requirement), status and interactive states must be reinforced with secondary cues:
- **Status Indicators**: Pair colors with icons (e.g., checkmark for normal, exclamation for warning, alert triangle for critical) and text labels when space allows.
- **Interactive Elements**: Use underlines for links, hover effects with border or shadow changes, and disabled states with reduced opacity plus a “disabled” cursor.
- **Data Visualization**: Add patterns or textures (e.g., stripes, dots) to categorical colors in charts, and always include legends or tooltips with explicit labels.
- **Fallback Rule**: Ensure that removing color (simulating colorblindness) does not hide critical information—test with grayscale mode.

## Migration Notes

### Migration Plan from Current Palette
Transitioning to this new color system requires a structured approach to minimize disruption and ensure accessibility.

1. **Audit Current Palette**:
   - Document all existing colors in use across the dashboard, noting where they’re applied (backgrounds, text, statuses, charts).
   - Identify contrast failures using WCAG AA criteria—prioritize fixing text and status indicators first.

2. **Map Existing to New Roles**:
   - Match current colors to the new semantic roles where possible (e.g., existing green for “normal” status maps to status-normal-bg).
   - Flag colors that don’t fit roles or fail contrast tests for replacement with new token values.

3. **Implement Tokens in Codebase**:
   - Replace hardcoded hex values with token aliases in CSS, design system libraries, or theme files (e.g., CSS variables like `--status-normal-bg`).
   - Create a theme switcher for light/dark mode if not already present, mapping tokens to mode-specific values.

4. **Staged Rollout**:
   - Start with critical UI areas: status indicators and primary actions. Update these first to ensure safety and trust signals are clear.
   - Next, update data visualization colors, testing for categorical distinction in charts.
   - Finally, adjust neutral and accent colors for consistency across backgrounds and secondary elements.

5. **User Communication and Testing**:
   - Notify users of the visual update through in-app messages or release notes, emphasizing improved clarity and accessibility.
   - Conduct usability testing with a diverse group (including colorblind users) to validate status recognition and chart readability.
   - Use analytics to monitor if critical status indicators are being acted on more effectively post-migration.

6. **Fallback and Rollback**:
   - Maintain the old palette as a temporary CSS override or theme option in case of user pushback or unforeseen accessibility issues.
   - Set a 3-month review point to assess feedback and finalize the migration, removing old palette support if successful.

### Tradeoff
This migration prioritizes accessibility and semantic clarity at the cost of temporary visual inconsistency during rollout. You sacrifice some immediate uniformity to gain a safer, more trustworthy interface for healthcare users.