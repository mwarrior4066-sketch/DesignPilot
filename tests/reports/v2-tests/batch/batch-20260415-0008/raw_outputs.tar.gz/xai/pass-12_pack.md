## Reading Contexts and Constraints

Fintech products demand a type system that balances modernity, trust, and functional clarity across diverse platforms. Here are the key contexts and constraints shaping the choices:

- **Marketing Site**: The primary goal is to convey trust and professionalism to potential users. Text needs to be inviting yet authoritative, with clear hierarchy to guide users through value propositions and calls to action. Reading happens on varied screen sizes, often in shorter bursts, under diverse lighting conditions.
- **Web App Dashboard**: This environment prioritizes data density and scanability for financial information. Users need to parse tabular data, charts, and navigation quickly, often under time pressure or multitasking. The type system must handle small sizes for labels and large sizes for headlines, maintaining legibility in dense grids.
- **Mobile App**: Space is constrained, and reading often occurs in suboptimal conditions (e.g., glare, motion). Touch targets and legible microcopy are critical, with hierarchy compressed into smaller viewports. The type must remain clear at reduced sizes and support quick glances.

Constraints include:
- Cross-platform consistency to maintain brand identity.
- Accessibility requirements, ensuring WCAG 2.1 AA contrast ratios (at least 4.5:1 for normal text, 3:1 for large text).
- Support for tabular data, requiring typefaces with distinct numerals and alignment-friendly metrics.
- A modern, trustworthy aesthetic that avoids overly decorative or dated styles, aligning with fintech’s need for precision and reliability.

## Scale and Role Map

I recommend a dual-typeface system combining a modern sans-serif for primary UI and marketing content with a complementary monospace or slab-serif for tabular data. This ensures hierarchy, trust, and data clarity. Here’s the role map with specific typeface and weight assignments:

- **Primary Typeface**: **Inter** (sans-serif, open-source, Google Fonts)
  - **Display Headlines** (Marketing Site, App Hero Sections): 36-48px, Inter Bold (700), used for primary calls to action and top-level messaging to convey authority.
  - **Section Headers** (All Platforms): 24-32px, Inter Semi-Bold (600), for secondary hierarchy in dashboards and marketing sections.
  - **Subheaders/Navigation** (Web App, Mobile): 16-20px, Inter Medium (500), for navigation items and tertiary hierarchy, balancing prominence and space.
  - **Body Text** (Marketing Site, App Content): 16-18px, Inter Regular (400), for readable paragraphs and longer content, optimized for web and mobile.
  - **Captions/Labels** (Dashboard, Mobile): 12-14px, Inter Regular (400), for compact metadata and form labels, ensuring clarity at small sizes.
- **Data Typeface**: **IBM Plex Mono** (monospace, open-source, Google Fonts)
  - **Tabular Data/Numerals** (Dashboard, Mobile): 12-14px, IBM Plex Mono Regular (400), for financial figures in tables and charts, ensuring alignment and distinct characters (e.g., 0 vs. O).
  - **Data Annotations** (Dashboard): 10-12px, IBM Plex Mono Regular (400), for secondary data labels, maintaining consistency in dense views.

**Rationale**: Inter offers a clean, geometric sans-serif design with multiple weights, a modern feel, and excellent readability across screen sizes. Its open-source nature ensures licensing flexibility for fintech startups. IBM Plex Mono complements it with monospaced precision for financial data, ensuring tabular alignment and character distinction critical for dashboards. Both typefaces support variable font options if needed for fine-tuned rendering, though static weights are prioritized for broader compatibility.

## Readability Rules

To ensure legibility and accessibility across platforms, adhere to these rules:

- **Line Length**: Target 50-75 characters per line for body text on marketing sites and web apps (approximately 600-800px width on desktop). On mobile, aim for 30-50 characters per line to prevent excessive wrapping. For dashboard labels and captions, keep lines under 30 characters to fit constrained spaces.
- **Contrast**: Ensure WCAG 2.1 AA compliance with minimum ratios of 4.5:1 for text below 18px/14pt bold (e.g., body, captions) and 3:1 for text above this threshold (e.g., headlines, headers). For dark mode, test against light text on dark backgrounds (e.g., #FFFFFF at 90% opacity on #1A1A1A). Use tools like Stark or Contrast Checker to validate pairings with your color system.
- **Spacing**: Set line height (leading) at 1.5x the font size for body text (e.g., 16px text at 24px line height) to aid readability in paragraphs. For headers, use 1.2-1.3x (e.g., 24px header at 30px line height) to keep hierarchy tight. In dashboards, reduce captions and data labels to 1.3x for density (e.g., 12px at 16px line height). Add 8-16px of paragraph spacing (margin-bottom) for body content, scaling down to 4-8px on mobile.
- **Tabular Data**: Ensure IBM Plex Mono tables have at least 4px padding per cell to prevent visual clutter. Align numerals right for consistency in financial data, and use subtle grid lines or zebra striping for scanability if contrast allows.
- **Responsive Behavior**: Scale font sizes down by 10-15% on mobile (e.g., 16px body to 14px), but never below 12px for critical text. Use viewport-based typography (CSS `clamp`) to adjust sizes fluidly across breakpoints if supported by your tech stack.

## Adoption Guidance

Phasing this type system into an existing or new fintech product requires a structured rollout to minimize disruption and ensure consistency. Here’s the sequence:

1. **Audit and Baseline (1-2 Weeks)**:
   - Review current typography across marketing, web app, and mobile for inconsistencies in fonts, weights, sizes, and readability issues.
   - Document where trust or data clarity is undermined by existing choices (e.g., poor numeral distinction in tables, low contrast).
   - Secure stakeholder buy-in on the modern, trustworthy aesthetic of Inter and IBM Plex Mono with mockups or live demos.

2. **Core Implementation (2-4 Weeks)**:
   - Start with the web app dashboard as the highest-impact area for financial data clarity. Implement Inter for UI hierarchy and IBM Plex Mono for tables, prioritizing data-heavy screens.
   - Define CSS or design tokens for each role (e.g., `--font-headline: 'Inter', sans-serif; font-weight: 700;`) to ensure systematic application.
   - Test readability and contrast on key dashboard views, adjusting sizes or spacing if WCAG thresholds fail.

3. **Marketing Site Update (1-2 Weeks)**:
   - Apply Inter’s weight range to marketing headlines, body text, and CTAs, focusing on trust signals through bold, confident headers.
   - Validate responsive behavior across desktop and mobile breakpoints, ensuring line lengths stay within readability targets.

4. **Mobile Alignment (1-2 Weeks)**:
   - Adapt the scale map for mobile constraints, reducing sizes while maintaining hierarchy. Focus on touch-friendly captions and labels.
   - Test in real-world conditions (e.g., outdoor glare, small screens) to confirm legibility of critical microcopy.

5. **Documentation and Handoff (1 Week)**:
   - Create a type system style guide detailing roles, sizes, weights, spacing, and accessibility rules. Include code snippets for developers (e.g., CSS classes, React components).
   - Host fonts via CDN (Google Fonts for Inter and IBM Plex Mono) or self-host if latency or privacy is a concern for fintech compliance.
   - Train design and dev teams on applying the system consistently, emphasizing data clarity in dashboards.

6. **Iterative Refinement (Ongoing)**:
   - Gather user feedback on readability, especially for dashboard data and mobile use. Adjust line heights or sizes if specific contexts underperform.
   - Monitor rendering issues (e.g., fallback fonts on older devices) and consider variable font adoption if tech debt accumulates.

**Tradeoff**: This phased approach prioritizes the dashboard first for immediate data clarity gains, at the cost of temporary inconsistency with marketing and mobile. You sacrifice short-term brand unity to gain faster functional wins in the core product, with alignment following quickly.

This type system, rooted in Inter’s modern versatility and IBM Plex Mono’s data precision, will establish a trustworthy, functional fintech identity across platforms while meeting accessibility and hierarchy needs. If you’d like mockups of specific screens or alternative typeface options, let me know.