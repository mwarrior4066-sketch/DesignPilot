## Component Spec: Split Button

### Purpose and Scope
The split button is a composite UI control that combines a primary action button with a dropdown trigger for secondary actions. This component is designed for scenarios where a user needs quick access to a default action while having the option to choose related alternatives. In this case, the primary action is "Save," and the secondary actions are "Save as draft" and "Save and close." The component must be accessible, responsive, and implementation-ready across web and mobile contexts.

This spec defines the anatomy, states, accessibility behavior, and implementation guardrails for the split button, ensuring it meets usability, touch-target, and keyboard-interaction requirements.

### Anatomy
The split button consists of two distinct interactive elements within a single container:
- **Primary Action Button**: Executes the default action ("Save"). This is the larger, more prominent part of the component, visually weighted to emphasize its priority.
- **Dropdown Trigger**: A smaller, visually distinct section (typically an icon or chevron) that reveals a dropdown menu with secondary actions ("Save as draft" and "Save and close") when activated.
- **Container**: A wrapper that ensures the two elements are visually cohesive and aligned, often with a shared border or background to indicate they are part of one control.

Visual layout:
- The primary action button is on the left, taking up approximately 70-80% of the total width to prioritize its action.
- The dropdown trigger is on the right, taking up the remaining 20-30%, often marked by a downward chevron or similar icon.
- A subtle vertical separator (e.g., a 1px line or color shift) may exist between the two to clarify the boundary, especially in light themes.

### State Matrix
The split button must handle multiple states for both the primary action and dropdown trigger, ensuring clarity and usability across contexts.

- **Default (Enabled) State**:
  - Primary action: Fully interactive, background color reflects the primary button style (e.g., solid fill, high contrast), with clear text ("Save").
  - Dropdown trigger: Interactive, background may be a lighter variant or outline style, with a visible chevron/icon.
  - Cursor: Pointer on hover (for desktop).
- **Hover State** (Desktop only):
  - Primary action: Background darkens slightly or shows an overlay to indicate interactivity.
  - Dropdown trigger: Chevron/icon or background highlights to indicate clickability.
- **Focus State**:
  - Primary action: Visible focus ring (minimum 2px outline, WCAG-compliant contrast) around the button when tabbed to.
  - Dropdown trigger: Separate focus ring around the trigger when tabbed to, ensuring the two elements are independently focusable.
- **Active/Pressed State**:
  - Primary action: Darkened or inset appearance when clicked or tapped to confirm the action.
  - Dropdown trigger: Similar pressed effect, or the chevron rotates/flips to indicate the dropdown is open.
- **Disabled State**:
  - Primary action: Grayed-out background, reduced opacity (e.g., 50%), non-interactive, with text/icon dimmed. No hover or focus effects.
  - Dropdown trigger: Similarly grayed out, non-interactive. If the primary action is disabled, the dropdown must also be disabled to avoid partial functionality confusion.
- **Loading State**:
  - Primary action: Replace "Save" text with a spinner or loading icon (centered), disable interaction during the loading process to prevent double-submits.
  - Dropdown trigger: Disabled and dimmed during loading to prevent conflicting actions.
- **Dropdown Open State**:
  - Primary action: Unchanged or slightly dimmed to shift attention to the menu.
  - Dropdown trigger: Chevron rotates upward (if applicable), and the dropdown menu appears below (or above if viewport-constrained), aligned to the trigger’s edge.
  - Menu items: Each secondary action ("Save as draft," "Save and close") is a list item with hover/focus states, clear text, and sufficient padding for touch targets.

Touch-target sizing:
- Primary action: Minimum 44x44px touch target (per WCAG 2.5.5) on mobile, with padding to ensure tappable area.
- Dropdown trigger: Minimum 44x44px touch target, even if the visible icon is smaller, achieved via transparent padding.
- Dropdown menu items: Minimum 44px height per item, full-width tap area.

### Accessibility and Implementation Notes
#### Accessibility Behavior
The split button must meet WCAG 2.1 Level AA requirements for keyboard navigation, focus management, and screen-reader support:
- **Keyboard Navigation**:
  - Tab order: Primary action receives focus first, followed by the dropdown trigger. Two separate tab stops ensure clarity.
  - Primary action activation: `Enter` or `Space` triggers the "Save" action when focused.
  - Dropdown trigger activation: `Enter`, `Space`, or `Down Arrow` opens the dropdown menu; `Up Arrow` may open it with the last item focused (optional).
  - Menu navigation: Once open, `Up` and `Down` arrows cycle through menu items; `Enter` or `Space` selects an item; `Escape` closes the menu and returns focus to the trigger.
- **Focus Management**:
  - Focus must remain trapped within the dropdown when open, cycling through menu items until a selection is made or `Escape` is pressed.
  - Focus ring must be visible (minimum 2px, 4.5:1 contrast ratio against background) on both the primary action and trigger.
- **ARIA Attributes**:
  - Primary action: `role="button"`, `aria-label="Save"` if text is insufficient or icon-only.
  - Dropdown trigger: `role="button"`, `aria-haspopup="menu"`, `aria-expanded="true|false"` to indicate menu state, `aria-label="Save options"` or similar.
  - Dropdown menu: `role="menu"`, with each item as `role="menuitem"`.
  - Disabled state: `aria-disabled="true"` on both elements when applicable.
  - Loading state: `aria-busy="true"` on the primary action during loading, with a status message ("Loading...") for screen readers if the spinner is not announced.
- **Motion Safety**:
  - Dropdown open/close animation must respect `prefers-reduced-motion`. If enabled, skip or minimize transitions (e.g., instant appearance instead of slide-down).
  - No unnecessary hover effects or animations on the primary action.

#### Mobile and Touch Considerations
- Ensure 44x44px minimum touch targets for all interactive elements, including menu items.
- Dropdown menu must be viewport-aware, adjusting position (above/below) to avoid being cut off on smaller screens.
- Avoid hover-dependent behavior; rely on tap for all interactions.

#### Implementation Boundaries
- **State Ownership**: The component must manage its own dropdown open/close state internally but allow parent components to override or listen to action events (e.g., "Save" click, menu item selection) via callbacks or events.
- **Rendering Model**: Render as a single container with two child elements (primary button and trigger). Use CSS flexbox or grid for alignment to ensure responsiveness. Dropdown menu should be a positioned element (absolute or fixed) tied to the trigger’s coordinates.
- **Semantic Contract**: HTML structure must reflect the dual nature: `<div class="split-button"> <button class="primary">Save</button> <button class="trigger" aria-haspopup="menu">▼</button> <ul class="menu" role="menu">...</ul> </div>`. Avoid using a single `<button>` with hacks for split behavior.
- **Cost and Degraded Path**: Keep the component lightweight; avoid heavy dependencies for dropdown positioning or state management if possible. Provide a fallback where the dropdown trigger degrades to a separate "More options" button on constrained viewports if positioning fails.
- **Framework Notes**: If using React, Vue, or similar, ensure event bubbling doesn’t trigger unintended parent handlers (e.g., stopPropagation on menu clicks). For CSS, use `:focus-visible` over `:focus` to avoid unnecessary focus rings on click for non-keyboard users.

This split button spec balances usability, accessibility, and implementation feasibility, ensuring it works across devices and input methods while maintaining a clear primary/secondary action hierarchy.