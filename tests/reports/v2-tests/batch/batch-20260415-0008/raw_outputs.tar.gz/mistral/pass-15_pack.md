Here’s a **backend architecture spec** for your multi-tenant scheduling platform, structured to address scalability, data residency, auditability, and extensibility while preserving the existing REST/relational foundation. The spec follows the required headings from the `backend_architecture_spec` contract and includes tradeoffs, constraints, and operational concerns.

---

## **Backend Architecture Spec**
**System**: Multi-tenant scheduling platform with team workspaces, activity feeds, approvals, and webhooks.
**Constraints**:
- Regional data residency (tenant data isolated by region).
- Audit trails for all mutations.
- Eventual support for customer-defined automation rules.
- Existing REST APIs and relational database (e.g., PostgreSQL).

---

### **1. System Framing**
#### **Core Domains**
| Domain               | Responsibility                                                                 | Key Entities                          |
|----------------------|-------------------------------------------------------------------------------|---------------------------------------|
| **Tenant Management** | Tenant isolation, regional data residency, identity federation.               | `Tenant`, `Region`, `IdentityProvider` |
| **Scheduling**        | Calendar events, team workspaces, recurrence, conflicts.                      | `Event`, `Workspace`, `Attendee`      |
| **Activity Feeds**    | Cursor-paginated feeds of tenant/team activity (e.g., event updates).         | `Activity`, `Cursor`                  |
| **Approvals**         | Workflow engine for event/change approvals (e.g., manager sign-off).          | `ApprovalRequest`, `ApprovalRule`     |
| **Webhooks**          | Outbound event delivery to customer systems (e.g., Slack, CRM).               | `WebhookSubscription`, `Delivery`     |
| **Automation**        | Future: Customer-defined rules (e.g., "auto-approve events < 4h").            | `AutomationRule`                      |
| **Audit**             | Immutable logs of all mutations (who, what, when, where).                     | `AuditLog`                            |

#### **Non-Functional Requirements**
- **Data Residency**: Tenant data must reside in their designated region (e.g., `us-east-1`, `eu-west-1`).
- **Consistency**: Strong consistency for scheduling/approvals; eventual for feeds/webhooks.
- **Observability**: Distributed tracing, structured logs, and metrics for all services.
- **Resilience**: Retries with backoff for webhooks; circuit breakers for external calls.

---

### **2. Core Model and Authority Boundaries**
#### **Service Decomposition**
| Service               | Authority Model                                                                 | Data Ownership                                                                 | Consistency Stance          |
|-----------------------|---------------------------------------------------------------------------------|--------------------------------------------------------------------------------|-----------------------------|
| **Tenant Service**    | Owns tenant metadata, region mapping, and identity provider config.             | `Tenant`, `Region`, `IdentityProvider`                                         | Strong                      |
| **Scheduling Service**| Owns events, workspaces, and attendee logic.                                    | `Event`, `Workspace`, `Attendee`, `RecurrenceRule`                             | Strong                      |
| **Activity Service**  | Owns cursor-paginated feeds (e.g., `/activities?cursor=...`).                   | `Activity`, `Cursor`                                                           | Eventual                    |
| **Approval Service**  | Owns approval workflows (e.g., "manager must approve events > 8h").             | `ApprovalRequest`, `ApprovalRule`                                              | Strong                      |
| **Webhook Service**   | Owns outbound webhook subscriptions and delivery.                               | `WebhookSubscription`, `Delivery`                                              | Eventual                    |
| **Audit Service**     | Owns immutable logs of all mutations (append-only).                             | `AuditLog`                                                                      | Strong (append-only)        |
| **Automation Service**| Future: Owns customer-defined rules (e.g., "auto-approve if X").                | `AutomationRule`                                                               | Eventual                    |

#### **Data Boundaries**
- **Tenant Isolation**:
  - All tenant data is partitioned by `tenant_id` (e.g., PostgreSQL schemas or row-level security).
  - Regional databases (e.g., `scheduling_us_east`, `scheduling_eu_west`) with cross-region replication disabled.
- **Cross-Service Communication**:
  - **Synchronous**: REST for strong-consistency operations (e.g., `POST /events`).
  - **Asynchronous**: Events (e.g., `EventCreated`, `ApprovalRequested`) via a regional event bus (e.g., Kafka or AWS EventBridge).
- **Webhook Delivery**:
  - Outbound calls are async (retries with exponential backoff, dead-letter queues for failures).

#### **Key Contracts**
1. **Event Bus Schema** (Async):
   ```json
   {
     "event_id": "evt_123",
     "tenant_id": "tn_456",
     "type": "EventCreated",
     "timestamp": "2024-01-01T00:00:00Z",
     "data": { "event_id": "evt_789", "title": "Team Sync" }
   }
   ```
2. **Webhook Payload** (Outbound):
   ```json
   {
     "id": "wh_123",
     "event": "event.updated",
     "tenant_id": "tn_456",
     "data": { "event_id": "evt_789", "status": "approved" },
     "timestamp": "2024-01-01T00:00:00Z"
   }
   ```
3. **Cursor-Based Feed** (REST):
   ```http
   GET /activities?cursor=abc123&limit=50
   ```
   Response:
   ```json
   {
     "data": [{ "id": "act_1", "type": "event_created", "timestamp": "..." }],
     "next_cursor": "def456",
     "has_more": true
   }
   ```

---

### **3. Data, Consistency, and Delivery Design**
#### **Data Model**
- **Relational Core** (PostgreSQL):
  - Tables: `events`, `workspaces`, `attendees`, `approval_requests`, `audit_logs`.
  - Tenant isolation via `tenant_id` column + row-level security or schema-per-tenant.
- **Event Store** (Kafka/EventBridge):
  - Immutable log of all domain events (e.g., `EventCreated`, `ApprovalRequested`).
  - Regional topics (e.g., `us-east-events`, `eu-west-events`).
- **Audit Logs**:
  - Append-only table with columns: `tenant_id`, `user_id`, `action`, `entity_type`, `entity_id`, `timestamp`, `metadata`.

#### **Consistency Tradeoffs**
| Scenario                     | Consistency Stance | Rationale                                                                 |
|------------------------------|--------------------|---------------------------------------------------------------------------|
| Event creation               | Strong             | Avoid double-booking; require atomic DB transaction.                     |
| Activity feed updates        | Eventual           | Accept stale reads for performance; use cursors to paginate.             |
| Webhook delivery             | Eventual           | Retries may delay delivery; idempotency keys prevent duplicates.         |
| Approval workflows           | Strong             | Prevent race conditions (e.g., two managers approving the same event).   |

#### **Webhook Delivery Flow**
1. **Event Emitted**: `EventUpdated` published to regional event bus.
2. **Webhook Service**:
   - Polls event bus for new events (or uses push via EventBridge).
   - Filters events by tenant subscriptions.
   - Enqueues deliveries to a regional queue (e.g., SQS).
3. **Delivery Worker**:
   - Processes queue with retries (exponential backoff, max 5 attempts).
   - Logs failures to a dead-letter queue (DLQ) for manual review.
   - Uses idempotency keys (e.g., `webhook_id + event_id`) to deduplicate.

#### **Automation Rules (Future)**
- **Design**:
  - Customers define rules via a DSL (e.g., "auto-approve events < 4h").
  - Rules stored in `automation_rules` table (tenant-scoped).
  - Rules engine evaluates events in real-time (e.g., on `EventCreated`).
- **Tradeoff**:
  - **Preserved**: Flexibility for customers.
  - **Sacrificed**: Increased complexity in event processing; potential for rule conflicts.

---

### **4. Observability and Failure Posture**
#### **Observability Tax**
| Concern               | Implementation                                                                 |
|-----------------------|-------------------------------------------------------------------------------|
| **Logging**           | Structured logs (JSON) with `tenant_id`, `request_id`, `service_name`.       |
| **Metrics**           | Prometheus/Grafana for latency, error rates, queue depths.                    |
| **Tracing**           | Distributed tracing (OpenTelemetry) for cross-service flows.                  |
| **Audit**             | Immutable `audit_logs` table with `tenant_id`, `user_id`, `action`, `entity`. |

#### **Failure Modes and Mitigations**
| Failure Mode               | Impact                          | Mitigation                                                                 |
|----------------------------|---------------------------------|----------------------------------------------------------------------------|
| Webhook delivery failure   | Customer systems miss updates.  | Retries with backoff; DLQ for manual review; circuit breakers.             |
| Event bus outage           | Async flows stall.              | Regional event bus redundancy; fallback to DB polling.                    |
| Regional DB outage         | Tenant data unavailable.        | Multi-AZ deployment; cross-region read replicas (eventual consistency).    |
| Approval workflow deadlock | Events stuck in "pending".      | Timeouts (e.g., auto-reject after 24h); escalation paths.                  |

#### **Resilience Contracts**
1. **Idempotency**:
   - All mutations (e.g., `POST /events`) accept an `idempotency_key` header.
   - Webhook deliveries use `webhook_id + event_id` as idempotency key.
2. **Retry Policy**:
   - Webhooks: Exponential backoff (1s, 2s, 4s, 8s, 16s) + jitter.
   - Event bus: Retry failed publishes 3x before DLQ.
3. **Circuit Breakers**:
   - External API calls (e.g., webhooks) trip after 5 failures in 10s.

---

### **5. Tradeoffs and Risks**
#### **Key Tradeoffs**
| Decision                          | Preserved                          | Sacrificed                          |
|-----------------------------------|------------------------------------|-------------------------------------|
| Regional data residency           | Compliance; low latency for users. | Cross-region joins impossible.      |
| Cursor-based feeds                | Performance at scale.              | Eventual consistency.               |
| Async webhooks                    | Scalability.                       | Immediate delivery guarantees.      |
| Strong consistency for approvals  | Correctness.                       | Higher latency for cross-region.    |
| Future automation rules           | Customer flexibility.              | Complexity in event processing.     |

#### **Risks and Safer Paths**
| Risk                              | Mitigation                                                                 |
|-----------------------------------|----------------------------------------------------------------------------|
| **Data residency violations**     | Enforce `tenant_id → region` mapping at DB level (row-level security).    |
| **Webhook spam**                  | Rate limiting (e.g., 100 deliveries/minute/tenant); customer quotas.      |
| **Approval workflow deadlocks**   | Timeouts (e.g., auto-reject after 24h); manual override API.               |
| **Eventual consistency surprises**| Document staleness bounds (e.g., "feeds may lag by 5s").                   |
| **Automation rule conflicts**     | Rule evaluation order (e.g., "deny overrides allow"); conflict detection. |

---

### **6. Implementation Roadmap**
1. **Phase 1: Core Services** (3–6 months)
   - Deploy regional databases (PostgreSQL).
   - Build `Tenant`, `Scheduling`, and `Approval` services.
   - Implement cursor-based feeds (eventual consistency).
   - Add audit logs (append-only table).
2. **Phase 2: Webhooks** (2–3 months)
   - Build `Webhook` service with retries/DLQ.
   - Add regional event bus (Kafka/EventBridge).
3. **Phase 3: Automation** (Future)
   - Design DSL for customer rules.
   - Build `Automation` service with rule engine.

---

### **7. Open Questions**
1. Should automation rules be tenant-scoped or workspace-scoped?
2. How to handle cross-region approvals (e.g., manager in EU approves event in US)?
3. What’s the SLA for webhook delivery (e.g., 99.9% within 5s)?

---

### **Evidence Classes Cited**
- **Data residency**: `tenant_id → region` mapping enforced at DB level.
- **Consistency**: Strong for scheduling/approvals; eventual for feeds/webhooks.
- **Audit**: Immutable `audit_logs` table with append-only writes.
- **Webhooks**: Idempotency keys + retries + DLQ.