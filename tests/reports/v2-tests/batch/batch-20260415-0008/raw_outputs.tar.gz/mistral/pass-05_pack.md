Here’s a **PDF remediation plan** that preserves the two-column layout while fixing screen-reader accessibility, reading order, and export fidelity. I’ll treat this as a **project artifact update** (workspace rules apply) and use the `rt_pdf_remediation` route with `document-accessibility-expert` and `layout-reconstruction-expert` as supporting skills.

---

### **Current Failure State**
**Observed (from visual/input protocol):**
- Two-column layout with pull quotes spanning both columns (inferred: likely anchored objects in InDesign).
- Decorative images untagged (observed: no alt text or artifact role).
- Table of contents (TOC) links broken (observed: hyperlinks exist but point to incorrect destinations).
- Reading order likely follows visual flow (left column → right column → pull quote), not semantic flow.

**Inferred (confidence: medium):**
- Pull quotes are semantically secondary to body text but visually interrupt the column flow.
- Decorative images may be part of the layout grid but lack `Artifact` role in the tag tree.
- TOC links were generated via InDesign’s "Create TOC" but not updated post-export.

---

### **Remediation Sequence**
#### **1. Tagging and Reading Order**
**Goal:** Restore semantic flow while preserving layout.
**Steps:**
- **Reconstruct the tag tree** in Adobe Acrobat (or PAC 2024 for validation):
  - Root: `<Document>`
    - `<TOC>` (as a `<Sect>` with `RoleMap` to `TOC`)
    - `<Body>` (as a `<Sect>`)
      - `<H1>`–`<H3>` for headings (match TOC entries).
      - `<P>` for body text (left column first, then right column).
      - `<PullQuote>` (as `<Quote>` with `Placement: Block`).
      - `<Figure>` for meaningful images (with alt text); `<Artifact>` for decorative images.
- **Fix reading order:**
  - Use Acrobat’s "Reading Order" tool to reorder content:
    1. TOC (top of order).
    2. Left-column body text (top to bottom).
    3. Right-column body text (top to bottom).
    4. Pull quotes (placed after the paragraph they reference).
  - **Confidence note:** If pull quotes are anchored to specific text in InDesign, their reading order should match the anchor point.

**Verification method:**
- Test with NVDA/JAWS: Ensure TOC → left column → right column → pull quote flow.
- Use PAC 2024’s "Reading Order" checker to confirm no orphaned tags.

#### **2. Pull Quote Repair**
**Problem:** Pull quotes visually span columns but semantically belong to one column.
**Solution:**
- **Option A (preferred):** Convert pull quotes to `<Quote>` tags with `Placement: Block` and position them in the reading order **after** the paragraph they reference.
- **Option B (if layout must be preserved):** Use `Span` tags with `ActualText` to associate pull quotes with their source paragraph (e.g., `"Pull quote from paragraph 3: [text]"`).
- **Tradeoff:** Option A may require slight layout adjustments; Option B adds verbosity for screen readers.

**Evidence class:** WCAG 1.3.2 (Meaningful Sequence) + PDF/UA-1 (Clause 7.1).

#### **3. Decorative Images**
**Problem:** Untagged images create noise for screen readers.
**Solution:**
- Tag decorative images as `<Artifact>` with `Type: Layout` (no alt text).
- **Verification method:** Use Acrobat’s "TouchUp Reading Order" tool to confirm artifacts are skipped.

#### **4. TOC Links**
**Problem:** Broken hyperlinks due to incorrect page destinations.
**Solution:**
- **Step 1:** In Acrobat, use "Edit PDF" → "Link" → "Add/Edit Web or Document Link" to update TOC entries.
- **Step 2:** Cross-reference with the actual page numbers in the PDF (not InDesign spreads).
- **Step 3:** Add `Title` attributes to links (e.g., `"Jump to Section 2: Methodology"`).
- **Verification method:**
  - Test all links in Acrobat’s "Link" tool.
  - Use PAC 2024’s "Link Checker" to validate destinations.

**Evidence class:** WCAG 2.4.5 (Multiple Ways) + PDF/UA-1 (Clause 7.18).

#### **5. Layout Preservation**
**Problem:** Two-column layout may break if tags are misapplied.
**Solution:**
- Use `Column` tags (PDF 2.0) or `Div` tags with `Placement: Block` to maintain column structure.
- **Tradeoff:** `Column` tags are ideal but may not be supported in older PDF viewers. Fall back to `Div` if needed.
- **Verification method:** Visually confirm columns remain intact in Acrobat’s "Tags" panel.

---

### **Verification Checks**
| **Check**               | **Tool**               | **Pass Criteria**                                                                 |
|--------------------------|------------------------|-----------------------------------------------------------------------------------|
| Reading order            | NVDA/JAWS              | TOC → left column → right column → pull quotes (no jumps).                        |
| Tag structure            | PAC 2024               | No untagged content; artifacts marked correctly.                                  |
| TOC links                | Acrobat Link Checker   | All links point to correct destinations.                                          |
| Contrast                 | Colour Contrast Analyser| Text meets WCAG 2.1 AA (4.5:1 for normal text).                                   |
| Alt text                 | PAC 2024               | Decorative images have no alt text; meaningful images have descriptive alt text.  |
| PDF/UA compliance        | PAC 2024               | No errors in "PDF/UA" tab.                                                        |

---

### **Risk Controls**
1. **Destructive shortcut rejected:**
   - Do **not** flatten the PDF or convert to raster images (loses all semantics).
   - Do **not** rely on "auto-tag" tools (they misclassify pull quotes and artifacts).

2. **Migration strategy:**
   - **Short-term:** Remediate the existing PDF using Acrobat.
   - **Long-term:** Fix the InDesign source file:
     - Update TOC hyperlinks to use unique section IDs (not page numbers).
     - Tag decorative images as "Nonstructural" in InDesign’s Articles panel.
     - Anchor pull quotes to specific paragraphs to preserve reading order.

3. **Fallback for broken TOC links:**
   - Add a `<Note>` tag at the start of the PDF: `"If links are broken, use the bookmarks panel (Ctrl+B) to navigate."`

---

### **Next Steps**
1. **Immediate action:** Remediate the PDF using the steps above (Acrobat Pro required).
2. **Source-file fix:** Update the InDesign file to prevent regression (see "Long-term" above).
3. **Workspace update (if applicable):**
   - Add this plan to `projects/[project_name]/remediation/pdf_remediation_plan.md`.
   - Log the TOC link destinations in `projects/[project_name]/context/state/toc_links.json`.

**Tradeoff resolution:**
- **Preserved:** Two-column layout, visual hierarchy, and pull quote emphasis.
- **Sacrificed:** Perfect reading order for pull quotes (they’ll appear after their source paragraph, not mid-column). This is the least disruptive compromise for screen readers.