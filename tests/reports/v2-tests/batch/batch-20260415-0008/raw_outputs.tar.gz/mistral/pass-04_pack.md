Here’s the **backend feasibility review** for adding real-time collaboration to your React/REST/PostgreSQL stack, structured exactly to the required headings and decision tokens.

---

## Backend Feasibility Review
**Requested capability**
Add Google-Docs-style real-time collaboration to an existing React app: simultaneous multi-user editing, visible cursors, conflict resolution, and persistent state.

---

### Hidden System Requirements
#### 1. **Data Model & Consistency**
- **Problem**: PostgreSQL + REST cannot natively support operational-transform (OT) or conflict-free-replicated-data-type (CRDT) semantics required for real-time sync.
- **Requirement**: Introduce a **collaboration-aware data layer** that:
  - Tracks document deltas (not full snapshots) to minimize bandwidth.
  - Maintains a **version vector** or **logical clock** per document to order operations.
  - Stores **client operation buffers** to resolve out-of-order edits.
  - Implements **OT/CRDT reconciliation** (e.g., Quill’s Delta, ProseMirror’s transform, or Yjs’s CRDT).

#### 2. **Real-Time Transport**
- **Problem**: REST is request/response; real-time collaboration requires **bidirectional, low-latency messaging**.
- **Requirement**: Adopt **WebSocket** (or Server-Sent Events as a fallback) with:
  - Connection lifecycle management (reconnect, heartbeat).
  - Message framing (JSON + binary for cursors).
  - Channel multiplexing (e.g., `doc:{id}:ops`, `doc:{id}:cursors`, `doc:{id}:presence`).

#### 3. **Presence & Cursors**
- **Problem**: Visible cursors/selections require **ephemeral state** (user ID, position, timestamp) that doesn’t persist in PostgreSQL.
- **Requirement**:
  - **In-memory store** (Redis) for presence data (TTL = 30s).
  - **WebSocket broadcast** of cursor updates to all subscribers.
  - **Cursor normalization** (convert client coordinates to document positions).

#### 4. **Conflict Resolution**
- **Problem**: PostgreSQL’s row-level locks are too coarse for character-level conflicts.
- **Requirement**:
  - **OT/CRDT library** (e.g., [Yjs](https://github.com/yjs/yjs), [ProseMirror](https://prosemirror.net/), or custom OT) to reconcile concurrent edits.
  - **Server-side transformation** to handle late-arriving operations.
  - **Client-side prediction** (optimistic UI updates) with server confirmation.

#### 5. **Persistence & Snapshots**
- **Problem**: Storing every delta in PostgreSQL is inefficient; snapshots are needed for recovery.
- **Requirement**:
  - **Delta log** (PostgreSQL table with `doc_id`, `version`, `operation`, `timestamp`).
  - **Periodic snapshots** (e.g., every 100 operations or 5 minutes) to limit replay time.
  - **Garbage collection** for old deltas (e.g., keep last 1,000 operations).

#### 6. **Authentication & Authorization**
- **Problem**: REST sessions (cookies/JWT) don’t automatically transfer to WebSocket connections.
- **Requirement**:
  - **Token handoff**: Pass a short-lived JWT (or session token) during WebSocket upgrade.
  - **Object-level auth**: Verify user has edit access to the document (e.g., `doc:{id}:editors` in Redis).
  - **Rate limiting**: Prevent abuse (e.g., 100 ops/sec per user).

#### 7. **Scalability & Load**
- **Problem**: WebSocket connections are stateful; REST statelessness scales horizontally.
- **Requirement**:
  - **Connection sharding**: Route WebSocket connections to the same server handling the document (e.g., via consistent hashing).
  - **Horizontal scaling**: Use Redis pub/sub to broadcast operations across servers.
  - **Load testing**: Simulate 100+ concurrent editors per document.

#### 8. **Fallback & Degraded Modes**
- **Problem**: WebSocket may be blocked by corporate firewalls; REST is universally supported.
- **Requirement**:
  - **Long-polling fallback**: If WebSocket fails, fall back to REST with 1s polling for deltas.
  - **Offline mode**: Client-side CRDT to queue edits locally; sync when online.
  - **Conflict UI**: Show merge conflicts visually (e.g., GitHub-style diff).

---

### Feasibility Assessment
#### **Explicit Blockers**
1. **PostgreSQL Schema Changes**:
   - Must add `documents` table with `id`, `snapshot`, `version`, `last_modified`.
   - Must add `deltas` table with `doc_id`, `version`, `operation`, `timestamp`, `user_id`.
   - **Blocker**: Schema migrations may require downtime or careful zero-downtime deployment.

2. **WebSocket Infrastructure**:
   - Current REST servers (e.g., Express, Django) may not support WebSocket natively.
   - **Blocker**: Need to add WebSocket server (e.g., `ws` library for Node, `Django Channels` for Python) or proxy via NGINX/HAProxy.

3. **OT/CRDT Library Integration**:
   - No off-the-shelf solution for PostgreSQL + React; must integrate a library (e.g., Yjs) or build custom OT.
   - **Blocker**: Custom OT is complex; Yjs/ProseMirror require client-side changes.

4. **Real-Time Auth**:
   - REST auth (e.g., JWT in cookies) won’t work for WebSocket upgrade requests.
   - **Blocker**: Must implement token handoff (e.g., `?token=xxx` in WebSocket URL) or use session cookies.

5. **Presence Data Store**:
   - PostgreSQL is too slow for ephemeral presence data (TTL = 30s).
   - **Blocker**: Must add Redis (or similar) for presence and pub/sub.

6. **Client-Side Changes**:
   - React app must:
     - Replace REST document fetches with WebSocket subscriptions.
     - Implement client-side OT/CRDT to apply deltas.
     - Add cursor/presence rendering.
   - **Blocker**: Significant frontend work; may require state management changes (e.g., Redux → Yjs).

---

### Safer Implementation Path
#### **Phase 1: Foundation (MVP)**
**Goal**: Enable real-time editing for a single document type (e.g., text) with minimal UI changes.
**Steps**:
1. **Schema Changes**:
   - Add `documents` and `deltas` tables to PostgreSQL.
   - Add `version` column to track operation order.
2. **WebSocket Server**:
   - Add WebSocket server (e.g., `ws` for Node) or proxy via NGINX.
   - Implement connection/auth lifecycle:
     - Upgrade request: `GET /collab?docId=123&token=xxx`.
     - Validate token and document access.
     - Subscribe client to `doc:{id}` channel.
3. **OT/CRDT Integration**:
   - Choose Yjs (recommended for CRDT) or ProseMirror (for OT).
   - Server:
     - Store deltas in PostgreSQL.
     - Broadcast operations to all subscribers via Redis pub/sub.
   - Client:
     - Replace REST document fetch with WebSocket subscription.
     - Use Yjs/ProseMirror to apply deltas to local state.
4. **Presence**:
   - Add Redis for presence data (TTL = 30s).
   - Broadcast cursor updates to all subscribers.
5. **Fallback**:
   - If WebSocket fails, fall back to REST polling (1s interval).
   - Show "offline" banner; queue edits locally.

**Validation**:
- Test with 2–5 concurrent users.
- Verify conflict resolution (e.g., simultaneous edits to the same word).
- Measure latency (< 200ms for local users).

---

#### **Phase 2: Scale & Polish**
**Goal**: Support 100+ concurrent users, add features (rich text, images), and improve reliability.
**Steps**:
1. **Horizontal Scaling**:
   - Shard WebSocket connections by `doc_id` (e.g., consistent hashing).
   - Use Redis pub/sub to broadcast operations across servers.
2. **Rich Text Support**:
   - Extend OT/CRDT to handle formatting (bold, italic, lists).
   - Use ProseMirror or Quill for rich-text editing.
3. **Snapshots & GC**:
   - Add snapshot generation (e.g., every 100 operations).
   - Implement garbage collection for old deltas.
4. **Monitoring**:
   - Track WebSocket connection count, message rate, and latency.
   - Alert on high latency or connection drops.
5. **Security**:
   - Add rate limiting (e.g., 100 ops/sec per user).
   - Validate all operations server-side (e.g., check `user_id` matches token).
6. **UI Improvements**:
   - Add cursor/selection rendering.
   - Show "who’s editing" sidebar.
   - Add conflict resolution UI (e.g., "Accept/Reject" for merge conflicts).

**Validation**:
- Load test with 100+ concurrent users.
- Verify snapshot recovery (kill server, restart, replay deltas).
- Test fallback modes (disable WebSocket, verify REST polling works).

---

#### **Phase 3: Advanced Features**
**Goal**: Add images, comments, and multi-document collaboration.
**Steps**:
1. **Images/Attachments**:
   - Store images in S3/PostgreSQL.
   - Extend OT/CRDT to handle binary data (e.g., Yjs with `Y.Array` for images).
2. **Comments**:
   - Add `comments` table to PostgreSQL.
   - Use WebSocket to sync comments in real-time.
3. **Multi-Document Collaboration**:
   - Extend WebSocket server to handle multiple documents per connection.
   - Add channel multiplexing (e.g., `doc:{id}:ops`, `doc:{id}:comments`).
4. **End-to-End Encryption**:
   - Encrypt deltas client-side (e.g., using libsodium).
   - Decrypt server-side before storing in PostgreSQL.

---

### Tradeoffs
| **Preserved**                          | **Sacrificed**                          |
|----------------------------------------|-----------------------------------------|
| REST/PostgreSQL compatibility          | Statelessness (WebSocket is stateful)   |
| Data durability (PostgreSQL snapshots) | Low-latency (WebSocket adds complexity) |
| Conflict resolution (OT/CRDT)          | Simple deployment (requires Redis)      |
| Offline support (client-side CRDT)     | Real-time auth (token handoff needed)   |

---

### Required Decisions (Contract Tokens)
- **data_dependency**: PostgreSQL for deltas/snapshots + Redis for presence.
- **permissions_dependency**: Token handoff for WebSocket auth + object-level checks.
- **system_surface_dependency**: WebSocket + Redis pub/sub + OT/CRDT library.
- **blocking_constraint**: Schema changes + WebSocket infrastructure + client-side OT/CRDT integration.

---

### Evidence Classes Cited
- **Threshold**: WebSocket latency < 200ms for local users (measured via `performance.now()`).
- **Rule**: OT/CRDT reconciliation (Yjs/ProseMirror docs).
- **Constraint**: PostgreSQL schema changes (migration scripts).
- **Artifact**: Redis pub/sub for cross-server broadcast (Redis docs).