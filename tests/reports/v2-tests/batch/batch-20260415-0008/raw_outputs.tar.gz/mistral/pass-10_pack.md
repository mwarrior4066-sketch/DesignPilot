Here’s a structured critique of the poster design, grounded in communication goals, hierarchy failures, and rebuild priorities:

---

### **Communication Goal**
The poster must:
1. **Identify the event** (what it is, who it’s for) *before* demanding attention with a decorative title.
2. **Prioritize actionable details** (date, location, how to attend) over aesthetic emphasis.
3. **Leverage the skyline photo** as a contextual anchor (e.g., "Design Conference in [City]"), not just a decorative backdrop.

---

### **Composition Failures**

#### 1. **Hierarchy Inversion**
- **Problem**: The decorative title dominates first, but the *event identity* (conference name/logo) is secondary and visually buried under the skyline. Viewers must work to understand what the poster is advertising.
- **Evidence**: Eye-tracking studies (e.g., NN/g) show users fixate on the largest/brightest element first—here, the title wastes that critical first impression.
- **Rebuild Move**:
  - **Swap priority**: Place the *conference name/logo* in the top 1/3 (highest visibility zone) with clear typography (e.g., bold sans-serif).
  - **Demote the decorative title** to a supporting role (e.g., subtitle or tagline) *after* the event is identified.

#### 2. **Weak Information Scaffolding**
- **Problem**: Critical details (date, location, registration) are either too small (gray text) or missing. The skyline photo competes with text instead of reinforcing it.
- **Evidence**:
  - **Date**: Gray text in the corner is low-contrast (likely fails WCAG AA for readability).
  - **Location**: Implied by the skyline but not explicitly stated (e.g., "Hosted in [City]"). Viewers may assume the skyline is generic.
  - **Call to Action**: No clear next step (e.g., "Register at [URL]").
- **Rebuild Move**:
  - **Create a "data bar"**: Dedicate a horizontal strip (e.g., bottom 20%) for high-contrast, left-aligned details (date, location, URL). Use a solid color overlay to ensure legibility over the photo.
  - **Overlay the skyline**: Add a semi-transparent scrim behind text to improve contrast without obscuring the image.

#### 3. **Logo Placement Conflict**
- **Problem**: The logo is centered over the skyline, creating visual tension with the title and competing for attention.
- **Evidence**: The logo’s white fill blends with bright parts of the skyline, reducing its impact.
- **Rebuild Move**:
  - **Reposition the logo**: Place it in a corner (e.g., top-left) with a solid background (e.g., a colored circle) to ensure it stands out.
  - **Scale it down**: The logo should support the event identity, not dominate it.

#### 4. **Decorative Typeface Misuse**
- **Problem**: The decorative title sacrifices readability for style. At a distance (e.g., on a wall or in a crowded hallway), it may become illegible.
- **Evidence**: Decorative typefaces often fail readability tests for large-format designs (e.g., posters, billboards) where viewers have limited time.
- **Rebuild Move**:
  - **Limit decorative type**: Use it only for the *tagline* (e.g., "Inspiring Design Conversations") or a single word (e.g., "CONFERENCE").
  - **Prioritize clarity**: Use a bold, high-contrast sans-serif for the event name (e.g., "2025 Global Design Summit").

---

### **Rebuild Moves (Prioritized)**
1. **Flip the hierarchy**:
   - Top 1/3: Conference name/logo (sans-serif, high contrast).
   - Middle: Tagline or decorative title (smaller, supporting role).
   - Bottom 1/3: Data bar (date, location, URL) with solid background.
2. **Clarify the skyline’s role**:
   - Add a text overlay: "Hosted in [City]" or "Design Conference in [City]."
   - Use a semi-transparent scrim behind text to improve legibility.
3. **Fix the logo**:
   - Move to a corner with a solid background.
   - Reduce size to avoid competing with the event name.
4. **Improve date/location visibility**:
   - Increase contrast (e.g., white text on dark scrim).
   - Left-align details for faster scanning.
5. **Add a call to action**:
   - Include a clear next step (e.g., "Register at [URL]" or "Scan QR code").

---

### **Distance and Emphasis Tradeoff**
- **Preserved**: The skyline photo remains a strong visual anchor, reinforcing the event’s location and mood.
- **Sacrificed**: The decorative title’s prominence is reduced to prioritize clarity and information hierarchy.
- **Why**: A poster’s job is to communicate quickly and clearly, not to showcase typographic experimentation at the cost of usability.

---

### **Verification Checkpoints**
1. **5-Second Test**: Can a viewer identify the event, date, and location in 5 seconds?
2. **Contrast Check**: Does all text meet WCAG AA contrast ratios (4.5:1 for normal text)?
3. **Hierarchy Validation**: Does the eye flow from event identity → details → call to action?
4. **Distance Legibility**: Is the text readable from 6 feet away (simulate by zooming out to 25% in design software)?