Here’s a **type system recommendation** for your fintech product, designed for trust, clarity, and cross-platform consistency. The system balances modern aesthetics with functional rigor, ensuring readability for dense financial data while supporting hierarchy and brand expression.

---

## **Reading Context and Constraints**
### **1. Primary Contexts**
- **Marketing site**: High-level messaging, trust-building, and conversion. Needs authority, clarity, and brand warmth.
- **Web app dashboard**: Dense financial data (tables, charts, transaction lists), real-time updates, and user controls. Requires precision, hierarchy, and scannability.
- **Mobile**: Smaller screens, touch targets, and glanceable information. Prioritizes legibility, compact hierarchy, and responsive scaling.

### **2. Key Constraints**
- **Trust and authority**: Fintech demands credibility. Avoid overly decorative or playful typefaces; prioritize clarity and professionalism.
- **Data density**: Tables, charts, and transaction lists require high contrast, tight spacing, and monospace or tabular figures for alignment.
- **Cross-platform consistency**: The system must adapt to web and mobile without losing coherence.
- **Accessibility**: WCAG AA+ compliance (minimum 4.5:1 contrast for text, 3:1 for large text).
- **Variable fonts**: Support for weights (400–700) and optical sizing (e.g., `opsz` for display vs. text) to optimize rendering.
- **Licensing**: Use open-source or commercially licensed fonts with broad platform support (e.g., Google Fonts, Adobe Fonts, or self-hosted).

---

## **Scale and Role Map**
### **Typeface Selection**
| Role                     | Typeface               | Weights       | Optical Size | Notes                                  |
|--------------------------|------------------------|---------------|--------------|----------------------------------------|
| **Primary (UI/Body)**    | [Inter](https://rsms.me/inter/) | 400, 500, 600 | Text (14–24px) | Neutral, highly legible, open-source, designed for UI. Supports tabular figures (`tnum`) and variable weights. |
| **Secondary (Data)**     | [IBM Plex Mono](https://www.ibm.com/plex/) | 400, 500      | Text (12–16px) | Monospace for tables, code, and aligned financial data. Clean and modern. |
| **Display (Marketing)**  | [Manrope](https://manropefont.com/) | 500, 600, 700 | Display (24px+) | Geometric sans with warmth; ideal for headlines and brand moments. Supports variable weights. |
| **Fallback**             | System UI (San Francisco, Segoe UI, Roboto) | 400, 500      | -            | For edge cases or performance-critical apps. |

### **Role Assignments**
| Role                     | Typeface       | Weight | Size (Desktop) | Size (Mobile) | Line Height | Letter Spacing | Use Case                                  |
|--------------------------|----------------|--------|----------------|---------------|-------------|----------------|-------------------------------------------|
| **Display (H1)**         | Manrope        | 700    | 48–64px        | 32–40px       | 1.1         | -0.02em        | Marketing headlines, hero sections.       |
| **Heading (H2)**         | Inter          | 600    | 32–40px        | 24–28px       | 1.2         | -0.01em        | Section titles, dashboard panels.         |
| **Heading (H3)**         | Inter          | 600    | 24–28px        | 20–24px       | 1.3         | 0               | Sub-sections, card titles.                |
| **Body (Primary)**       | Inter          | 400    | 16–18px        | 14–16px       | 1.5         | 0               | Default text, instructions, descriptions. |
| **Body (Secondary)**     | Inter          | 500    | 14–16px        | 12–14px       | 1.4         | 0               | Labels, metadata, tooltips.               |
| **Data (Tables/Charts)** | IBM Plex Mono  | 400    | 14px           | 12px          | 1.4         | 0               | Transaction lists, financial tables.      |
| **UI (Buttons/Inputs)**  | Inter          | 500    | 14–16px        | 14px          | 1.3         | 0               | Buttons, form inputs, interactive elements. |
| **Caption/Small Text**   | Inter          | 400    | 12–14px        | 12px          | 1.4         | 0.01em          | Footnotes, disclaimers, timestamps.       |

### **Key Features**
- **Tabular figures (`tnum`)**: Enable in Inter for aligned numbers in tables/charts.
- **Variable fonts**: Use `wght` (weight) and `opsz` (optical size) for smoother rendering at all sizes.
- **Fallback stack**: `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`.

---

## **Readability Rules**
### **1. Line Length**
- **Body text**: 45–75 characters per line (ideal: 60).
- **Data tables**: No strict limit, but use `IBM Plex Mono` for alignment and avoid wrapping.
- **Mobile**: 35–50 characters per line (adjust font size or container width).

### **2. Contrast**
- **Primary text**: ≥ 4.5:1 (WCAG AA).
- **Large text (18.66px+ bold or 24px+ regular)**: ≥ 3:1.
- **Data tables**: ≥ 7:1 for critical financial data (e.g., account balances).
- **Disabled/placeholder text**: ≥ 3:1 (but avoid relying on color alone).

### **3. Spacing**
- **Line height**:
  - Body: 1.4–1.6 × font size.
  - Headings: 1.1–1.3 × font size (tighter for hierarchy).
  - Data tables: 1.3–1.4 × font size (compact but legible).
- **Paragraph spacing**: 1.5 × line height (e.g., 24px spacing for 16px text with 1.5 line height).
- **Letter spacing**:
  - Headings: -0.01em to -0.02em (tighter for impact).
  - All caps: +0.05em to +0.1em (improves legibility).

### **4. Responsive Scaling**
- **Desktop → Mobile**:
  - Reduce font sizes by 2–4px (e.g., 16px → 14px).
  - Increase line height slightly (e.g., 1.5 → 1.6) for touch targets.
  - Use `clamp()` for fluid typography (e.g., `clamp(16px, 1vw + 12px, 18px)`).
- **Touch targets**: Minimum 48×48px for interactive elements (e.g., buttons, inputs).

---

## **Adoption Guidance**
### **Phase 1: Audit and Foundation (1–2 weeks)**
1. **Inventory current typography**:
   - Document all typefaces, sizes, weights, and roles in use.
   - Identify inconsistencies (e.g., multiple fonts for the same role).
2. **Define tokens**:
   - Create a design token system (e.g., in Figma or CSS) for font families, weights, sizes, and spacing.
   - Example tokens:
     ```css
     --font-primary: 'Inter', sans-serif;
     --font-secondary: 'IBM Plex Mono', monospace;
     --font-display: 'Manrope', sans-serif;
     --text-body: 16px;
     --text-body-line-height: 1.5;
     --text-heading-h1: 48px;
     ```
3. **Test in isolation**:
   - Apply the new system to a single component (e.g., a transaction table or marketing headline) and validate readability, contrast, and hierarchy.

### **Phase 2: Pilot Implementation (2–3 weeks)**
1. **Start with the web app dashboard**:
   - Replace body text and UI controls with Inter.
   - Use IBM Plex Mono for tables and financial data.
   - Validate with real users (e.g., A/B test a transaction list).
2. **Extend to marketing site**:
   - Apply Manrope to headlines and Inter to body text.
   - Ensure brand warmth doesn’t compromise clarity.
3. **Mobile adaptation**:
   - Adjust sizes and spacing for smaller screens.
   - Test on iOS/Android with real devices.

### **Phase 3: Full Rollout (3–4 weeks)**
1. **Replace all legacy typography**:
   - Update CSS/design files to use the new tokens.
   - Remove redundant fonts to reduce bundle size.
2. **Document the system**:
   - Create a style guide with:
     - Type scale and role map.
     - Dos/don’ts (e.g., "Never use Manrope for data tables").
     - Accessibility checks (contrast, spacing).
3. **Train teams**:
   - Workshops for designers, developers, and content creators.
   - Highlight fintech-specific considerations (e.g., tabular figures, trust signals).
4. **Monitor and iterate**:
   - Track user feedback on readability and trust.
   - Adjust weights/sizes if needed (e.g., increase contrast for data tables).

### **Phase 4: Maintenance**
- **Performance**: Self-host fonts to reduce latency (e.g., use [Google Webfonts Helper](https://google-webfonts-helper.herokuapp.com/)).
- **Updates**: Review the system annually for new weights, variable font features, or licensing changes.
- **Localization**: Test with non-Latin scripts (e.g., Cyrillic, CJK) if expanding globally.

---

## **Tradeoffs and Rationale**
### **Preserved**
- **Trust and authority**: Inter and Manrope strike a balance between professionalism and approachability.
- **Data clarity**: IBM Plex Mono ensures aligned numbers in tables, reducing cognitive load.
- **Cross-platform consistency**: Variable fonts and responsive scaling maintain coherence.

### **Sacrificed**
- **Brand uniqueness**: Inter/Manrope are widely used; if distinctiveness is critical, consider a custom typeface (e.g., [GT Flexa](https://www.grillitype.com/family/gt_flexa) for fintech).
- **Performance**: Variable fonts add ~50–100KB to bundle size. Mitigate by subsetting (e.g., only include `wght` and `opsz`).
- **Design flexibility**: Strict role assignments limit creative expression but ensure consistency.

### **Why This Works for Fintech**
- **Trust signals**: Neutral sans-serifs (Inter) and geometric warmth (Manrope) convey stability and modernity.
- **Data density**: Monospace (IBM Plex Mono) and tabular figures handle financial data without misalignment.
- **Hierarchy**: Multiple weights (400–700) support clear information architecture.
- **Accessibility**: High contrast and variable fonts ensure readability for all users.

---

## **Verification Checkpoints**
1. **Contrast audit**: Use [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/) or [APCA](https://www.myndex.com/APCA/) for data tables.
2. **Readability test**: Print a transaction table at 100% zoom; numbers should align perfectly.
3. **Mobile test**: Check font sizes and touch targets on iOS/Android devices.
4. **User feedback**: Conduct usability tests with finance professionals to validate trust and clarity.