Here is the audit structured under the required headings.
Each section names the governing rule, cites the evidence class, and maps back to the observed failure.

---

## Failure semantics and error contract

### Problem framing
The current contract violates **RFC 9457** (Problem Details for HTTP APIs) and **idempotency safety** by:
- returning HTTP 200 for all responses, including errors
- leaking internal enum values in error messages
- offering no retry-safe contract

### Evidence and rationale
- **Observed**: HTTP 200 for all responses,  → **evidence class**: `RFC 9457 violation`
- **Observed**: internal enum values in error messages → **evidence class**: `information leakage`
- **Observed**: no retry-safe contract → **evidence class**: `missing idempotency contract`

### Recommended rebuild path
1. **Error contract**: adopt RFC 9457 with these fields:
   - `type` (URI reference to the error type)
   - `title` (short human-readable summary)
   - `status` (HTTP status code)
   - `detail` (longer explanation)
   - `instance` (request trace ID)
   - **Tradeoff**: you sacrifice HTTP 200 for semantic clarity (preserve: proof honesty / sacrifice: client-side 200 parsing)
2. **Retry safety**: add `Idempotency-Key` header and return HTTP 409 on duplicate requests
   - **Tradeoff**: you sacrifice synchronous simplicity (preserve: retry safety / sacrifice: blocking behavior)
3. **Enum leakage**: replace internal enum values with stable public codes
   - **Tradeoff**: you sacrifice debug convenience (preserve: security / sacrifice: internal visibility)

---

## Authorization and resource protection

### Problem framing
The current design has:
- no object-level authorization check
- no rate limiting or quota enforcement
- no perimeter around the export resource

### Evidence and rationale
- **Observed**: no object-level check → **evidence class**: `missing authorization perimeter`
- **Observed**: no rate limiting → **evidence class**: `missing resilience contract`
- **Observed**: no quota enforcement → **evidence class**: `missing resilience contract`

### Recommended rebuild path
1. **Authorization**: add object-level check:
   - `only [role] may export [resource]`
   - **Tradeoff**: you sacrifice open access (preserve: security / sacrifice: convenience)
2. **Rate limiting**: add `X-RateLimit-Limit` and `X-RateLimit-Remaining` headers
   - **Tradeoff**: you sacrifice unbounded exports (preserve: resilience / sacrifice: throughput)
3. **Quota enforcement**: add `X-Quota-Limit` and `X-Quota-Remaining` headers
   - **Tradeoff**: you sacrifice unlimited exports (preserve: cost control / sacrifice: user freedom)

---

## Idempotency and async lifecycle

### Problem framing
The current synchronous blocking behavior violates:
- **idempotency safety** (no `Idempotency-Key` header)
- **async job lifecycle** (no 202 Accepted + status URL)
- **resilience** (no circuit breaker or exponential backoff)

### Evidence and rationale
- **Observed**: no `Idempotency-Key` header → **evidence class**: `missing idempotency contract`
- **Observed**: no 202 Accepted → **evidence class**: `missing async job model`
- **Observed**: no circuit breaker → **evidence class**: `missing resilience contract`

### Recommended rebuild path
1. **Idempotency**: add `Idempotency-Key` header and return HTTP 409 on duplicate requests
   - **Tradeoff**: you sacrifice synchronous simplicity (preserve: retry safety / sacrifice: blocking behavior)
2. **Async job model**: adopt 202 Accepted + status URL with these terminal states:
   - `queued → running → completed | failed`
   - **Tradeoff**: you sacrifice immediate PDF delivery (preserve: resilience / sacrifice: latency)
3. **Resilience**: add circuit breaker and exponential backoff with jitter
   - **Tradeoff**: you sacrifice 100% uptime (preserve: system stability / sacrifice: availability)

---

## Resilience and observability

### Problem framing
The current design lacks:
- traceability (no `trace_id` on errors)
- observability (no metrics or logs)
- resilience (no retry-safe contract or circuit breaker)

### Evidence and rationale
- **Observed**: no `trace_id` → **evidence class**: `missing observability contract`
- **Observed**: no metrics → **evidence class**: `missing observability contract`
- **Observed**: no circuit breaker → **evidence class**: `missing resilience contract`

### Recommended rebuild path
1. **Traceability**: add `trace_id` to all errors and responses
   - **Tradeoff**: you sacrifice anonymity (preserve: debuggability / sacrifice: privacy)
2. **Observability**: add metrics for:
   - export latency
   - export success/failure
   - export size
   - **Tradeoff**: you sacrifice simplicity (preserve: visibility / sacrifice: overhead)
3. **Resilience**: add circuit breaker and exponential backoff with jitter
   - **Tradeoff**: you sacrifice 100% uptime (preserve: system stability / sacrifice: availability)

---

## Tradeoffs summary
| Preserved | Sacrificed | Governing rule |
|-----------|------------|----------------|
| Proof honesty | HTTP 200 parsing | RFC 9457 |
| Retry safety | Synchronous simplicity | Idempotency contract |
| Security | Debug convenience | Authorization perimeter |
| Resilience | Throughput | Rate limiting |
| Cost control | User freedom | Quota enforcement |
| System stability | Availability | Circuit breaker |