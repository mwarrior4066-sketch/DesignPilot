Here’s how I would reconstruct the layout system from your 2018 brand guidelines PDF, translating it into a modern, implementation-ready framework:

---

### **1. Extract: Grid Foundation**
**What to pull from the PDF:**
- **Master grid diagrams**: Column count (e.g., 12-column), gutter width, margin sizes (inside/outside, top/bottom).
- **Baseline grid**: If specified (e.g., 4pt or 8pt increments), note the unit and whether it’s used for vertical rhythm.
- **Breakpoints**: Any responsive tiers (e.g., mobile/tablet/desktop) or fixed-width constraints.
- **Examples**: Page layouts showing how content aligns to the grid (e.g., "headlines span 8 columns, body text spans 6").

**Modern translation:**
- **CSS Grid/Flexbox specs**:
  ```css
  :root {
    --grid-columns: 12;
    --gutter-width: 24px;
    --margin-inner: 48px;
    --margin-outer: 72px;
    --baseline-unit: 8px; /* If vertical rhythm is critical */
  }
  .container {
    display: grid;
    grid-template-columns: repeat(var(--grid-columns), 1fr);
    gap: var(--gutter-width);
    padding: 0 var(--margin-outer);
  }
  ```
- **Breakpoint logic**: Map legacy breakpoints to modern viewport ranges (e.g., `min-width: 768px` for "tablet").
- **Normalization**: Convert absolute units (e.g., inches) to relative units (e.g., `rem`, `vw`) for digital use.

---

### **2. Extract: Layout Archetypes**
**What to pull from the PDF:**
- **Template examples**: Common page types (e.g., "cover page," "content spread," "data table") and their grid usage.
- **Span rules**: How elements like images, pull quotes, or sidebars span columns (e.g., "images always span 4 columns").
- **Hierarchy cues**: How typography (headings, body text) aligns to the grid (e.g., "H1 aligns to column 1, H2 to column 3").

**Modern translation:**
- **Component-level rules**:
  ```css
  .hero-headline {
    grid-column: 1 / span 8; /* Spans 8 of 12 columns */
    margin-bottom: calc(var(--baseline-unit) * 3);
  }
  .sidebar {
    grid-column: 9 / -1; /* Starts at column 9, ends at last column */
  }
  ```
- **Modularity**: Group rules by archetype (e.g., `.layout-cover`, `.layout-content`) for reuse.
- **Legacy preservation**: Note deviations (e.g., "cover pages ignore outer margins for full-bleed") and document as exceptions.

---

### **3. Extract: Spacing System**
**What to pull from the PDF:**
- **Margin/gutter specs**: Explicit values (e.g., "gutters = 1p6" or "margins = 2 inches").
- **Padding rules**: Spacing between elements (e.g., "headline to body text = 1 line height").
- **Vertical rhythm**: If baseline grid is used, note how text and images align to it.

**Modern translation:**
- **Tokenized spacing**:
  ```css
  :root {
    --space-xs: 8px;
    --space-s: 16px;
    --space-m: 24px;
    --space-l: 48px;
    /* Map legacy values to modern tokens */
    --legacy-gutter: var(--space-m); /* 24px */
  }
  ```
- **Consistency**: Replace ad-hoc values (e.g., "12pt") with a scalable system (e.g., `var(--space-s)`).
- **Vertical rhythm**: Use `line-height` and `margin-block` to align text to the baseline grid if critical.

---

### **4. Extract: Edge Cases & Constraints**
**What to pull from the PDF:**
- **Fixed vs. fluid**: Are layouts fixed-width (e.g., "8.5x11 inches") or fluid (e.g., "adapts to screen")?
- **Print-specific rules**: Bleed zones, crop marks, or color profiles (e.g., CMYK for print).
- **Legacy quirks**: Workarounds for outdated tools (e.g., "text frames must snap to 1/8 inch increments").

**Modern translation:**
- **Digital adaptation**:
  - Replace fixed-width containers with `max-width: 1200px` and `margin: 0 auto`.
  - Convert print bleed zones to `padding` or `box-shadow` for digital.
- **Fallbacks**: Document print-only rules (e.g., "CMYK swatches → use RGB equivalents") and flag them as "print-only."
- **Quirks**: Note legacy constraints (e.g., "avoid sub-pixel rendering for alignment") and test in modern browsers.

---

### **5. Rebuild: Modern Layout System**
**Output structure:**
1. **Grid Spec**:
   - Column/gutter/margin values (CSS variables).
   - Breakpoint ranges (e.g., `768px–1024px`).
2. **Layout Archetypes**:
   - CSS classes for common page types (e.g., `.layout-cover`).
   - Span rules for components (e.g., "images span 4 columns").
3. **Spacing Tokens**:
   - Scalable spacing system (e.g., `--space-s: 16px`).
4. **Edge Cases**:
   - Print-to-digital adaptations.
   - Legacy quirks and workarounds.
5. **Verification Checklist**:
   - "Does the headline align to column 1?"
   - "Are gutters consistently 24px?"
   - "Do images respect the 4-column span rule?"

---

### **6. Validation & Confidence**
- **Observed vs. Inferred**:
  - *Observed*: Grid diagrams, margin specs (high confidence).
  - *Inferred*: Breakpoint logic, responsive behavior (medium confidence; flag for review).
- **Testing**:
  - Rebuild 1–2 example pages from the PDF using the new system.
  - Check alignment in browser dev tools (e.g., Firefox Grid Inspector).
- **Documentation**:
  - Add a "Migration Notes" section for print-specific rules (e.g., "CMYK → RGB").

---

### **Key Tradeoffs**
- **Preserved**:
  - Brand consistency (grid, margins, hierarchy).
  - Legacy constraints that still apply (e.g., baseline grid for vertical rhythm).
- **Sacrificed**:
  - Print-specific rules (e.g., bleed zones) unless critical.
  - Outdated tools (e.g., fixed-width InDesign templates).
- **Added**:
  - Responsive breakpoints (if missing in the original).
  - CSS Grid/Flexbox compatibility.

---

### **Next Steps**
1. **Extract artifacts**: Share the PDF (or screenshots of grid diagrams) for a visual pre-pass to confirm inferred structures.
2. **Prototype**: Rebuild one template (e.g., a cover page) to test the system.
3. **Refine**: Adjust spacing/breakpoints based on modern needs (e.g., mobile-first).