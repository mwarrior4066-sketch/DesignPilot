Here’s a structured, compelling rewrite of your case study that highlights your process, impact, and insights while keeping it concise and portfolio-ready:

---

### **Redesigning Onboarding: From Confusion to Clarity**
**Project:** Onboarding Flow Redesign
**Role:** Lead UX Designer
**Team:** Product, Engineering, Research
**Tools:** Figma, Miro, UserTesting

#### **The Problem**
New users were dropping off during onboarding—confused by unclear steps, overwhelmed by choices, and unsure how to get started. Our data showed a **30% abandonment rate** in the first 5 minutes, and user feedback revealed frustration with the lack of guidance. The existing flow prioritized speed over clarity, leaving users stuck before they even began.

#### **My Process**
1. **Research: Uncovering the "Why"**
   - Conducted **12 user interviews** and analyzed session recordings to identify pain points.
   - Key findings:
     - Users struggled to connect actions to their goals (e.g., "Why do I need to set this up now?").
     - The flow assumed prior knowledge of our product’s terminology.
     - Micro-interactions (e.g., progress indicators) were missing or misleading.

2. **Strategy: Aligning on Goals**
   - Collaborated with Product to define success metrics: **reduce time-to-value** and **increase Day 1 retention**.
   - Prioritized **progressive disclosure**—breaking the flow into digestible steps with clear "why" explanations.

3. **Design: From Wireframes to Prototypes**
   - Created **low-fidelity wireframes** to test structure, then iterated based on usability tests.
   - Key improvements:
     - **Guided setup**: Added tooltips and contextual help to explain each step.
     - **Visual hierarchy**: Simplified forms and used bold CTAs to reduce cognitive load.
     - **Progress tracking**: Introduced a dynamic progress bar with micro-rewards (e.g., "You’re 50% done!").
   - Prototyped in Figma and ran **A/B tests** with 50 users to validate changes.

4. **Collaboration: Bridging Design and Engineering**
   - Worked closely with engineers to ensure feasibility, especially for dynamic progress tracking.
   - Advocated for **accessibility** (e.g., keyboard navigation, screen-reader compatibility) and **performance** (e.g., lazy-loading assets).

#### **The Impact**
- **40% increase in conversion** (users completing onboarding).
- **25% reduction in support tickets** related to onboarding confusion.
- **Positive user feedback**: "Finally, an onboarding that doesn’t feel like a chore!"

#### **Key Learnings**
- **Clarity > Speed**: Users prefer a slightly longer flow if it’s intuitive and rewarding.
- **Collaboration is critical**: Early engineering input saved time and prevented last-minute compromises.
- **Small details matter**: Micro-interactions (e.g., progress feedback) can significantly improve perceived usability.

#### **What I’d Do Differently**
- Test earlier with **low-literacy users** to catch accessibility gaps sooner.
- Explore **personalized onboarding paths** (e.g., role-based flows) to further reduce friction.

---

### **Why This Works for Your Portfolio**
1. **Structured storytelling**: Problem → Process → Impact → Learnings.
2. **Quantifiable results**: Hard numbers (40% conversion lift) make your work tangible.
3. **Collaboration emphasis**: Shows you work cross-functionally, a key skill for employers.
4. **Visual hooks**: Use **bold headers** and **bullet points** for scannability.
5. **Reflection**: Adds depth by acknowledging tradeoffs and future improvements.

**Pro tip**: Pair this with **before/after screenshots** or a **short Loom video** walking through the prototype to make it even more engaging.