## Color System Spec for Healthcare SaaS Dashboard

### Role model
**Semantic roles and meaning**
- `primary` – brand anchor, used for main navigation, primary actions, and global chrome
- `secondary` – supporting UI, secondary actions, and less critical chrome
- `background` – base surface, used for page and card backgrounds
- `surface` – elevated surfaces, used for cards, modals, and overlays
- `border` – separators and outlines, used for dividers, input borders, and focus indicators
- `text` – primary text, used for body copy, headings, and labels
- `text-secondary` – secondary text, used for captions, hints, and less critical labels
- `text-on-color` – text on colored backgrounds, used for text on buttons, badges, and status indicators
- `status-normal` – normal state, used for healthy metrics, stable systems, and positive feedback
- `status-warning` – warning state, used for cautionary metrics, attention-needed systems, and transient issues
- `status-critical` – critical state, used for unhealthy metrics, failed systems, and urgent issues
- `data-1` to `data-5` – categorical data, used for charts, graphs, and data series (5 distinct hues)
- `interactive` – interactive elements, used for buttons, links, and interactive controls
- `interactive-hover` – hover state, used for button and link hover states
- `interactive-active` – active/pressed state, used for button and link pressed states
- `interactive-focus` – focus state, used for keyboard focus indicators
- `interactive-disabled` – disabled state, used for disabled buttons and controls

### Token map
**Alias structure mapping roles to usage**
```json
{
  "color": {
    "primary": {
      "value": "#2E5AAC",
      "darkValue": "#6A96E8"
    },
    "secondary": {
      "value": "#6C757D",
      "darkValue": "#A7B0B8"
    },
    "background": {
      "value": "#FFFFFF",
      "darkValue": "#121212"
    },
    "surface": {
      "value": "#FFFFFF",
      "darkValue": "#1E1E1E"
    },
    "border": {
      "value": "#DEE2E6",
      "darkValue": "#495057"
    },
    "text": {
      "value": "#212529",
      "darkValue": "#E9ECEF"
    },
    "text-secondary": {
      "value": "#6C757D",
      "darkValue": "#A7B0B8"
    },
    "text-on-color": {
      "value": "#FFFFFF",
      "darkValue": "#FFFFFF"
    },
    "status-normal": {
      "value": "#28A745",
      "darkValue": "#5CB87A"
    },
    "status-warning": {
      "value": "#FFC107",
      "darkValue": "#FFD76E"
    },
    "status-critical": {
      "value": "#DC3545",
      "darkValue": "#F1707A"
    },
    "data-1": {
      "value": "#17A2B8",
      "darkValue": "#5BC0DE"
    },
    "data-2": {
      "value": "#6F42C1",
      "darkValue": "#A98EDA"
    },
    "data-3": {
      "value": "#FD7E14",
      "darkValue": "#FFA366"
    },
    "data-4": {
      "value": "#E83E8C",
      "darkValue": "#F17EB8"
    },
    "data-5": {
      "value": "#20C997",
      "darkValue": "#6BE4B8"
    },
    "interactive": {
      "value": "#2E5AAC",
      "darkValue": "#6A96E8"
    },
    "interactive-hover": {
      "value": "#254A8A",
      "darkValue": "#5A86D8"
    },
    "interactive-active": {
      "value": "#1E3A6E",
      "darkValue": "#4A76C8"
    },
    "interactive-focus": {
      "value": "#6A96E8",
      "darkValue": "#2E5AAC"
    },
    "interactive-disabled": {
      "value": "#DEE2E6",
      "darkValue": "#495057"
    }
  }
}
```

### Contrast and state rules
**Rules preventing color-only semantics**
- **WCAG AA compliance** – all text meets at least 4.5:1 contrast ratio against its background (normal text) and 3:1 (large text)
- **Status indicators** – status colors (`normal`, `warning`, `critical`) are always paired with an icon or text label to ensure accessibility
- **Data visualization** – categorical colors (`data-1` to `data-5`) are always paired with a legend, label, or tooltip to ensure clarity
- **Dark mode adaptation** – all colors have a dark mode variant that maintains contrast and semantic meaning
- **State visibility** – interactive states (`hover`, `active`, `focus`, `disabled`) use both color and additional visual cues (e.g., underline, border, opacity) to ensure visibility
- **Non-text contrast** – interactive elements, borders, and status indicators meet at least 3:1 contrast ratio against their surroundings

### Migration notes
**Plan for migrating from the current palette**
1. **Audit current usage** – map current colors to their semantic roles in the existing dashboard (e.g., "green" → `status-normal`, "blue" → `primary`)
2. **Define aliases** – create a token map that aliases current colors to the new semantic roles (e.g., `current-green` → `status-normal`)
3. **Update design system** – replace hardcoded colors in the design system with the new semantic tokens
4. **Refactor CSS/SCSS** – update stylesheets to use the new token variables instead of hardcoded colors
5. **Update components** – refactor components to use the new tokens for status indicators, data visualization, and interactive states
6. **Test contrast** – verify WCAG AA compliance for all text, interactive elements, and status indicators in both light and dark modes
7. **Phase rollout** – deploy the new palette in stages, starting with low-risk surfaces (e.g., backgrounds, borders) and progressing to high-risk areas (e.g., status indicators, data visualization)
8. **Monitor feedback** – collect user feedback on readability, accessibility, and semantic clarity, and adjust as needed

---
**Tradeoffs**
- **Preserved**: WCAG AA compliance, semantic clarity, dark mode support, and data visualization safety
- **Sacrificed**: Some aesthetic flexibility (e.g., fewer "brand" colors) to ensure accessibility and consistency across the dashboard