Here’s a **component spec** for the **Split Button** with the requested features, structured for implementation safety and accessibility.

---

# **Split Button**
**Purpose and scope**
A compound button that combines a primary action (`Save`) with a dropdown trigger for secondary actions (`Save as draft`, `Save and close`). It must:
- Maintain clear visual hierarchy between primary and secondary actions.
- Support keyboard navigation, disabled/loading states, and mobile touch targets.
- Preserve accessibility (focus order, ARIA, touch targets ≥ 48×48px).
- Avoid ambiguity between the primary action and dropdown trigger.

---

## **Anatomy**
### **1. Primary Button**
- **Label**: "Save" (default) or dynamic text (e.g., "Saving..." in loading state).
- **Role**: `button` (implicit).
- **Action**: Triggers the primary action on click/tap or `Enter`/`Space`.
- **States**:
  - Default: Primary brand color, filled.
  - Hover: Subtle shadow or brightness increase.
  - Active: Pressed-down effect.
  - Disabled: 50% opacity, `aria-disabled="true"`.
  - Loading: Spinner + "Saving..." text (or spinner-only if space-constrained).

### **2. Dropdown Trigger**
- **Label**: Chevron icon (▼) or "More options" (hidden text for screen readers).
- **Role**: `button` with `aria-haspopup="menu"` and `aria-expanded="false"`.
- **Action**: Opens a dropdown menu of secondary actions on click/tap or `ArrowDown`/`Space`.
- **States**:
  - Default: Bordered or subtle background.
  - Hover: Background color change.
  - Active: Pressed-down effect.
  - Disabled: 50% opacity, `aria-disabled="true"`.

### **3. Dropdown Menu**
- **Role**: `menu` with `aria-labelledby` referencing the trigger.
- **Items**: `menuitem` roles for each action (`Save as draft`, `Save and close`).
- **Behavior**:
  - Opens below the button (or above if space is constrained).
  - Closes on:
    - Clicking outside.
    - Pressing `Escape`.
    - Selecting an item.
  - Highlights the focused item with a background color.

---

## **State Matrix**
| State               | Primary Button                     | Dropdown Trigger                     | Dropdown Menu       |
|---------------------|------------------------------------|--------------------------------------|---------------------|
| **Default**         | Enabled, "Save"                    | Enabled, chevron icon                | Hidden              |
| **Hover (Primary)** | Shadow/brightness increase         | No change                            | Hidden              |
| **Hover (Trigger)** | No change                          | Background color change              | Hidden              |
| **Active**          | Pressed-down effect                | Pressed-down effect                  | Hidden              |
| **Disabled**        | 50% opacity, `aria-disabled="true"`| 50% opacity, `aria-disabled="true"`  | Hidden              |
| **Loading**         | Spinner + "Saving..."              | Disabled, `aria-disabled="true"`     | Hidden              |
| **Menu Open**       | No change                          | `aria-expanded="true"`               | Visible             |
| **Menu Hover**      | No change                          | No change                            | Highlighted item    |

---

## **Accessibility and Implementation Notes**
### **Keyboard Support**
- **Tab**: Moves focus to the primary button first, then the dropdown trigger.
- **Enter/Space** (on primary button): Triggers the primary action.
- **ArrowDown/Space** (on dropdown trigger): Opens the menu.
- **ArrowUp/Down** (in menu): Navigates items.
- **Enter** (in menu): Selects the focused item.
- **Escape**: Closes the menu.

### **Touch Targets**
- Primary button and dropdown trigger must each be ≥ **48×48px** (WCAG 2.5.5).
- Add padding if the default size is too small.

### **ARIA Attributes**
- Primary button: `aria-label="Save"` (or dynamic text in loading state).
- Dropdown trigger:
  ```html
  <button aria-haspopup="menu" aria-expanded="false" aria-label="More save options">
    <span class="chevron-icon" aria-hidden="true">▼</span>
  </button>
  ```
- Dropdown menu:
  ```html
  <ul role="menu" aria-labelledby="dropdown-trigger-id">
    <li role="menuitem">Save as draft</li>
    <li role="menuitem">Save and close</li>
  </ul>
  ```

### **Loading State**
- Replace the primary button’s text with a spinner + "Saving..." (or spinner-only if space is tight).
- Disable the dropdown trigger (`aria-disabled="true"`) to prevent menu access during loading.

### **Disabled State**
- Both buttons must be disabled (`aria-disabled="true"`) and visually grayed out.
- Prevent all interactions (click, keyboard, touch).

### **Mobile Considerations**
- Ensure touch targets are large enough (≥ 48×48px).
- Add subtle haptic feedback (optional) for touch interactions.
- Test dropdown menu positioning to avoid viewport overflow.

### **Implementation Boundary**
- **Frontend**: Use a framework-agnostic approach (e.g., React/Vue components with slots for primary/dropdown actions).
- **Backend**: No direct backend dependency, but ensure the primary action and dropdown items map to valid API endpoints.
- **Tokens**: Use design tokens for colors, spacing, and states to ensure consistency.

---

## **Example Code (React)**
```tsx
import { useState } from "react";

type SplitButtonProps = {
  primaryLabel: string;
  dropdownItems: { label: string; onClick: () => void }[];
  isDisabled?: boolean;
  isLoading?: boolean;
  onPrimaryClick: () => void;
};

export const SplitButton = ({
  primaryLabel,
  dropdownItems,
  isDisabled = false,
  isLoading = false,
  onPrimaryClick,
}: SplitButtonProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="split-button">
      <button
        className="primary-button"
        onClick={onPrimaryClick}
        disabled={isDisabled || isLoading}
        aria-label={isLoading ? "Saving..." : primaryLabel}
      >
        {isLoading ? <Spinner /> : primaryLabel}
      </button>
      <button
        className="dropdown-trigger"
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        disabled={isDisabled || isLoading}
        aria-haspopup="menu"
        aria-expanded={isMenuOpen}
        aria-label="More save options"
      >
        <span className="chevron-icon" aria-hidden="true">▼</span>
      </button>
      {isMenuOpen && (
        <ul className="dropdown-menu" role="menu">
          {dropdownItems.map((item) => (
            <li
              key={item.label}
              role="menuitem"
              onClick={() => {
                item.onClick();
                setIsMenuOpen(false);
              }}
            >
              {item.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
```

---

## **Tradeoffs**
- **Preserved**:
  - Clear visual hierarchy between primary and secondary actions.
  - Full keyboard and touch accessibility.
  - Disabled/loading states prevent invalid interactions.
- **Sacrificed**:
  - Slightly higher complexity than a single button (requires managing dropdown state).
  - Mobile touch targets may require extra padding to meet WCAG.
  - Loading state may need to hide the dropdown trigger to avoid confusion.