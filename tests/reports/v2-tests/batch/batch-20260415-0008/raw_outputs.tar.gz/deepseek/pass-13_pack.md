[SESSION_STATE]
{
  "route": "rt_ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": ["gap_priority: user_abandonment_cause", "method_mapping: qualitative_exit_interviews", "research_sequence: abandonment -> power_users -> competition"],
  "evidence_classes_cited": ["threshold", "artifact"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Known evidence
*   **Stakeholder Interviews (3):** Provides internal perspective on goals, constraints, and perceived problems. This is a proxy for user needs, not direct evidence.
*   **Usability Tests (2):** Direct observation of users interacting with the current product. This reveals *how* users struggle with specific UI elements and flows.
*   **Analytics (60% drop-off):** A critical, measurable threshold that quantifies a major failure point in the project creation flow. This is a symptom, not a diagnosis.

## Critical gaps
1.  **Abandonment Causality (Highest Priority):** We know *that* 60% of users drop off, but we do not know *why*. This is the single most critical unknown blocking an effective redesign. Without this, any solution is a guess.
2.  **Power User Behavior & Needs:** We lack data on the most engaged users. What workflows do they rely on? What shortcuts or advanced features would retain them? Redesigning without this risks alienating your core user base.
3.  **Competitive Context:** We do not know how users' mental models are shaped by other tools (e.g., Asana, Jira, Monday, ClickUp). This gap risks designing a novel interaction that feels unfamiliar or inferior to established patterns.

## Research plan
**Sequence:** Solve the most critical, blocking unknown first.

| Gap | Method | Sample & Goal | Artifact |
| :--- | :--- | :--- | :--- |
| **1. Abandonment Causality** | **Screener Surveys & Exit Interviews** | Recruit 5-8 users who recently abandoned the project creation flow. Goal: Uncover the specific point of confusion, frustration, or missing feature that caused them to leave. | Interview transcripts, affinity map of abandonment drivers. |
| **2. Power User Needs** | **Contextual Inquiry / Diary Study** | Recruit 3-5 existing power users. Goal: Observe their actual end-to-end workflow, including workarounds, and identify unmet needs for efficiency, control, and reporting. | Process maps, feature request backlog prioritized by observed pain. |
| **3. Competitive Analysis** | **Comparative Usability Test** | Recruit 5 target users to complete core tasks (like project creation) in your tool and 1-2 key competitors. Goal: Identify superior patterns, mental model mismatches, and differentiators. | Heuristic evaluation matrix, video clips of user reactions. |

## Decision impact
*   **If you skip Abandonment Causality research,** you will be solving for symptoms, not the disease. You might redesign the UI while the real blocker is a missing field, a permissions issue, or a confusing pricing step.
*   **If you skip Power User research,** you risk optimizing for novice usability at the expense of efficiency, creating a tool that feels "dumbed down" and fails to retain high-value customers.
*   **If you skip Competitive Analysis,** you risk reinventing the wheel poorly or missing a convention that users already understand, increasing cognitive load.

**Next useful move:** Draft the screener survey and interview guide for the Abandonment Causality study.