[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": ["failure_semantics_contract: RFC 9457", "authorization_perimeter: object-level", "idempotency_contract: idempotency-key header", "async_job_model: 202 Accepted + status URL", "resilience_strategy: circuit breaker + exponential backoff"],
  "evidence_classes_cited": ["threshold", "rule", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Failure semantics and error contract

**Current failure:** The endpoint returns HTTP 200 for all responses, including errors. This violates the HTTP contract, making it impossible for clients and infrastructure (load balancers, API gateways) to distinguish success from failure without parsing the response body. It also leaks internal enum values in error messages, which is an information disclosure risk.

**Required contract:** Adopt [RFC 9457 (Problem Details for HTTP APIs)](https://www.rfc-editor.org/rfc/rfc9457.html).
*   **Success:** `200 OK` with the PDF in the response body.
*   **Client Error (4xx):** Use specific status codes.
    *   `400 Bad Request` for malformed requests (e.g., invalid date range).
    *   `401 Unauthorized` if authentication is missing/invalid.
    *   `403 Forbidden` if the user lacks permission for the requested resource.
    *   `404 Not Found` if the target resource (e.g., a project) doesn't exist.
    *   `409 Conflict` on duplicate requests when idempotency is enforced.
*   **Server Error (5xx):** `500 Internal Server Error` or `503 Service Unavailable` for system failures.
*   **Error Body:** All 4xx/5xx responses must return a consistent `application/problem+json` body. It must contain a human-readable `title`, a precise `detail`, and a stable `type` URI (e.g., `https://api.example.com/errors/invalid-parameter`). **Crucially, `detail` must not contain internal enums, stack traces, or system paths.** Use opaque, client-actionable error codes.

**Rationale:** This allows automated retry logic, monitoring dashboards, and client code to handle failures correctly without guessing.

## Authorization and resource protection

**Current failure:** The audit doesn't specify authorization, creating a risk of Broken Object Level Authorization (BOLA). A user might be able to request a PDF for a project they don't own.

**Required model:** Implement object-level authorization checks.
1.  **Authentication:** All requests must include a valid bearer token (e.g., JWT) in the `Authorization` header.
2.  **Authorization:** Before processing, the service must resolve the resource IDs from the request (e.g., `project_id`). It must then query the database to verify the authenticated user has `view` or `export` permission for *that specific resource*. This check must happen **after** authentication but **before** any expensive PDF generation begins.
3.  **Failure Response:** If the check fails, return `403 Forbidden` with a generic problem detail (e.g., "You do not have permission to access this resource"). Do not confirm the resource's existence to an unauthorized user.

**Rationale:** This enforces the principle of least privilege and is a primary defense against data breaches via API.

## Idempotency and async lifecycle

**Current failure:** The endpoint is synchronous, blocking for up to 3 minutes, and has no idempotency key. This creates three major problems:
1.  **Client Timeouts:** HTTP clients and browsers will time out long before 3 minutes, causing retries that create duplicate reports.
2.  **Duplicate Work:** Without idempotency, those retries cause redundant, expensive PDF generations.
3.  **System Load:** Long-running synchronous requests consume worker threads, leading to thread exhaustion and system instability under load.

**Required rebuild:** Convert to an asynchronous, idempotent job model.
1.  **Request (`POST /exports`):**
    *   Client includes an `Idempotency-Key: <random_unique_string>` header.
    *   Server validates the request and starts a background job (e.g., in Redis, RabbitMQ, or a database).
    *   Server responds with **`202 Accepted`**.
    *   The response includes a `Location` header pointing to a job status endpoint (e.g., `Location: /exports/status/<job_id>`).
    *   The response body is a JSON object containing the `job_id`, `status: "queued"`, and an `estimated_completion_time`.
2.  **Status Polling (`GET /exports/status/{job_id}`):**
    *   Clients poll this endpoint to check progress.
    *   Returns job status: `queued` → `running` → `completed` | `failed`.
3.  **Result (`GET /exports/download/{job_id}`):**
    *   When status is `completed`, clients fetch the PDF from this dedicated download URL.
    *   The download endpoint should support `Range` requests for resilience.
4.  **Idempotency Enforcement:**
    *   The server stores the `Idempotency-Key` with the initial request parameters.
    *   If a duplicate request with the same key arrives while the first job is `queued` or `running`, return `409 Conflict` with a problem detail pointing to the existing `job_id`.
    *   If the first job is `completed`, return `303 See Other` redirecting to the download URL.

**Rationale:** This pattern decouples request acceptance from work completion, prevents duplicate work, and provides a predictable, resilient lifecycle for long-running operations.

## Resilience and observability

**Current failure:** A synchronous, 3-minute blocking call with no defined retry behavior is inherently brittle. It will fail under load and provide no visibility into failures.

**Required posture:**
1.  **Circuit Breaker:** Implement a circuit breaker pattern (e.g., using Resilience4j, Polly) around the PDF generation service. After a threshold of failures (e.g., 5 failures in 60 seconds), the circuit opens and fails fast for 30 seconds, preventing cascade failures and allowing the downstream service to recover.
2.  **Retry with Backoff:** For transient failures (network timeouts, temporary third-party service unavailability), implement **exponential backoff with jitter**. Do not retry on 4xx client errors. For 5xx errors or timeouts, retry with a delay like: `delay = min(max_delay, initial_delay * (2 ^ retry_attempt) + random_jitter)`.
3.  **Graceful Degradation:** If the PDF generation service is unavailable, the async job should fail with a clear `failure_reason`. The system could offer a fallback, such as generating a CSV version of the report if the PDF engine is down.
4.  **Observability Tax:**
    *   **Structured Logging:** Log key events (job created, started, completed, failed) with consistent fields: `job_id`, `user_id`, `resource_id`, `duration`, `error_code`.
    *   **Distributed Tracing:** Inject and propagate a `trace_id` (e.g., W3C Trace Context) from the initial API request through the queuing system and into the background worker. This is non-negotiable for debugging.
    *   **Metrics:** Instrument the endpoint with metrics: request rate, job queue length, job duration histogram, and error rate by type (4xx, 5xx, timeout).
    *   **Alerting:** Set alerts on elevated 5xx error rates, job queue backlog, and circuit breaker state changes.

**Rationale:** These practices ensure the system remains available and operable under partial failure, and provide the data needed to diagnose issues when they occur.

## Summary of required changes

| Area | Current Anti-Pattern | Required Pattern |
| :--- | :--- | :--- |
| **Error Contract** | HTTP 200 for errors, leaks internals. | RFC 9457 with specific 4xx/5xx codes, opaque problem details. |
| **Authorization** | Unspecified, BOLA risk. | Object-level check (`user_id` + `resource_id`) before processing. |
| **Execution Model** | Synchronous, 3-minute block. | Async job model (`202 Accepted` + status polling). |
| **Idempotency** | None, duplicate work on retry. | `Idempotency-Key` header with `409 Conflict` for duplicates. |
| **Resilience** | Brittle, no retry logic. | Circuit breaker, exponential backoff with jitter, graceful degradation. |
| **Observability** | Limited visibility. | Structured logs, distributed tracing, metrics, alerting. |

**Implementation Priority:**
1.  **Immediate (Security/Stability):** Fix the error contract (RFC 9457) and add object-level authorization. These prevent security issues and client confusion.
2.  **High (Reliability):** Implement the async job model with idempotency. This is essential for production load.
3.  **High (Operability):** Add circuit breaker, structured logging, and tracing. You cannot manage what you cannot measure.

**Tradeoff:** The async model adds complexity—clients must now poll for status. However, you **sacrifice** simplicity to **gain** scalability, resilience, and a predictable contract that won't fail under load. The operational tax of implementing tracing and metrics is the cost of running a reliable service.