[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "standard",
  "decisions_committed": ["semantic_roles: defined", "state_mapping: defined", "contrast_boundary: WCAG AA", "migration_strategy: phased"],
  "evidence_classes_cited": ["threshold", "rule", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Role model

The system is built on semantic roles, not decorative colors. Each role defines a specific job in the interface.

1.  **Primary (--color-primary)**: The core brand identity and main action color. Used for primary buttons, active navigation, and key interactive elements. It must be trustworthy and calm for healthcare.
2.  **Secondary (--color-secondary)**: A supporting brand color for secondary actions, subtle highlights, and complementary UI elements. It should harmonize with the primary color without competing.
3.  **Surface (--color-surface)**: The background for major UI containers (cards, modals, sidebars). It defines the base canvas against which all other elements are layered.
4.  **Surface Elevated (--color-surface-elevated)**: A lighter/darker variant of the surface for layered elements (dropdowns, tooltips, floating action buttons) to create visual hierarchy.
5.  **Text (--color-text)**: The default, high-contrast color for body text and primary labels.
6.  **Text Muted (--color-text-muted)**: A lower-contrast variant for secondary labels, placeholder text, and disabled states.
7.  **Border (--color-border)**: For subtle separators, dividers, and non-interactive outlines.
8.  **Status - Normal (--color-status-normal)**: Communicates positive, stable, or nominal states (e.g., "Healthy", "Online", "Complete"). Should be a calm, non-alarming green.
9.  **Status - Warning (--color-status-warning)**: Communicates caution, pending, or degraded states (e.g., "Needs Review", "Moderate Load"). Should be a distinct, attention-grabbing yellow/orange.
10. **Status - Critical (--color-status-critical)**: Communicates errors, failures, or urgent attention required (e.g., "Critical Alert", "Offline", "Error"). Must be a high-visibility red.
11. **Data - Categorical 1-5 (--color-data-1 to --color-data-5)**: A set of five distinct, accessible colors for differentiating data series in charts and visualizations. They must be distinguishable from each other and from the status colors.

## Token map

Tokens create a layer of abstraction between semantic roles and their final values, enabling theming (light/dark mode) and future changes.

**Structure:**
```
--color-{semantic-role}: {light-mode-value};
--color-{semantic-role}-dark: {dark-mode-value};
```

**Example Mapping (Light Mode):**
```css
:root {
  /* Brand & UI */
  --color-primary: #2563eb; /* Calm, trustworthy blue */
  --color-secondary: #7c3aed; /* Complementary purple */
  --color-surface: #ffffff;
  --color-surface-elevated: #f8fafc;
  --color-text: #1e293b;
  --color-text-muted: #64748b;
  --color-border: #e2e8f0;

  /* Status */
  --color-status-normal: #059669; /* Calm green */
  --color-status-warning: #d97706; /* Distinct amber */
  --color-status-critical: #dc2626; /* High-visibility red */

  /* Data */
  --color-data-1: #3b82f6; /* Blue */
  --color-data-2: #8b5cf6; /* Violet */
  --color-data-3: #10b981; /* Emerald */
  --color-data-4: #f59e0b; /* Amber */
  --color-data-5: #ef4444; /* Red (distinct from status-critical) */
}
```

**Example Mapping (Dark Mode):**
```css
@media (prefers-color-scheme: dark) {
  :root {
    --color-primary: #60a5fa;
    --color-secondary: #a78bfa;
    --color-surface: #0f172a;
    --color-surface-elevated: #1e293b;
    --color-text: #f1f5f9;
    --color-text-muted: #94a3b8;
    --color-border: #334155;

    /* Status colors are often kept more saturated in dark mode for clarity */
    --color-status-normal: #34d399;
    --color-status-warning: #fbbf24;
    --color-status-critical: #f87171;

    /* Data colors may be slightly adjusted for dark backgrounds */
    --color-data-1: #93c5fd;
    --color-data-2: #c4b5fd;
    --color-data-3: #6ee7b7;
    --color-data-4: #fcd34d;
    --color-data-5: #fca5a5;
  }
}
```

**Usage in CSS:**
```css
.button--primary {
  background-color: var(--color-primary);
  color: white; /* Ensure contrast on colored background */
}

.alert--critical {
  border-left: 4px solid var(--color-status-critical);
  background-color: color-mix(in srgb, var(--color-status-critical) 10%, transparent);
}

.chart-series-a {
  fill: var(--color-data-1);
}
```

## Contrast and state rules

Color cannot be the sole means of conveying information. These rules enforce accessibility and robustness.

1.  **WCAG AA Minimum**: All text (`--color-text`, `--color-text-muted`) on their respective backgrounds (`--color-surface`, `--color-surface-elevated`) must meet or exceed a **4.5:1 contrast ratio**. Status and data colors used for text or small icons must also meet this threshold against their backgrounds.
2.  **Non-Text Contrast**: Graphical objects (like chart lines, icons, and focus rings) require a **3:1 contrast ratio** against adjacent colors.
3.  **Status is More Than Color**: Every status indicator (normal, warning, critical) must include a **text label**, a **distinct icon**, and/or a **pattern/texture** in addition to color. For example, a "Critical" alert uses the red `--color-status-critical`, an exclamation icon, and the label "Critical".
4.  **Focus & Interaction States**: Interactive elements must have a non-color focus indicator, such as a `2px` solid outline with a `--color-primary` or a high-contrast color that achieves at least a **3:1 ratio** against the background. Hover states should use changes in brightness (`color-mix()`), border, or shadow, not just a color shift.
5.  **Data Visualization Safeguards**:
    *   Provide a **legend** that pairs each color with a label.
    *   Support a "colorblind-friendly" mode that can overlay patterns (stripes, dots) on data series.
    *   Ensure adjacent data colors in a chart are distinguishable by both hue and lightness.

## Migration notes

Adopt this system in phases to avoid breaking changes and ensure consistency.

**Phase 1: Audit & Foundation (1-2 weeks)**
*   **Inventory**: Catalog all current color uses in the codebase (CSS, JS, components). Tools like Stylelint or a custom script can help.
*   **Create Tokens**: Implement the CSS custom properties (`:root` variables) for the new semantic roles in a global stylesheet. Initially, map them to the closest existing colors to prevent immediate visual change.
*   **Document**: Publish the token map and usage guidelines for the engineering and design teams.

**Phase 2: Incremental Replacement (3-4 weeks)**
*   **Target Components**: Start with foundational, low-risk components (Buttons, Alerts, Cards) and replace hard-coded hex values with the new semantic tokens (e.g., change `#dc2626` to `var(--color-status-critical)`).
*   **Update Design Library**: Synchronize the component library (Figma, etc.) to use the new token structure. This ensures future designs are consistent.
*   **Add Dark Mode**: Once core components use tokens, implement the dark mode `@media` query and define the `-dark` values. Test thoroughly.

**Phase 3: Data Viz & Consolidation (2 weeks)**
*   **Refactor Charts**: Update all charting libraries (Chart.js, D3, etc.) to use the `--color-data-*` tokens.
*   **Enforce Rules**: Implement linting rules (e.g., via Stylelint) to forbid the use of hex codes and direct color values, enforcing token usage.
*   **Remove Legacy**: After full coverage, delete old, unused color variables and values from the codebase.

**Governance**: Designate a point person (e.g., a Design System lead) to approve any additions to the color token list, ensuring the system remains semantic and doesn't bloat.