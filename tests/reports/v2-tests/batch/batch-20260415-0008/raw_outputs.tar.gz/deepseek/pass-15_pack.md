[SESSION_STATE]
{
  "route": "rt_backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": ["authority_model: tenant-scoped", "consistency_stance: eventual for activity feeds, strong for approvals", "data_delivery: event-driven with webhook fanout", "observability_tax: per-tenant audit trail, structured logs, and webhook delivery receipts"],
  "evidence_classes_cited": ["threshold", "constraint", "rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## System framing

You’re building a multi-tenant scheduling platform that must scale beyond basic CRUD. The core challenge is balancing strong consistency for business-critical workflows (approvals, schedules) with the scalability and flexibility needed for real-time activity feeds, automation, and integrations. The existing REST+relational foundation is a good start, but inconsistent background jobs and eventing will become a reliability bottleneck.

The architecture must enforce tenant isolation, support regional data residency, provide a complete audit trail, and enable future customer-defined automations without breaking the system. This spec defines the service boundaries, data models, contracts, and operational posture to meet those goals.

## Core model and authority boundaries

### 1. Tenant & Workspace Model
*   **Tenant:** The top-level billing and data-residency entity. A tenant’s data is pinned to a specific geographic region (e.g., `us-east`, `eu-west`). All services must respect this boundary.
*   **Workspace:** A team or project group within a tenant. Users belong to a workspace. Schedules, resources, and approval workflows are scoped to a workspace. This allows large organizations to segment their data.
*   **Authority Rule:** Every data access and mutation must be preceded by a **tenant-scoped authorization check**. The service layer must resolve `(user_id, workspace_id)` to a `tenant_id` and confirm the user has the required role/permission within that workspace. Deny by default.

### 2. Core Services & Data Boundaries
Break the monolith into these bounded contexts, each with its own data store and internal domain model.

| Service | Responsibility | Data Store | Consistency Need |
| :--- | :--- | :--- | :--- |
| **Tenant & Identity** | Tenant/workspace/user lifecycle, authentication, role/permission mapping. | Relational DB (existing) | Strong. The source of truth for membership and access. |
| **Scheduling Core** | Resources, calendars, appointment booking, conflict detection. | Relational DB (existing, extended) | Strong. Double-bookings and schedule integrity are critical. |
| **Approval Workflow Engine** | Defines and executes approval chains (e.g., "manager approval for time-off"). State machine per request. | Relational DB (new tables) | Strong. Approval state must be unambiguous and auditable. |
| **Activity Feed Service** | Generates and serves the cursor-based activity stream for a workspace (e.g., "User X booked Y", "Approval for Z was granted"). | **Time-series DB** (e.g., TimescaleDB) or a **stream-optimized relational schema**. | Eventual. Feeds are read-heavy, append-only, and tolerate slight lag. |
| **Event Bus & Webhook Dispatcher** | Reliable event routing and outbound webhook delivery to customer systems. | **Message Queue** (e.g., RabbitMQ, Kafka) + **Relational DB for delivery receipts**. | At-least-once delivery. Must support retries, dead-letter queues, and customer-configured endpoints. |
| **Automation Rules Engine (Future)** | Evaluates customer-defined "if-this-then-that" rules against platform events. | Relational DB for rule definitions + **In-memory cache** for rule evaluation. | Depends on the action. Trigger evaluation can be eventual; executing an action (e.g., create approval) follows the target service's consistency model. |

### 3. Contracts Between Services
Communication shifts from direct REST calls to **asynchronous, event-driven messaging** for all cross-context updates, with synchronous APIs reserved for command responses and queries.

*   **Command-Query Responsibility Segregation (CQRS) Pattern:** Use for the activity feed.
    *   **Command Side:** `Scheduling Core` and `Approval Engine` publish domain events (e.g., `AppointmentBooked`, `ApprovalRequested`) to the **Event Bus**.
    *   **Query Side:** The `Activity Feed Service` subscribes to these events, transforms them into feed items, and stores them in its optimized data store. It exposes a cursor-based GraphQL or REST API for paginated feed queries.
*   **Event Catalog:** All services must publish events to a shared, versioned schema registry (e.g., Protobuf, JSON Schema in a Git repo). Example events:
    *   `tenant.workspace.created`
    *   `scheduling.appointment.booked`
    *   `approval.request.state_changed`
    *   `user.assigned_to_workspace`
*   **Webhook Contract:** The `Webhook Dispatcher` subscribes to relevant events, formats them per a customer-defined template, and delivers them via HTTPS. It must:
    *   Sign payloads with a tenant-specific secret.
    *   Implement exponential backoff with jitter for retries.
    *   Guarantee at-least-once delivery and store a verifiable receipt with status (`delivered`, `failed`, `retrying`).
    *   Expose a dashboard for tenants to view recent webhook delivery attempts.

## Data, consistency, and delivery design

### 1. Data Residency & Storage
*   **Tenant Data Locality:** The `Tenant & Identity` service's database is sharded by region. All other services must be deployable per region, with their databases scoped to that region's tenant subset. A global load balancer routes tenant API requests to their regional cluster.
*   **Data Sovereignty:** No service may replicate or persist a tenant's data outside its designated region, unless encrypted for cross-region backup (with tenant consent documented).

### 2. Consistency Stance
*   **Strong Consistency (Immediate):** Required for `Scheduling Core` (conflict detection) and `Approval Workflow Engine` (state transitions). Use the existing relational DB with transactions.
*   **Eventual Consistency (Acceptable):** Used for `Activity Feed Service` (propagation delay of a few seconds is fine) and read-side projections for customer dashboards.
*   **The Tradeoff:** You gain massive scalability and decoupling for feeds and integrations, but you accept that the activity feed may lag behind the actual booking by a second or two. This is a conscious, acceptable tradeoff for this product domain.

### 3. Background Job & Eventing System
*   **Unified Job Queue:** Replace inconsistent background jobs with a single, monitored job queue (e.g., Bull for Redis, Celery for Python). All services use this queue for deferred tasks (e.g., sending email, cleaning up stale data).
*   **Centralized Event Bus:** The `Event Bus` becomes the nervous system. Services publish events after successfully committing their local transactions (Outbox Pattern). A separate process polls the outbox table and publishes to the message queue, ensuring events are not lost if a service crashes after a DB commit but before publishing.

## Observability and failure posture

### 1. Audit Trail
*   **Immutable Log:** Every state-changing command (e.g., `BookAppointment`, `ApproveRequest`) must generate an **audit entry** stored in a dedicated, append-only audit table, linked to `tenant_id` and `workspace_id`. Entries include the user ID, timestamp, action, and a snapshot of the relevant data before/after the change.
*   **Access:** Expose a secure, filterable API for tenants to export their own audit logs for compliance.

### 2. Observability Tax
*   **Structured Logging:** All services must emit structured logs (JSON) with a mandatory `tenant_id` and `trace_id` for correlating requests across services.
*   **Metrics:** Instrument key business metrics per tenant: booking volume, approval cycle time, webhook delivery success rate, and API latency percentiles.
*   **Health Checks:** Each service exposes a `/health` endpoint verifying its connections to its database and the event bus. The deployment orchestrator uses this for readiness/liveness probes.

### 3. Failure & Degradation Design
*   **Circuit Breakers:** Services calling external customer webhooks or internal dependencies must use circuit breakers to prevent cascading failures.
*   **Degraded Modes:**
    *   If the `Activity Feed Service` is down, the UI should gracefully disable the feed widget but not block scheduling.
    *   If the `Event Bus` is down, services should buffer events locally (using the Outbox Pattern) and continue operating; core scheduling and approvals remain functional.
    *   Webhook delivery failures are queued for retry; persistent failures alert the platform team and the tenant admin.
*   **Disaster Recovery:** Per-region database backups and documented playbooks for regional failover (though the goal is to avoid cross-region data transfer).

## Summary of Key Decisions

1.  **Authority Model:** Tenant-scoped, with workspace-level user permissions. All services enforce this.
2.  **Consistency Stance:** Strong for scheduling/approvals, eventual for activity feeds and most integrations.
3.  **Data Delivery:** Event-driven architecture with a central Event Bus and dedicated Webhook Dispatcher for reliable external integrations.
4.  **Observability Tax:** Paid upfront via per-tenant audit trails, structured logging with tenant context, and webhook delivery receipts.

This architecture isolates complexity into bounded services, scales the read-heavy feed separately, ensures reliable integrations, and lays the foundation for customer automation—all while maintaining the strong consistency required for your core business logic.