I’ll help you fix this InDesign‑exported PDF for screen‑reader compatibility and logical reading order. This is a **PDF/document accessibility remediation** task.

---

## Current failure state
- **Source**: InDesign export → two‑column layout, decorative images, pull quotes, broken TOC links.
- **Semantic failures**:  
  - No/incorrect tagging → screen readers cannot interpret structure.
  - Reading order likely follows visual column flow (top‑to‑bottom left column, then right column), which breaks logical narrative order.
  - Decorative images lack alt‑text or artifact tagging.
  - Pull quotes interrupt reading flow (likely placed as floating elements).
  - Table of contents links are broken (destinations missing or mis‑anchored).
- **Extraction risk**: If exported to plain text or reflowed, content will be garbled.

## Remediation sequence
1. **Open in Adobe Acrobat Pro** (or equivalent tool with full accessibility workspace).
2. **Run Accessibility Check** (Tools → Accessibility → Full Check) to get a baseline report.
3. **Tag the document**:
   - Use **Autotag** as a starting point, then manually correct.
   - Ensure `<H1>`, `<H2>`, etc., match the visual heading hierarchy.
   - Tag the two‑column layout as a single `<Sect>` or use `<Div>` with reading‑order override.
4. **Fix reading order**:
   - Open **Reading Order Panel** (Tools → Accessibility → Reading Order).
   - Drag elements into logical sequence:  
     *Headings → body text in continuous flow, ignoring visual columns.*  
     *Pull quotes → place after the paragraph they reference, tag as `<Quote>` or `<Aside>`.*  
     *Decorative images → mark as “Background/Artifact” so screen readers skip them.*
   - Verify with **Read Out Loud** (View → Read Out Loud → Activate) to hear the flow.
5. **Repair TOC links**:
   - In **Tags Panel**, find the TOC entries.
   - Right‑click each link → **Properties** → **Actions** → ensure “Go to a page in this document” points to the correct destination (check page number and zoom).
   - If destinations are missing, recreate them using **Destinations Panel** (View → Show/Hide → Navigation Panes → Destinations).
6. **Add alt‑text**:
   - For informative images: right‑click → **Edit Alt‑Text** → concise description.
   - For decorative images: right‑click → **Edit Alt‑Text** → check “Decorative.”
7. **Set document language**:
   - File → Properties → Advanced → Language → choose correct language (e.g., English).
8. **Re‑run accessibility check** and clear all errors/warnings.

## Verification checks
- **Screen‑reader test**: Use NVDA, JAWS, or VoiceOver to navigate by headings, links, and read continuously.
- **Reflow test**: View → Zoom → Reflow — text should follow the corrected reading order.
- **Export test**: Save As → Text (Plain) — verify paragraphs, headings, and lists export in logical sequence.
- **Link test**: Click each TOC entry — must jump to correct section.

## Risk controls
- **Preserve visual layout**: Tagging and reading‑order changes do not alter the original PDF appearance.
- **Avoid destructive shortcuts**: Do not flatten the PDF, rasterize text, or remove interactive elements.
- **Backup original**: Keep the untagged PDF as a backup before remediation.
- **InDesign re‑export**: If tagging fails repeatedly, return to InDesign, enable “Create Tagged PDF” and “Use Structure for Tab Order” in export settings, then re‑export.

---

**Next step**: If you can share the PDF (or a sample page), I can provide a more specific tagging map and reading‑order sequence. Otherwise, follow the steps above—focus first on tagging and reading order, then repair links, then verify with a screen‑reader.