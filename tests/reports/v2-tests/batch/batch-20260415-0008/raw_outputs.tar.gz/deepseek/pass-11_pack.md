I’ll reconstruct the layout system from your 2018 PDF brand guidelines and translate it into a modern layout system you can apply to new templates.

---

## Source constraints

From your description, the PDF contains:
- Grid diagrams
- Margin specifications
- Column layout examples

These are typical components of a classic print/editorial grid system, likely built for fixed‑width documents (like letter/A4 pages, brochures, or reports) rather than responsive web.

---

## Reconstruction assumptions

I’ll assume:
- The original system was designed for **print‑first** or **fixed‑width digital** (PDF, slides, static templates).
- It uses a **baseline grid** for vertical rhythm and a **column grid** for horizontal alignment.
- Margins, gutters, and column widths are specified in **points, millimeters, or inches**.
- There may be multiple grid templates for different page types (cover, interior, spreads).

If you upload the PDF or share screenshots of the grid diagrams, I can give exact measurements and infer the underlying manuscript or modular grid logic.

---

## Rebuild sequence

### 1. Extract the core metrics
From the grid diagrams and margin specs, capture:

- **Page dimensions** – width × height (e.g., 8.5″×11″, A4, custom)
- **Margins** – top, bottom, inner, outer (for spreads)
- **Column count** – how many columns per page
- **Gutter width** – space between columns
- **Baseline increment** – vertical unit (e.g., 4pt, 6pt)
- **Live‑area width** – page width minus margins

### 2. Infer the grid type
Classic brand‑guideline grids tend to be:

- **Manuscript grid** – single column of text with large margins for notes/annotations.
- **Modular grid** – multiple columns and rows, used for complex layouts with images, sidebars, tables.
- **Hierarchical grid** – custom alignment system for specific content types.

I’ll look for repeating units (modules) and alignment guides.

### 3. Normalize to relative units
Convert absolute print measurements to relative units for modern digital use:

- **For web**: convert to `rem`/`em` (based on a root font size, e.g., 1rem = 16px).
- **For flexible digital templates** (Figma, Canva, Google Docs): use percentages or fractional units.
- **Keep the proportional relationships** – e.g., gutter ÷ column width ratio.

### 4. Adapt for responsive contexts
Print grids are fixed‑width; digital layouts need breakpoints.

I’ll propose:
- **Base grid** at a canonical screen width (e.g., 1024px) that matches the original live‑area proportion.
- **Simplified mobile grid** – often reduce columns, increase margins, keep baseline rhythm.
- **Wide‑screen adaptation** – add columns, maintain gutter ratio.

### 5. Define the layout tokens
Express the system as design tokens or CSS custom properties:

```css
--grid-baseline: 0.25rem;        /* 4pt → 0.25rem */
--grid-column-count: 12;
--grid-gutter: 1.5rem;           /* from original gutter */
--grid-margin-sm: 1rem;
--grid-margin-lg: 2rem;
--page-max-width: 75rem;         /* matches original live‑area proportion */
```

### 6. Create usage guidelines
Map original layout examples to modern components:

- **Full‑bleed images** → CSS `grid-column: 1 / -1`
- **Sidebar layout** → CSS Grid `grid-template-columns: 2fr 1fr`
- **Multi‑column text** → `column-count: 2` (print‑like) or CSS Grid for control
- **Vertical rhythm** → `margin‑bottom: var(--grid-baseline) * N`

---

## Verification checkpoints

Before applying the new system:

1. **Print‑to‑screen proportion check** – does the live‑area width feel balanced on a desktop viewport?
2. **Baseline rhythm test** – does vertical spacing feel consistent when text size changes?
3. **Grid overlay validation** – overlay the reconstructed grid on the original PDF examples to confirm alignment.
4. **Breakpoint sanity** – test mobile, tablet, desktop, and wide‑screen.

---

## What I need from you to be precise

If you can share:

- **Screenshots of the grid diagrams** – I’ll extract exact measures.
- **Page‑size note** – US Letter, A4, custom?
- **Intended modern use** – web UI, slide decks, digital reports, responsive PDFs?

I can then give you a complete, ready‑to‑implement layout token system with CSS/Fig‑ma examples.

---

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": ["reconstruction_order: extract → normalize → adapt → tokenize"],
  "evidence_classes_cited": ["inferred_grid", "print_to_digital_conversion"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": ["page_size", "intended_modern_medium", "screenshots_of_grid_diagrams"],
  "turn": 1
}
[/SESSION_STATE]