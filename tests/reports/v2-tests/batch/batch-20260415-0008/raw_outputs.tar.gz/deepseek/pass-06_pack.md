[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": ["audience_frame: freelancers as business operators", "differentiation_frame: operational intimacy vs. scale", "trust_logic: transparency and control as trust", "messaging_consequence: utility-first, not aspiration-first"],
  "evidence_classes_cited": ["category_convention", "audience_constraint", "differentiation_tradeoff"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Audience and problem

**Target:** Freelancers, solopreneurs, and small agency owners (1–10 people).
**Core struggle:** They are business operators, not just individuals with side income. Their financial life is a constant, messy loop of invoicing, chasing payments, estimating taxes, managing irregular cash flow, and reconciling personal and business expenses. They feel ignored by big banks (too impersonal) and underserved by neobanks that treat them as consumers with a side hustle.

**Competitive landscape:**
*   **Stripe:** The infrastructure layer. Powerful, but it's a developer tool first. It feels like plumbing, not a partner.
*   **Mercury:** Startup banking for venture-backed companies. Its positioning is about "moving fast" and "fundraising," which is irrelevant or even alienating to most freelancers.
*   **Relay:** Small business banking focused on multi-user collaboration and permissions. It's practical but frames the problem as "team banking," which doesn't resonate with the solo operator's specific anxieties.

## Positioning frame

**Territory to own: Operational Intimacy.**

The position is not about being the *friendliest* or the *most powerful*, but the **most intimately useful for the daily financial operations of a business-of-one.**

This means:
*   **Language:** Speak in verbs of work (invoice, deduct, project, reconcile, withhold) not nouns of finance (account, yield, asset).
*   **Metaphor:** The toolbelt or the business manager, not the bank or the advisor.
*   **Antagonist:** The "admin tax" – the mental load, lost hours, and anxiety of manual financial management that steals from their core work.

**Differentiation:** While Stripe provides the pipes and Mercury chases growth, you provide the **control room**. You are the system that turns chaotic freelance income into a legible, manageable business.

## Trust and proof burden

For freelancers, trust is not built on marble lobbies or decades of history. It's built on:
1.  **Transparency:** No hidden fees. Clear, upfront explanations of *exactly* what every feature costs and why.
2.  **Control:** They must feel they understand their cash flow and tax situation at all times. Tools should educate, not obfuscate.
3.  **Reliability:** Invoices go out, payments arrive, tax estimates are accurate. The platform is boringly dependable.

**Proof Strategy:**
*   **Avoid:** Vague claims of "security" or "ease." Every security claim must be paired with a concrete, user-visible behavior (e.g., "You get a notification for every login from a new device").
*   **Lead with:** Case studies that are less about revenue growth and more about **time reclaimed and anxiety reduced.** "Saved 6 hours a month on reconciliation" is a more powerful proof point than "Processed $500k."
*   **Evidence Class:** Use **constraint-based honesty.** "Because freelancers have irregular income, we built a tax estimator that updates with every transaction, not just quarterly." This ties the feature directly to a known user pain point.

## Messaging consequences

Adopting "Operational Intimacy" dictates specific messaging choices:

**Tone: Utility-first, not aspiration-first.**
*   **Not:** "Empower your dream." / "Banking for the bold."
*   **Instead:** "Know exactly what you owe, when." / "Turn receipts into deductions automatically." / "Get paid for your work, not your admin."

**Visual & Interaction Cues:**
*   Clarity over coolness. High information density is acceptable if it's supremely well-organized.
*   Use progressive disclosure – show the simple summary, offer deep dives for the detail-oriented.
*   Visuals should show the *interface in use* (e.g., a screenshot of a tax projection dashboard) more often than aspirational lifestyle shots.

**Feature Prioritization:**
*   **Winning features** are those that directly reduce operational drag: automated receipt matching, real-time tax withholding estimates, flexible invoicing with gentle chase-up reminders, clear cash-flow forecasting.
*   **Secondary features** are "business banking basics" done exceptionally well: multiple envelopes (not just accounts), high-yield on all balances, seamless transfers.
*   **Avoid** features that drift into the social (community forums) or venture-focused (fundraising cap tables) unless they can be tightly tied back to core operations.

**Tradeoff:** By owning "Operational Intimacy," you explicitly **cede** the territory of "Fastest-Growing Startup Bank" (Mercury) and "Global Financial Infrastructure" (Stripe). You are not for the founder trying to scale to 100 employees with venture capital. You are for the skilled operator who wants their business to run smoothly so they can focus on the work they love. This focus is your strength.