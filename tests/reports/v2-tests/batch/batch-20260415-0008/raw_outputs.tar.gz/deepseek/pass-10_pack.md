[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": ["communication_goal: clarity_first", "hierarchy_failure: title_before_context", "rebuild_move: contextual_lead_in", "distance_tradeoff: decorative_for_emphasis"],
  "evidence_classes_cited": ["visual_observation", "hierarchy_analysis"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Communication goal
The primary job of this poster is to compel a designer to attend a conference. It must communicate **what the event is, who it's for, and why it matters** before it can sell with style. The current design uses a decorative title as the lead, which creates a moment of confusion before the viewer can resolve the event's purpose.

## Composition failures
1.  **Hierarchy Inversion:** The largest, most stylized element is the conference title. However, the viewer lacks the context to understand *what* the title refers to (a conference, a talk series, a brand) until they find smaller, secondary text. This forces a cognitive backtrack.
2.  **Buried Call-to-Action & Logistics:** The date—a critical logistical detail—is de-emphasized with small, low-contrast gray text placed in a corner. The location or a tagline explaining the event type (e.g., "Annual Design Conference") appears to be missing entirely, based on your description.
3.  **Visual Competition:** A full-bleed city skyline is a strong atmospheric element, but it risks competing with the overlaid logo for visual attention. If the logo is also white and centered, it may get lost in bright areas of the photo, weakening brand recognition.
4.  **Decorative Over Functional:** The choice of a decorative typeface for the primary headline prioritizes stylistic vibe over immediate legibility and scanability, which are essential for a poster viewed at a distance or in passing.

## Rebuild moves
**1. Lead with Context, Then Title.**
*   **Move:** Introduce the event *before* naming it. Add a prominent, highly legible line like "Annual Design Conference" or "A Gathering for Digital Designers" above the decorative title.
*   **Tradeoff:** You sacrifice some of the dramatic, stylized first impression of the title alone to gain immediate comprehension. The title remains the focal point but is now properly framed.

**2. Elevate Key Logistics to a Structural Element.**
*   **Move:** Pull the date, location, and a primary call-to-action (e.g., "Register Now," "Learn More") out of the corners and integrate them into the layout's structure. Group them in a high-contrast block or along a strong grid line.
*   **Tradeoff:** You sacrifice some minimalist aesthetic purity to gain clear, actionable information. This makes the poster useful, not just beautiful.

**3. Clarify the Visual Layers.**
*   **Move:** Ensure the conference logo has a guaranteed clear space or a subtle background treatment (e.g., a slight dark overlay behind it) to separate it from the variable background photo. Treat the skyline as atmosphere, not the primary communication layer.
*   **Tradeoff:** You sacrifice a perfectly "clean" overlay to guarantee brand visibility and hierarchy across different photo conditions.

**4. Use Decorative Type as Emphasis, Not Foundation.**
*   **Move:** Keep the decorative typeface for the conference title, but ensure the supporting contextual text (event type, date, location) uses a highly legible, neutral sans-serif. This creates a clear typographic hierarchy: legible context -> expressive title -> legible details.
*   **Tradeoff:** You sacrifice typographic uniformity to create a hierarchy that guides the eye logically from "what is this?" to "what's it called?" to "when and where?"

## Distance and emphasis tradeoff
The current design prioritizes **close-up, stylistic impact** (the decorative type, the full-bleed photo) at the cost of **distance readability and instant comprehension**. The rebuild shifts the priority: it ensures the poster works at **3–10 feet away** (what it is, key details) to draw people in, then rewards a closer look with the stylistic title and detailed atmosphere. The decorative title becomes the reward for looking closer, not the barrier to entry.