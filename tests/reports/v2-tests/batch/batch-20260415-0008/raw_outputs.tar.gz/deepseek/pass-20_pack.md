I’ll write a backend architecture spec for a multi-tenant scheduling platform with team workspaces, cursor-based activity feeds, approval workflows, and outbound webhooks.

---

## System framing

**Platform type:** Multi-tenant B2B scheduling platform  
**Core capabilities:**  
- Team-based workspaces with role-based access  
- Scheduling engine with resource/calendar management  
- Cursor-based activity feeds for real-time audit and updates  
- Configurable approval workflows  
- Outbound webhooks to customer systems for event synchronization  

**Non‑goals (for this spec):**  
- Native mobile apps (API‑first design supports them)  
- Built‑in payment processing (integrates via webhooks)  
- Custom UI theming per tenant (handled at front‑end layer)  

---

## Core model and authority boundaries

### 1. Tenancy model  
**Choice:** Database‑level isolation with schema‑per‑tenant (PostgreSQL)  
- Each tenant gets a dedicated schema: `tenant_<id>`  
- Shared `control_plane` schema for tenant metadata, user accounts, and subscriptions  
- **Why:** Strong data isolation, simpler backups/restores per tenant, clear billing attribution  

**Tradeoff:** Higher operational overhead for schema migrations; use a migration orchestrator that applies changes across all tenant schemas.

### 2. Workspace and membership model  
- A **tenant** can have multiple **workspaces** (e.g., “Marketing Team,” “Support Team”)  
- **User** belongs to a tenant, can be invited to one or more workspaces  
- **Role‑based access control (RBAC)** per workspace:  
  - `admin` (manage members, settings, webhooks)  
  - `scheduler` (create/edit schedules, manage resources)  
  - `approver` (review/approve workflow requests)  
  - `viewer` (read‑only)  

**Authority check:** Every request must validate:  
1. User is in tenant (JWT `tenant_id`)  
2. User has required role in the target workspace (`workspace_membership` table)  
3. Resource belongs to the same workspace (`workspace_id` on all resources)  

**BOLA protection:** Deny by default; all resource queries include `WHERE workspace_id = ?`.

### 3. Scheduling engine  
**Resources:**  
- `users` (schedulable people)  
- `rooms`, `equipment`, `vehicles` (schedulable assets)  
- `calendars` (Google Calendar, Outlook sync via webhooks)  

**Appointments:**  
- `start_at`, `end_at` (with timezone)  
- `resource_ids` (array of booked resources)  
- `status` (tentative, confirmed, cancelled)  
- `recurrence_rule` (RFC 5545‑like)  
- **Conflict detection:** Query for overlapping appointments across all selected resources at write time.

---

## Data, consistency, and delivery design

### 1. Activity feed (cursor‑based)  
**Table:** `activity_events`  
- `id` (auto‑increment, but not exposed)  
- `cursor` (ULID‑based, globally sortable)  
- `workspace_id`, `tenant_id`  
- `event_type` (e.g., `appointment.created`, `approval.requested`)  
- `actor_id` (user who performed the action)  
- `resource_type`, `resource_id`  
- `payload` (JSON snapshot of the resource at event time)  
- `created_at`  

**API:** `GET /api/v1/activity?after=<cursor>&limit=50`  
- Index on `(workspace_id, cursor)`  
- **Why cursor‑based:** Stable pagination across real‑time inserts, no missing/duplicate rows during live updates.

### 2. Approval workflows  
**Model:**  
- `workflow_definitions` (per workspace): steps, approvers, conditions  
- `workflow_instances` (tied to an appointment or schedule change)  
- `approval_tasks` (per approver, with status: pending, approved, rejected)  

**State machine:**  
`draft → pending → (approved|rejected) → (completed|cancelled)`  
- Each transition emits an activity event.  
- Time‑out escalation: background job moves stale tasks to next approver or notifies admins.

### 3. Outbound webhooks  
**Registration:**  
Tenants configure webhook endpoints per event type (`appointment.updated`, `approval.resolved`).  

**Delivery guarantees:**  
- At‑least‑once delivery with retry (exponential backoff + jitter)  
- Webhook payload includes: `event_id` (ULID), `event_type`, `resource`, `timestamp`, `signature` (HMAC)  
- **Dead‑letter queue (DLQ):** Failed deliveries after max retries move to DLQ for manual review.  

**Idempotency:**  
Receivers should deduplicate by `event_id` (idempotency contract).

### 4. Consistency stance  
**CP (Consistency‑Partition tolerance):**  
- Primary database is PostgreSQL (strong consistency within tenant).  
- Activity feed and webhook queues are eventually consistent (async workers).  
- **Tradeoff:** Activity events may appear a few seconds after the write; webhooks may be delayed under load. This is acceptable for audit trails and external sync.

**Caching strategy:**  
- Redis cache for per‑workspace role/permission lookups (TTL 5 minutes).  
- No cache for scheduling conflict checks (always fresh read).  
- Cache‑key pattern: `tenant:{tenantId}:workspace:{workspaceId}:members`.

---

## Observability and failure posture

### 1. Monitoring  
- **Metrics:** Appointment volume, webhook delivery latency, approval‑cycle time, error rates per tenant.  
- **Traces:** OpenTelemetry spans across API → DB → queue → worker → webhook.  
- **Logs:** Structured JSON logs with `tenant_id`, `workspace_id`, `user_id`, `trace_id`.

### 2. Failure modes and mitigations  
| Failure | Impact | Mitigation |
|---------|--------|------------|
| Tenant schema migration fails | New features blocked for affected tenant | Pause migration, rollback, alert, retry later |
| Webhook endpoint down | External systems out of sync | Retry with exponential backoff, DLQ after 24h |
| Approval task timeout | Workflow stalls | Escalate to backup approver, notify admins |
| Redis outage | Permission checks fall back to DB | Higher DB load, slower auth checks |

### 3. Degraded modes  
- If activity‑feed writes are slow, buffer in Redis queue and async flush.  
- If webhook delivery fails repeatedly, disable that endpoint after DLQ threshold and alert tenant admin.  
- If conflict‑detection query times out, fail closed (reject the appointment) rather than double‑book.

### 4. Multi‑region considerations  
- Primary database in one region (strong consistency).  
- Read‑replicas in other regions for low‑latency reads (activity feed, calendar views).  
- Webhook workers run in multiple regions with regional queues; each region delivers to nearby endpoints.

---

## Required implementation sequence

1. **Schema‑per‑tenant setup** – migration orchestrator, tenant provisioning service.  
2. **Workspace RBAC** – membership table, role checks, JWT claims.  
3. **Scheduling core** – resource and appointment models, conflict detection.  
4. **Activity feed** – ULID cursor, index, pagination API.  
5. **Approval workflow engine** – state machine, task assignment, timeouts.  
6. **Webhook dispatcher** – queue, retry, DLQ, signing.  
7. **Observability** – metrics, tracing, structured logging per tenant.

---

## Key tradeoffs

| What’s preserved | What’s sacrificed |
|------------------|-------------------|
| **Strong tenant isolation** – data leaks nearly impossible at DB level | **Operational complexity** – schema migrations must be orchestrated across all tenants |
| **Real‑time audit trail** – cursor‑based feed supports live updates and historical pagination | **Eventual consistency** – activity events may lag writes by a few seconds |
| **External integration readiness** – webhooks with at‑least‑once delivery | **Higher latency** for write‑heavy operations (webhook queue adds delay) |
| **Scalable reads** – read‑replicas for low‑latency calendar views | **Cross‑region writes** go to primary region (higher latency for global tenants) |

---

[SESSION_STATE]
{
  "route": "rt_backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": ["authority_model: schema-per-tenant", "consistency_stance: CP (strong consistency within tenant, eventual consistency for feeds/webhooks)", "data_delivery: cursor-based activity feed (ULID), at-least-once webhooks", "observability_tax: per-tenant metrics, structured logs, OpenTelemetry traces"],
  "evidence_classes_cited": ["threshold", "constraint", "tradeoff"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]