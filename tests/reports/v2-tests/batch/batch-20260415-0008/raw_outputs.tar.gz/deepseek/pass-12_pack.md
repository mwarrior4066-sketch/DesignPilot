## Reading contexts and constraints

**Primary reading contexts:**
- **Marketing site** – long-form editorial content (blog, case studies, landing pages), headlines, trust signals, and calls to action. Requires high readability, brand expression, and a modern but trustworthy tone.
- **Web app dashboard** – dense tabular data, numeric KPIs, form labels, status messages, navigation, and UI controls. Needs clarity, density tolerance, and strong hierarchy.
- **Mobile** – smaller viewports, touch interaction, reduced line lengths, and variable reading distances. Requires robust legibility at small sizes and responsive scaling.

**Key constraints:**
- **Trustworthiness** – typefaces must feel stable, precise, and professional. Avoid overly expressive or decorative styles.
- **Data density** – numerals must align cleanly in tables; tabular figures need consistent width and clarity.
- **Hierarchy** – system must support at least 4–5 distinct levels (display, headline, subhead, body, caption, UI labels) using weight, size, and case.
- **Cross-platform consistency** – typefaces must render well across macOS, Windows, iOS, Android, and major browsers.
- **Licensing** – commercial use across web and mobile; variable-font support preferred for performance and flexibility.
- **Accessibility** – meet WCAG 2.1 AA for contrast (4.5:1 for normal text, 3:1 for large text), support reduced-motion preferences, and ensure readability for users with dyslexia or low vision.

---

## Scale and role map

| Role | Typeface | Weights | Size range (web) | Mobile scale | Use case |
|------|----------|---------|------------------|--------------|----------|
| **Display** | Inter (variable) | 700–900 | 3.5–5rem (56–80px) | 2.5–3.5rem | Marketing hero headlines, major dashboard titles |
| **Headline** | Inter (variable) | 600–700 | 2–2.5rem (32–40px) | 1.75–2.25rem | Section titles, modal headings, card headers |
| **Subhead** | Inter (variable) | 500–600 | 1.25–1.5rem (20–24px) | 1.125–1.375rem | Sub‑sections, form group labels, data‑viz titles |
| **Body** | Inter (variable) | 400–500 | 1rem (16px) base | 1rem (16px) | Paragraphs, descriptions, explanatory text |
| **UI / Label** | Inter (variable) | 500–600 | 0.875–1rem (14–16px) | 0.875–1rem | Buttons, form fields, navigation, table headers |
| **Caption / Meta** | Inter (variable) | 400–500 | 0.75–0.875rem (12–14px) | 0.75–0.875rem | Timestamps, helper text, table footers, legal |
| **Monospace (data)** | **Roboto Mono** (variable) | 400–500 | 0.875–1rem (14–16px) | 0.875–1rem | Currency values, IDs, code snippets, tabular figures |

**Why Inter + Roboto Mono:**
- **Inter** is a highly legible, neutral sans‑serif with excellent on‑screen performance, extensive language support, and a variable axis (weight 100–900) that allows fine‑tuned hierarchy without loading multiple files.
- **Roboto Mono** provides clean, fixed‑width numerals for financial tables, ensuring decimal alignment and consistent column widths. Its slightly rounded forms maintain approachability while feeling precise.
- Both are freely available via Google Fonts, support variable fonts, and have robust fallback stacks.

**Fallback stack:**
```css
font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
font-family: 'Roboto Mono', 'SF Mono', Monaco, 'Courier New', monospace;
```

---

## Readability rules

**Line length**
- Marketing prose: 45–75 characters per line (≈ 20–35em).
- Dashboard UI / dense content: 30–50 characters per line (≈ 15–25em).
- Mobile: 35–50 characters per line.

**Line height (leading)**
- Display: 1.1–1.2
- Headline: 1.2–1.3
- Body: 1.5–1.6
- UI labels: 1.4
- Captions: 1.4

**Spacing (vertical rhythm)**
Use a **baseline grid of 8px**. All vertical margins, padding, and line‑heights should be multiples of 8px.
- Paragraph spacing: 1.5 × body line‑height (≈ 24px).
- Headline margin‑bottom: 1 × headline line‑height.
- Section spacing: 2–3 × baseline (16–24px).

**Contrast**
- Normal text (≤ 18px): minimum 4.5:1 (WCAG AA).
- Large text (≥ 18px bold or ≥ 24px regular): minimum 3:1.
- UI states (hover, focus, disabled): maintain at least 3:1 difference from default.
- Data‑viz and charts: ensure adjacent colors differ by at least 3:1 in lightness.

**Mobile adjustments**
- Increase touch‑target size around interactive text (min 44×44px).
- Slightly increase letter‑spacing for uppercase labels (0.05em).
- Use `text-size-adjust: 100%;` to prevent iOS zooming on input.

---

## Adoption guidance

**Phase 1: Foundation (weeks 1–2)**
1. Load Inter and Roboto Mono via Google Fonts (variable versions).
2. Define CSS custom properties for the scale and roles in a central `typography.css`.
3. Apply the system to the marketing site first – test hero headlines, blog posts, and CTAs.
4. Verify contrast and readability across light/dark themes.

**Phase 2: Dashboard integration (weeks 3–4)**
1. Extend the token system to the web app, focusing on data tables and KPI displays.
2. Implement Roboto Mono for all currency values and IDs.
3. Test table alignment and density with real financial data.
4. Adjust line‑height and spacing for dense UI components.

**Phase 3: Mobile refinement (weeks 5–6)**
1. Apply responsive scaling rules (use `clamp()` for fluid type where supported).
2. Test touch targets and legibility on iOS/Android devices.
3. Validate reduced‑motion preferences (respect `prefers‑reduced‑motion`).
4. Audit screen‑reader announcements with the new type stack.

**Phase 4: Governance and maintenance**
1. Document the type scale and roles in the design system.
2. Set up linting (e.g., Stylelint) to enforce contrast ratios and font‑family usage.
3. Plan for future expansion – consider adding a serif (e.g., **Source Serif Pro**) for long‑form editorial if the brand evolves.
4. Monitor performance: font‑loading strategy, FOUT/FOIT, and variable‑font support in target browsers.

**Tradeoffs made**
- **You gain** a unified, performant, and highly legible system that works across marketing, dashboard, and mobile contexts with a single variable sans‑serif.
- **You sacrifice** some brand distinctiveness – Inter is widely used, which may reduce visual uniqueness in exchange for reliability and familiarity.
- **You accept** the overhead of managing two typefaces (Inter + Roboto Mono) instead of one, but the separation ensures tabular data remains perfectly aligned.

---

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": ["reading_context: marketing, dashboard, mobile", "scale_decision: Inter + Roboto Mono", "pairing_rationale: legibility + tabular alignment", "adoption_sequence: marketing → dashboard → mobile"],
  "evidence_classes_cited": ["threshold", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]