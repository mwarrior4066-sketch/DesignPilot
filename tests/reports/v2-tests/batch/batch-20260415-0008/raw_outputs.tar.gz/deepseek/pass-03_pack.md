[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": ["dashboard_role: operational", "kpi_failure: missing_reference", "chart_failure: unlabeled_axis", "density_or_navigation_decision: grouping_required"],
  "evidence_classes_cited": ["threshold", "rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Dashboard role
This is an **operational dashboard** for a SaaS analytics team. Its primary job is to surface performance trends, segment health, and potential problems quickly. The current layout suggests a "monitoring" posture but fails to provide the context needed for meaningful action.

## Key failures
1.  **KPI row lacks reference points.** DAU, MRR, and churn are presented as isolated numbers with trend arrows. Without a target, a previous period, or a benchmark, the trend is meaningless. Is a 5% uptick in MRR good or bad? Is churn moving toward a goal?
2.  **Chart is unreadable.** A 30-day line chart with four segments has no Y-axis label (is it count, percentage, dollars?) and a legend that is below the fold. This forces the user to scroll to decode the data, breaking the visual connection and making comparison impossible.
3.  **Navigation is a flat list.** Twelve ungrouped items in the sidebar create high scan cost. Users must read every item to find what they need, which contradicts the dashboard's goal of speed.

## Evidence and rationale
*   **Threshold:** For operational dashboards, a KPI must be paired with a reference (target, prior period, forecast) within 2 seconds of glance. The current design fails this.
*   **Rule:** WCAG 2.1 Success Criterion 1.4.11 requires non-text content (like charts) to have a visible label or accessible name. A missing Y-axis label is a direct accessibility failure.
*   **Rule:** The "7±2" cognitive load principle suggests grouping related navigation items. A flat list of 12 exceeds working memory capacity, increasing error rates and time-to-task.

## Recommended rebuild path
1.  **Anchor the KPIs.** Add a subtle secondary line of text below each large number: either a target (e.g., "vs. Goal: $120K"), a prior period comparison (e.g., "vs. Last Month: +2.1%"), or a variance indicator. This provides the necessary context for the trend arrow to be meaningful.
2.  **Fix the chart immediately.**
    *   Add a clear Y-axis label.
    *   Move the legend inline, adjacent to the chart title, or use direct labeling on the lines themselves.
    *   Consider if four lines are necessary for the default view; a "key segments" toggle might reduce clutter.
3.  **Group the navigation.** Cluster the 12 items into 3-4 logical groups (e.g., "Core Metrics," "User Analysis," "Financials," "Settings"). Use visual spacing or subtle headings. This reduces scan time from ~12 items to ~4 groups.

**Tradeoff:** Adding reference values to KPIs and grouping navigation increases information density slightly, but it trades a small amount of visual simplicity for a massive gain in decision speed and clarity. The chart fixes are non-negotiable for basic readability and accessibility.