I'll write a component spec for a split button with primary action, dropdown, and full state coverage.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: split button with dropdown", "state_coverage: primary, disabled, loading, hover, focus, active", "accessibility_behavior: keyboard navigation + ARIA menu", "implementation_boundary: semantic HTML with progressive enhancement"],
  "evidence_classes_cited": ["wcag_rule", "touch_target_threshold"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Purpose and scope

**Component name:** SplitButton  
**Category:** Form control / Action button  
**Problem solved:** Provides a primary action with related secondary actions in a compact, scannable pattern. Reduces cognitive load vs. separate buttons while maintaining clear hierarchy.

**When to use:**
- Primary action is clear and frequently used (Save, Submit, Continue)
- 2–4 related secondary actions exist (Save as draft, Save and close, Save and new)
- Screen real estate is constrained
- User needs quick access to primary action with discoverable alternatives

**When not to use:**
- More than 5 secondary actions (use regular dropdown menu)
- Secondary actions are unrelated to primary action
- Primary action isn't statistically dominant (>70% usage)
- On mobile-only interfaces where split interaction is fiddly

## Anatomy

```
┌─────────────────────────────────────────────┐
│  ┌─────────────┐ ┌───┐                     │
│  │    Save     │ │ ▼ │                     │
│  └─────────────┘ └───┘                     │
│  Primary button    Dropdown trigger        │
└─────────────────────────────────────────────┘
          ┌─────────────────┐
          │ Save as draft   │
          │ Save and close  │
          │ Save and new    │
          └─────────────────┘
               Menu panel
```

**1. Primary button (left segment)**
- Contains primary action label and/or icon
- Full button semantics (role="button", tabindex="0")
- Triggers primary action on click/Enter/Space
- 44×44px minimum touch target (mobile)
- Visual connection to dropdown trigger

**2. Dropdown trigger (right segment)**
- Visual separator (1px border or subtle background shift)
- Chevron icon (▼) indicating expandable content
- 36×44px minimum (maintains 44px height with primary)
- Opens/closes secondary actions menu
- ARIA: `aria-haspopup="menu"`, `aria-expanded="true/false"`

**3. Menu panel**
- Positioned below dropdown trigger (preferred) or aligned to button bottom
- Contains 2–4 menu items as `<button>` or `<a>` elements
- ARIA: `role="menu"` on container, `role="menuitem"` on items
- Auto-closes on: item selection, click outside, Escape key
- Minimum width: matches button width (recommended)

## State matrix

| State | Primary button | Dropdown trigger | Menu items | Visual cues |
|-------|----------------|------------------|------------|-------------|
| **Default** | Background: primary color<br>Text: white | Background: slightly darker<br>Icon: neutral | Hidden | Clear hierarchy, trigger distinguishable |
| **Hover** | Background: 10% darker<br>Cursor: pointer | Background: 20% darker<br>Cursor: pointer | Background: subtle highlight | Interactive affordance |
| **Focus** | Outline: 2px solid focus color<br>Outline-offset: 2px | Same focus ring | Focus ring per item | Keyboard navigation visible |
| **Active** (pressed) | Background: 20% darker<br>Transform: translateY(1px) | Same as primary | Background: active state | Press feedback |
| **Disabled** | Opacity: 0.5<br>Cursor: not-allowed<br>Events: none | Same disabled state | Menu cannot open | Non-interactive clarity |
| **Loading** | Primary only: spinner replaces text<br>Events: disabled during load | Disabled during load | Menu cannot open | Processing feedback |
| **Open** (menu visible) | Unchanged | Background: menu background color<br>Icon: rotated (180°) | Visible with hover/focus states | Clear open/closed state |

**Loading state specifics:**
- Primary button shows spinner + "Saving..." text
- Dropdown trigger remains visible but non-interactive
- If async operation fails, restore original state with error message near button

## Accessibility and implementation notes

### Keyboard interaction
```
Tab → Focus lands on primary button
Enter/Space on primary → Trigger primary action
ArrowRight/ArrowLeft → Move focus to dropdown trigger
Enter/Space on trigger → Open/close menu
ArrowDown/ArrowUp in open menu → Navigate menu items
Enter/Space on menu item → Select item, close menu
Escape → Close menu, return focus to trigger
Tab with menu open → Close menu, move to next focusable
Shift+Tab → Move focus backward
```

### ARIA attributes
```html
<div class="split-button">
  <button id="primary-action" aria-describedby="loading-status">
    Save
  </button>
  <button 
    id="dropdown-trigger"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="secondary-menu"
    aria-label="More save options"
  >
    ▼
  </button>
  <ul id="secondary-menu" role="menu" aria-labelledby="dropdown-trigger">
    <li role="none">
      <button role="menuitem">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem">Save and close</button>
    </li>
  </ul>
</div>
```

### Touch target compliance
- **Minimum:** 44×44px for primary button segment
- **Dropdown trigger:** At least 36px wide × 44px tall
- **Menu items:** 44px minimum height, full width
- **Spacing:** 8px between menu items for accidental tap prevention
- **Mobile consideration:** Consider collapsing to regular dropdown on viewports < 480px

### Implementation boundaries
1. **Semantic HTML first** – Use `<button>` elements, not `<div>` with click handlers
2. **Progressive enhancement** – Works without JavaScript (dropdown becomes visible list)
3. **CSS containment** – Use `contain: layout` for performance
4. **Focus management** – `focus-trap` for open menu, return focus properly
5. **Event delegation** – Single click handler on container, not per element

### Testing checklist
- [ ] Tab sequence follows visual order
- [ ] Screen reader announces "button, menu" and expanded state
- [ ] Color contrast ≥ 4.5:1 for all states
- [ ] Touch targets ≥ 44×44px at all breakpoints
- [ ] Menu closes on outside click, Escape, item selection
- [ ] Loading state disables interaction
- [ ] Disabled state prevents all interaction
- [ ] Reduced motion preference respected

### React/Vue implementation notes
- **Controlled component** – `isOpen`, `isLoading`, `isDisabled` props
- **Event handlers** – `onPrimaryAction`, `onSecondaryAction(index)`
- **Slot support** – Primary icon slot, custom menu items
- **Keyboard hooks** – Use `useFocusTrap`, `useKeyboardNavigation`
- **State lift** – Loading state should be managed by parent

**Tradeoff:** The split pattern saves horizontal space but adds complexity over separate buttons. You gain scannability for the primary action while sacrificing some discoverability of secondary options. The dropdown trigger must be immediately recognizable as "more options" related to the primary action.