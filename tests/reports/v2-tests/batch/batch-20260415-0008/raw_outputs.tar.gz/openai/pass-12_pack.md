## Reading context

This fintech product spans three distinct surfaces:  
- **Marketing site:** This context requires expressive, trust-building, branded headers and accessible body text for conversion, trust, and credibility.  
- **Web app dashboard:** Here, dense tabular data, quick number scanning, and transactional UIs are common. Readability, clarity, and resistance to visual fatigue are paramount.  
- **Mobile app:** The interface must remain legible at smaller sizes, support touch interaction, and adjust for varying lighting (including dark mode).

Constraints across all surfaces:
- Financial data and tabular layouts demand strong numerals and excellent alignment.
- Modern trust requires avoiding overtly playful or decorative faces.
- Hierarchy should be clear with minimal reliance on color alone (for accessibility and scanability).
- The system must support multiple weights to articulate structural relationships.

## Scale and role map

### Typefaces
- **Primary sans-serif:**  
  Choose an open, neutral, professional sans with excellent numeral design:
  - [Inter](https://rsms.me/inter/) (free, variable, designed for UI, supports tabular figures, modern and widely supported)
  - Alternative: [Roboto](https://fonts.google.com/specimen/Roboto) (web/app native, good numeral support, but less distinctive)
- **Optional secondary (for marketing and key promo headlines):**  
  A geometric or humanist sans serif with a touch more character (optional, only for headline distinction):
  - [Satoshi](https://www.fontshare.com/fonts/satoshi) or [IBM Plex Sans](https://fonts.google.com/specimen/IBM+Plex+Sans)

### Weight palette (for Inter or similar)
- **Regular (400):** Body, labels, main data
- **Medium (500):** Card headers, navigation labels, numbers in summary or data context
- **Bold (700):** Main headlines, section titles, call-to-action
- **Variable:** For smarter density control, use variable font interpolation where supported for fine-tuning.

### Role mapping

| Role                        | Typeface           | Weight  | Features / Notes                |
|-----------------------------|-------------------|---------|---------------------------------|
| Main headline               | Inter             | Bold    | Large size, allow negative letterspacing if legible on web |
| Section headline            | Inter             | Bold    | Slightly smaller than main; tracking slightly tighter |
| Card/dashboard headline     | Inter             | Medium  | Max 2 lines                    |
| Body text                   | Inter             | Regular | Aim for 16–18px web, 15–17px mobile |
| Table headers               | Inter             | Medium  | All-caps only if accessible and not overused |
| Numeric data                | Inter, tabular    | Medium  | Use tabular (monospaced) numerals—see below |
| Secondary/caption/auxiliary | Inter             | Regular | 0.85–0.95 of body size          |
| Button/Label/Chip text      | Inter             | Medium  | Letterspacing +0.5–1% for all-caps labels |

**Critical:** Enable and use `font-feature-settings: "tnum"` (tabular numbers) for all financial data, tables, and charts.

## Readability rules

- **Line length:**  
  - Body: 48–72 characters per line (“~10–12 words”), capped at 600–680px max on web, or 93–105% viewport width on mobile.
  - Never let tabular layouts or data tables push line lengths wide: prefer horizontal scroll or responsive stacking.
- **Contrast:**  
  - Follow **WCAG AA** minimums: 4.5:1 for body, 3:1 for large text/headers.
  - For dark mode, ensure text meets at least 4.5:1 against background.
- **Spacing:**  
  - **Line height:** 1.4–1.6 for body; headline line heights can be slightly tighter (1.2–1.3).
  - **Vertical rhythm:** Use a baseline grid (e.g., multiple of 4px or 8px) to align text and components.
  - **Hierarchy via spacing:** Use vertical spacing and weight, not just size, to show structure.
- **Number alignment:**  
  - Always use tabular figures for financial data—proportionally spaced numerals will cause misalignment and errors in quick scanning.

## Adoption guidance

**Phase 1: Foundation audit & implementation**
- Audit all current use of typography and text roles.
- Replace existing body and UI text with the selected primary font (Inter or equivalent).
- Set correct font-feature-settings for numbers.
- Apply scale and weight mapping to key templates and shared components.
- Fix contrast and line spacing according to rules above.

**Phase 2: Hierarchy & marketing**
- Roll the system out to headline, section titles, and call-to-action elements.
- If needed for visual differentiation on the marketing site, introduce the secondary font for big headlines only (optional—extra value for differentiated brands).

**Phase 3: Data & tabular contexts**
- Enforce tabular numerals for tables, dashboards, and all places where numbers are compared or summed.
- Tune column alignment and decimal placement in table components.

**Phase 4: Consistency & polish**
- Audit across web and mobile for weight, size, and spacing consistency.
- Add automated or design system checks for accessible contrast and line-length limits.
- Document fallback stacks and variable font support for engineering handoff.

**Phase 5: Refinement and feedback**
- Run regular usability checks focusing on number legibility for financial/pro users and headline scan for less-experienced users.
- Refine weights or style application as needed based on real-world feedback.

---

**Tradeoff:** This system prioritizes professional clarity and scanned trust over expressive branding in the dashboard and data context.  
You gain modern clarity, scan-friendly numerals, and variable-weight flexibility by standardizing on Inter (or similar), but you sacrifice a “fashion-driven” or highly decorative look in favor of universal trust and usability.  
If brand differentiation strongly demands it, adding a secondary headline font for the marketing layer is a safe, contained option without compromising the core system.

---
**Summary:**  
Choose a professional sans-family like Inter, use tabular numerals in all data contexts, maintain strict line length and contrast, and phase in hierarchy via weights and spacing across all surfaces. Focus on real-world scan habits, tune for modern trust, and keep roles, weights, and accessibility rules explicit for engineering handoff.