## Role model

### Semantic Color Roles and Meanings

**Core status colors:**
- `status.normal`: Indicates healthy/expected state or successful completion. Used for ready, healthy, or "ok" indicators.
- `status.warning`: Signals caution or attention needed; a state not yet critical but out of the normal range (e.g., elevated vital, incomplete step).
- `status.critical`: Represents urgent failures, errors, or critical alerts that require immediate attention.

**Palette for data charts:**
- `chart.categorical.1` through `chart.categorical.5` (expandable): Distinct, visually separable colors for dimension encoding in bar, line, or pie charts.

**System roles:**
- `surface.primary`: Main background.
- `surface.secondary`: Card or panel backgrounds.
- `border.default`: Divider lines, outlines.
- `text.primary`: Core UI and dashboard text.
- `text.muted`: Secondary/help/inactive text.
- `focus`: For focus ring/highlighting current element.
- `interactive.active`/`interactive.inactive`: Interactive states.

**State overlays:**
- `state.hover`: Background on hover.
- `state.selected`: Background for selected row/card.
- `state.disabled`: For elements that are turned off (with pattern/opacity, not color alone).

**Non-color indicators:**
- Iconography, shapes (e.g., warning triangles, error exclamation marks), text labels, or patterns reinforce status and chart information, ensuring that meaning does not rely on color alone.

---

## Token map

| Token (alias)                | Example light | Example dark      | Usage                                            |
|------------------------------|:-------------|:------------------|:-------------------------------------------------|
| `status.normal`              | #15803d      | #42d777           | Success, “ok”, healthy status badges              |
| `status.warning`             | #eab308      | #ffe066           | Warnings, elevated but not critical               |
| `status.critical`            | #dc2626      | #ff7b80           | Errors, critical alerts                          |
| `chart.categorical.1`        | #3b82f6      | #60a5fa           | Bar/line/pie color 1 (blue)                      |
| `chart.categorical.2`        | #f59e42      | #fabd60           | Color 2 (orange)                                 |
| `chart.categorical.3`        | #a21caf      | #f472b6           | Color 3 (purple/pink)                            |
| `chart.categorical.4`        | #10b981      | #6ee7b7           | Color 4 (teal/green)                             |
| `chart.categorical.5`        | #6366f1      | #818cf8           | Color 5 (indigo)                                 |
| `surface.primary`            | #f9fafb      | #1b1f23           | Backgrounds                                      |
| `surface.secondary`          | #ffffff      | #24292f           | Cards, panels, popovers                          |
| `border.default`             | #d1d5db      | #353b43           | Dividers, outlines                               |
| `text.primary`               | #1e293b      | #f9f9fa           | Main UI & dashboard text                         |
| `text.muted`                 | #64748b      | #94a3b8           | Secondary text                                   |
| `focus`                      | #2563eb      | #93c5fd           | Focus ring, hover states                         |
| `interactive.active`         | #2563eb      | #60a5fa           | Active buttons/links                             |
| `interactive.inactive`       | #64748b      | #475569           | Disabled buttons/links                           |
| `state.hover`                | #e0ebf9      | #283b4d           | Row/card hover                                   |
| `state.selected`             | #c7d2fe      | #3730a3           | Selected row/card background                     |
| `state.disabled`             | #f3f4f6      | #27272a           | Disabled/locked areas (use opacity/pattern too)  |

- Use these tokens (not raw hex codes) in code and design files.
- Each token maps to 2 color values: one for light, one for dark mode.
- All tokens chosen for at least 4.5:1 contrast (WCAG AA for normal text; 3:1 for large text), tested on their background color.

---

## Contrast and state rules

- **Contrast:**  
  - All key text (including status indicators) must maintain at least AA contrast (4.5:1) against their background.  
  - Tokens for `text.primary`, `text.muted`, and status colors are tested against both `surface.primary` and `surface.secondary`.
- **Color-only semantics are forbidden:**  
  - All status indicators (e.g., warning, critical) include:
    - A color change
    - An icon or shape (warning triangle, error glyph, etc.)
    - A text label (e.g., “Warning” or “Critical”)  
  - Chart series always include:
    - Both color and shape encodings (e.g., different marker shapes for scatter/line)
    - Pattern overlays or data labels for print/monochrome accessibility
  - Disabled states use lower opacity, reduced contrast, and pattern/label ("Disabled") as needed, never only a change in shade.
- **Dark mode rules:**  
  - All tokens have explicit dark-mode variants; never rely on automatic inversion.
  - Tokens reviewed for contrast in both modes before being published.

---

## Migration notes

### Plan for migrating from the current palette

1. **Tokenization audit:**  
   Map all current colors in use to their functional purpose (status, surface, chart, etc.). Flag any usages that do not fit (e.g., custom reds or greens used ad hoc).

2. **Side-by-side mapping:**  
   For each legacy color, assign the closest new semantic token. Prepare a lookup table for designers and engineers.

3. **Passive alias layer:**  
   In code, create an alias (legacy color name → new semantic token) so UI can transition safely (e.g., `old_success_green → status.normal`).  
   In Figma/design tokens, rename styles and components to use tokens rather than hardcoded colors.

4. **State overlay update:**  
   Replace old highlight/selection/hover colors with new state tokens, ensuring that all have dark-mode and contrast-checked variants.

5. **Status and chart logic:**  
   Refactor all status badges/alerts to use `status.normal`, `status.warning`, `status.critical` tokens PLUS accessible text and icons.  
   Update all charts to use the defined categorical palette and verify both shape and color make each data series discernible.

6. **Accessibility regression test:**  
   Run automated and manual audits for color contrast (using tools like Axe, Lighthouse, and Figma color contrast checker) across light and dark modes and all color tokens.

7. **Documentation & enforcement:**  
   Update the design system docs (and developer docs) to show intended token usage, color contrast rules, and fallback patterns for all status and data situations.  
   Communicate that raw hex codes or arbitrary color codes are no longer allowed — only tokens.

8. **Deprecate legacy tokens:**  
   After safe coverage, remove/deprecate legacy color aliases.  
   Block introduction of new raw colors by design review and linting.

---

This color system ensures clear status signaling, supports dark mode from the start, keeps data visualizations accessible and colorblind-friendly, prevents color-only semantics, and creates a maintainable migration path with AA contrast and future extensibility.