## System framing

This platform enables multiple customers (tenants) to manage team-based scheduling, with features for team workspaces, real-time activity feeds, approval-driven workflows, and integration via outbound webhooks. The system must ensure strict tenant isolation, robust data privacy, correct authority boundaries, and strong observability for troubleshooting and security.

**Core constraints:**
- Multi-tenancy (data and configuration isolation)
- Hierarchical user/team permissions (tenant admins, workspace leaders, members)
- High-concurrency event handling (activity feeds, approvals)
- Integration with customer systems (secure webhook delivery)
- Auditable changes with traceable causality
- Scaling for large tenants (many users/workspaces) and high activity rates

## Core model and authority boundaries

**Tenancy and workspace model:**
- Each tenant is a logical container, owning all subordinate resources (teams, users, schedules, feeds, approval rules, webhook configs).
- Users are scoped to tenants, with authority roles (Admin, Workspace Owner, Member); roles govern actions at both tenant and workspace levels.
- Workspaces are subdomains within a tenant, typically grouping users by team/project.

**Data boundaries:**
- **Row-level tenant isolation:** All business tables (schedules, events, approvals, feeds, webhook logs) are keyed by tenant_id. Do **not** allow cross-tenant resource access at any API, query, or job layer; enforce in DB queries, API contracts, and background jobs.
- **Workspace-level scoping:** Within a tenant, actions are limited by workspace membership and assigned role. Authority model: least-privilege; users see and act on only authorized workspaces.

**Approval and feed flows:**
- **Approval workflows**: Approval requests and actions are versioned, with signed audit trails (who, what, when, why). Approval states (pending/approved/denied) are immutable after finalization; denormalized feeds are regenerated on workflow state change.
- **Activity feeds**: Cursor-based (not offset), sorted by event_time (with tie-breaker on unique event_id). Feeds support pagination, time/window queries, and user/workspace scoping. Every event is tagged by type, actor, resource, and authority path.

**Outbound webhooks:**
- Webhook configs are owned and managed per tenant; only tenant admins can create, update, or delete webhook endpoints.
- Webhooks are dispatched by a background job worker that loads queued events, signs payloads with a tenant-unique secret, and retries on delivery failure (with exponential backoff and dead-letter queue for failures).
- All outbound calls are permission-checked and event-scoped; sensitive/regulated events require admin-level override for enablement.

## Data, consistency, and delivery design

**Data model and storage:**
- **RDBMS for transactional data**: PostgreSQL or similar, with row-level security enforced for tenant isolation, and explicit indexes on (tenant_id, workspace_id, event_time) for feeds and audits.
- **Activity/event store:** Append-only log for feeds and webhook queues. Each event is atomic, with foreign-key links to primary business entities.
- **Cache layer**: Redis (or similar) for short-lived event pages, webhook deduplication, approval status inflation.
- **File/object storage**: For upload artifacts, schedule PDFs, etc.; all objects are tenant-scoped and encrypted at rest.

**Consistency and delivery:**
- **Strong consistency** for all in-tenant edits and approvals; use DB transactions for all approval state changes to ensure feeds and state remain synchronized.
- **Eventual delivery** for webhooks, with at-least-once semantics; idempotency keys on outgoing webhook deliveries to prevent repeats.
- **Feed pagination**: Cursor-based approach guards against item insertions/deletions between reads; cursors embed (event_time, event_id).

**Concurrency and scale:**
- Support burst writes (heavy feed traffic, simultaneous approvals) by queuing event processing, decoupling write and dispatch layers.
- Partition activity feeds and webhook queues by tenant and (optionally) workspace for horizontal scaling.

**Data protection:**
- All access to resources strictly requires (tenant_id, workspace_id, user_id, role) checks at the API, service, and worker levels.
- Full audit trail of user actions, accessible by tenant admins.

## Observability and failure posture

**Tracing and auditing:**
- All requests (API, admin, webhook) include a unique trace_id (propagated end-to-end, including in webhook payloads and delivery logs).
- Structured audit logs for all write, approval, and webhook events: who, what, when, workspace, IP/source, and authority path for every change.

**Metrics and monitoring:**
- Emit metrics for:
  - Feed and event queue lengths, delivery latencies
  - Webhook success/failure rates, retries, and dead-letter entries
  - Approval workflow durations and error rates
  - Access denials and authentication/authorization failures

**Rate limiting and resilience:**
- Per-tenant API rate limiting to guard shared resources, prevent tenant abuse or runaway bots/webhooks.
- All critical APIs, job workers, and webhook dispatchers implement circuit breakers and exponential backoff on integration failures.
- Any unexpected error triggers a circuit-breaker state and notification to ops/tenant admin (when possible), and disables problematic webhook until acknowledged/reset.

**Data recoverability:**
- All transactional changes are logged with version history; deleted resources are soft-deleted for safety, with administrator recovery options.
- Dead-letter queues for irrecoverable webhook or approval errors with admin-facing diagnostics and replay capability.

---

**Tradeoffs:**  
This architecture prioritizes strict tenant data isolation and audit-friendly design, at the cost of extra complexity around row-level security and multi-actor workflows. Real-time feeds and webhook delivery are decoupled for resilience (eventual consistency for integrations), which means customer systems may see approved events with slight lag. At scale, partitioning by tenant/workspace permits horizontal expansion but may complicate cross-tenant analytics.

**If you skip explicit row-level security or authority boundary checks, you risk accidental data leakage between tenants—a category-killing failure in SaaS.** Maintaining strong observability and detailed auditing enables safer operation, but slightly increases complexity in tracing, metrics, and incident handling logic.