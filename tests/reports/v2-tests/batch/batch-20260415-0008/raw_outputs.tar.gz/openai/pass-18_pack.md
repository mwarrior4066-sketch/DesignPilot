## Architectural framing

**Endpoint:**  
`POST /api/v1/projects/{id}/members`  
Intended to add a user to a project. Returns a 200 with the updated member list.

**Context:**  
Architectural concerns include authorization boundaries, idempotency, error contract, and response design. Each is handled below by surfacing the governing system decisions before rationale.

---

## Boundary and state model

**Decision: Authorization checks must enforce project-level permissions, not just authentication.**  
_Reasoning:_ Checking only if the user is logged in (`isAuthenticated`) exposes the endpoint to any user, allowing arbitrary additions to any project. Authority to mutate membership must be scoped: _only project admins or owners_ should be permitted. This is a system surface dependency: “project admin required” because team composition is a privileged mutation. The lack of this boundary is a security and integrity failure.

**Decision: Idempotency is required for POSTs that may be retried or pipelined.**  
_Reasoning:_ Adding a member is commonly subject to duplicate requests (retries, accidental double-submits, user confusion). Without an idempotency key or an internal check ("is this user already a member?"), the server may add duplicate entries or trigger repeated side effects. RFC 9457 and robust API practices require idempotency for such endpoints: "idempotency-key header" or enforced logical idempotence (e.g., only create if not present). Failing this, clients cannot safely retry without risking state drift.

**Decision: The error response contract must use structured error objects, not plain strings.**  
_Reasoning:_ Returning a plain string (e.g., `"Unauthorized"`) gives clients no semantic fields for programmatic handling. Best practice is a consistent error envelope:  
```json
{ "error": { "type": "authorization_error", "message": "Project admin required" } }
```
This supports robust error handling, localization, front-end mapping, and observability. Using a string alone blocks these capabilities.

**Decision: 200 OK for a successful addition is appropriate, but error status codes should be aligned with semantics.**  
_Reasoning:_ On success, returning the updated member list with a 200 status is a valid choice ("returns the canonical list"). However, on failure, e.g., not being a project admin, the endpoint should return a 403 Forbidden (not a 401 Unauthorized unless the user is unauthenticated). Aligning error status with the source of failure supports both security and traceability.

---

## Rendering and mutation strategy

- **Authorization perimeter:** Only users with a project admin role may call this endpoint. "Authorization perimeter: project admin required."  
- **Idempotency contract:** Either require an `Idempotency-Key` header _or_ enforce membership uniqueness server-side so repeated identical requests are safe.  
- **Error contract:** Response bodies for errors should be structured objects with a standard type/code and message, enabling programmatic parsing.  
- **Success payload:** 200 OK with the updated member list is reasonable for the write pattern, but only if the write is validated against permission and idempotency constraints.

---

## Risks and safer path

- **If you skip project-level authorization, you open all projects to unauthorized modification (data and trust breach).**
- **Without idempotency, normal retries may cause multiple or repeated effects.**
- **Plain-string error responses block robust automation and degrade observability.**
- **Returning 401 instead of 403 blurs authentication and authorization failures, weakening both debugging and security posture.**

**Safer pattern:**  
- Enforce role-based access (`project admin required`).
- Require or implement idempotency logic.
- Use structured error responses.
- Align HTTP status with semantic failure reason.

---

## Summary of tradeoffs

- You **gain speed** with the current simple implementation, **but** at the cost of security, reliability, and integration robustness.
- You **sacrifice proper access control** to gain development simplicity.
- You **sacrifice retry and error handling** to gain minimalism.
- Tradeoff resolution: For production, always prioritize strict boundaries, idempotent behavior, and robust contracts in APIs that mutate shared state.