## Dashboard role

This is a SaaS analytics dashboard’s landing (first) view, meant to give a quick scan of top-level product or business health — focusing on DAU (Daily Active Users), MRR (Monthly Recurring Revenue), and churn rate, as well as segment-wise time trends. The layout consists of:
- A top KPI row with large numbers and trend arrows for DAU, MRR, and churn.
- A 30-day line chart showing four user segments (colors), legend placed below the fold.
- A left sidebar with 12 navigation items, ungrouped.

This screen’s job is to enable fast sense-making for someone who needs to spot trends, identify warnings, and decide where to dig deeper. Usual target users: product managers and founders.

## Key failures

**1. KPI row: No reference or target values**  
- Large numbers alone do not convey whether a KPI is good, bad, or atypical for the business. Without reference benchmarks (e.g., last month, target, industry quartile), trend arrows are ambiguous and can be misleading.

**2. Chart: Insufficient labeling and inaccessible legend**
- The 30-day line chart lacks a Y-axis label, making the metric/unit ambiguous, especially if DAU is not the only y-metric, or if the user segment lines represent different scale ranges.
- The color-segment legend is below the fold (requires scrolling), so users don’t know what each line or color represents at a glance. This increases scan cost and causes confusion, particularly for new users or when sharing screenshots.

**3. Navigation: Excessive, ungrouped sidebar items**
- The sidebar presents 12 ungrouped navigation items. This creates visual and cognitive overload, hinders discoverability, and slows routine navigation. Grouping by function or usage frequency is conventional because it helps users form a mental model and reduces scan/routing time.
- No clear separation between primary workflows and secondary/data/config options.

## Evidence and rationale

- **KPI role:** Research and dashboard heuristics indicate "large number" KPIs are useful only when judgment is possible at a glance ([source: Stephen Few, "Information Dashboard Design"]). Without context, users either ignore the numbers or wrongfully assume "up is good."
- **Line chart legibility:** Lack of Y-axis labels is a recurring usability failure in dashboards ([source: Edward Tufte, "The Visual Display of Quantitative Information"])—it undermines comprehension, consistent scaling, and reliable comparison.
- **Segment legend placement:** Usability studies show that when chart legends are out of direct view, most users misinterpret or entirely miss the mapping ([source: Nielsen Norman Group, dashboard design best practices]).
- **Sidebar overload:** Grouping reduces time to locate items, shifts recall to recognition, and is a basic navigation best practice ([source: "Don't Make Me Think," Krug; NN/g navigation guidelines]). 12 flat options exceed typical bounds (recommended: 5–7 per group).

## Recommended rebuild path

**Above-the-fold clarity and scan optimization:**
- Add explicit reference values to each KPI — e.g., show "last 30 days," "target," or percent vs goal directly under the main number.
- Use less ambiguous trend indicators (arrow with exact percent difference, hover tooltip with historical context).
- For the line chart:
  - Add a clear Y-axis label specifying units (e.g., "Active users per day" or "MRR (USD)").
  - Move the segment legend directly above or beside the chart, not below the fold. Alternatively, label endpoints inline for even faster reading.
  - Consider direct annotation for inflection points if one segment spikes/drops.
- Redesign the sidebar:
  - Cluster nav items into 2–3 labeled groups (e.g., "Core metrics," "User analysis," "Settings & billing").
  - Show primary actions or most-used areas first; nest or minimize lower-frequency options.
  - Use separators or headings to visually distinguish groups.

**Tradeoffs:**  
You preserve navigational simplicity and speed of initial ship by flattening all items and streamlining visuals, but you sacrifice scan efficiency, user trust/confidence, and quick anomaly detection. Adding grouping and clearer metrics introduces a small design/implementation cost but pays off in reduced user confusion, faster issue spotting, and higher dashboard trust.

**If you skip these changes,** users will form inaccurate judgments, waste time looking for context, and may repeatedly request clarifications from teammates or support — leading to frustration and loss of dashboard credibility.

---

**References for dashboard standards and scan cost:**
- Few, S. (2013). Information Dashboard Design.
- Tufte, E. (2001). The Visual Display of Quantitative Information.
- Nielsen Norman Group: https://www.nngroup.com/articles/dashboards/
- Krug, S. (2014). Don't Make Me Think.

---

**Next step:**  
Mock up a revised KPI row showing reference values under each metric, position the chart’s legend above the plot, and propose a sidebar grouping scheme based on your nav item categories.