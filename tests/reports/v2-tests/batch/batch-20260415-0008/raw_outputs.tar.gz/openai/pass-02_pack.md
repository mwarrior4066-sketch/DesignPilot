## Purpose and scope

A split button is a compound button that exposes a primary action (e.g., “Save”) and a trigger for additional, related secondary actions (e.g., “Save as draft,” “Save and close”). It allows users to quickly access the most common operation while still offering alternate flows. This component will be deployed in forms and other UIs where users need to commit or save work with nuanced options.

**In scope:**  
- Split button with two interactive areas: main action and dropdown trigger  
- Primary action always visible and accessible  
- Dropdown contains 2+ secondary actions  
- Full keyboard and screen reader support  
- Touch target compliance (WCAG AAA recommended min: 44x44px, minimum AA: 24x24px)  
- Loading, disabled states for both actions  
- Mobile-friendly tap and accessible focus/activation

## Anatomy

- **Container:** horizontal group, <button-group role="group" aria-label="Save options">  
- **Primary button:** triggers main action (e.g., ‘Save’)  
  - Visual: contains label (“Save”), styled as primary
  - Accessible: aria-label or visible label
  - Receives focus first in tab order
- **Dropdown trigger:**  
  - Icon only (chevron/down arrow), or chevron + visually hidden label  
  - Opens a menu of secondary actions
  - Accessible: aria-haspopup="menu", aria-controls references menu id
  - Receives focus after primary action (Tab key order)
- **Dropdown menu:**  
  - List of menu items (“Save as draft”, “Save and close”)  
  - aria-label (e.g., “More save options”)  
  - Focus managed via arrow keys, Esc closes menu
- **Separator (optional visual):** between primary and trigger buttons for clarity
- **States:**  
  - Default  
  - Disabled (for both primary and/or all)  
  - Loading (for primary and/or individual menu actions)

## State matrix

| State                   | Primary Button      | Dropdown Trigger       | Menu Item(s)                 | Behavior                                                         |
|-------------------------|--------------------|-----------------------|------------------------------|------------------------------------------------------------------|
| Default                 | active             | active                | visible on open              | Both actionable; dropdown controlled by trigger                  |
| Disabled (all)          | disabled           | disabled              | n/a                          | Both buttons not focusable or actionable                         |
| Disabled (primary only) | disabled           | active                | visible on open              | Only menu trigger and items enabled                              |
| Disabled (menu only)    | active             | active                | disabled as relevant         | Some/All menu items disabled                                     |
| Loading (primary)       | shows spinner, aria-busy | active          | visible on open              | Primary cannot be triggered again while loading                  |
| Loading (secondary)     | active             | spinner on item       | item shows spinner/aria-busy | The triggered menu item is busy; other items can remain enabled  |
| Focused                 | focus ring         | focus ring            | highlight on arrow, enter    |                                                              |
| Mobile touch            | 44x44px min        | 44x44px min           | 44x44px min row/item height  | touch targets per WCAG, all interactions accessible by tap       |

## Accessibility and implementation notes

- **Keyboard support:**  
  - Tab: moves sequentially through primary, then trigger  
  - Space/Enter: activates focused button  
  - Down Arrow when menu is open: moves to first item  
  - Esc when menu is open: closes the menu, returns focus to trigger  
  - Menu items navigable by up/down arrows, Enter/Space activates  
- **Screen reader support:**  
  - Use role="group" with an accessible name for button group  
  - Dropdown trigger: aria-haspopup="menu", aria-expanded with state  
  - Menu: role="menu", menu items role="menuitem"  
  - Loading: aria-busy or aria-disabled as appropriate  
  - Ensure visually hidden labels describe chevron/menu trigger purpose (“More save options”)
- **Disabled state:**  
  - Set disabled attribute (not just visual dimming) for both buttons as needed  
  - Disabled buttons are not focusable/tabbable  
  - Menu items can be individually disabled with aria-disabled
- **Loading state:**  
  - Show visible spinner or progress indicator in-button or menu item  
  - Hide underlying label for screen readers or update with loading announcement  
  - Prevent duplicate action on double-click/tap
- **Touch support:**  
  - Both primary and trigger are at least 44x44px (mobile)  
  - Avoid nested hover states—menu trigger must be tap-activated  
  - Do not depend on hover-based interactions alone
- **Focus management:**  
  - When menu opens, focus is placed in the first enabled menu item  
  - Closing the menu returns focus to the menu trigger
- **Responsiveness:**  
  - Ensure horizontal grouping does not overflow mobile screen; consider stacking options for very narrow viewports

---

**Tradeoff notes:** The split button offers task efficiency (single tap for main action, options for less common flows), but at the cost of slightly higher cognitive load and implementation complexity versus a simple button group or menu—because users must understand the split affordance and different triggers must be accessible across input types. Keyboard, disabled, and loading states must all be handled for both segments for full accessibility.

**If you skip keyboard or ARIA support, screen reader and keyboard-only users will be blocked from secondary options. If you do not provide touch-adequate target sizes, mobile and accessibility users are at risk of missed taps.**