## Failure semantics

**Findings:**

- **HTTP 200 for all responses, even errors**: Using HTTP 200 for both successful and failed requests weakens failure signaling. Clients cannot reliably distinguish between a successful export and one that failed due to a server, client, or validation error. This obscures semantic meaning and breaks REST expectations, making automated error handling difficult.
- **Error messages leak internal enum values**: Revealing internal enum values in error responses increases the attack surface. Attackers or untrusted clients may learn about underlying implementation details, allowing targeted probing or reverse-engineering of server logic.

**Recommendations:**

- Return appropriate HTTP status codes: use `4xx` for client or validation errors (e.g., 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found) and `5xx` for server or unexpected errors (e.g., 500 Internal Server Error, 503 Service Unavailable).
- Define a structured error response contract—e.g. per [RFC 9457 Problem Details for HTTP APIs](https://datatracker.ietf.org/doc/html/rfc9457) or the [RFC 7807 Problem Details](https://datatracker.ietf.org/doc/html/rfc7807)—with fields like error code, human-readable message, type, and trace ID.
- Remove or sanitize internal enum values from client-facing error messages. Map internal failures to public error categories, and include only necessary, stable detail.

**Tradeoff:** Retaining a strict error contract increases surface development work and requires up-front thought, but pays off in easier debugging, safer integrations, and better client resilience.

---

## Authorization and resource protection

**Findings:**

- No detail provided on authentication or authorization requirements.
- Lack of defined resource-level authorization risks unauthorized export access, data leakage, or privilege escalation.

**Recommendations:**

- Enforce strong authentication for all export endpoints: require session tokens, JWTs, or another secure credential.
- Add resource-level, object-level authorization checks: every export request should be validated so that only privileged roles or the resource owner can access or trigger the export.
- Explicitly deny by default if authorization checks are missing; avoid “fail open” behavior.

**Tradeoff:** Implementation may require integration with identity and permissions systems, but this is necessary to prevent data exfiltration or compliance violations.

---

## Idempotency and async lifecycle

**Findings:**

- **No idempotency key:** Repeated POST requests (due to client, network, or server retries) may trigger duplicate exports, excessive processing, stale PDFs, or race conditions.
- **No async support, blocking up to 3 minutes:** Synchronous blocking prevents clients from safely retrying requests and ties up resources. Requests can timeout or be dropped by infrastructure (reverse proxies/load balancers) before completion.

**Recommendations:**

- Implement [idempotency-key](https://stripe.com/docs/idempotency) support: allow clients to provide an Idempotency-Key header. For the same key and parameters, respond with the same result without duplicating processing.
- Migrate to an asynchronous model for long-running jobs:
  - Accept POST requests to `/exports` that enqueue export jobs and immediately return `202 Accepted` and a status URL (e.g., `/exports/{job_id}/status`).
  - Clients poll or subscribe for job completion and can download the final PDF after it is ready.
- Define clear state transitions: e.g., queued → running → completed or failed.

**Tradeoff:** Asynchronous jobs introduce client complexity, but they enable safe retries and robust job lifecycles that scale better and are more reliable for long-running exports.

---

## Resilience and observability

**Findings:**

- No strategy for resilience (e.g., handling retries, timeouts, overload, quota).
- No mention of traceability or structured error reporting.

**Recommendations:**

- Rate-limit or quota export requests per user/tenant to guard against abuse.
- Return retriable vs. terminal error codes. E.g., use `429 Too Many Requests` for quota exhaustion — this signals the client to back off.
- Include a trace identifier (trace_id or correlation_id) in all responses (success and error) to allow troubleshooting and incident response.
- Log all export failures, slow exports, and security-relevant events (e.g., unauthorized export access attempts) with meaningful context.
- Consider using circuit breakers or backoff with jitter if backend dependencies are unreliable.
- Communicate job state and failure reasons clearly in status/polling endpoints, without leaking sensitive detail.

**Tradeoff:** Enhanced observability and resilience features introduce operational overhead but are essential for real-world systems where failures, traffic spikes, and attacks are expected.

---

## Summary and safer path

- **Block synchronous, 3-minute blocking POST for long-running PDF exports.**
- **Adopt async job lifecycle:** on POST, queue export, return 202 Accepted with status URL.
- **Return correct HTTP response codes and sanitize client-visible errors.**
- **Require and enforce authentication and resource/role-based authorization.**
- **Support idempotency-key for safe retries and idempotent behavior.**
- **Add quotas, logging, and trace IDs to support resilience and observability.**

**You preserve** compatibility with RESTful and resilient API idioms and make integration and debugging safer for consumers.

**You sacrifice** slightly more client code (to poll for results), and initial setup is higher.  
**This tradeoff** is necessary if you want secure, robust, production-ready APIs for exports or other long-running, sensitive back-end actions.