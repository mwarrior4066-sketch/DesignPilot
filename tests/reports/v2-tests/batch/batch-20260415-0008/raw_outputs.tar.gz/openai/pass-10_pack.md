## Problem framing

The poster is meant to announce a design conference but uses a visual hierarchy that leads with a decorative title, positions the date in small gray text in the corner, features a full-bleed city skyline background, and places the conference logo prominently in the center over the photo. The issue is that the hierarchy puts the large decorative title first—even before the viewer can understand what the event is or its relevance. This can create confusion and reduce the communication effectiveness of the poster.

## Findings

- **Hierarchy failure**: The largest visual element is a decorative title, but without sufficient supporting context ("what," "who," "when," "where"), viewers may not immediately realize this is a design conference poster or what the title refers to.
- **Date legibility risk**: Placing the date in small gray text in a bottom corner risks it being overlooked, especially against a busy or bright photo background.
- **Background distraction**: A full-bleed city skyline photo, while visually engaging, can reduce text contrast and make other elements (date, logo) difficult to read or insufficiently prominent.
- **Logo placement**: Centering the white logo over the photo may help branding, but if the logo lacks supporting text, attendees may not recognize the type of event at a glance.
- **Overemphasis on style**: Leading with a decorative typeface and large title expresses visual identity but sacrifices immediate clarity and communication for first-time viewers.

## Recommendations

- **Move context above the title**: Add a clear, smaller pre-title or "eyebrow" line at the top or above the main title that states the event—e.g., "Design Conference 2024" or "Annual Design Summit." This provides instant context before the decorative title draws attention.
- **Increase date visibility**: Enlarge the date, increase its contrast (e.g., use solid white or black depending on background), and consider repositioning it closer to the main information cluster (not in a far bottom corner).
- **Support the logo with text**: If the logo is not highly recognizable, pair it with a subtitle or descriptor to clarify its relevance (e.g., "Presented by [Organization]").
- **Control background contrast**: Apply a subtle overlay to the city skyline photo (such as a transparent dark or light layer) to ensure all text is easily readable atop the image.
- **Balance decorative with functional type**: Use the decorative typeface as an accent for the title, but ensure supporting information (event type, date, location, call to action) uses clear, legible fonts with appropriate sizing and contrast.

## Tradeoffs

- **Preserving visual drama vs. communication speed**: Making the title large and decorative prioritizes visual impact and brand expression but comes at the cost of informational clarity for those unfamiliar with the event or organization.
- **Minimalism vs. functional redundancy**: Too little context can be mysterious but ineffective—adding a supporting event name or descriptor makes the poster clearer but may seem less "minimal."
- **Background engagement vs. readability**: A vibrant photo draws interest, but without overlays or careful composition, it can undermine text legibility.
- **Logo centrality vs. explicit labeling**: Relying on logo recognition increases prestige for known audiences, but can alienate or confuse new ones. Blending the logo with explicit event labeling strikes a better balance.

**In summary:**  
This poster design makes a strong first impression but at the cost of quick understanding. By reordering information and increasing the clarity of context, date, and event details, you can maintain visual appeal while ensuring the poster communicates instantly to all audiences—especially those seeing it for the first time.