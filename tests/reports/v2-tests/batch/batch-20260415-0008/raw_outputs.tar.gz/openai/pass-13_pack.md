## Known evidence

- **Stakeholder interviews**  
  The team has conducted 3 interviews with stakeholders (likely internal, managerial, or business-side decision makers), providing insight into organizational needs, business priorities, and strategic direction.  
  *Trust constraint: covers internal priorities, may not reflect end-user behaviors directly.*

- **Usability tests on current product**  
  Two sessions have been run, offering observed behavior and explicit pain points for the existing interface. This provides some qualitative data about problem areas, task friction, and navigation/interaction challenges.  
  *Constraint: Small sample size, potential lack of saturation, likely skewed toward more obvious surface issues.*

- **Analytics: 60% drop-off in project creation flow**  
  Quantitative evidence highlights a severe falloff at a critical funnel point (project creation), indicating a substantial problem with conversion or early engagement.  
  *Proxy evidence: What is happening (drop-off), not why.*

## Critical gaps

1. **Abandonment motivation (Why users abandon)**  
   *Open gap: No direct evidence explaining reasons for high drop-off; current analytics are descriptive, not diagnostic.*  
   This is the highest-priority research gap because it blocks targeted intervention: Without understanding abandonment drivers (e.g., confusion, insufficient onboarding, missing features, trust, perceived value, required information friction), prioritization of fixes is speculative.

2. **Competitive/contextual benchmarks (No competitive analysis)**  
   The team lacks data on how similar platforms structure onboarding, project creation, and power-user features, or what baseline performance/conversion rates are in the industry.  
   *Proof gap: No "what good looks like" reference, making it hard to pitch improvements or set clear KPIs.*

3. **Power user needs and behaviors (No power-user research)**  
   There is no evidence about advanced user segments (e.g., managers, project leads with complex workflows, super-users who drive volume or adoption internally).  
   *Open evidence gap: Risk of missing advanced feature needs, shortcut flows, or dissatisfaction among most valuable cohorts.*

4. **Drop-off stage granularity**  
   It's unclear at which specific steps in the project creation flow users are exiting. Without step-by-step analytics, diagnosis is too broad.  
   *Critical for targeting fixes and designing follow-up research.*

5. **Longitudinal experience or retention insight**  
   No evidence is cited about post-adoption retention, cohort churn, or repeated use behaviors for project creation. This limits the team's ability to judge whether project creation improvements drive sustainable engagement.

6. **Non-customer and lost-customer insights**  
   No research is provided on prospects who evaluate the product but do not adopt, or on users who churned after initial use—potentially hiding systemic blockers.

## Research plan

1. **Rapid, targeted abandonment study**  
   - Run intercept interviews, pop-up surveys, or rapid usability sessions with users who exited at various points in the project creation flow.  
   - Focus: motivations, blockers (cognitive, trust, information, UI, policy).  
   - Priority: Highest—enables conversion improvement, UX design, and back-end support planning.

2. **Detailed funnel and path analytics**  
   - Instrument step-level analytics during project creation to locate exact drop-off points.  
   - Combine with session replays for context (assuming privacy guidelines allow).

3. **Competitive and landscape review**  
   - Map 3–5 major competitors: flows, features, onboarding friction, drop-off rates (where available), unique value, and power-user pathways.  
   - Benchmark: project creation, onboarding, and key workflow customization.

4. **Power-user interviews / contextual inquiry**  
   - Identify and interview heavy users, team leads, or advanced admins.  
   - Explore: shortcuts, integration needs, pain points not visible at basic usage levels, workarounds, unmet advanced needs.

5. **Lost/churned customer interviews (if accessible)**  
   - Brief interviews or surveys asking why adoption failed or why they moved to another tool.

6. **Ongoing longitudinal follow-up**  
   - Plan for ongoing metrics after changes are deployed to check whether interventions reduce abandonment and improve overall engagement/retention.

## Decision impact

- **Risks without gap closure:**  
  - Redesigns may fix only surface usability or business-stakeholder-identified problems, missing silent abandonment drivers.
  - Missing competitive benchmarks may lead to re-inventing solutions or failing to differentiate.
  - Ignoring power users may cause churn among high-value cohorts, limiting advocacy and internal adoption.
  - No granularity in funnel data could result in misplaced effort (fixing the wrong part of the flow).
- **By closing these gaps:**  
  - The team can sequence fixes to known, high-impact problems.
  - Research evidence allows design and engineering to align on the causes and fixes, not just symptoms.
  - Quantitative and qualitative depth allows for targeting both new and advanced user needs, increasing adoption and retention, and improving defensibility of roadmap choices.

---

**Tradeoff:**  
Focusing on rapid abandonment research means some exploratory or long-term power-user research is delayed, but this is necessary because conversion and activation block downstream adoption.  
*To gain actionable clarity and reduce drop-off risk, the team must accept some up-front research investment and a potential short delay in shipping non-critical features.*