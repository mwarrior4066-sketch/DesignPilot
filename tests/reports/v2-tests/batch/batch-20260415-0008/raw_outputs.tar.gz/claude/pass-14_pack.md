## Architectural framing

The proposal as described carries four compounding risks: a rendering model that conflicts with the permission structure, a state shape that breaks under async load, custom interactive elements that fail accessibility requirements by default, and an optimistic update strategy that cannot be safely rolled back across recurring entries. Each of these is individually fixable; together they indicate the plan needs a structural revision before implementation begins, not a polish pass after.

---

## Boundary and state model

**Rendering model decision**

Role-based visibility means the server already knows what each user can see before the page loads. Sending a large client-rendered payload and then hiding elements in the browser wastes the permission check you already own, creates a flash of unauthorized content when JS is slow, and makes your permission logic live in two places at once. The safer model is server-rendered shells by role, with client hydration only at the boundaries that require interactivity.

Concretely: the dashboard frame, the visible table columns, and the filter set should be server-rendered based on the authenticated session. Client hydration takes over at the filter interaction layer and at the individual row action layer. This gives you a page that is correct before JS runs, because the server/client boundary sits at the permission check rather than below it.

**State shape**

Separate boolean flags for loading and error state are a known failure pattern. Two booleans produce four possible combinations, three of which are valid and one of which (`isLoading: true, isError: true`) is incoherent. As async complexity grows, the incoherent state becomes reachable and produces undefined UI behavior.

Replace the boolean pair with a discriminated union or a named status field:

```ts
type AsyncStatus = 'idle' | 'loading' | 'success' | 'error';
```

State lives in this single field, paired with a typed result or typed error payload. The UI renders exactly one branch per status. This pattern is not more code; it is the same code with the incoherence removed. If you are using React Query or SWR, both already implement this model and you should use their `status` field rather than managing it separately.

**Mutations owned by**

Recurring edit mutations must be owned by the server, not by optimistic client updates. Optimistic updates work well when the scope of the mutation is a single record, the rollback is trivial (restore one previous value), and the server is highly likely to confirm. Recurring schedule edits fail all three conditions: the scope is one-to-many (all future occurrences, or a subset, or just this one), the rollback requires knowing which records were affected, and partial failures are plausible if the recurrence rule hits a constraint. The UI must present the edit scope choice (this event / this and following / all), send that scope to the server, wait for confirmation, and then reflect the result. Optimistic rendering across a recurrence chain before the server confirms means your rollback surface is unbounded.

The safer path is: show a loading state at the row or modal level, commit server-confirmed state, use an undo action with a server-side reversible write if fast perceived recovery matters.

---

## Rendering and mutation strategy

**Table-heavy screens**

Server-driven tables should be rendered server-side and paginated at the server. Do not client-render a full dataset and filter it in memory. This is not a performance concern alone: for role-based tables, the client should never receive rows it is not permitted to see, even if those rows are hidden. The filter state should be URL-serialized so that filter changes produce a server request, not a client-side array filter.

If the table needs live updates (new appointments appearing without a full reload), use targeted revalidation or a narrow websocket channel scoped to the visible date range, not a full page refresh and not a client-side polling loop over the entire dataset.

**Server-driven filters**

If the available filter options depend on the user's role or the data they can see, those options must come from the server. Do not hardcode filter options in the client and then suppress the ones that do not apply. The server delivers the correct filter set for the authenticated user; the client renders whatever it receives. This means filter chips are stateless renderers, not stateful controllers.

**Client hydration boundaries**

The three surfaces that genuinely need client hydration are:

1. The filter interaction layer (selecting chips, clearing filters, submitting the filter state back to the server)
2. Row-level action menus (edit, cancel, reassign) that open modals
3. Any inline date or time picker within an edit flow

Everything else can stay server-rendered. This keeps the JS bundle proportional to the actual interactivity required.

---

## Risks and safer path

**Filter chips: custom div elements**

This is the clearest accessibility failure in the proposal. A `div` is not an interactive element. It has no role, no keyboard handler, no focus behavior, and no accessible name by default. A user navigating by keyboard cannot reach it. A screen reader user has no signal that it is actionable.

Use `button` elements for single-select chips (toggling a filter on or off). Use `checkbox` inputs with a visually styled label for multi-select chip groups where multiple filters can be active simultaneously. Use `role="group"` with a visible or visually-hidden label to name the chip group. These are not stylistic preferences; they are the minimum required for keyboard operability and WCAG 2.1 success criteria 1.3.1, 2.1.1, and 4.1.2.

The visual appearance of a chip is achieved with CSS. The semantic behavior is achieved by using the correct element. There is no design constraint that requires a `div` here, and the cost of fixing it after the component is in production is substantially higher than building it correctly now.

**Role-based visibility: where the check lives**

The permission check must live server-side. The client may conditionally render UI surfaces as a usability improvement (no point showing an "Assign to clinician" button to a patient), but that conditional rendering is not the access control. If a user calls the API directly and bypasses the UI, the server must reject the unauthorized action. This is an object-level authorization check at the API layer, not a CSS display toggle. Confirm that the API contract enforces `deny by default` for actions outside the caller's role before the frontend ships.

**Recurring edit failure modes**

The plan should define the terminal states for a recurring edit before writing the mutation logic: what does the UI show if the server accepts the edit for some occurrences and rejects it for others? What does it show if the network drops mid-request? These are not edge cases to handle later; they are the primary design surface for this feature, because they are the moments that damage user trust most.

**Migration sequence**

If this is an existing codebase moving toward the safer architecture rather than a greenfield build:

1. Fix the state shape first (boolean pair to discriminated union). This is the lowest-risk structural change and catches the most latent bugs immediately.
2. Move filter options to server-delivery. Change the client to render what it receives rather than maintaining a static list.
3. Replace custom div chips with button or checkbox elements. This is mechanical and testable in isolation.
4. Shift the rendering model. Move the dashboard shell and table columns to server-rendered output. Hydrate only the three surfaces named above.
5. Remove optimistic updates from recurring edits last. Replace with confirmed-state writes and a loading indicator at the modal level.

Do not reverse this order. Starting with the rendering model change before fixing state shape means you will debug two things simultaneously. Starting with removing optimistic updates before the state shape is clean means rollback logic will be built on top of the fragile boolean pattern you are replacing.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: server-rendered shells by role with client hydration at filter and row-action boundaries",
    "state_ownership: discriminated union status field replacing boolean pair; mutations owned by server",
    "boundary_placement: server/client boundary at permission check, not below it",
    "semantic_contract: button and checkbox elements for filter chips, not div elements",
    "cost_or_degraded_path: optimistic updates removed from recurring edits; replaced with confirmed-state writes and row-level loading indicator"
  ],
  "evidence_classes_cited": [
    "wcag_2.1_sc_1.3.1",
    "wcag_2.1_sc_2.1.1",
    "wcag_2.1_sc_4.1.2",
    "object_level_authorization",
    "deny_by_default",
    "server_client_boundary",
    "discriminated_union_state_model"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the existing API enforce object-level authorization server-side, or does access control currently live only in the UI?",
    "Is this a greenfield build or a migration from an existing client-rendered implementation?",
    "What are the defined terminal states for a partial-failure recurring edit (some occurrences accepted, some rejected)?"
  ],
  "turn": 1
}
[/SESSION_STATE]