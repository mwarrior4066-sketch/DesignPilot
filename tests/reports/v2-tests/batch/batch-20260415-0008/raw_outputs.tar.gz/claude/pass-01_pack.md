## Problem framing

The core failure here is not aesthetic — it is a pricing page that makes comparison harder than purchase. The hierarchy is inverted: the largest element (hero) does the least persuasive work, the most important element (pricing table) has an accessibility failure that actively breaks it for a meaningful portion of your B2B audience, and the feature comparison table is positioned where it can't support the decision it was built to support.

The CTA size problem is secondary to these structural failures. Fixing the button before fixing the table and flow order will give you a louder entry into a broken experience.

---

## Findings

**1. Hero does not earn its size**

"Everything your team needs" is a brand statement, not a decision frame. B2B buyers arrive at a pricing page having already cleared the "what is this" question. What they need at the top of this page is: how do these tiers differ, what does the middle tier actually cost at my team size, and is there a reason to go Enterprise.

The hero headline answers none of those questions. The background image adds visual weight without adding decision value. The hero is large because it was designed with a marketing-site pattern applied to a conversion page — these are different jobs.

The CTA at hero scale is small *because the hero itself has no specific job*. A well-sized CTA on a vague headline doesn't fix the conversion problem; it just makes the vagueness louder.

**2. Pricing table color-coding is inaccessible and does the wrong job**

Using color alone to highlight the Pro tier is a WCAG 2.1 SC 1.4.1 (Use of Color) failure — information conveyed by color must have a non-color redundant cue. If the Pro tier distinction disappears without color perception, the table's hierarchy collapses for colorblind users (roughly 8% of men, ~0.5% of women in most markets) and in high-contrast or forced-colors environments.

This is not a polish issue. It is a barrier that prevents a segment of your B2B audience from reading your most important comparison correctly.

Beyond the accessibility failure, color-coding alone as a "recommended" signal is a weak persuasion mechanism. It signals *to look at Pro* but does not tell the buyer *why Pro* — the color just says "this one."

**3. Feature comparison table is in the wrong position**

A feature comparison table belongs *adjacent to* or *directly below* the pricing cards, not after them. Its job is to justify the price delta. When it sits further down the page, users who are already skeptical of the Pro vs. Starter price gap have already formed a cost objection before they can resolve it with feature information.

The current order — pricing cards → testimonials → feature table — means the social proof arrives before the feature justification, which is backwards for B2B buyers who need logical justification before social validation is credible.

**4. Enterprise CTA is underspecified**

"Custom" pricing without an action anchor creates a dead end for Enterprise consideration. Enterprise buyers need to know what "custom" means enough to decide whether to start a conversation — they will not fill out a form without a reason. The pricing card needs a short signal (team size threshold, named features, SLA) and a specific CTA ("Talk to sales" or "Book a demo") rather than a generic contact.

**5. Three-column layout creates false parity**

Presenting three tiers at equal visual weight implies that the choice between them is equally uncertain. For most B2B SaaS products, the real conversion goal is Starter-to-Pro or Pro-to-Enterprise, not all three simultaneously. Equal-weight columns diffuse the hierarchy of that conversion goal.

---

## Recommendations

**Fix the accessibility failure first.** Add a non-color cue to the Pro tier: a badge or label ("Most popular" or "Recommended"), a border weight difference, a structural distinction in the card header. The color accent can remain but it cannot be the only differentiator. This satisfies WCAG 2.1 SC 1.4.1 and SC 1.4.3 if the highlighted tier has text over the background color. Verify contrast ratios — the combination most likely to fail is light text on a saturated mid-tone brand color. Target a minimum 4.5:1 for normal-weight text, 3:1 for large text. Without fixing this, the page has a legal and usability exposure, not just a visual one.

**Move the feature comparison table directly below the pricing cards.** The testimonials strip should follow the comparison table, not precede it. The decision sequence for a B2B buyer is: understand the tiers, compare features, validate with peer evidence. Reversing steps two and three breaks the rational decision path. This is a reorder, not a rebuild — it costs close to nothing structurally.

**Reframe the hero as a decision entry point.** Replace the brand headline with a concrete scope statement: who this is for, what the tiers cover, whether there is a trial or free tier. Shrink the hero height. Reduce or remove the background image if it does not carry specific meaning (a background image on a pricing page is almost always visual filler). The CTA in the hero should either disappear or become a scroll anchor ("See plans"), because the primary CTA belongs on the pricing card, not above the pricing information.

**Resize the Pro card to create intentional hierarchy.** The Pro card should be visually dominant — slightly taller, with a bolder header treatment, the non-color badge applied here — not just color-accented. This makes the recommended tier legible to users who scan before reading, which is most users.

**Give Enterprise a reason to click.** Add one or two qualifying signals to the Enterprise card — team size, a named feature (SSO, dedicated support, custom SLA), an approximate deployment type. Replace any generic CTA with a specific one. "Custom" as the only Enterprise descriptor is a dead end.

---

## Tradeoffs

**Moving the comparison table above testimonials** means testimonials appear later in the scroll. You sacrifice above-the-fold social proof in exchange for a decision sequence that matches how B2B buyers actually evaluate price tiers. The testimonials still get seen; they just earn their position after the rational work is done rather than before it.

**Shrinking the hero** means less visual drama on first load. You sacrifice the impression of scale in exchange for getting buyers to the actual decision surface faster. On a pricing page, time-to-price-visibility is a conversion variable — the hero is delay, not persuasion.

**Adding a non-color badge to Pro** means Pro gets explicit preferential treatment rather than a subtle color nudge. You sacrifice the "let the buyer decide" neutrality in exchange for a clear recommended path, which is what most B2B pricing pages actually need. If your product genuinely has a significant Starter audience, this should be tested; if Pro is the conversion goal, the explicit signal is the right call.

**Fixing the color contrast** will require adjusting the accent color or the text color on Pro. You may need to desaturate or darken the highlight background, which changes its visual energy. You sacrifice some brand vibrancy in exchange for legibility across all users and all display conditions.

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "hierarchy_winner: feature comparison table should precede testimonials",
    "intervention_order: accessibility fix first, then structure reorder, then hero reduction, then Enterprise CTA",
    "structural_failure: hero applying marketing-site pattern to conversion page job",
    "tradeoff_resolution: explicit Pro badge over color-only highlight to satisfy WCAG 1.4.1",
    "visual_confidence_boundary: color contrast ratios stated as likely failures based on described pattern, not measured from artifact"
  ],
  "evidence_classes_cited": [
    "wcag_2_1_sc_1_4_1",
    "wcag_2_1_sc_1_4_3",
    "contrast_threshold_4_5_1_normal_text",
    "contrast_threshold_3_1_large_text"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is Pro the primary conversion goal, or is Starter-to-trial the intended entry path?",
    "Is there a free tier or trial that should appear in the hero or pricing cards?",
    "What is the actual accent color used for Pro highlighting — contrast cannot be confirmed without the hex values?"
  ],
  "turn": 1
}
[/SESSION_STATE]