## Problem framing

The poster has a hierarchy failure before it has an aesthetic problem. The decorative title fires first, but a title earns attention only after the viewer understands what they're looking at. Right now the sequence is: *name → nothing → date buried in a corner → logo that should be doing organizational work*. The audience has to do interpretive work before they've been given a reason to care.

The full-bleed skyline is a generic credibility signal, not a communication move. And the white logo centered on a photo background is fighting for legibility it hasn't earned through placement.

---

## Findings

**Hierarchy failure — context arrives too late.** The title dominates before the viewer knows this is a design conference, who runs it, or whether the event is relevant to them. The organizational identity (logo) and the event type should land first or at minimum simultaneously with the title.

**Date is non-discoverable.** Small gray text in a corner on a photo background is a contrast and hierarchy failure together. The date is functionally the most time-critical piece of information on the poster, and it's treated as a footnote.

**The decorative typeface is doing the wrong job.** Decorative type signals character and identity — but only once the viewer already trusts the event. Used as the first element, it reads as style noise before the event has earned enough context to justify personality.

**The logo is stranded.** A white logo centered on a variable photo background has unpredictable contrast. On a busy skyline photo, portions of the logo will be unreadable depending on print or screen conditions. Centering it doesn't anchor it — it floats it.

**The skyline photo is a missed communication opportunity.** City skylines are the default background for every conference poster that didn't commit to a stronger visual idea. It says "professional event somewhere" but not "this specific design conference has a point of view."

---

## Recommendations

**Reorder the hierarchy: organization → event type → title → date.** The logo or organization name should orient the viewer first, because it answers "who is putting this on." Event type ("Design Conference" as a clear descriptor, not just an assumed title) confirms relevance. The title can then land with personality once the context holds it.

**Treat the date as primary information, not a footnote.** Move it out of the corner. Give it weight comparable to the subtitle or event descriptor. Viewers scanning a poster in a hallway need the date to make a fast decision — burying it at low contrast means most people will leave without it.

**Reserve the decorative typeface for the title only, and ground it with a weight contrast.** Pair it with a clean, high-legibility sans-serif for all supporting information. The decorative face earns its place once it's sitting on top of a clear information scaffold, not leading without one.

**Give the logo a legibility anchor.** Either place it in a reserved zone with a dark or light background field behind it, or move it to a corner position where it functions as a sender mark rather than a visual centerpiece. The center of a photo background is the hardest place to guarantee contrast across print conditions.

**Reconsider the photo or add a decisive treatment.** If the skyline stays, it needs a strong tonal treatment — a heavy dark overlay, a duotone, a deliberate crop that creates a clear contrast zone for type — so the photo serves the layout rather than competing with it. Without that treatment, the photo adds visual noise and removes contrast budget that the type needs.

---

## Tradeoffs

Reordering the hierarchy means the title gets less immediate visual dominance. You sacrifice the dramatic-first impression in order to gain a legible, scannable communication sequence. For a design conference poster, which is also an argument about design quality, legibility and hierarchy coherence are a stronger credibility signal than decorative impact.

Anchoring the logo gives up centerpiece placement, but the logo's job is sender identification, not visual hero. A logo that works reliably in a constrained zone does more communication work than a centered logo that sometimes disappears into a bright section of the photo.

A treated or replaced background means less atmospheric realism, at the cost of significantly better contrast headroom. The poster will read better from farther away and reproduce more reliably in both print and digital contexts.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "communication_goal: orient viewer before delivering personality",
    "hierarchy_failure: title precedes organizational context and event type",
    "rebuild_move: reorder to organization → event type → title → date",
    "distance_tradeoff: decorative impact sacrificed for legible scan sequence"
  ],
  "evidence_classes_cited": ["contrast_threshold", "hierarchy_sequence", "legibility_constraint", "print_reproduction_risk"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is this poster primarily for print, digital, or both? That affects contrast and type size decisions.",
    "Does the conference have a defined visual identity beyond the logo, or is this a blank-slate design?"
  ],
  "turn": 1
}
[/SESSION_STATE]