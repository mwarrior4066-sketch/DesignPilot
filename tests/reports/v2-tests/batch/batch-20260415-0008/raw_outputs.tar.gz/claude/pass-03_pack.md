## Dashboard role

This is a **monitoring and diagnostic dashboard** — its job is to let a user detect problems fast and understand why they are happening. The current design structure fails at both. Numbers appear without anchors, trends appear without comparators, and navigation appears without structure. The user cannot act on what they see because they cannot interpret what they see.

---

## Key failures

### KPI row: numbers without meaning

Large DAU, MRR, and churn figures with trend arrows provide signal only if the user already knows what "good" looks like. Without a reference value — a target, a prior period comparison, or a threshold — the arrow direction is the entire interpretation surface. An upward churn arrow is ambiguous: is churn worsening relative to last month, or recovering toward a seasonal norm? The number alone cannot answer that.

The trend arrow is doing work it cannot do alone. It indicates direction but not magnitude relative to expectation. A user who needs to decide whether to escalate a problem has no anchor to make that call.

### Line chart: four lines with no decoding surface

Four colored segment lines run across 30 days, but the legend that names them sits below the fold. This breaks the decode loop: the user sees the chart before they know what they are reading. If two lines cross or diverge, that event is visible but uninterpretable until the user scrolls, finds the legend, and maps color back to segment. Under cognitive load — which is when dashboards actually get used — this creates meaningful friction.

The missing Y-axis label compounds this. The chart axis could be showing absolute counts, percentages, indexed values, or something else. Without a label, the user is guessing the unit of the thing they are trying to track. That is not a minor aesthetic gap; it invalidates quantitative comparison between segments.

### Left sidebar: 12 unstructured nav items

Twelve navigation items presented as a flat list makes every item equally weighted. There is no grouping that would let the user build a mental model of what this product does or how to navigate it purposefully. Scanning cost for the correct destination increases linearly with list length when there is no structure. The cognitive load of orientation competes with the cognitive load of the dashboard itself.

---

## Evidence and rationale

**KPI anchoring:** A metric with no reference value requires the user to hold prior context in working memory. Research on monitoring interfaces — and the design patterns used in Amplitude, Mixpanel, and similar products — consistently anchors KPIs against a target, a period-over-period delta as a percentage, or a threshold range. This is not aesthetic convention; it directly reduces the time to correctly interpret state.

**Legend placement:** The chart decode surface must be co-present with the chart. Placing it below the fold forces a task interruption: scroll down, decode, scroll back, re-examine. When the chart is the primary diagnostic surface, that interruption degrades the monitoring loop. The legend should either live inside the chart as a direct label on each line, or sit immediately adjacent to the chart frame — not subordinated to page scroll.

**Y-axis label omission:** Omitting the axis label is a presentation shortcut that transfers cognitive cost to the reader. Even when the metric name seems obvious from context, explicit labeling is required for correct interpretation — especially when four different segments may be measured on different scales or when the same dashboard serves multiple user roles.

**Flat navigation:** Jakob Nielsen's principle of recognition over recall applies directly here. A flat 12-item list forces the user to read every item to locate the right one. Grouped navigation with 3 to 5 labeled categories reduces scan cost to a two-step process: identify the right group, then identify the right item within it. This is also the pattern that scales as the product adds features, rather than forcing a sidebar redesign at item 15.

---

## Recommended rebuild path

### 1. Anchor every KPI metric

Add a secondary value below or beside each primary number. Use one of:

- **Target vs. actual**: shows whether current performance meets expectations
- **Period-over-period delta**: "vs. last 30 days" with a percentage and direction
- **Threshold band**: a light background range (green zone, warning zone) behind the number

The trend arrow should stay, but it should accompany a percentage change, not replace it. The arrow communicates direction; the delta communicates magnitude. Both are required to make the metric interpretable without external context.

You sacrifice display simplicity to gain interpretability. A cleaner KPI row with no secondary values looks more composed but leaves the user without the anchor they need to take action.

### 2. Move the legend and label the Y-axis

Move the legend into the chart using direct line labels at the right terminus of each line, or float it inside the chart frame anchored to the top-right. Both options keep the decode surface co-present with the chart without requiring scroll.

Label the Y-axis with the metric name and unit. One line: "Active users" or "MRR (USD)" or "Churn rate (%)". If the four segments are measured on the same scale, one label is sufficient. If they are not — if some lines show counts and others show rates — that needs to be resolved at the data model level before it can be fixed at the display level, because overlaying non-comparable scales on one chart produces false visual comparisons.

### 3. Group the sidebar navigation

Organize the 12 items into 3 to 5 named groups based on task type. A common grouping structure for SaaS analytics:

- **Overview** (dashboard, summary)
- **Acquisition** (traffic, conversion, campaigns)
- **Engagement** (DAU, retention, feature usage)
- **Revenue** (MRR, churn, billing)
- **Settings / Admin**

Exact grouping depends on what the 12 items actually are, but the principle holds: group by user task or product domain, not by technical category or implementation order. Add group labels as non-interactive section headers. This reduces scan cost and makes the navigation scalable.

You sacrifice the appearance of a flat, uniform nav structure to gain task-oriented organization. The cost is a slightly taller sidebar; the gain is a navigable mental model.

### 4. Consider adding a reference line to the chart

A single horizontal reference line at a meaningful threshold — a target retention rate, a churn ceiling, a baseline MRR growth band — transforms the 30-day chart from a trend viewer into a diagnostic tool. Without it, the user can see that a line moved; they cannot see whether the move is significant. A reference line gives the motion meaning.

This is a low-cost change at the display layer, but it requires the product to have defined what "good" looks like for each segment. If that definition does not exist, the display fix is blocked by a product decision upstream.

---

## Tradeoffs

| Change | What you gain | What you sacrifice |
|---|---|---|
| KPI secondary values | Interpretability without external context | Visual simplicity of the KPI row |
| Direct line labels | No scroll interrupt, immediate decode | Chart clarity if lines are dense or converging |
| Y-axis label | Unit fidelity, cross-segment comparability | One line of vertical space |
| Grouped navigation | Scan efficiency, scalable IA | Uniform flat list appearance |
| Chart reference line | Motion becomes diagnostic | Requires upstream product definition of "good" |

The highest-priority fix is the KPI anchoring, because it affects the first decision the user makes on page load. The legend placement is the highest-friction interaction failure because it breaks the decode loop during active monitoring. The sidebar grouping is the highest-leverage structural fix because it scales forward. Address them in that order.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_role: monitoring and diagnostic",
    "kpi_failure: no reference values or targets — trend arrows uninterpretable alone",
    "chart_failure: legend below fold breaks decode loop; missing Y-axis label invalidates unit comparison",
    "density_or_navigation_decision: flat 12-item sidebar requires grouping into 3–5 task-oriented categories"
  ],
  "evidence_classes_cited": [
    "threshold_reference: WCAG and monitoring UI conventions for KPI anchoring",
    "benchmark_comparison: Amplitude, Mixpanel KPI pattern reference",
    "constraint: legend must be co-present with chart to avoid scroll interruption",
    "rule: Nielsen recognition-over-recall applied to flat navigation"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are the four chart segments measured on the same scale or different scales? If different, chart overlay is producing false visual comparison.",
    "Has the product defined target thresholds for each KPI? Reference line fix is blocked without upstream product definition.",
    "What are the 12 sidebar nav items? Grouping recommendation depends on actual item taxonomy."
  ],
  "turn": 1
}
[/SESSION_STATE]