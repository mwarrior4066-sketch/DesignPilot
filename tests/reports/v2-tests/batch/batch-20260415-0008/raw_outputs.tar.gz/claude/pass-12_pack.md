## Reading context

Four distinct reading contexts govern this system, and they impose different constraints.

**Marketing site** is a persuasion surface. Long-form reading is minimal; the work is building trust at a glance, communicating a category position, and moving visitors toward a conversion action. Type must read well at large display sizes and carry emotional weight. Paragraph blocks are short.

**Dashboard** is a task surface. Users scan rather than read. The hierarchy is KPI figures at the top, supporting metrics mid-range, and auxiliary labels and metadata at small sizes. Tabular financial data is the hardest constraint here: figures must align on decimal points, distinguish zero from O, and remain legible under cognitive load. Proportional spacing will break column alignment, so tabular figures are non-negotiable.

**Mobile** imposes the tightest physical constraints. Minimum body size is 16px to avoid browser zoom triggers and preserve readability on lower-DPI screens. Line length must stay under 70 characters to prevent eye-travel fatigue on narrow viewports. Touch targets are separate from text sizing, but dense type stacks cause mis-tap errors, so leading and vertical rhythm matter as much as size.

**Cross-context constraints** shared by all three surfaces: the typeface must have a wide enough weight range to build hierarchy without introducing a third family, it must perform well at small sizes (11-12px labels are unavoidable in dashboards), and it must feel contemporary without feeling playful. Fintech users are context-sensitive to visual cues around trustworthiness, so geometric novelty for its own sake carries a trust cost.

---

## Scale and role map

Two-family system: one variable sans for all UI, text, and display roles; one monospace for all financial figures and code.

**Primary: Inter (variable)**

Inter is the right choice here because it was designed for screen legibility at small sizes, carries genuine tabular figures (`tnum` OpenType feature) in its Latin character set, has a wide weight axis (100-900), has tight letter spacing that works well at display and UI sizes, and reads as serious rather than decorative. It is not a compromise choice. It was built for exactly this density class.

| Role | Size | Weight | Notes |
|---|---|---|---|
| Display / hero headline | 48-64px | 700-800 | Marketing only; use tracked-tight `ls: -0.02em` |
| Section headline (h2) | 32-40px | 600-700 | All three surfaces |
| Subsection (h3) | 22-28px | 600 | Dashboard section headers, article headers |
| Body text | 16-18px | 400 | Marketing long-form; 16px minimum mobile |
| UI label / supporting text | 14px | 400-500 | Dashboard labels, form labels |
| Small / metadata / captions | 12px | 400-500 | Column headers, footnotes, timestamps |
| Button | 14-16px | 500-600 | Sentence case; do not use all-caps at this size |

**Figures: iA Writer Mono or Fira Code**

For financial figures, dedicated monospace is worth the extra load. Every character is full-width and optically consistent. Choose based on brand posture:

- **iA Writer Mono** if the brand is editorial and considered
- **Fira Code** if the product is developer-adjacent or the team prefers OSS clarity

Either is a better choice than relying on Inter's `tnum` feature alone, because `tnum` does not guarantee consistent character widths across all platforms and browser rendering engines. A true monospace eliminates the alignment risk entirely for column-critical contexts.

| Role | Size | Weight | Notes |
|---|---|---|---|
| Primary KPI figure | 28-40px | 500-600 | Use monospace family; `font-variant-numeric: tabular-nums lining-nums` |
| Table cell figure | 13-14px | 400 | Right-aligned; monospace family |
| Inline figure in prose | match body | 400 | Monospace family; optical size slightly smaller |
| Status badge / change indicator | 12px | 500 | Monospace; color-coded by semantic role, not decoration |

---

## Readability rules

**Line length.** Marketing body text: 60-75 characters (roughly 600-700px at 16px body). Dashboard: line length is rarely the problem because UI labels don't wrap, but any paragraph content inside cards or tooltips should be capped at 60 characters. Mobile: 45-65 characters; use `max-width: 65ch` as a CSS constraint rather than a fixed pixel value.

**Contrast.** All body text and labels must clear WCAG AA (4.5:1 for text under 18px, 3:1 for large text over 18px bold). Dashboard metadata and small labels at 12px must meet AA or be considered non-text (decorative only, which creates accessibility debt). For financial figures carrying semantic meaning, 4.5:1 is the floor regardless of size. Do not use mid-gray on white for dashboard labels as a default visual treatment; the difference between placeholder state and active data is often carried entirely by contrast and weight, and collapsing them creates a usability failure.

**Leading.** Body: `line-height: 1.5-1.6`. UI labels and dense dashboard rows: `line-height: 1.3-1.4` to preserve vertical density without collapsing touch targets. Display headlines: `line-height: 1.1-1.2`. Monospace figures in tables: `line-height: 1.4` minimum; tighter than this causes row-scanning errors on tall tables.

**Spacing rhythm.** Use an 8px base unit or 4px sub-unit. This is not typography-specific advice, but type decisions that ignore it create visual inconsistency: a 17px body with 1.5 leading gives ~25.5px line height, which does not fit an 8px grid. Round to 24px leading and use 16px body, or accept the fractional value and compensate with margin increments. Commit to one approach in the design token spec.

**Weight contrast.** The minimum perceptible weight step for hierarchy is 200 units on the variable axis. 400 to 500 is not a hierarchy marker; it is a hover-state or emphasis marker. Use 400 to 600 or 400 to 700 to signal a genuine level change. Do not use 300 weight for body text below 18px on screens that are not high-DPI, because hinting and rendering quality collapse.

**Letter spacing.** Do not add positive letter spacing to lowercase body or UI text. It reduces readability at that context. Positive tracking is appropriate only on all-caps labels (if you use them) at small sizes, where it aids differentiation. Negative tracking at -0.01 to -0.02em can improve display headlines above 40px.

---

## Adoption guidance

Phase the system to reduce disruption and build evidence before committing to irreversible choices.

**Phase 1 — Foundation (first 2 to 4 weeks).** Load Inter variable via Google Fonts or self-hosted (self-hosted is faster and eliminates third-party data sharing, which matters for fintech trust and privacy). Define tokens for size, weight, leading, and letter spacing in CSS custom properties or your design token system. Establish the monospace family and load it. Do not deploy to all surfaces yet. Apply to the design system documentation site or component library first. Validate rendering at 12px and 40px. Check that tabular figures align correctly in a test table with 5-digit currency values.

**Phase 2 — Dashboard first (weeks 4 to 8).** Apply the type system to the dashboard before the marketing site. The dashboard has the hardest constraints (dense data, small sizes, tabular alignment), so resolving them first prevents discovering a fundamental mismatch after the marketing site is already live. Audit every numeric column for alignment. Test with real financial data values including negatives, long decimal strings, and zero. Run contrast checks on your actual background colors, not the spec colors.

**Phase 3 — Marketing site (weeks 6 to 12, can overlap Phase 2).** Apply display scale and body styles. The marketing site is more forgiving because text blocks are short and sizes are large, but it is also the first surface new users see. Validate headline rendering on mobile at 320px wide. Check that display weight (700-800) does not look aggressive against your brand palette.

**Phase 4 — Mobile (concurrent with Phase 3, extended QA).** Mobile is not a separate type system; it is the same system with narrower scale stops. Reduce display sizes to 32-40px, confirm body is 16px minimum, confirm line length stays within `65ch`, and test on a range of actual devices including lower-DPI Android. Inter renders well on Android but check your chosen monospace family on Android WebKit, as monospace rendering inconsistency is more common there than on iOS.

**Phase 5 — Token governance.** Once the system is stable across surfaces, lock the token names and values, document the decisions in your design system, and remove any locally overridden font-size or font-weight values that were not migrated. The goal is that future component work starts from tokens, not from per-component font decisions.

The tradeoff you are accepting with a two-family system rather than a single-family system is a small increase in loading overhead and a slightly more complex token schema. What you gain is column-alignment reliability that a sans-serif with OpenType numeric features alone cannot guarantee across all browsers and operating systems.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: marketing site persuasion surface, dashboard task surface with tabular data, mobile with 16px floor and 65ch line-length cap",
    "scale_decision: Inter variable (100-900) as primary; iA Writer Mono or Fira Code for financial figures",
    "pairing_rationale: two-family system — Inter for all UI/display/text roles, dedicated monospace for all numeric columns to guarantee tabular alignment across browsers",
    "adoption_sequence: Phase 1 foundation tokens, Phase 2 dashboard first, Phase 3 marketing site, Phase 4 mobile QA, Phase 5 token governance lock"
  ],
  "evidence_classes_cited": [
    "wcag_contrast_threshold: 4.5:1 body and financial figures, 3:1 large text",
    "line_length_threshold: 60-75ch marketing, 65ch mobile cap, 60ch card/tooltip content",
    "leading_ratio: 1.5-1.6 body, 1.3-1.4 UI labels, 1.1-1.2 display, 1.4 min monospace tables",
    "weight_contrast_rule: minimum 200-unit axis step for hierarchy",
    "font_variant_numeric: tabular-nums lining-nums on all financial figures",
    "rendering_constraint: tnum OpenType unreliable cross-browser for column alignment; true monospace eliminates risk"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is Inter already in the product stack, or does the team need to evaluate loading strategy (self-hosted vs CDN)?",
    "Does the mobile app use React Native or native rendering — if so, Inter and monospace loading behavior differs from web?",
    "Is there an existing brand typeface that must be reconciled or sunset?"
  ],
  "turn": 1
}
[/SESSION_STATE]