## Backend Architecture Spec

### System framing

This is a multi-tenant SaaS platform where tenant isolation, event ordering, and outbound reliability are not incidental concerns — they are the load-bearing structure. Four subsystems interact: workspace-scoped data access, cursor-paginated activity feeds, state-machine-driven approval workflows, and outbound webhook delivery to customer-controlled endpoints. Each has distinct consistency requirements, and they compound when a single user action must update workspace state, append to the feed, advance a workflow, and trigger a webhook in sequence.

The failure modes are asymmetric. Missed webhook delivery breaks customer integrations silently. Out-of-order feed events create incorrect audit history. Partial approval state transitions can deadlock a workflow. Over-fetching across tenant boundaries is a BOLA vulnerability. Any architecture that treats these as afterthoughts will require a rewrite under load.

The governing tension is: **strong per-tenant isolation at the cost of cross-tenant query efficiency**. This platform sacrifices global aggregate queries and simple sharding schemes in exchange for predictable tenant boundaries, auditable event history, and safe external integration.

---

### Core model and authority boundaries

**Tenancy model**

Every resource lives under a tenant. The tenant is the outermost authority boundary, not a filter applied after data is retrieved.

```
Tenant
  └── Workspace (one or more per tenant)
        ├── Members (role-scoped)
        ├── Schedules / items (the schedulable entities)
        ├── Activity feed (append-only per workspace)
        └── Approval workflows (state machine per item)
```

Tenant ID is injected at the session layer, not passed in request payloads. Every database query includes `tenant_id` as the first predicate, not the last. Row-level security enforces this at the database layer as a backstop -- not as the only control.

Object-level authorization follows the pattern: `only [role] may perform [action] on [resource within workspace]`. A workspace admin cannot act on another workspace's resources even within the same tenant. A tenant superadmin can act across workspaces within that tenant only.

Authorization checks run in this order:
1. tenant membership
2. workspace membership and role
3. object-level permission for the specific resource

Skipping step 2 or 3 because step 1 passed is a BOLA check failure. Deny by default -- no permission grants access unless it is explicitly modeled.

**Identity and session model**

Sessions carry: `tenant_id`, `workspace_id` (if scoped), `user_id`, `role[]`, `session_token`. Tokens are short-lived with refresh. Role claims are re-evaluated at the authorization layer, not trusted from the token alone, because roles can change mid-session.

**Data ownership boundaries**

- Scheduling data is owned by the workspace. Items are created, modified, and owned within one workspace.
- Activity feed is owned by the workspace and is append-only. Feed entries are never updated or deleted in the hot path.
- Approval workflow state is owned by the workflow instance, which is scoped to one schedulable item. Workflow state transitions are the only write authority for status changes -- direct field updates to status are blocked.
- Webhook configuration is owned at the tenant level, with optional workspace-level scoping. Webhook delivery records are tenant-scoped and immutable after creation.

---

### Data, consistency, and delivery design

**Scheduling and workspace data**

Use a relational store (PostgreSQL is the natural fit here) with tenant_id as a leading index key on every significant table. Do not rely on separate schemas or databases per tenant unless you have hard regulatory isolation requirements -- row-level security plus leading-key indexing is sufficient for most multi-tenant SaaS at scale, and it avoids the operational tax of thousands of schema migrations.

```sql
-- canonical pattern: tenant_id is always the leading predicate
SELECT * FROM schedule_items
WHERE tenant_id = $1
  AND workspace_id = $2
  AND id = $3;
```

The cost of this approach is that global analytics queries (cross-tenant reporting) become expensive and require a separate read model or data warehouse. That is an accepted tradeoff -- OLTP and OLAP are separated from the start.

**Activity feed with cursor-based pagination**

The feed is an append-only event log scoped to a workspace. This is not a social feed -- it is an audit and activity surface, so immutability is a design constraint, not an optimization.

Cursor design: use an opaque cursor that encodes `(created_at, event_id)` as a compound position. Do not use integer offsets -- offset pagination breaks when new events are inserted between pages.

```
Cursor encodes: { workspace_id, created_at, event_id }
Cursor is base64-encoded and treated as opaque by the client
Direction: forward-only by default; backward cursors supported but less common
Page size: caller-specified, capped at a server-enforced maximum (e.g. 100 events)
```

Feed entries are written by a feed-writer service (or a dedicated database trigger + outbox pattern) whenever a schedulable action occurs: item created, status changed, approval decision made, comment added, webhook fired. The feed writer must be idempotent -- if an event is written twice due to a retry, the second write is a no-op keyed on `event_id`.

Feed entries are never soft-deleted. If a record must be hidden for legal reasons, mark it with a `redacted_at` timestamp and replace content with a tombstone -- but the entry remains in position. This preserves cursor integrity.

```
Feed schema (simplified):
  event_id        UUID (primary key)
  tenant_id       UUID
  workspace_id    UUID
  actor_id        UUID
  event_type      ENUM (item_created | status_changed | approval_decided | webhook_fired | ...)
  payload         JSONB
  created_at      TIMESTAMPTZ (indexed, non-nullable)
  redacted_at     TIMESTAMPTZ (nullable)
```

**Approval workflow state machine**

Approval workflows are state machines. The current status of any schedulable item is not a field that gets directly updated -- it is the result of applying a sequence of transitions. This distinction matters because it gives you a recoverable history, makes invalid transitions detectable, and prevents partial writes from leaving state undefined.

State machine for a typical approval workflow:

```
draft --> submitted --> pending_review --> approved
                    \-> rejected
                    \-> revision_requested --> submitted (loop)
```

Each transition is a database row, not an update to a status column. The current state is derived by replaying transitions (or cached in a `current_state` denormalized column that is only written by the state machine service, never directly by application code).

Transition rules enforced at the service layer:
- only the workspace admin or designated approver may approve or reject
- only the item owner may submit or resubmit
- transitions that skip states are blocked
- a workflow in `approved` state cannot be re-submitted without an explicit unlock action

When a transition succeeds: the transition is written to the `workflow_transitions` table, the feed is updated, and a webhook event is enqueued. These three writes are coordinated via the transactional outbox pattern -- all three rows are written in a single database transaction so they are either all committed or all rolled back.

```
Workflow transition schema (simplified):
  transition_id   UUID
  tenant_id       UUID
  item_id         UUID
  from_state      ENUM
  to_state        ENUM
  actor_id        UUID
  notes           TEXT
  created_at      TIMESTAMPTZ
```

The architecture tax of the state machine approach is that simple status reads require a join or a denormalized cache. That cost is worth accepting because partial state transitions under the direct-update approach are undetectable and unrecoverable.

**Webhook delivery**

Outbound webhooks to customer systems are not fire-and-forget. Customer endpoints fail, go offline, and return 5xx responses. The delivery subsystem must absorb this reliably.

Delivery model:
```
1. Business event occurs (approval decided, item scheduled, etc.)
2. Outbox row is written in same transaction as the business event
3. Webhook dispatcher reads outbox and enqueues delivery job
4. Job POSTs to customer endpoint with:
     - Content-Type: application/json
     - X-Webhook-ID: <delivery_id>
     - X-Webhook-Signature: HMAC-SHA256(payload, tenant_secret)
     - X-Delivery-Timestamp: ISO 8601
5. On 2xx: mark delivery as succeeded, write delivery record
6. On 4xx (except 429): mark as permanently failed (do not retry -- client error)
7. On 5xx or timeout or network error: enqueue retry with exponential backoff with jitter
8. After N retries (e.g. 5): mark as failed, alert tenant admin, pause delivery to that endpoint
```

Retry schedule example: 10s, 30s, 2m, 10m, 30m. After 5 failures, the endpoint is marked degraded and the tenant is notified.

Payload signing (step 4) is not optional. Customer systems must be able to verify that a webhook originated from this platform. Use HMAC-SHA256 with a per-tenant signing secret. Include the raw body in the HMAC input -- not a serialized representation.

Delivery records are immutable after creation. They serve as the audit log for all outbound calls. Tenants can view delivery history and retry failed webhooks manually up to a configurable window.

The customer endpoint is not trusted. Treat any response as potentially malicious. Do not follow redirects. Cap the response body read to a small size (e.g. 1 KB). Set a strict timeout (e.g. 10s).

---

### Observability and failure posture

**Trace and correlation**

Every inbound request generates a `trace_id` that propagates through the entire call graph: API handler, database queries, feed write, state machine transition, outbox write, webhook dispatch. `trace_id on all errors` is non-negotiable -- without it, debugging a failed webhook delivery that began as an approval transition becomes a multi-log reconstruction problem.

Webhook delivery records include the originating `trace_id` so support staff can trace a customer complaint about a missed webhook back to the original business event in one lookup.

**Failure classes and handling**

| Failure class | Handling |
|---|---|
| Tenant not found | 401 -- do not distinguish from invalid credentials |
| Authorization failure | 403 with RFC 9457 body |
| Invalid state transition | 409 with `current_state` and `allowed_transitions` in body |
| Feed write failure | Retry via outbox -- feed must eventually receive the event |
| Webhook endpoint timeout | Retry with exponential backoff with jitter |
| Webhook endpoint permanently degraded | Pause + notify, do not retry indefinitely |
| Database unavailable | Circuit breaker at service boundary, return 503 |

RFC 9457 is the error envelope for all structured errors. Every 4xx and 5xx response includes `type`, `title`, `status`, `detail`, and `trace_id`. Client-readable error bodies must not leak internal table names, stack traces, or tenant data.

**Key metrics and alerts**

- webhook delivery success rate per tenant (alert below threshold)
- feed write lag (time from event to feed entry appearing)
- state machine transition latency (alert on p99 spikes)
- outbox queue depth (alert if backlog grows -- indicates dispatcher failure)
- approval workflow age (alert on items stuck in `pending_review` beyond SLA)
- per-tenant API error rate (5xx spike may indicate isolation failure or schema migration impact)

**Consistency stance**

This platform uses **eventual consistency between the business write and feed/webhook delivery**, with **strong consistency within a single workspace's state transitions**.

Specifically:
- a workflow transition and its feed entry are written in the same database transaction (strong)
- the webhook delivery is dispatched from the outbox asynchronously (eventual, but guaranteed via retry)
- cursor-paginated feed reads reflect committed data only -- no dirty reads

The tradeoff: a customer webhook may arrive slightly after the state transition is committed. This is acceptable. A state transition and its audit record being inconsistent is not acceptable. The architecture is designed so that only the webhook dispatch is eventually consistent -- the source of truth for state is always the `workflow_transitions` table.

**Scaling posture**

- stateless API tier scales horizontally
- webhook dispatcher scales via job queue worker count, not API tier replicas
- feed reads are read-replica-friendly -- cursor queries are stable and deterministic
- approval workflow writes go to primary only -- state machine transitions require serializable isolation per item (use `SELECT FOR UPDATE` on the item row to prevent concurrent transitions)
- outbox polling interval is a tuning knob; at high volume, switch from polling to PostgreSQL `LISTEN/NOTIFY` to reduce query load

[SESSION_STATE]
{
  "route": "backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "authority_model: tenant_id as outermost boundary, workspace_id as secondary scope, object-level authorization as third layer",
    "consistency_stance: strong consistency within workspace state transitions, eventual consistency for feed and webhook delivery via transactional outbox",
    "data_delivery: cursor-based pagination on (created_at, event_id) compound key, opaque base64 cursor, server-enforced page cap",
    "observability_tax: trace_id on all errors propagated through full call graph including webhook delivery records"
  ],
  "evidence_classes_cited": [
    "authorization_perimeter",
    "BOLA_check",
    "deny_by_default",
    "object_level_authorization",
    "RFC_9457",
    "exponential_backoff_with_jitter",
    "circuit_breaker",
    "idempotency_contract",
    "job_lifecycle",
    "HMAC_SHA256_signing",
    "transactional_outbox_pattern",
    "state_machine_transitions",
    "SELECT_FOR_UPDATE_serialization"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there a regulatory isolation requirement (e.g. HIPAA, GDPR data residency) that would force per-tenant schema or database separation rather than row-level security?",
    "What is the expected webhook delivery SLA -- best-effort with retry, or guaranteed delivery within a defined window?",
    "Are cross-workspace approval chains needed (e.g. an item initiated in workspace A requiring approval from a member of workspace B)?"
  ],
  "turn": 1
}
[/SESSION_STATE]