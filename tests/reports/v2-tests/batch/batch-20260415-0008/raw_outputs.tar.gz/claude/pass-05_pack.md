## Current failure state

This is a compound remediation task. The governing route is document accessibility (reading order, tag fidelity, extraction) with PDF layout as a supporting skill for frame logic and InDesign source decisions. The failures below are ordered by severity — fix them in sequence because earlier repairs affect whether later ones are even necessary.

**Failure 1 — Broken tag structure (critical)**
InDesign's Export Tags feature maps paragraph styles to PDF tags, but only if paragraph styles were consistently applied and the Export Tagging panel was configured before export. If body text was manually styled or if the InDesign template used local overrides, the PDF may have a shallow or missing tag tree. Screen readers encountering untagged or weakly tagged content will either skip content entirely or read it in document order, which in a two-column layout means column 1 top, column 2 top, column 1 next, column 2 next — interleaving both columns into nonsense.

**Failure 2 — Reading order wrong for two-column layout (critical)**
PDF reading order is governed by the Articles panel in InDesign (if used before export) or the Order tab in Acrobat's Tags panel (after export). Two-column layouts almost always export with reading order reflecting InDesign's object stacking order, not left-column-then-right-column narrative flow. You need to verify and manually correct this in the Tag tree or via the Reading Order tool.

**Failure 3 — Pull quotes interrupting reading flow (high)**
Pull quotes are visual repetitions of body text. They carry no new semantic information for screen reader users. If they are tagged as `<P>` or `<BlockQuote>` with full text, a screen reader will read the same sentence twice mid-paragraph. The correct fix depends on intent: if the pull quote repeats body text exactly, tag it as `<Artifact>` so it is skipped. If it contains unique wording, keep it tagged but reposition it in the reading order to appear after the passage it references, not inside it.

**Failure 4 — Decorative images not tagged as artifacts (high)**
Any image that does not carry meaning necessary to understand the document must be tagged as `<Artifact>` in the tag tree. If it carries meaning, it needs an `<Figure>` tag with an Alt Text value. InDesign exports images as `<Figure>` by default regardless of whether they are decorative, so this must be corrected manually in Acrobat or by tagging images correctly in InDesign before re-export.

**Failure 5 — Broken TOC links (high)**
InDesign TOC entries export as PDF hyperlinks only if the InDesign TOC was generated via the Layout > Table of Contents feature using paragraph styles. If someone built the TOC manually as styled text, InDesign has no way to create destination anchors. Broken links in the exported PDF can mean: the destinations were not created, the destination names were changed after the TOC was generated, or the links were set to "None" in the Hyperlinks panel before export. This is almost always easier to fix by regenerating the TOC in InDesign and re-exporting than by repairing destination anchors in Acrobat.

---

## Remediation sequence

Work in this order. If you fix reading order before tags are correct, you will re-do the reading order work after the tag repair changes the tree structure.

**Step 1 — Fix at the InDesign source if possible**

This is always preferable to Acrobat repair because InDesign structural fixes survive re-export. If the source file is available:

- Audit every paragraph style for its Export Tag assignment. In InDesign, go to Paragraph Styles > Style Options > Export Tagging. Map `H1` through `H4` styles to the matching heading levels. Map body text to `<P>`. Map captions to `<Caption>` if your tag schema uses it, or `<P>` with a `Caption` role if not.
- Tag all decorative images. Select each decorative image > Object Export Options > Alt Text tab > set to "Decorative Image" and check "Apply Tag: Artifact." For meaningful images, write descriptive Alt Text in the same panel.
- Tag pull quotes. Select each pull quote frame > Object Export Options > set the PDF export tag to "Artifact" if the text repeats body copy. If it contains unique wording, set it to `<BlockQuote>` and verify it is not nested inside the paragraph it interrupts.
- Regenerate the TOC using Layout > Table of Contents. Confirm the paragraph styles selected in the TOC dialog match the heading styles used in the document. Export the TOC to an existing text frame (not as a new story) so anchors are rebuilt consistently.
- Use the Articles panel to set reading order. In InDesign, open the Articles panel (Window > Articles). Build article threads in left-column-then-right-column order. Each text frame and anchored object should be added to an article thread. Check "Use for Reading Order in Tagged PDF" in the Articles panel menu before export.
- Export. File > Export > Adobe PDF (Print or Interactive). In the Export dialog, under the Tags and Hyperlinks section: check "Create Tagged PDF," check "Use Structure for Tab Order," and confirm "Hyperlinks" and "Table of Contents" are both checked.

**Step 2 — Verify the exported PDF tag structure in Acrobat**

Open the exported PDF in Acrobat Pro. Open the Tags panel (View > Show/Hide > Navigation Panes > Tags).

Check:
- The root `<Document>` tag is present
- `<H1>` through `<H4>` tags appear in the correct nesting order
- `<P>` tags are present for body text
- No large blocks of text are grouped under a single tag that should be multiple paragraphs
- Pull quotes appear as `<Artifact>` (not visible in the tag tree — this is correct) or as `<BlockQuote>` out of the flow interruption
- Images are tagged as `<Artifact>` or `<Figure>` with non-empty Alt Text
- TOC entries are tagged as `<Link>` with a `<OBJR>` child referencing the correct destination

If you have multiple column threads and they are interleaved, do not try to re-sort the tag tree manually. Go back to InDesign, fix the Articles panel order, and re-export. Manual tag resorting in Acrobat for long documents is fragile and does not survive re-export.

**Step 3 — Fix reading order in Acrobat if source is unavailable**

If InDesign source is not available, you must work in Acrobat Pro directly. This is slower and more fragile, but it is recoverable.

Use the Reading Order tool (Accessibility > Reading Order) for visual inspection. The tool shows numbered regions — the numbers are the reading sequence. If column 2 content is interleaved with column 1, you will see alternating region numbers that do not follow left-then-right flow.

To reorder: open the Tags panel, locate the missequenced tags, and drag them into correct order within the tag tree. For a two-column layout, all of column 1's `<P>` and heading tags should be contiguous in the tree before column 2's tags begin.

For pull quotes tagged as `<P>` that are mid-paragraph: right-click the tag in the Tags panel, select Properties, and change the tag type to "Artifact" if the text repeats body copy. If the pull quote should stay as tagged content, cut its tag from the tree and paste it after the paragraph that contains the source text.

For images: right-click the `<Figure>` tag, select Properties, click the Tag tab, and confirm Alt Text is present and accurate. For decorative images, right-click the tag > Change Tag to Artifact. In the Artifact dialog, select "Layout" as the artifact type.

For broken TOC links: open the Hyperlinks panel or use Edit > Links > Edit All Links. Locate each broken TOC link, right-click > Properties, change the link action from "Go to a page view" with a missing destination to "Go to a page view" with the correct page number. This is a workaround, not a structural fix — rebuild the TOC in InDesign if the document will be re-exported.

**Step 4 — Fix the document's tab order**

Tab order for screen readers and keyboard navigation must follow the logical reading order, not the object placement order. In Acrobat Pro, open the Pages panel, right-click any page, select Page Properties > Tab Order, and set it to "Use Document Structure." Do this for all pages. If your document is long, use a batch action.

**Step 5 — Run the Accessibility Checker**

After all repairs, run the full Acrobat Accessibility Checker (Accessibility > Full Check). Common remaining failures at this stage:

- "Document is not tagged" — means the tag tree export failed; return to InDesign and re-export with "Create Tagged PDF" enabled
- "Reading order" — flagged when the logical reading order and visual order diverge; return to Step 3
- "Tab order" — return to Step 4
- "Figures alternate text" — return to Step 2/3 for image Alt Text
- "Form fields" — outside this task's scope, but flag for later if the document contains forms

The checker is not exhaustive. Passing the checker is a necessary condition, not sufficient for full accessibility. Always follow up with a manual screen reader test using NVDA + Chrome or JAWS + Acrobat.

---

## Verification checks

Do not assume the repair is complete without these:

**Tag tree audit**: open Tags panel in Acrobat, expand the full tree for the first 3 pages, and confirm heading nesting is correct, body text is `<P>`, and no content tags appear after `<Artifact>` blocks that should have been hidden.

**Screen reader test**: navigate the document with NVDA or JAWS using the arrow keys and heading navigation shortcut (H key). Confirm column 1 is read completely before column 2 begins. Confirm pull quotes do not interrupt paragraph flow. Confirm images announce as decorative or with meaningful alt text. Confirm TOC links navigate to the correct page.

**Export test**: extract the document text using Acrobat's Save As > Text (Plain) option. Open the text file and read the first 500 words. If the reading order is correct in the tag tree, this extraction will follow the same order. Interleaved columns in the extraction means the reading order is still wrong.

**TOC verification**: in the final PDF, click each TOC link and confirm it navigates to the expected section heading on the correct page.

---

## Risk controls

**Destructive shortcut rejected**: do not use Acrobat's "Auto-tag document" feature on an InDesign-exported PDF that has partial tagging. Auto-tag will overwrite existing correct tags with heuristic guesses and often produces worse results than the original export — especially for multi-column layouts, pull quotes, and sidebars. Use Auto-tag only on completely untagged documents where the tag tree is entirely absent.

**Re-export risk**: if you repair the PDF in Acrobat and the InDesign source is later re-exported without the Articles panel and Export Tagging configuration, all Acrobat repairs are lost. Document the InDesign configuration changes so the export process produces a correctly tagged PDF from the source without requiring Acrobat cleanup on every cycle.

**Pull quote duplication risk**: if you leave pull quote text tagged as `<BlockQuote>` rather than `<Artifact>`, you must verify the text content differs from the body passage it references. Identical text appearing twice in the tag tree is a WCAG 2.1 SC 1.3.2 reading order failure (meaningful sequence).

**Alt text quality risk**: the Accessibility Checker only verifies that Alt Text is non-empty. It does not check whether the text is meaningful. "Image" or "photo" as alt text passes the checker and fails the user. Write alt text that describes the content and function of the image in one concise sentence.

[SESSION_STATE]
{
  "route": "rt_pdf_remediation + rt_document_accessibility",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_failure: broken tag structure, wrong reading order for two-column layout, pull quotes interrupting flow, decorative images untagged, broken TOC links",
    "reading_order_or_extraction: column 1 complete before column 2; pull quotes as Artifact or repositioned BlockQuote; verified via plain text extraction",
    "verification_method: tag tree audit + screen reader test (NVDA/JAWS) + plain text extraction + TOC link click test",
    "destructive_shortcut_rejected: Auto-tag feature rejected for partially-tagged InDesign export"
  ],
  "evidence_classes_cited": [
    "WCAG 2.1 SC 1.3.2 meaningful sequence",
    "InDesign Articles panel reading order mechanism",
    "Acrobat Pro Tags panel and Reading Order tool",
    "PDF tag schema: Document, H1-H4, P, Figure, Artifact, BlockQuote, Link, OBJR"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the InDesign source file available for re-export, or is Acrobat-only repair required?",
    "Do any pull quotes contain text that differs from the body copy they reference, or are they all direct repetitions?",
    "Are there form fields or interactive elements in the document beyond the TOC links?"
  ],
  "turn": 1
}
[/SESSION_STATE]