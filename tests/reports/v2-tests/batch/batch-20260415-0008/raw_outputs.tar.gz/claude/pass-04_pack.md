## Requested capability

Real-time collaborative document editing with simultaneous multi-user presence (visible cursors), conflict resolution, and persistent state — added to an existing React + REST + PostgreSQL stack.

---

## Hidden system requirements

This request carries substantially more infrastructure than the visible feature implies. Each category below represents a real system dependency that must be resolved before a single cursor appears on screen.

**Transport layer**
REST is request-response. Real-time collaboration requires a persistent bidirectional channel. You need WebSockets (Socket.io, native WS, or a managed service like Ably or Pusher) or Server-Sent Events at minimum for presence. WebSockets are the practical requirement for two-way cursor and edit broadcasting. Your existing REST infrastructure cannot carry this — you need a new transport surface.

**Operational transformation or CRDT engine**
Simultaneous edits to the same document position create conflicts that HTTP-level "last write wins" cannot resolve without destroying one user's work. You need either:
- Operational Transformation (OT) — transforms concurrent operations so they converge. Used by Google Docs. Complex to implement correctly from scratch. Libraries: ShareDB (uses OT over JSON), ot.js.
- CRDTs (Conflict-free Replicated Data Types) — data structures that merge by design without central coordination. More resilient to network partitions. Libraries: Yjs (strongly recommended), Automerge.

Yjs with a persistence provider is the current standard for new implementations. You cannot skip this layer and maintain correctness under concurrent edits.

**Session and presence model**
Cursor positions, user identity, and awareness (who is in the document, where) require a presence system separate from document state. Yjs has a built-in awareness protocol. If you build custom, you need: a session registry, a heartbeat/eviction mechanism, and broadcast logic scoped to document rooms. PostgreSQL alone cannot serve this — it has no push capability and no in-memory session bus.

**Real-time broadcast infrastructure**
When User A types, User B must receive the delta within ~100ms to feel live. This requires:
- A pub/sub bus or in-process channel if single-server
- A distributed message broker (Redis Pub/Sub, Redis Streams, or NATS) if you run multiple server instances — which you almost certainly do in production

Without a distributed bus, collaboration breaks the moment two users hit different server instances. This is a blocking constraint on multi-instance deployments.

**Persistence and durability model**
Collaborative edits arrive as a stream of operations or CRDT updates, not as full document saves. Your PostgreSQL schema almost certainly stores documents as complete serialized blobs. You need one of:
- An append-only operation log (write each delta, reconstruct document from log)
- Snapshot + delta hybrid (periodic full snapshot, operation log between snapshots)
- Yjs document state serialized to binary and stored in PostgreSQL (simpler, but you lose granular history)

The current REST-to-Postgres "save document" pattern will produce lost updates under concurrent writes without this change. Must come before launch.

**Authorization perimeter for document rooms**
Only users with read/write permission to a document may join its WebSocket room. Your existing REST auth (session cookie or JWT) must be validated at WebSocket upgrade time — the HTTP handshake is your one enforcement point. After upgrade, the connection is trusted until closed. If you skip object-level authorization at the room level, any authenticated user can join any document room. This is a BOLA (Broken Object Level Authorization) exposure. Object-level authorization must be enforced at room join, not just at REST endpoints.

**Tombstoning and offline/reconnect behavior**
Users lose connections. When they reconnect, they need to receive the diff since their last known state, not a full document reload. CRDT libraries handle this better than OT — Yjs state vectors make syncing from a known point straightforward. With OT you must store the full operation history for the session window.

**Operational cost surface**
WebSocket connections are long-lived. Each open document costs one persistent connection per user. Under load, this degrades differently than REST — a connection pool of 10,000 concurrent users is not the same as 10,000 req/s. Your infrastructure, load balancer config (timeouts, sticky sessions or shared state), and horizontal scaling strategy all change.

---

## Feasibility assessment

**Overall verdict: feasible, but not a feature addition — this is an infrastructure project.**

The existing stack (React + REST + PostgreSQL) provides zero of the required real-time primitives. Everything must be added. The scope is closer to a new subsystem than a feature.

| Requirement | Current state | Blocker level |
|---|---|---|
| Bidirectional transport | REST only | **Blocking** — cannot proceed without WebSocket layer |
| Conflict resolution engine | None | **Blocking** — concurrent edits will corrupt documents without OT or CRDT |
| Distributed pub/sub | None | **Blocking** on multi-instance deployments |
| Object-level room authorization | Not present at WS layer | **Blocking** — security exposure |
| Persistence model change | Full-blob saves | **Blocking** — lost updates guaranteed under concurrency |
| Presence/awareness system | None | High priority, not a launch blocker if presence is deferred |
| Reconnect/sync protocol | None | High priority before production; manageable in early access |
| Load balancer reconfiguration | Untested for WS | Must be validated before any load testing |

**Explicit blockers before any production traffic:**
1. No WebSocket server exists — cannot broadcast anything
2. No conflict resolution means concurrent edits will overwrite each other
3. REST auth is not wired to WebSocket upgrade — document rooms are unprotected
4. PostgreSQL write model produces lost updates under concurrency without a delta or operation-log model
5. Multi-instance deployment without Redis pub/sub means users on different servers cannot see each other's edits

---

## Safer implementation path

Attempting to build the full system in one pass — custom OT engine, presence, persistence, broadcast, auth — is the highest-risk path. The failure mode is months of work followed by subtle data-corruption bugs under real concurrency.

The safer path uses Yjs as the CRDT layer (battle-tested, not invented here), Redis for pub/sub, and PostgreSQL for persistence. It stages delivery so each phase is shippable independently.

---

### Phase 1: Foundation (do not skip, do not compress)

**Goal:** establish the transport, CRDT, and security layer before any user-facing feature exists.

1. **Add a WebSocket server.** Use Socket.io or ws. Wire it to your existing Express/Node process or run it as a sidecar. Validate that your load balancer supports persistent connections (disable aggressive timeout, enable sticky sessions or move to shared-state model).

2. **Integrate Yjs.** Use `yjs` with `y-websocket` as the provider. Each document gets a Yjs `Y.Doc`. The server maintains a room per document ID. Clients sync state via the y-websocket protocol — you do not write custom merge logic.

3. **Implement object-level authorization at WebSocket upgrade.** Before allowing a client to join a room, validate their JWT or session cookie and check their permission for that document ID against your existing permission model. Deny by default. Only the document owner or users with explicit access may join.

4. **Change the persistence model.** Store the serialized Yjs document binary (`Y.encodeStateAsUpdate`) to PostgreSQL on a debounced interval (every 30 seconds or on idle). On document load, retrieve the binary and initialize the Y.Doc from it. This is not a full operation log — it is a binary snapshot. It is simpler and sufficient unless you need granular version history.

Phase 1 produces: a working WebSocket server, correct conflict resolution, persistent state, and a secure room model. No UI changes required yet.

---

### Phase 2: Presence and awareness

**Goal:** show who is in the document and where their cursor is.

1. Use Yjs's built-in `awareness` protocol. Each client broadcasts cursor position and user identity as awareness state. The server relays it. No custom presence table required.

2. Render cursors in the React editor layer (Slate.js, TipTap, ProseMirror, or your existing editor — all have Yjs bindings). Cursor labels include user name and color, assigned at room join.

3. Add a heartbeat/eviction timer: if a client's awareness state goes stale after 30 seconds with no update, remove their cursor from other clients' views.

Phase 2 is additive. It does not change the persistence or auth model from Phase 1.

---

### Phase 3: Distributed scaling

**Goal:** make Phase 1 and 2 work correctly across multiple server instances.

1. **Add Redis pub/sub.** Use `y-redis` (the official Yjs Redis provider) or implement a thin Redis Pub/Sub relay: each WebSocket server publishes Yjs updates to a Redis channel keyed by document ID, and subscribes to that channel to relay updates to its local clients. Without this step, two users on different server instances cannot see each other's edits — this is a blocking constraint on any horizontally scaled deployment.

2. Reconfigure your load balancer. Sticky sessions (IP hash or cookie) are a short-term workaround for a single-region deployment. Redis-backed shared state is the correct long-term model because it survives instance replacement.

Phase 3 is required before any meaningful production load. It can follow Phase 1/2 in a single-region low-traffic early access period, but must come before scaling.

---

### Phase 4: Version history (optional, post-launch)

If you need "see all changes, restore a previous version," move from binary snapshots to an append-only operation log:
- Store each Yjs update as a row in a `document_updates` table with a timestamp and user ID
- Reconstruct any point-in-time state by replaying updates from the beginning (or from the nearest snapshot)
- Add a snapshot compaction job to prevent unbounded log growth

This is a significant additional scope. It is not required for the core collaboration feature. Defer it unless version history is a hard product requirement at launch.

---

### What you preserve vs. what you sacrifice

You preserve your existing REST API surface entirely. Document reads and non-collaborative workflows continue unchanged. REST remains the right model for document listing, metadata, sharing settings, and auth flows.

You sacrifice the simplicity of a single-transport, single-write-path architecture. The stack now has two communication models (REST + WebSocket), two write paths (REST saves + Yjs sync), and a new infrastructure dependency (Redis). This means accepting higher operational complexity, a new failure domain (WebSocket server health, Redis availability), and a longer onboarding curve for new engineers on the codebase. That is the correct tradeoff for a feature that is inherently stateful and bidirectional — there is no version of real-time collaboration that does not require this complexity.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "system_surface_dependency: WebSocket transport required, REST cannot carry real-time",
    "system_surface_dependency: CRDT engine (Yjs) required for conflict resolution",
    "system_surface_dependency: Redis pub/sub required for multi-instance broadcast",
    "permissions_dependency: object-level authorization required at WebSocket upgrade",
    "data_dependency: PostgreSQL write model must change to delta/snapshot before concurrent writes",
    "blocking_constraint: five explicit blockers identified before production traffic"
  ],
  "evidence_classes_cited": [
    "blocking_constraint",
    "system_surface_dependency",
    "permissions_dependency",
    "data_dependency",
    "object_level_authorization_BOLA"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the team have a preference for managed WebSocket service (Ably, Pusher) vs. self-hosted y-websocket?",
    "Is granular version history (per-keystroke restore) a launch requirement or post-launch?",
    "What is the current deployment topology — single instance or horizontally scaled?"
  ],
  "turn": 1
}
[/SESSION_STATE]