## Purpose and scope

A split button that pairs a primary commit action with a disclosed menu of secondary save variants. The two interactive surfaces — the primary button and the dropdown trigger — are intentionally separate: they have distinct focus stops, distinct labels, and distinct hit areas. This separation is what makes the component keyboard-navigable and screen-reader honest, rather than a visually split button that behaves as one ambiguous control.

The component serves a save workflow with three actions: Save (primary, immediate), Save as draft (secondary), Save and close (secondary). The primary action must be reachable in one step. The menu must be reachable without requiring a mouse.

---

## Anatomy

### Segments

**Primary button segment**
- Label: "Save"
- Role: `button`
- Behavior: fires the save action immediately on activation
- Width: content-driven with minimum touch target padding

**Dropdown trigger segment**
- Label: accessible label "More save options" — not an empty chevron
- Role: `button` with `aria-haspopup="menu"` and `aria-expanded` toggling true/false
- Visual: chevron icon only, but the accessible name must be text, not icon title
- Behavior: opens and closes the menu panel; does not fire the primary action

**Divider**
- Visual only, not interactive
- Marks the boundary between the two segments
- Must not introduce a third focus stop

**Menu panel**
- Role: `menu`
- Opens anchored below the trigger, left- or right-aligned based on available viewport space
- Contains exactly two `menuitem` elements: "Save as draft" and "Save and close"
- Dismisses on: item selection, Escape, click/tap outside, or focus leaving the component entirely

### Token slots

| Token | Purpose |
|---|---|
| `--split-btn-height` | Row height, applies equally to both segments |
| `--split-btn-radius` | Border radius; left segment takes leading corners, right segment takes trailing corners |
| `--split-btn-divider-color` | Divider line between segments |
| `--split-btn-bg-default` | Default surface |
| `--split-btn-bg-hover` | Hover and focus-visible surface per segment |
| `--split-btn-bg-disabled` | Disabled surface |
| `--split-btn-text-default` | Label and icon color |
| `--split-btn-text-disabled` | Label and icon color in disabled state |
| `--split-btn-focus-ring` | Focus outline color |
| `--split-btn-menu-bg` | Menu panel background |
| `--split-btn-menu-item-hover` | Menu item hover/focus surface |
| `--split-btn-loading-indicator` | Spinner or skeleton color in loading state |

Tokens apply per segment where relevant. A disabled trigger should not visually implicate the primary button.

---

## State matrix

Both segments can carry state independently. The matrix covers the meaningful combinations.

### Primary button segment

| State | Visual | Behavior |
|---|---|---|
| Default | Normal fill, full opacity | Activates save on click or Enter/Space |
| Hover | `--split-btn-bg-hover` surface | Cursor pointer |
| Focus-visible | Focus ring on segment boundary | Keyboard-navigable; ring must not bleed into trigger segment |
| Active | Press depression | Brief during pointer hold |
| Loading | Spinner replaces label text; segment width held | Inert — does not accept activation; `aria-busy="true"` on the segment or on the containing form region |
| Disabled | `--split-btn-bg-disabled`, `--split-btn-text-disabled`, reduced opacity | `disabled` attribute set; removed from tab order; no hover change |
| Disabled + loading | Not a valid combination | Loading implies the action was accepted; disable before or after, not during |

### Dropdown trigger segment

| State | Visual | Behavior |
|---|---|---|
| Default | Normal fill, chevron icon | Opens menu on click, Enter, Space, or Down Arrow |
| Hover | `--split-btn-bg-hover` per segment | Cursor pointer |
| Focus-visible | Focus ring on trigger boundary only | Independent focus stop |
| Menu open | `aria-expanded="true"`, chevron rotates 180° | Menu panel visible; focus moves into menu |
| Loading (primary active) | Trigger remains available unless explicitly disabled | User can still open menu while primary is processing, unless that would cause a conflict — document the choice |
| Disabled | Same as primary disabled rules | Disabled attribute; removed from tab order; menu cannot open |

### Menu items

| State | Visual | Behavior |
|---|---|---|
| Default | Normal item row | Activatable |
| Focus | `--split-btn-menu-item-hover` highlight | Arrow key navigation within menu |
| Activated | Brief press state | Fires action and closes menu |
| Disabled item | Reduced opacity, `aria-disabled="true"` | Skipped in arrow-key navigation; not removed from DOM |

### Combined disable rules

- Disabling the entire component disables both segments simultaneously and uses a single `fieldset` or wrapper `disabled` strategy that avoids partial-disable ambiguity.
- Partial disable (primary disabled, trigger enabled) is a valid variant only if the product explicitly needs it, such as when no primary save target exists yet but drafts are still allowed. If you ship this variant, it needs its own token for the partial disabled state, not a recycled opacity hack.

---

## Accessibility and implementation notes

### Keyboard contract

| Key | Context | Result |
|---|---|---|
| Tab | Anywhere | Moves focus to primary segment, then trigger segment, then exits component |
| Enter or Space | Primary segment focused | Fires save action |
| Enter or Space | Trigger segment focused | Opens menu |
| Down Arrow | Trigger segment focused | Opens menu and moves focus to first menu item |
| Down Arrow | Menu open | Moves focus to next item; wraps to first from last |
| Up Arrow | Menu open | Moves focus to previous item; wraps to last from first |
| Escape | Menu open | Closes menu; returns focus to trigger segment |
| Home | Menu open | Moves focus to first item |
| End | Menu open | Moves focus to last item |
| Tab | Menu open | Closes menu; moves focus forward out of component (does not cycle through menu items) |

This matches the ARIA Authoring Practices Guide menu button pattern. The menu is not a listbox. Do not use `role="option"` on the items.

### ARIA structure

```html
<div class="split-button">
  <button 
    type="button" 
    class="split-button__primary"
    aria-label="Save">
    Save
  </button>

  <button
    type="button"
    class="split-button__trigger"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-label="More save options">
    <!-- chevron icon, aria-hidden="true" -->
  </button>

  <ul 
    role="menu"
    aria-label="Save options"
    hidden>
    <li role="none">
      <button role="menuitem">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem">Save and close</button>
    </li>
  </ul>
</div>
```

The `role="none"` on `li` elements removes the implicit list semantics so the menu role is unambiguous. The `hidden` attribute removes the panel from the accessibility tree when closed — `display: none` achieves this if `hidden` is not used, but `visibility: hidden` alone does not.

### Loading state accessibility

When the primary button enters loading state:
- Add `aria-busy="true"` to the button or to the region it controls
- The spinner must have an accessible label: `<span class="visually-hidden">Saving…</span>` adjacent to or inside the button, not relying on the icon title
- Do not remove the button from the DOM during loading — this drops focus and breaks keyboard users mid-task
- Make the button inert or `disabled` during loading so it cannot be double-activated; if you use `disabled`, ensure focus management restores focus to the button after the action resolves

### Touch targets

- Minimum 44x44 CSS pixels per segment (WCAG 2.5.5 AAA; 24x24 minimum for AA compliance under WCAG 2.5.8)
- The divider must not reduce the effective hit area of either segment. Use padding inside each segment rather than relying on the visual divider position to define the edge.
- On narrow viewports (below 360px effective width), consider stacking the component: primary button full-width, trigger full-width beneath it, menu opening upward. This is preferable to shrinking touch targets below floor.
- The menu items need the same 44px minimum touch target height on mobile.

### Implementation boundary

This component owns: its own focus management, menu open/close toggle, keyboard navigation within the menu, and ARIA state updates.

This component does not own: the save action logic, routing after "Save and close," draft storage, or conflict detection when two saves overlap. Those concerns belong to the form or page layer. The component emits named events (`save`, `save-as-draft`, `save-and-close`) and the consuming layer decides what to do with them.

The loading state is set externally by the consuming layer after the save action begins. The component should accept a `loading` prop or attribute rather than managing async state internally — this keeps the component predictable and testable without mocking network calls.

---

## Key tradeoffs

**Two focus stops rather than one.** A single focus stop with arrow-key access to the trigger would reduce Tab presses, but it makes the trigger undiscoverable to users who navigate without a mouse and don't know to press arrow keys. Two stops costs one Tab press and gains transparent keyboard behavior. You preserve discoverability; you sacrifice minimal navigation economy.

**Trigger remains available during primary loading.** Allowing the menu to open while save is processing means a user could select "Save as draft" while a save is already in flight. If the backend cannot safely handle overlapping writes, disable the trigger during loading too. The component should not make this decision unilaterally — document the constraint clearly so the consuming layer knows to set `trigger-disabled` when overlap is unsafe.

**Partial disable is opt-in.** The default behavior disables both segments together. Partial disable ships only if the product explicitly needs it, because it introduces a state that looks broken to users who expect the two segments to move together.

[SESSION_STATE]
{
  "route": "component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: split button owns focus management, menu toggle, keyboard nav, ARIA state; consuming layer owns action logic and loading prop",
    "state_coverage: default, hover, focus-visible, active, loading, disabled, menu-open for each segment; partial-disable as opt-in variant",
    "accessibility_behavior: APG menu button pattern; two independent focus stops; full keyboard contract documented",
    "implementation_boundary: component emits named events; loading set externally via prop; no internal async ownership"
  ],
  "evidence_classes_cited": ["wcag_2_5_5", "wcag_2_5_8", "aria_apg_menu_button_pattern", "aria_role_contracts"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Can the primary button and trigger be independently disabled (partial disable), or does the product always disable them together?",
    "Should the menu trigger remain active during primary loading, or must it be disabled when overlapping writes are unsafe?"
  ],
  "turn": 1
}
[/SESSION_STATE]