## Audience and problem

Freelancers are not small businesses that haven't grown yet. They are people whose financial life is structurally different: income is irregular, clients are slow, invoices get ignored, and the tax burden is invisible until it isn't. Their core anxiety is not "am I managing my capital efficiently" — it's "will I have enough when I need it, and will I look legitimate enough to get paid."

Traditional banks solve for stability and scale. Stripe, Mercury, and Relay solve for operators: founders, small teams, people who think in accounts and payment flows. None of them solve for the freelancer as a person navigating irregular financial reality.

That is the gap.

## Positioning frame

**Territory to own: financial clarity for irregular earners.**

Not "banking for freelancers." That just names the category. The differentiation is that the product understands the rhythm of freelance income — the feast-famine cycle, the invoice-to-cash delay, the tax-saving discipline that most freelancers fail at not because they're irresponsible but because no tool has made it automatic and visible at once.

The emotional register is: "this was built by someone who has been paid late."

**Why this territory works against these three competitors:**

Stripe is infrastructure. It moves money. It does not hold it, protect it, or help you think about it. Freelancers often use Stripe to collect payments but still feel financially exposed after the transfer clears.

Mercury is excellent for funded startups. Its design language, feature set, and mental model are built for companies with teams, payroll, and a runway number. A solo copywriter or independent developer using Mercury is essentially using a tool that wasn't built for them.

Relay is honest multi-account banking. Organized, but its primary value proposition is envelope-style budgeting for business owners — not the psychological and operational reality of unpredictable income.

None of them say: "you are not a broke startup. You are a professional with an unusual cash flow pattern, and we are built for that."

**Differentiation frame:** rather than positioning against "old banks" (which is tired and unearned), position against the assumption that financial tools are for teams. The category convention is that "business banking" means operations, multiple users, payroll. You sacrifice some of the founder/operator market to gain clear ownership of the solo professional market. That tradeoff is worth taking — the three competitors have the operator segment reasonably well covered, and none have made a real claim on the solo professional who earns six figures but feels financially unstable.

## Trust and proof burden

The approachable-but-trustworthy tension is real, and it has to be solved structurally, not tonally. Calling yourself "the bank that gets you" is tone. That is not what earns trust from a freelancer who has been burned by a platform hold, a delayed ACH, or a tax bill they weren't ready for.

Trust in this category requires:

**Behavioral proof, not brand language.** Features that demonstrate understanding before the user has to explain themselves. Examples: automatic tax withholding as a default-on behavior, not a setting buried in an advanced tab. Invoice tracking that surfaces payment latency as a visible number, not a feature the user configures. Cash flow projection that accounts for irregular income patterns, not just a trailing average.

**Tone proof.** The copy has to sound like someone who lives close to the problem. That means precise language about real scenarios — "your client hasn't paid in 30 days" is more trustworthy than "manage your receivables." But tone alone cannot carry the proof burden. If the product does not behave the way the copy implies, the brand fails.

**Category convention constraints.** Freelancers operate in a trust-sensitive environment. They share financial information with this product. That means the brand must not read as scrappy, early, or experimental in its visual and verbal execution. The approachability has to live in the voice and interaction design, not in the brand identity itself. A logotype that looks like a startup weekend project will lose the trust signal before the user reads a single feature description.

Open gap: there is no data here on whether freelancers in this market weight peer recommendation, third-party review credibility, or regulatory transparency most heavily in their trust formation. That research gap matters for how much to invest in community/referral positioning versus certification and compliance visibility.

## Messaging consequences

If you own "financial clarity for irregular earners," the consequences are:

You cannot speak to teams as a primary use case. Multi-user features can exist, but they are not the hero. The moment you start talking about "your team's expenses," you've drifted into Mercury's territory and given up the positioning claim.

Your onboarding must do diagnostic work. It should surface the user's income pattern early and visibly use it to configure defaults. If onboarding is generic, the brand promise is immediately broken.

The visual language should be calm and precise, not playful. Trustworthy-but-approachable in fintech means clear, not cute. Mercury and Relay both use serious, clean design. The differentiator is not making the interface more colorful or friendly-looking — it's making the interface more personal and specific to freelance financial reality.

The competitive comparison should be made by implication rather than direct callout. The frame is "built for how you actually earn," not "better than Mercury." Direct comparisons invite the user to evaluate features, and early-stage products rarely win feature comparisons against established tools. Emotional and contextual fit is harder to compare and easier to own.

Proxy evidence only: the claim that freelancers feel underserved by existing tools is strongly suggested by category behavior (most freelancers use a mix of Stripe, a personal account, and a spreadsheet), but direct research validating this as a primary pain point rather than a convenience preference has not been cited here. That gap should be closed before significant brand investment.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: freelancers as irregular earners, not small business operators",
    "differentiation_frame: financial clarity for irregular earners, not banking for freelancers",
    "trust_logic: behavioral proof through default-on features, not tone alone",
    "messaging_consequence: cannot serve teams as primary use case without losing positioning claim"
  ],
  "evidence_classes_cited": [
    "competitor_behavior_analysis",
    "category_convention_constraint",
    "proxy_evidence_flagged"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What do freelancers weight most in trust formation: peer recommendation, third-party review credibility, or regulatory/compliance transparency?",
    "Is the underserved-by-existing-tools claim validated by direct research or inferred from category behavior only?"
  ],
  "turn": 1
}
[/SESSION_STATE]