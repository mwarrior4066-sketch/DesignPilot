## Color system spec

---

### Role model

The system organizes color into three layers: **base**, **semantic**, and **data**. Each role carries a named meaning that cannot be borrowed across contexts. Borrowing is how status systems break.

**Background and surface roles**

| Role | Meaning |
|---|---|
| `bg-base` | Canvas behind everything. Never used as a foreground element. |
| `bg-surface` | Cards, panels, modals. One step above the canvas. |
| `bg-raised` | Dropdowns, tooltips, popovers. Visually elevated above surface. |
| `bg-sunken` | Input wells, table stripes, read-only fields. Below surface. |
| `bg-overlay` | Scrim behind modals and drawers. Always semi-transparent. |

**Interactive roles**

| Role | Meaning |
|---|---|
| `action-primary` | The single highest-priority action per screen. |
| `action-secondary` | Supporting actions that are not destructive. |
| `action-danger` | Irreversible or high-consequence actions: delete, discharge, override. |
| `action-disabled` | Visually suppressed but must remain accessible as a labeled state, not invisible. |
| `focus-ring` | Keyboard focus indicator. Never shares a value with `action-primary`. Applies to every interactive element without exception. |

**Content roles**

| Role | Meaning |
|---|---|
| `text-primary` | Body copy, data labels, table cells. Highest contrast requirement. |
| `text-secondary` | Captions, metadata, helper text. Still AA-compliant. |
| `text-disabled` | Inactive labels. Must still be readable enough to explain why something is disabled. |
| `text-inverse` | Text on dark fills in light mode; text on light fills in dark mode. |
| `text-link` | Interactive inline text. Distinct from body text by color and underline. |
| `border-default` | Structural borders around containers, inputs, table rows. |
| `border-focus` | Focus ring color. Matches `focus-ring` role. |
| `border-subtle` | Dividers and separator lines. Lower emphasis than default. |

**Status roles**

These are the highest-risk roles in a healthcare context. Each must be distinguishable by more than color alone.

| Role | Meaning | Never use it for |
|---|---|---|
| `status-normal` | Within expected range. Patient stable, value green. | Generic success, form confirmation |
| `status-warning` | Elevated concern. Requires monitoring or follow-up. | Mild UI feedback like unsaved changes |
| `status-critical` | Requires immediate clinical action. Alerts, alarms, out-of-range critical labs. | Any non-clinical urgency |
| `status-info` | Neutral informational context. System messages, guidance. | Positive outcomes |
| `status-neutral` | Unknown or not yet assessed. Pending states. | Normal or OK states |
| `status-bg-normal` / `status-bg-warning` / `status-bg-critical` / `status-bg-info` | Background fills behind status text or badges. Lower saturation variants of the status hues. | Direct text on dark backgrounds without checking contrast |

**Data visualization roles**

Five categorically distinct colors that must be:
- distinguishable from each other at standard screen brightness
- distinguishable by users with deuteranopia and protanopia (the two most common color vision deficiencies)
- not reusing any status color hue, because chart segments should not read as clinical states

| Role | Suggested hue family | Notes |
|---|---|---|
| `data-cat-1` | Blue (primary) | Safe anchor. Most common default. |
| `data-cat-2` | Teal / cyan | Distinct from blue at distance; shifts away from green-red conflict zone. |
| `data-cat-3` | Purple / violet | Holds contrast in dark mode without needing yellow. |
| `data-cat-4` | Orange-amber | Distinct from red; use with a texture or shape backup to separate from `status-warning`. |
| `data-cat-5` | Pink / rose | Distinguishable from red and orange; validates well under deuteranopia simulation. |

Avoid pure red and pure green as categorical series colors in this system. They are reserved for `status-critical` and `status-normal` respectively. Mixing them into a chart color loop creates category-to-status confusion and fails under common color vision deficiencies simultaneously.

---

### Token map

Organize tokens in two explicit layers: **primitive** and **semantic**. Primitives are raw values. Semantics are named aliases that point to primitives. Components consume semantics only, never primitives directly.

**Structure**

```
color.primitive.green.500 = #2D7D46      ← raw value, never used in components
color.primitive.green.200 = #B7DFBF

color.status.normal.fg = color.primitive.green.500    ← semantic alias
color.status.normal.bg = color.primitive.green.200

color.primitive.red.600 = #C0392B
color.primitive.red.100 = #FDDEDE

color.status.critical.fg = color.primitive.red.600
color.status.critical.bg = color.primitive.red.100
```

**Why two layers matter.** If you only have primitive tokens and then hardcode them in components, a system-wide status color change requires touching every component. With a semantic layer, you change one alias and the update propagates everywhere. This is the migration path in section four.

**Required semantic token groups**

```
color.bg.base
color.bg.surface
color.bg.raised
color.bg.sunken
color.bg.overlay

color.action.primary
color.action.primary.hover
color.action.primary.active
color.action.secondary
color.action.danger
color.action.disabled

color.text.primary
color.text.secondary
color.text.disabled
color.text.inverse
color.text.link
color.text.link.visited

color.border.default
color.border.focus
color.border.subtle

color.status.normal.fg
color.status.normal.bg
color.status.warning.fg
color.status.warning.bg
color.status.critical.fg
color.status.critical.bg
color.status.info.fg
color.status.info.bg
color.status.neutral.fg
color.status.neutral.bg

color.data.cat1
color.data.cat2
color.data.cat3
color.data.cat4
color.data.cat5
```

**Dark mode token behavior**

Do not create a separate dark-mode token namespace. Instead, map each semantic token to different primitive values per mode.

```
/* Light mode */
color.bg.base = color.primitive.neutral.050
color.text.primary = color.primitive.neutral.900

/* Dark mode */
color.bg.base = color.primitive.neutral.950
color.text.primary = color.primitive.neutral.050
```

The component sees `color.bg.base` and `color.text.primary` in both modes. The mode switch happens at the token resolution layer, not at the component layer. This keeps components mode-agnostic by default.

---

### Contrast and state rules

**WCAG AA minimums**

| Pairing type | Required ratio |
|---|---|
| Normal text on any background | 4.5:1 |
| Large text (18pt+ or 14pt+ bold) on any background | 3:1 |
| UI components and graphical objects (borders, icons, chart marks) | 3:1 |
| Focus ring against adjacent background | 3:1 minimum, aim for 4.5:1 |

In a healthcare context, voluntarily reaching WCAG AAA (7:1) for body text and clinical data is worth the constraint. A provider misreading a lab value because of low contrast is a patient safety event, not just a UX inconvenience.

**Status color contrast requirements**

Each `status-*.fg` token must pass 4.5:1 against `color.bg.surface` in both light and dark modes before it ships. The status background fills (`status-*.bg`) are not required to meet 4.5:1 against the canvas on their own because they are not text. But any text placed over a status background must still meet 4.5:1 against that specific background fill.

Verify this at the composite pairing level, not just at the token level in isolation.

**The color-only rule**

No status, error, or warning state may rely on color alone to communicate its meaning. This is both a WCAG 1.4.1 requirement and a clinical risk control.

Required secondary signals by component type:

| Component | Required non-color indicator |
|---|---|
| Status badge or pill | Icon or text label inside the badge |
| Alert banner | Leading icon + descriptive text |
| Table row with status | Icon in a dedicated status column; do not rely only on row background color |
| Chart data point or line | Shape marker, line dash pattern, or direct label |
| Form field error | Error message text below the field + border style change |
| Disabled state | Reduced opacity + `aria-disabled` + cursor change |

**State layer rules for interactive elements**

Interactive states cannot rely on color shift alone. Provide a structural or value change paired with the color shift.

| State | Color behavior | Structural behavior |
|---|---|---|
| Default | Token value | None |
| Hover | Lighten or darken by one primitive step | Cursor: pointer |
| Active / pressed | Two primitive steps | Scale or inset shadow |
| Focus | `color.border.focus` ring at 2px minimum | Ring is always visible, even when mouse is active |
| Disabled | `color.action.disabled` fill | `aria-disabled`, reduced opacity, cursor: not-allowed |
| Error | `color.status.critical.fg` border | Error text below input |

**Focus ring rules**

The focus ring must be visible against every background in the system. Use `color.border.focus` paired with a 2px offset so the ring does not blend into the element border it surrounds. In dark mode, verify the focus ring against `color.bg.base` and `color.bg.surface` independently because they often differ.

**Data visualization contrast floor**

Chart categorical colors must meet 3:1 against the chart background (not the page background, the actual plot area fill). In dark mode the chart background is often a slightly elevated surface. Test `data-cat-*` tokens against `color.bg.surface` in both modes.

Adjacent categorical segments in pie or stacked bar charts need a 1px white or neutral separator line when segments share similar luminance. This is the non-color backup for distinguishing segments without relying on hue alone.

---

### Migration notes

A color system migration in a live healthcare SaaS has one overriding constraint: the existing product must stay clinically safe throughout the transition. You cannot put status colors into a half-migrated state where some screens use the old system and others use the new one. A clinician working across screens needs consistent status meaning at all times.

The migration runs in four sequenced phases.

**Phase 1: Primitive token layer (no visible change)**

Introduce the full primitive palette as a token file alongside the existing hardcoded values. No component changes yet. This phase is invisible to users. Its purpose is to give you a stable target for phase 2 and to validate that every primitive you need actually exists before you start aliasing.

Deliverable: primitive token file merged and deployed. Regression: none expected.

**Phase 2: Semantic alias layer (no visible change)**

Map every semantic token to a primitive. At this point, the semantic tokens shadow the old hardcoded values but components have not been updated to consume them yet. Run automated contrast checks across the full semantic-to-primitive matrix now, before any component touches the new tokens.

This phase catches palette problems before a single pixel changes in production.

Deliverable: semantic token file deployed. All pairs passing contrast checks in CI.

**Phase 3: Component migration by criticality (visible changes begin here)**

Migrate components in this order. Do not reverse it.

1. **Status components first.** Alert banners, badges, status pills, clinical alarm indicators. These carry the highest safety weight. Migrate them first so the clinical meaning of the color system is correct before everything else is updated.
2. **Text and background tokens.** Body text, headings, surface backgrounds. Wide impact but low clinical risk.
3. **Interactive components.** Buttons, links, inputs, focus rings.
4. **Data visualization.** Chart colors last because they often require the most manual verification against real dashboard data.

For each component: update token reference, verify contrast in both modes, verify non-color indicator is present, run accessibility audit on the component in isolation before releasing it to the full layout.

Migrate one component group per sprint. Do not bundle status components with anything else.

**Phase 4: Deprecation and cleanup**

After all components have migrated to semantic tokens, remove the old hardcoded color values from the codebase. Add a lint rule that prevents any future component from consuming primitive tokens directly. The lint rule is the enforcement mechanism that keeps the semantic layer intact after migration is complete.

Audit the deployed product for any remaining hardcoded hex values using a regex sweep. In healthcare SaaS, a stale hardcoded red that looks like `status-critical` but is not connected to the token system is a patient safety liability, not just a design debt item.

---

**One tradeoff to name explicitly.** Keeping status hues completely separated from data visualization categorical colors reduces the available hue range for charts. Orange-amber and blue-teal are doing double duty as safe chart colors while staying clear of red-green clinical status territory. This means the chart palette is somewhat constrained. You gain clinical clarity and color-vision-deficiency safety; you accept a more limited hue spread for categorical data. If the product later needs more than five categorical series, add them using lightness and saturation variations of existing hues rather than reaching into the status color space.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_roles: bg, action, text, border, status, data-vis defined as named layers",
    "state_mapping: hover/active/focus/disabled each carry structural non-color backup",
    "contrast_boundary: WCAG AA 4.5:1 for text, 3:1 for UI components and chart marks, AAA recommended for clinical data text",
    "migration_strategy: 4-phase primitive-first, status-components-migrated-first, hardcoded-removal-last"
  ],
  "evidence_classes_cited": [
    "wcag_1_4_1_color_not_sole_means",
    "wcag_aa_contrast_thresholds",
    "deuteranopia_protanopia_safe_palette_heuristics",
    "semantic_token_alias_architecture"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What is the current palette — are status colors already hue-based or icon-based?",
    "Is there an existing design token file, or are colors hardcoded throughout?",
    "Does the product need to support high-contrast mode beyond WCAG AA?"
  ],
  "turn": 1
}
[/SESSION_STATE]