## Access failure framing

This audit covers four described interface patterns. No screenshot was provided, so all findings are drawn from the stated design descriptions. Confidence is high for the barrier classifications because each pattern is a well-documented failure class with clear WCAG mapping. Confidence is medium for severity ranking because actual interaction flows, screen sizes, and platform (iOS/Android/web) are unspecified.

The four patterns each block a distinct user group in a distinct way. None of these are cosmetic. All four reach WCAG 2.1 Level AA.

---

## Barrier inventory

### Barrier 1 — Icon-only bottom navigation (no labels)
**WCAG rule:** 1.1.1 Non-text Content (Level A) · 4.1.2 Name, Role, Value (Level A)

**What fails:** Icon buttons without visible text or a programmatic accessible name have no meaning to screen reader users. VoiceOver and TalkBack will either announce nothing, announce a file name, or announce a generic "button" depending on whether the icons are images or SVG. Even for sighted users with cognitive disabilities, icon-only navigation relies entirely on visual convention, which is not universally shared.

**Who is blocked:** Blind users cannot determine which tab they are activating. Users with cognitive or memory impairments cannot reliably identify navigation destinations. Users new to the app have no affordance discovery path.

**Severity: Critical.** Navigation is the primary wayfinding system. A blocked navigation bar blocks access to every screen in the app.

---

### Barrier 2 — Placeholder text as label substitute
**WCAG rule:** 1.3.1 Info and Relationships (Level A) · 2.4.6 Headings and Labels (Level AA) · 3.3.2 Labels or Instructions (Level A)

**What fails:** Placeholder text disappears on input focus. Once the user begins typing, the label is gone. Screen readers may or may not announce placeholder text as a label depending on the platform and browser, and the behavior is inconsistent across assistive technology. Placeholder text also typically renders at low contrast (often around 3:1 or below), which fails against the 4.5:1 text contrast requirement for placeholder strings that function as instructions.

**Who is blocked:** Screen reader users lose field context mid-entry. Users with short-term memory difficulties cannot check what a field requires once they have started typing. Low-vision users often cannot see placeholder text at all before focus. Voice control users (Dragon NaturallySpeaking, Voice Control on iOS) may not be able to target the field by spoken name because the accessible name is absent or derived from placeholder only.

**Severity: Critical.** Forms are task-completion surfaces. A user who cannot identify fields cannot complete the form.

---

### Barrier 3 — Red-only error messages
**WCAG rule:** 1.4.1 Use of Color (Level A) · 3.3.1 Error Identification (Level A)

**What fails:** Conveying error state through color alone fails 1.4.1 explicitly. A user who cannot distinguish red from adjacent colors (roughly 8 percent of males have red-green color deficiency) receives no signal that an error exists. The message text may still be present, but if the only cue that something is wrong is the red color of that text, the error is not meaningfully communicated.

**Who is blocked:** Color-blind users, specifically those with deuteranopia or protanopia, are the primary affected group. Additionally, if error messages are injected dynamically and are not announced by a live region, screen reader users will not hear the error unless they navigate back to find it, making this a dual failure.

**Severity: High.** Error messages that are invisible to some users corrupt form recovery. Users will not know a submission failed, cannot identify which field failed, and cannot correct the error.

---

### Barrier 4 — Unanounced loading spinner
**WCAG rule:** 4.1.3 Status Messages (Level AA) · 1.3.1 Info and Relationships (Level A)

**What fails:** A visual spinner with no accessible state announcement means screen reader users receive no feedback that an action is in progress. From a blind user's perspective, tapping a button and receiving silence is indistinguishable from the app freezing, the action failing, or the action completing silently. Without a live region (`aria-live` on web, or `UIAccessibilityPostNotification` / `AccessibilityEvent.TYPE_ANNOUNCEMENT` on native), the spinner is invisible to assistive technology.

**Who is blocked:** Blind and low-vision users who rely on audio feedback cannot determine whether their action registered. This affects any async operation: form submissions, data loads, search, uploads.

**Severity: High.** The user cannot distinguish between working, frozen, and complete. This erodes trust and forces repeated taps, which can cause duplicate submissions.

---

## Repair priorities

Ordered by severity and blocking scope. Fix in this sequence because earlier failures block more users from completing core tasks.

### Priority 1 — Repair bottom navigation labels

**What to do:** Add a visible text label beneath each icon. Do not rely on `aria-label` alone as a substitute for visible labels, because visible labels serve sighted users with cognitive disabilities and benefit all users. If design constraints force icon-only at smaller breakpoints, provide a `tooltip` or `title` that surfaces the name on hover/focus, and ensure each button has a robust `aria-label` or `accessibilityLabel` that matches the visible destination name.

**Implementation specifics:**
- Web: each `<button>` in the nav should contain an `<svg>` plus a `<span>` with the label text. The span can be visually small but must not be visually hidden with `display:none` or `visibility:hidden`.
- iOS native: set `accessibilityLabel` on each `UITabBarItem`. Prefer labels that match the tab's destination name exactly.
- Android native: use `android:contentDescription` on each tab item. Ensure `Tab` items in Jetpack Compose use `Modifier.semantics { contentDescription = "..." }`.

**Why this is first:** Navigation is the prerequisite for everything else. A user who cannot navigate cannot encounter the form errors or spinners.

---

### Priority 2 — Replace placeholder-as-label with persistent visible labels

**What to do:** Add a `<label>` element (web) or equivalent platform label (iOS: `UILabel` paired with `accessibilityLabel` on the field; Android: `hint` plus a visible `TextInputLayout` label) that persists above the input at all times. The placeholder can remain as supplementary hint text, but it cannot be the only label.

**Implementation specifics:**
- Web: `<label for="field-id">` explicitly associated with `<input id="field-id">`. Never use `aria-placeholder` as a label substitute.
- If a floating label pattern is used (label starts inside the input and moves up on focus), verify the animation does not violate `prefers-reduced-motion` and that the label is announced correctly by VoiceOver and TalkBack before and after focus.
- Placeholder text that functions as an example value (e.g., "e.g. name@email.com") is acceptable supplementary content, but the persistent label must still be present.

**Contrast note:** Once true labels are in place, verify the label text itself meets 4.5:1 against its background (WCAG 1.4.3). Placeholder hint text that is supplementary and not the sole instruction must still meet 3:1 minimum; exceeding 4.5:1 is safer.

---

### Priority 3 — Add non-color error indicators and live-region announcement

**What to do:** Pair every error message with a redundant non-color indicator. The minimum is an icon (a filled warning or exclamation symbol) placed adjacent to the error text. The icon must have an accessible label or be treated as decorative if the text already communicates the error fully.

Additionally, error messages injected dynamically must be announced. On web, wrap the error container in `aria-live="assertive"` or use `role="alert"`. On iOS, use `UIAccessibilityPostNotification(.announcement, ...)` after error injection. On Android, use `ViewCompat.setAccessibilityLiveRegion(view, ViewCompat.ACCESSIBILITY_LIVE_REGION_ASSERTIVE)`.

**Why both repairs are needed here:** Color fixes 1.4.1 for color-blind sighted users. The live region fixes 4.1.3 for screen reader users. These are separate failure modes with the same error message as the surface.

**Do not:** Make the icon the only error indicator. Icon plus text plus color is the correct redundant triplet.

---

### Priority 4 — Announce loading spinner state

**What to do:** When a spinner appears, announce the loading state to assistive technology. When the spinner resolves (success or failure), announce the outcome.

**Implementation specifics:**
- Web: use a visually hidden live region (`aria-live="polite"` for normal loads, `aria-live="assertive"` for error outcomes) that receives a text update when the spinner state changes: "Loading", "Content loaded", or "Failed to load, please try again."
- iOS: call `UIAccessibilityPostNotification(.announcement, "Loading")` when the spinner appears and announce the result on completion.
- Android: update a `TextView` with `ACCESSIBILITY_LIVE_REGION_POLITE` set on it when state changes.
- Use `polite` for expected background loads. Use `assertive` only for errors or situations requiring immediate user action, because `assertive` interrupts ongoing speech.

**Do not** use `aria-busy` alone as the announcement mechanism on web. While `aria-busy="true"` on a container suppresses its subtree from announcement, it does not itself announce a loading state to users on all screen reader and browser combinations.

---

## Verification method

### Icon-only navigation
- **VoiceOver (iOS):** navigate to the bottom bar with swipe. Each tab should announce its name followed by "tab" or "button." If VoiceOver announces the image file name or says only "button," the accessible name is missing or wrong.
- **TalkBack (Android):** explore by touch across the navigation bar. Each item should announce its label. Use the TalkBack verbosity settings to confirm the role is announced.
- **Keyboard (web):** tab into the navigation bar. Each focused button should show a visible focus ring and the accessible name should be announced by a screen reader. Run an axe or Lighthouse audit to catch missing accessible names automatically.

### Persistent labels on forms
- **VoiceOver / TalkBack:** navigate to the form. Focus each input. The announced name should match the visible label and should not change or disappear when you begin typing.
- **Manual visual check:** begin entering text in each field. Confirm the label remains visible above the input at all times.
- **Automated:** axe-core will flag `<input>` elements with no associated `<label>`. Run axe in browser devtools or CI.

### Error messages
- **Color-blind simulation:** use Figma's color-blind simulation plugin, Stark, or Chrome DevTools' vision deficiency emulator set to deuteranopia. Confirm errors are still clearly distinguishable.
- **Screen reader:** submit a form with an intentional error. Without navigating, wait three to five seconds. VoiceOver or TalkBack should announce the error automatically via the live region. If it does not, the live region is missing or not firing.
- **Keyboard-only (web):** confirm the error message receives focus or is in the logical reading order immediately after the invalid field.

### Loading spinner
- **VoiceOver / TalkBack:** trigger an action that produces the spinner. Within one to two seconds, the screen reader should announce "Loading" or an equivalent string without the user navigating. On completion, the result should be announced.
- **Automated (web):** check that the live region element exists in the DOM before the spinner appears, not injected with it. Live regions injected at the moment of the announcement are not reliably picked up by all screen readers. The region should pre-exist in the DOM with empty content, then receive text updates.
- **Manual timing check:** measure the delay between spinner appearance and announcement. If it exceeds two to three seconds, the live region update may be firing too late or the region may have been injected rather than pre-existing.

---

## Summary of what is preserved vs. what changes

Fixing these barriers preserves the current visual design, color palette, icon language, and layout. What changes is the addition of text labels, the introduction of persistent label elements above inputs, the addition of a small error icon, and three or four invisible live region nodes in the DOM or accessibility tree. The visual weight increase is small. The information surface for all users, including sighted users glancing at the screen in low-attention contexts, improves. You sacrifice nothing of design intent. You sacrifice the assumption that the visual surface is the complete interface.

[SESSION_STATE]
{
  "route": "rt_accessibility_feedback_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "barrier_severity: icon-only nav = critical, placeholder-as-label = critical, color-only errors = high, unanounced spinner = high",
    "wcag_rule: 1.1.1, 4.1.2, 1.3.1, 2.4.6, 3.3.2, 1.4.1, 3.3.1, 4.1.3",
    "repair_priority: navigation first, then labels, then errors, then spinner",
    "verification_method: VoiceOver, TalkBack, keyboard, axe-core, color-blind simulation, live-region pre-existence check"
  ],
  "evidence_classes_cited": [
    "wcag_threshold",
    "platform_implementation_rule",
    "color_contrast_threshold",
    "live_region_behavior_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Platform (web, iOS, Android, or hybrid) not specified — implementation specifics may need narrowing per platform",
    "Whether error messages are dynamically injected or present on page load affects live region strategy"
  ],
  "turn": 1
}
[/SESSION_STATE]