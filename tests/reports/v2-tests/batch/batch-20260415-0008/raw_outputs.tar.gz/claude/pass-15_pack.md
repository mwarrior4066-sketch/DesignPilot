## Backend Architecture Spec

### System framing

This is a multi-tenant B2B scheduling platform where the unit of isolation is a **team workspace**, not a user account. The combination of approval workflows, outbound webhooks, and eventual customer automation rules means the system must treat eventing as a first-class architectural concern — not a background-job afterthought bolted onto REST APIs.

The current stack (REST + relational DB, inconsistent jobs and eventing) can survive as the foundation, but the inconsistency in eventing is the single most dangerous gap. Approval workflows and outbound webhooks both require durable, ordered, retryable event delivery. Cursor-based activity feeds require an append-only ordered log. Regional data residency requires tenant data to be bounded at the storage level, not just filtered at the query level. These four requirements converge on the same architectural decision: **event log first, delivery second**.

Escalation level: **compound** — multi-constraint, multi-layer, proof-sensitive on residency and audit.

---

### Core model and authority boundaries

#### Tenant and workspace model

The fundamental authority unit is the **workspace**. A workspace belongs to exactly one tenant, lives in exactly one region, and owns its data boundary entirely. Cross-workspace data access does not exist at the application layer — only at the platform layer for billing and support, with explicit authorization gates.

```
Platform
└── Tenant (billing entity)
    └── Workspace (data isolation unit, pinned to a region)
        ├── Members (roles: owner / admin / member / guest)
        ├── Schedules
        ├── Events (scheduled items)
        ├── Approval workflows
        ├── Activity feed log
        ├── Webhook endpoints
        └── Automation rules (future)
```

Every database row carrying business data carries `workspace_id`. No query may omit it. The validator that enforces this is not optional middleware — it is the query layer itself. Any service that can run a query without `workspace_id` in scope is a design failure.

#### Regional data residency

Residency is a storage commitment, not a routing rule. The platform must physically place workspace data in the declared region and must not replicate it out.

Enforcement model:
- Each region runs an independent database cluster. There is no cross-region replication of tenant data.
- A routing layer (thin, stateless) receives the request, reads the workspace's region from a global control-plane registry, and proxies or redirects to the correct regional cluster.
- The global control plane holds only: workspace ID, region assignment, tenant ID, plan tier, and suspension status. It holds no scheduling or business data.
- Background job queues are also region-local. A job enqueued for a workspace in EU-West executes in EU-West and writes only to EU-West storage.

**Blocking constraint:** if the current relational DB is a single global instance, regional residency requires a migration plan before any residency guarantees can be published to customers. This is not a runtime configuration — it requires a data-layer split.

#### Authorization model

Deny by default. Every API surface checks:

1. **Authentication:** valid session or service token
2. **Tenant membership:** caller belongs to a tenant that owns this workspace
3. **Workspace membership:** caller is a member of this specific workspace
4. **Object-level authorization (BOLA check):** caller's role permits this action on this specific resource

Only workspace owners may invite members, modify webhook endpoints, or delete the workspace. Only admins and above may create or modify approval workflows. Members may create and edit schedules within their permission scope. Guests have read-only access unless explicitly elevated per resource.

No role inference from adjacent workspaces. A member of Workspace A has zero implicit access to Workspace B, even within the same tenant.

---

### Data, consistency, and delivery design

#### Event log as the backbone

The core insight that resolves inconsistent jobs and eventing: treat the **activity log as the system of record for what happened**, not as a side effect of what the application wrote to the main table.

Every state-changing operation in the system — schedule created, event updated, approval requested, approval granted or rejected, webhook delivered, automation rule triggered — appends an entry to a workspace-scoped event log before (or atomically with) the state change it describes.

The event log is:
- **append-only** (no updates, no deletes)
- **ordered** by a monotonic sequence per workspace (a 64-bit integer sequence, not a timestamp — clocks lie)
- **durable** before the HTTP 200 returns
- **the source of truth for the activity feed, audit trail, and webhook fan-out**

Implementation options in order of operational preference:
1. A `workspace_events` table in the existing relational DB with a per-workspace sequence counter, using a serializable or select-for-update lock on the sequence row. Simple. Works at moderate scale. Migrates forward.
2. A dedicated event log service (Postgres with partitioning by workspace, or a managed stream like Kafka with compaction) when write volume outgrows option 1.

Do not use option 2 before you need it. The complexity cost is real.

#### Cursor-based activity feeds

The activity feed is a read projection over the event log. Cursors are opaque tokens that encode the last-seen sequence number for a workspace. The API returns a page of events and a `next_cursor`. The client presents the cursor on the next call. No offset pagination — offsets are unstable under concurrent writes.

Contract:
```
GET /workspaces/{id}/feed?cursor={token}&limit=50
→ { events: [...], next_cursor: "...", has_more: bool }
```

Cursor token format (internal, base64-encoded):
```json
{ "workspace_id": "...", "seq": 1042, "region": "eu-west" }
```

The cursor is workspace-scoped and region-pinned. A cursor from EU-West cannot be used against US-East. Return `400` with an RFC 9457 problem detail if the region in the cursor does not match the request routing target.

Consistency stance: **read-your-own-writes within a workspace session**. A write that returns 200 is guaranteed to appear in the feed on the next cursor poll. Cross-workspace consistency is not a requirement and is explicitly out of scope.

#### Approval workflows

Approval workflows are state machines, not ad-hoc status fields.

States:
```
draft → pending_approval → approved | rejected | expired
```

Transitions are events in the event log. The workflow engine is not a separate microservice at this scale — it is a set of transition functions in the application layer, guarded by database row-level locks on the workflow record, producing event log entries atomically.

Rules:
- Only the workflow definition's declared approvers may approve or reject. Object-level authorization applies.
- Approvals are idempotent: submitting a second `approve` for the same workflow instance that is already `approved` returns `200` with the current state, not an error.
- Expiry is enforced by a background job that scans for `pending_approval` workflows past their deadline and transitions them to `expired` with an event log entry. This job is idempotent and safe to retry.
- Rejection must include a reason field (required, not optional) — this feeds the audit trail.

#### Outbound webhooks

Webhooks are the highest-risk delivery surface. They fail in ways REST APIs do not: the customer's endpoint may be down, slow, or misconfigured, and failure must not block the platform.

Delivery model:
1. When a qualifying event enters the event log, the webhook fan-out worker picks it up asynchronously.
2. The worker consults the workspace's registered webhook endpoints and their event filter subscriptions.
3. For each matching endpoint, the worker enqueues a **delivery attempt record** in a `webhook_deliveries` table: `{ delivery_id, endpoint_id, event_id, status: queued, attempt_count: 0, next_attempt_at }`.
4. A delivery executor pulls queued deliveries and makes the HTTP POST to the customer endpoint.
5. On success (2xx): mark delivery `completed`, record response time and status.
6. On failure (non-2xx, timeout, DNS failure): apply exponential backoff with jitter, increment attempt count, update `next_attempt_at`, re-queue.
7. After N failed attempts (recommend: 5), mark delivery `exhausted`, emit a platform event to notify workspace admins, stop retrying.

**Idempotency contract:** every webhook payload carries a `delivery_id` that is stable across retry attempts. Customer endpoints should use it to deduplicate. Document this requirement explicitly in the customer-facing webhook spec.

Payload envelope:
```json
{
  "delivery_id": "dlv_01HX...",
  "event_type": "schedule.approved",
  "workspace_id": "ws_...",
  "sequence": 1042,
  "occurred_at": "2025-01-15T09:41:00Z",
  "payload": { ... }
}
```

HMAC-SHA256 signature in the `X-DesignPilot-Signature` header using a per-endpoint signing secret. Rotate signing secrets without downtime by supporting a dual-secret grace window during rotation.

**Circuit breaker:** if an endpoint accumulates more than 10 consecutive failures within a 1-hour window, pause delivery to that endpoint automatically and notify workspace admins. Resume delivery when an admin acknowledges and retests the endpoint. Do not silently drop events during the pause — buffer them (up to a defined limit) and replay on resume.

#### Background job architecture

The current inconsistency in background jobs needs a single fix: **one durable job queue, not multiple ad-hoc mechanisms**. The relational DB can serve as the queue substrate at current scale using a table-based job queue (pg-boss, River, Faktory, or equivalent). This avoids introducing a new infrastructure dependency before it is warranted.

Job categories:
| Category | Examples | Execution model |
|---|---|---|
| Workflow expiry sweep | expire overdue approvals | Scheduled, idempotent, per-region |
| Webhook fan-out | pick up new events, enqueue deliveries | Triggered by event log watermark |
| Delivery executor | execute queued webhook deliveries | Poll-based, concurrent, retryable |
| Audit compaction | summarize old log segments for reporting | Scheduled, low-priority |
| Automation rules (future) | evaluate rules against events | Event-triggered, sandboxed |

Every job records: `job_id`, `workspace_id`, `type`, `status`, `attempt_count`, `last_error`, `started_at`, `completed_at`. This is not optional — it is the operational floor for debugging delivery failures and audit queries.

#### Audit trail

The event log is the audit trail. It is not a separate system. The distinction is the **retention and query contract**:

- The live event log supports cursor pagination and feed rendering for recent activity (90-day hot window recommended).
- The audit trail is a queryable archive of all events for the lifetime of the workspace, compressed, indexed by actor, resource type, and time range.
- Archive writes happen via the background job layer (audit compaction) — they move events older than the hot window to cheaper storage while keeping them queryable.

Required fields on every audit entry: `actor_id`, `actor_type` (user / service / automation), `workspace_id`, `event_type`, `resource_id`, `resource_type`, `occurred_at`, `sequence`, `region`, `ip_address` (for user-actor events), `request_id`.

Audit entries are immutable at the storage level. No application path may delete or update them. Support staff access to audit logs requires a separate elevated authorization path, logged separately.

---

### Data, consistency, and delivery design: automation rules (future boundary)

Define the boundary now even though the feature ships later. This prevents the existing system from accumulating patterns that automation rules cannot use.

Automation rules will be: **if [event matches condition] then [execute action]**.

The integration point is the event log. When automation rules ship, the rule engine is a subscriber to the event log — exactly like the webhook fan-out worker. It evaluates rules against incoming events, enqueues actions as jobs, and records rule evaluation results as events in the same log.

**Do not let automation rules execute synchronously in the API request path.** Async-only. This means: the API that creates a schedule does not block on rule evaluation. The rule evaluates after the event is persisted.

For customer-defined rules, the execution sandbox must:
- be isolated per workspace
- have a defined CPU and memory budget
- produce a structured result (action taken / action skipped / error) recorded in the event log
- not have direct database access — it interacts only through the same API surface customers use

Define these constraints in the rule-engine contract before the feature is designed, not after.

---

### Observability and failure posture

#### Required instrumentation

Every service boundary emits:
- `trace_id` on all errors — present in response bodies (RFC 9457 `extensions.trace_id`), logs, and metrics
- Request latency histograms by route and workspace tier
- Queue depth and age for the job queue and delivery queue
- Webhook delivery success rate, failure rate, and exhausted-delivery count per workspace
- Event log write latency and sequence lag
- Approval workflow completion time by outcome (approved / rejected / expired)

#### Failure semantics contract (RFC 9457)

All error responses use RFC 9457 problem detail format:
```json
{
  "type": "https://api.example.com/problems/workflow-not-approvable",
  "title": "Workflow cannot be approved in its current state",
  "status": 409,
  "detail": "Workflow ws_abc/wf_123 is in state 'approved'. Only pending_approval workflows accept approval actions.",
  "instance": "/workspaces/ws_abc/workflows/wf_123",
  "extensions": {
    "trace_id": "t_01HX...",
    "current_state": "approved",
    "workspace_id": "ws_abc"
  }
}
```

This is not an aesthetic choice. Structured errors are what webhook consumers, automation rules, and support tooling parse. Inconsistent error formats multiply the cost of every integration.

#### Graceful degradation posture

| Failure | Behavior |
|---|---|
| Event log write fails | API returns 500; no state change committed (atomic with event log write) |
| Webhook endpoint unreachable | Buffer, retry with backoff; do not fail the scheduling operation |
| Job queue unavailable | API writes succeed; queue recovery resumes delivery when queue restores |
| Regional DB unreachable | Return 503 with `Retry-After`; do not route to a different region's data |
| Approval expiry job delayed | Workflows expire on the next successful job run; SLA definition must account for job delay |
| Automation rule evaluation error | Log the error, skip the action, emit a rule-failure event; do not block the triggering operation |

The governing principle: **scheduling operations must not fail because a downstream delivery mechanism fails**. The event log decouples them. Deliver reliably or degrade visibly — never silently drop.

---

### Migration path from the current stack

The current REST + relational DB baseline does not need to be replaced. The path is additive:

1. **Add the event log table** (append-only, workspace-scoped sequence). Wire all state-changing endpoints to write atomically to it. This takes the inconsistent job/event behavior off the critical path immediately.
2. **Consolidate background jobs** onto one durable queue using the relational DB as the substrate. Remove ad-hoc job mechanisms.
3. **Build the webhook delivery pipeline** against the event log watermark. This replaces any existing ad-hoc webhook calls.
4. **Implement the routing layer** and regional DB split. This is the highest-cost step and should be scoped as its own migration with a per-workspace migration tool and a freeze window.
5. **Implement cursor-based activity feed** as a read projection over the event log. Retire any existing activity feed that reads from mutable state.
6. **Instrument** before step 4, not after. Residency migration without observability is a compliance risk, not just an operational one.

Do not attempt steps 4 and 5 concurrently. The regional split changes the substrate that the feed projection reads from, and they need independent verification.

---

### Named tradeoffs

**Event log in the relational DB vs. a dedicated stream:** you gain operational simplicity and zero new infrastructure at the cost of write throughput limits. At the scale described, the relational DB is the right choice. If write volume exceeds roughly 5,000 event log inserts per second sustained, revisit.

**Table-based job queue vs. a managed broker:** same logic. Table-based queues (pg-boss, River) are significantly easier to operate, debug, and migrate. You sacrifice throughput ceiling and some advanced fan-out patterns in exchange for one fewer infrastructure dependency.

**Synchronous webhook fan-out (simpler) vs. async delivery pipeline (specified here):** synchronous fan-out is a reliability trap. One slow customer endpoint blocks your delivery thread. The async pipeline specified here means accepting a small delivery latency in exchange for complete delivery decoupling from your scheduling write path.

**Regional DB split (correct) vs. filtered single global DB (wrong):** filtering is not residency. A customer in an EU workspace whose