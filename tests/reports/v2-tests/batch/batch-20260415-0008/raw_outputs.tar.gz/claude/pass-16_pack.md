## Failure semantics and error contract

The single most visible problem is that the endpoint returns HTTP 200 for every response, including errors. This destroys the HTTP contract entirely. A client receiving 200 cannot distinguish a successful PDF from a server error without parsing the response body and knowing the internal error schema — which itself changes when you rename an enum. Every retry mechanism, load balancer health check, monitoring alert, and upstream orchestrator built on standard HTTP semantics will be blind to failures here.

**What to replace it with:**

Use RFC 9457 Problem Details for every error response. The structure is:

```json
{
  "type": "https://api.example.com/problems/export-limit-exceeded",
  "title": "Export limit exceeded",
  "status": 429,
  "detail": "You have reached the maximum of 10 concurrent exports for your plan.",
  "instance": "/exports/req_abc123"
}
```

Status codes must map to actual conditions:

| Condition | Status |
|---|---|
| Accepted and queued | 202 |
| Validation failure | 400 |
| Auth missing or invalid | 401 |
| Resource access denied | 403 |
| Idempotency key conflict | 409 |
| Rate limit or plan quota | 429 |
| Export generation failure | 500 |
| Dependency timeout | 503 |

The `type` field must be a stable, versioned URI — not an internal enum value. The internal enum leaking into error messages (`EXPORT_FAILED_REASON_PDF_RENDERER_TIMEOUT`) couples your clients to internal implementation detail. When you rename the enum, you break any client that branches on the error string. Expose only the `type` URI and a human-readable `detail`. Map internal enums to stable `type` URIs in a private translation layer.

---

## Authorization and resource protection

A PDF export endpoint typically touches sensitive data — user records, financial summaries, or organizational data depending on the product. The access control surface here is larger than it looks.

**Object-level authorization is the critical gap.** The request likely includes parameters identifying whose data to export: a report ID, a date range, an org scope. Every one of those parameters must be checked against the authenticated session at the object level, not just at the route level. A user authenticated to access the API is not automatically authorized to export any report they can construct a request for. Deny by default: if the session cannot be confirmed to own or have explicit permission over the export target, return 403 before the job starts — not after the PDF is generated.

**The permission model needs three checks:**

1. Is the session authenticated? If not, 401.
2. Does the session have export permission? If not, 403 at the route level.
3. Does the session have access to the specific data being exported? If not, 403 at the object level. This check must happen before any data is loaded.

**Scope creep via parameter manipulation is a BOLA risk.** If the request accepts something like `org_id`, `user_id`, or `report_id` as a body parameter, verify that the authenticated user is the session owner or holds an explicit grant for that resource. A missing object-level check here is a Broken Object Level Authorization (BOLA) vulnerability — the most common API security failure class.

**Export size and rate limits are also a security surface, not just a reliability concern.** An unenforced export endpoint is an amplification vector: one request can trigger significant CPU, memory, and I/O load. Enforce per-user and per-tenant concurrent export limits. Return 429 when limits are hit. The limit should be checked before the job is accepted, not after work has begun.

---

## Idempotency and async lifecycle

A synchronous 3-minute blocking endpoint is not a viable production contract. This is the architectural failure that makes the other problems worse.

**The async rewrite is not optional.** A request that blocks for 3 minutes will be retried by every HTTP client with a default timeout. Each retry creates a new export job. You have no idempotency contract, so there is no mechanism to detect or deduplicate those retries. The result is duplicate jobs consuming the same expensive compute, potentially generating duplicate PDFs, and creating a thundering-herd failure mode under any load spike.

**The correct contract:**

On POST /exports, accept the request, validate parameters, run authorization checks, and return immediately:

```
HTTP 202 Accepted
Location: /exports/jobs/job_xyz789
Retry-After: 30
```

```json
{
  "job_id": "job_xyz789",
  "status": "queued",
  "status_url": "/exports/jobs/job_xyz789",
  "estimated_completion_seconds": 90
}
```

The job lifecycle has terminal states: `queued → running → completed | failed`. Every state transition is queryable at the status URL. On `completed`, the status response includes a time-limited, pre-signed download URL for the PDF — not a direct link to a permanent storage path. On `failed`, the status response includes a Problem Details body explaining the failure without leaking internal enums.

**Idempotency key contract:** Require an `Idempotency-Key` header on POST /exports. Store the key with the job on first receipt. On a duplicate request with the same key, return 409 Conflict if the job is still running, or return the original 202 response body if the job completed. The idempotency window should be at least as long as the maximum plausible retry window — 24 hours is a reasonable default for export jobs.

```
Idempotency-Key: client-generated-uuid-v4
```

On duplicate detection:

```
HTTP 409 Conflict
```

```json
{
  "type": "https://api.example.com/problems/duplicate-request",
  "title": "Duplicate export request",
  "status": 409,
  "detail": "A job with this idempotency key is already in progress.",
  "instance": "/exports/jobs/job_xyz789"
}
```

This eliminates duplicate jobs from client retries without requiring the client to track job state before the first response.

---

## Resilience and observability

**The synchronous model concentrates failure.** When the PDF renderer is slow or unavailable, every in-flight request blocks a connection. Under any meaningful load, this exhausts the connection pool before the first timeout fires. Moving to async decouples acceptance from execution — the connection closes at 202, and the renderer failure is isolated to the job queue.

**Circuit breaker on the PDF renderer dependency.** The renderer is an internal or external dependency that can degrade independently. Without a circuit breaker, a slow renderer causes cascading timeouts across all export requests. With a circuit breaker, after a threshold of renderer failures, new jobs are rejected immediately at 503 with a `Retry-After` header rather than blocking until timeout.

**Exponential backoff with jitter for internal retries.** If the job worker retries a failed render attempt, use exponential backoff with jitter — not a fixed interval. Fixed retries synchronize across workers and amplify load on a degraded dependency. The jitter breaks that synchronization.

**Every request needs a trace ID.** Assign a `trace_id` at the point of acceptance and include it in:
- The 202 response body
- Every job status response
- Every error response (as the `instance` field or a dedicated field)
- Every internal log line related to the job
- The PDF filename or metadata if supportable

This is the minimum requirement for debugging a report failure without asking the user to describe what they did. A user who can give you their job ID or trace ID makes every support conversation shorter and every incident faster to resolve.

**Structured logging with consistent fields.** Every log line for an export job should include at minimum: `trace_id`, `job_id`, `user_id`, `tenant_id` (if applicable), `status`, `duration_ms`, and `error_type` if applicable. Free-text log messages with embedded context make aggregate failure analysis impossible.

**Timeout contract must be explicit, not ambient.** Define a hard timeout for the render worker — not the HTTP connection. The worker should emit a `failed` terminal state with a `render_timeout` error type when the renderer exceeds the SLA. The client should never be the one discovering the timeout by waiting.

---

## Summary of required changes

| Problem | Fix | Priority |
|---|---|---|
| HTTP 200 for all responses | RFC 9457 status codes mapped to actual conditions | Blocking |
| Synchronous 3-minute block | 202 + async job lifecycle with status URL | Blocking |
| No idempotency key | `Idempotency-Key` header, 409 on duplicate | Blocking |
| Internal enum leaking in errors | Stable `type` URIs, private translation layer | Blocking |
| No object-level authorization | BOLA check before data load, deny by default | Blocking |
| No circuit breaker on renderer | Circuit breaker with 503 + `Retry-After` | High |
| No trace ID propagation | `trace_id` on all responses and logs | High |
| No rate or concurrency limit | Per-user/tenant limits enforced at acceptance | High |
| Fixed retry intervals | Exponential backoff with jitter in job worker | Medium |
| Unstructured logs | Structured logs with consistent field schema | Medium |

[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "failure_semantics: RFC 9457 Problem Details with stable type URIs",
    "status_codes: 202 accepted, 400 validation, 401 auth, 403 access, 409 idempotency conflict, 429 rate limit, 500 generation failure, 503 dependency timeout",
    "async_job_model: 202 Accepted + status URL, terminal states queued→running→completed|failed",
    "idempotency_contract: Idempotency-Key header required, 409 on duplicate, 24-hour window",
    "authorization_perimeter: object-level BOLA check before data load, deny by default",
    "resilience_strategy: circuit breaker on renderer, exponential backoff with jitter, trace_id on all responses and logs"
  ],
  "evidence_classes_cited": [
    "RFC 9457 problem details contract",
    "BOLA authorization pattern",
    "202 Accepted + status URL async pattern",
    "circuit breaker pattern",
    "exponential backoff with jitter",
    "idempotency-key header contract",
    "409 on duplicate"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]