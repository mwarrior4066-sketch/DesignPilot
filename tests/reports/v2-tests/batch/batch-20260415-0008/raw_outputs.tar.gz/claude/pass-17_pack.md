## Functional tier

State is how your app remembers things: which user is logged in, what's in the cart, whether a panel is open. Every piece of state needs to live *somewhere*, and the question is whether that somewhere is a shared global store (Redux) or the individual components and their local connections (local state plus React Context).

**The practical difference:** Redux creates one central place where any component in the app can read or update data. Local state plus Context means each component or small group of components manages its own data, and you only share it upward or downward when something nearby needs it.

**When local state is the right call:** If a dropdown knows whether it is open or closed, only that dropdown needs to know. If a form tracks what the user is typing, that form owns that data. Keeping state close to where it is used makes the app easier to change, because a bug in one place does not ripple into ten other places.

**When a global store helps:** If your app has a shopping cart that shows up in the header, the checkout page, and a confirmation screen, all three places need the same data. A global store makes that sharing straightforward. The same logic applies to the currently logged-in user, notification counts, or a permissions model that dozens of components check.

**Governing recommendation:** Use local component state as the default for UI behavior and form state, add React Context only when a small group of components needs to share data, and introduce Redux only if your app has genuinely shared cross-cutting data that cannot be co-located without prop drilling four or more levels deep.

---

## Integrative tier

The real question is not Redux versus Context, but where each piece of state *belongs* and who has the authority to change it. Getting this wrong creates one of two problems: unnecessary complexity (a global store managing which tab is selected) or invisible coupling (five components secretly depending on the same Context value in ways that make debugging painful).

**State ownership model**

Think about state in three layers:

- **Local UI state** belongs to the component that renders it. Open/closed, hover, focus, form field values before submission. This state has no business being shared.
- **Shared feature state** belongs to a subtree. A wizard's step progress, a modal's form, a filter panel's selections. React Context works well here because the boundary is clear and intentional.
- **Cross-cutting application state** is data that is genuinely used across unrelated parts of the app. Auth tokens, user profile, permissions, real-time notification counts. This is the legitimate home of a global store.

**Why the distinction matters for maintenance:** Redux adds a cost. Actions, reducers, selectors, and potentially middleware all need to be written and maintained. That cost is worth it when you have cross-cutting state with complex update logic, time-travel debugging needs, or a team that benefits from explicit mutation contracts. It is not worth it when you are using it because someone on the team was comfortable with it on a previous project.

**The performance note:** Context re-renders every subscriber when its value changes. For high-frequency updates like typed input or animation state, Context is the wrong tool regardless of scope. Redux with `useSelector` can isolate re-renders more precisely, which is relevant at scale but rarely the deciding factor for most apps.

**Server state as a separate concern:** Tools like React Query or SWR handle fetched data with their own lifecycle: caching, invalidation, background refetch, optimistic updates. Moving server data out of Redux is one of the most common architectural improvements for apps that currently use Redux as a data-fetching layer. If most of your global store is remote data, you may not need a global store at all after introducing a server-state library.

**Governing recommendation:** Introduce Redux only for cross-cutting client state with complex update logic or explicit mutation contracts; use Context for bounded feature subtrees; use React Query or SWR for server state; and default to local component state for everything else, because the cost of a global store is only justified when the alternative is unmanageable prop drilling or shared state that genuinely has no clear owner.

---

## Strategic tier

**The architectural frame**

The Redux-versus-Context question is a proxy for a more fundamental decision: what is your state boundary model, and are mutations owned at the right layer?

Three categories, three owners:

- **Local UI state:** `useState` / `useReducer` in the component. No justification needed.
- **Bounded feature state:** Context with a clear provider boundary. The boundary is the discipline -- a Context that leaks across unrelated features is a global store with worse tooling.
- **Cross-cutting client state:** A signal-based or flux-based global store. Redux remains defensible when you need explicit action contracts, devtools-supported time-travel debugging, or a large team that benefits from strict mutation discipline.

**The missing piece most teams ignore:** Server state is not client state. React Query, SWR, or TanStack Query own the remote-data lifecycle: caching, deduplication, background revalidation, optimistic mutation, and stale-while-revalidate semantics. If your Redux store's primary job is holding API responses, you do not need Redux. You need a server-state library, and the store collapses to a small slice of genuinely shared client state, or disappears entirely.

**Architecture tax:** Redux carries a fixed overhead -- action constants, reducers, selectors, potentially saga or thunk middleware. That overhead is amortized across a large app with complex client-side state transitions. On a small to medium app, or any app where most state is server-derived, the overhead is a net negative.

**The modern alternative stack:** Local state + Context (bounded) + TanStack Query (server) + Zustand or Jotai (cross-cutting client state, when needed) gives you the same capability as Redux with significantly less ceremony. Zustand in particular provides a global store with minimal boilerplate and selective re-render primitives -- it is Redux's architecture without Redux's cost surface.

**Governing recommendation:** Start with local state and TanStack Query for server data; introduce a bounded Context only when a feature subtree has genuine shared state; and if cross-cutting client state emerges that cannot be co-located, prefer Zustand over Redux unless your team already has Redux infrastructure, devtools debugging is a hard requirement, or strict action-contract discipline is a deliberate architectural choice.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "state_ownership: local state default, Context for bounded subtrees, global store only for cross-cutting client state",
    "server_state_separation: server state owned by React Query / TanStack Query, not Redux",
    "global_store_selection: Zustand preferred over Redux unless devtools, action contracts, or existing infrastructure justify Redux"
  ],
  "evidence_classes_cited": [
    "rendering_model: Context re-renders all subscribers on value change",
    "cost_surface: Redux action/reducer/selector/middleware overhead is fixed and amortized only at scale",
    "state_ownership: three-layer boundary model — local, bounded feature, cross-cutting",
    "server_client_boundary: server state lifecycle distinct from client state lifecycle"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the app already have Redux infrastructure in place?",
    "What proportion of current global state is server-derived versus genuinely client-owned?",
    "Is time-travel debugging or strict action-contract discipline a team requirement?"
  ],
  "turn": 1
}
[/SESSION_STATE]