## Authorization and resource protection

**Governing decision:** Authorization must check object-level ownership, not just authentication status.

Checking whether the caller is logged in is authentication. It answers "who are you?" Authorization answers "are you allowed to do this to this specific resource?" Those are separate questions, and conflating them is the most common cause of horizontal privilege escalation (BOLA). Right now, any authenticated user can add members to any project they can reach the endpoint for. The fix is an explicit object-level check: only a project admin, or an owner with delegated rights, may mutate the member list for project `{id}`. Deny by default; grant only when the caller's role on that specific project is confirmed.

---

## Failure semantics

**Governing decision:** Error responses must follow RFC 9457 (Problem Details), not plain strings.

Plain string errors are untyped. Clients cannot branch on them programmatically without fragile string matching, and they carry no machine-readable context about what failed or why. RFC 9457 gives every error a `type` URI, a `title`, a `status` code, and optional `detail` and `instance` fields. This means a duplicate-member conflict, a permission failure, and a not-found response are all distinguishable by structure, not by parsing a sentence. Add a `trace_id` on all errors so operations teams can correlate client-reported failures to server-side logs without guessing.

---

## Idempotency contract

**Governing decision:** Mutating POST endpoints that add members require an idempotency key to be safe to retry.

Without an idempotency key, a client that retries after a timeout (because the first request got a 503 or a dropped connection) cannot know whether the mutation already succeeded. The server has no way to detect the duplicate either. The result is either silent double-application or a duplicate-member error with no safe recovery path. Require a client-supplied `Idempotency-Key` header. On the server, store the key against the outcome for a fixed TTL (24 hours is conventional). A second request with the same key returns the stored response without re-executing. Return `409 Conflict` on duplicate submission if you choose not to silently replay the result.

---

## Status code contract

**Governing decision:** A POST that mutates state and returns the updated resource should return 200 only when the member already existed; it should return 201 Created when a new membership is created.

Returning 200 uniformly obscures whether something was created or found. Clients that need to trigger a downstream action (send a welcome notification, provision access) use the status code to decide. `201` with a `Location` header pointing to the new membership resource is the correct signal for a net-new addition. If the member was already present and the request is idempotent, `200` is appropriate. Mixing them without distinction makes the contract ambiguous.

---

## Response body design

**Governing decision:** Returning the full updated member list on every mutation creates an implicit pagination and consistency problem at scale.

If a project has 500 members, every single add-member call returns 500 records. That is a payload size that grows unboundedly, and it requires the client to hold and diff the whole list to detect what changed. The safer contract: return the newly created membership resource (the single member record with its role, timestamps, and `id`), and let the member list be a separate paginated GET. This decouples mutation confirmation from collection retrieval, keeps response size stable, and avoids the consistency edge case where the list returned in the response is already stale because another concurrent write landed between your write and the read that built the list.

---

## Summary of required changes

| Concern | Current state | Required fix |
|---|---|---|
| Authorization | Auth check only | Object-level check: `only project admin may add members` |
| Error format | Plain string | RFC 9457 Problem Details with `trace_id` |
| Idempotency | None | `Idempotency-Key` header, 24h TTL, `409` on duplicate |
| Success status | `200` always | `201 Created` + `Location` for new membership; `200` for replay |
| Response body | Full member list | Return single created membership resource only |

[SESSION_STATE]
{
  "route": "api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "authorization_perimeter: object-level check required, deny by default, only project admin may add members",
    "problem_details_contract: RFC 9457 required, trace_id on all errors",
    "idempotency_contract: Idempotency-Key header, 24h TTL, 409 on duplicate",
    "status_code_contract: 201 for new membership, 200 for idempotent replay",
    "async_job_model: not applicable, synchronous mutation",
    "resilience_strategy: retry-safe via idempotency key"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "BOLA / object-level authorization",
    "idempotency-key header",
    "409 on duplicate",
    "201 Created + Location header",
    "deny by default"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there a role hierarchy beyond admin/member that affects who can add members?",
    "Should the idempotency key be client-generated (UUID) or server-assigned?",
    "Is there a rate limit or quota policy on membership mutations per project?"
  ],
  "turn": 1
}
[/SESSION_STATE]