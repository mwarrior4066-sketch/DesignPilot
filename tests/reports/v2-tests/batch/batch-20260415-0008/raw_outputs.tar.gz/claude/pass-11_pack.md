Good task for layout reconstruction governing this, with document accessibility and PDF layout in support where the source artifact matters.

Here is how I would work through it.

---

## Source constraints

A 2018 brand guidelines PDF is a specific type of artifact. Before extracting anything, I need to know what kind of document I am actually dealing with, because that changes confidence in every downstream claim.

**What to check first:**

- Is it a native PDF (vector text, embedded fonts, programmatic geometry) or a scan (rasterized pages)? Native PDFs let you extract exact values. Scans require measurement and inference.
- Is the grid drawn as vector objects or as rasterized diagrams? Vector grids are measurable. Rasterized diagrams require pixel-counting with a known reference dimension.
- Are the margin and column specs written as text in the document, or only shown visually in diagrams? Written specs are ground truth. Diagrams require reading and inference.
- What output formats does the document mention? A 2018 brand guide was probably designed for print, presentation, and possibly early web. Those grids may not map cleanly to responsive web or modern app layouts without deliberate translation.

**Confidence ceiling:** If the PDF is a scan, or if specs only appear in diagrams, all extracted values are inferred, not measured. I will label them as such and build in a verification step before committing them to a template.

---

## Reconstruction assumptions

**What I would extract, in priority order:**

### 1. Canonical page and canvas dimensions
- The page size establishes the coordinate system for everything else. Letter, A4, or a custom slide size all produce different margin ratios.
- Extract or infer: width, height, and orientation for each distinct layout type (full-page, two-column spread, slide, etc.).

### 2. Margin specifications
- Four-side margins (top, bottom, inside/outside for spreads, left/right for single pages).
- Note whether margins are symmetric or asymmetric, and whether the guide uses a binding gutter for spreads.
- If specs are written as numbers, extract directly. If only shown in diagrams, measure the margin-to-page ratio and apply that ratio to the target canvas.

Why this matters: margins define the live area, which is the actual content field. Columns sit inside it. Getting margins wrong cascades into every column calculation.

### 3. Column count and gutter width
- Column count per layout type. A 2018 brand guide likely shows a small set: 1-, 2-, 3-, or 4-column variants for different content types.
- Gutter width between columns. This is frequently unspecified in older guides; it may need to be inferred from the diagram.
- If the guide shows both text and image columns, note whether they use the same column unit or different ones.

### 4. Baseline grid or leading specification
- Older brand guides sometimes include a baseline grid, often tied to body type size. If a baseline increment is shown, record it.
- If no baseline is shown, I would infer it from the body text size if type specs are present.

### 5. Typography dimensions as secondary grid evidence
- Body type size and leading often reveal the baseline increment.
- Heading sizes reveal the scale ratio, which can be used to construct a modern type scale.
- Column width combined with type size lets me check whether the column-to-character-count relationship is readable.

### 6. Visual examples as inference anchors
- Each layout example in the guide is a constraint check. If a three-column layout shows an image spanning two columns, that is a span rule, not just an aesthetic choice.
- Extract: which span combinations are shown, whether any elements break the grid intentionally, and what the hierarchy implies about content priority.

---

## Rebuild sequence

**Step 1: Reconstruct the source grid in the source medium**

Build the extracted grid in a layout tool (Figma, InDesign) at the original canvas size. Plot margins, columns, and gutters exactly as extracted. Place the guide's example content over it. If the extracted values are correct, content aligns. If it does not align, adjust until it does. This is the calibration pass.

**Step 2: Abstract the proportional system**

Once the source grid validates, convert the values to ratios relative to the canvas width. For example: margin is 8.3% of page width, column is 7.6% of page width, gutter is 1.5% of page width. These ratios survive medium translation better than absolute pixel or millimeter values.

**Step 3: Translate to target medium**

Apply the proportional system to the new canvas. If the target is a web layout, map the column structure to a CSS grid with named column tracks. If the target is a presentation template, apply to slide dimensions. If the target is print, apply to the new page size.

The translation step is where 2018-era decisions may need deliberate updates. Specifically:

- **Gutter widths:** Older print-derived gutters are often too narrow for screen readability. A 5 mm print gutter at 96 dpi may feel cramped on screen. Evaluate and adjust with the ratio as a floor, not a ceiling.
- **Column counts:** Print typically supports tighter column counts because resolution is higher. A 4-column print layout may need to become a 12-column CSS grid with 4-column spans to retain flexibility.
- **Responsive breakpoints:** 2018 brand guides almost never specified responsive behavior. You will need to define breakpoint column-collapse rules from scratch. Use the source column count as the desktop state and define tablet and mobile collapse from there.
- **Baseline grid:** Print baseline grids do not map directly to CSS. A 12 pt print baseline might translate to an 8 px or 4 px spacing increment in a CSS system. Choose the nearest clean unit that matches your design token system.

**Step 4: Define the modern specification**

Produce a spec sheet for the new system using modern vocabulary:

- Container max-width and centered or full-bleed behavior
- Column count by breakpoint
- Gutter width in px or rem by breakpoint
- Margin (horizontal padding) by breakpoint
- Baseline increment in px (often 4 or 8)
- Named column span classes or named grid areas

This replaces the 2018 diagram with a living specification that developers can implement directly.

---

## Verification checkpoints

**Checkpoint 1 – Source calibration:** Place existing brand assets over the reconstructed source grid. Text blocks, image frames, and dividers should align. If they do not, re-extract.

**Checkpoint 2 – Proportional stability:** Apply the ratio system to at least two different canvas sizes and confirm that content areas remain usable and margins do not become disproportionate.

**Checkpoint 3 – Readability at target column width:** At your primary body type size, confirm that the column width produces a character count between 45 and 75 characters per line. If a reconstructed column is too narrow or too wide, adjust the span logic rather than compromising the column unit.

**Checkpoint 4 – Developer handoff legibility:** Give the new spec to a developer unfamiliar with the source document and ask them to implement a sample page. Gaps in the spec become visible immediately.

---

## Tradeoffs to name explicitly

**Fidelity vs. medium fitness:** Preserving the source grid exactly protects visual brand continuity, but a 2018 print grid applied without translation will produce layouts that feel wrong on screen. You sacrifice strict source fidelity to gain medium-appropriate spacing and readability. The proportional system approach is the middle path.

**Explicit spec vs. inferred spec:** If the original guide only shows diagrams without written values, any extracted spec is an inference, not a measurement. You gain a working system, but you accept that some values are approximations. The verification checkpoints close most of that gap, but they do not eliminate it.

**Column count inheritance vs. CSS grid flexibility:** Matching the source column count directly (say, 4 columns) is simpler to communicate but less flexible than a 12-column CSS grid with 4-column-span defaults. You sacrifice simplicity to gain responsive flexibility, or you accept constraint to stay closer to the original intent.

---

## What I would not do

I would not eyeball the diagram and convert it directly to pixel values without a calibration pass. Print-to-screen dimension translation is lossy unless you anchor to a known reference dimension first. Skipping calibration means the grid looks approximately right but fails on close inspection, particularly at column edges and text alignment.

I would also not assume the 2018 guide covers all the layout states you need. It was built for its original deliverables. New templates will need states the original never addressed. Document those gaps explicitly so they get designed rather than improvised.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: source margins, column count, gutter ratios, span rules from examples",
    "inference_boundary: rasterized diagrams require pixel-ratio inference, not direct measurement; written specs are ground truth",
    "reconstruction_order: source calibration -> proportional abstraction -> medium translation -> modern spec",
    "verification_method: source calibration pass, proportional stability check, readability character-count check, developer handoff legibility test"
  ],
  "evidence_classes_cited": [
    "proportional ratio system for medium translation",
    "45-75 character-per-line readability threshold",
    "print-to-CSS baseline increment translation (12pt -> 8px or 4px)",
    "WCAG-adjacent readability constraint on column width"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the PDF native vector or a scan? This determines whether extracted values are measurements or inferences.",
    "What are the target output formats for the new templates (web responsive, presentation, print)?",
    "Does a current design token system exist that the new grid spec should align to?"
  ],
  "turn": 1
}
[/SESSION_STATE]