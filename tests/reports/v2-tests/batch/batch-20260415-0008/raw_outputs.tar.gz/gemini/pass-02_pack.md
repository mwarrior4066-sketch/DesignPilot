## Purpose and scope

This component specification defines the structure, behavior, and states for a **Split Button**. Its primary purpose is to combine a frequently used main action with a set of less-frequent, contextually related secondary actions. This pattern prevents clutter while keeping related actions discoverable.

**Scope:** This document covers the visual anatomy, interactive states, accessibility requirements, and implementation considerations for a split button supporting a primary "Save" action and secondary "Save as draft" and "Save and close" options. It explicitly addresses keyboard navigation, disabled states, loading states, and mobile touch targets.

## Anatomy

The split button consists of two distinct, adjacent interactive areas:

1.  **Primary Action Button:**
    *   **Label:** "Save" (or the most common primary action).
    *   **Behavior:** When clicked, it directly executes the primary action without opening the dropdown.
    *   **Visuals:** Visually prominent, typically styled as a primary button.

2.  **Dropdown Trigger Button:**
    *   **Label:** No visible text label; typically uses an icon (e.g., a down-caret or chevron) to indicate expandable content. `aria-label` is required for accessibility.
    *   **Behavior:** When clicked, it toggles the visibility of the associated dropdown menu. It does not execute any immediate action itself.
    *   **Visuals:** Smaller than the primary button, typically sharing the same background/border styling as the primary button but distinct in size and containing an icon.

3.  **Dropdown Menu:**
    *   **Content:** A container of secondary action items (e.g., "Save as draft", "Save and close"). Each item within the menu acts as a distinct, actionable button.
    *   **Behavior:** Appears when the trigger button is activated. Closes when an item is selected, focus moves outside the menu, or the escape key is pressed.
    *   **Visuals:** Typically a vertical list of text-labeled items, following standard menu styling.

## State matrix

The split button, and its constituent parts, must clearly communicate their interactive state.

*   **Default (Enabled):** Both primary and trigger buttons are interactable and visually active.
*   **Hover:**
    *   Primary button: Visual feedback (e.g., background color change) when the pointer is over it.
    *   Trigger button: Visual feedback when the pointer is over it.
    *   Dropdown menu items: Visual feedback when the pointer is over them.
*   **Focus:**
    *   Primary button: Clear visual focus indicator (e.g., a distinct ring or outline) when it receives keyboard focus.
    *   Trigger button: Clear visual focus indicator when it receives keyboard focus.
    *   Dropdown menu items: Clear visual focus indicator when they receive keyboard focus.
*   **Active (Pressed):**
    *   Primary button: Visual feedback (e.g., darker background, slight depression) when actively being pressed.
    *   Trigger button: Visual feedback when actively being pressed.
    *   Dropdown menu items: Visual feedback when actively being pressed.
*   **Disabled:**
    *   **Primary button disabled:** Visually muted (e.g., reduced opacity, grayscale), non-interactive. This prevents the main action from being executed.
    *   **Trigger button disabled:** Visually muted, non-interactive. The dropdown menu cannot be opened. This implies no secondary actions are available.
    *   **Individual menu items disabled:** Secondary actions within the dropdown can also be individually disabled, appearing muted and non-interactive, even if the primary button and trigger are enabled.
*   **Loading:**
    *   **Primary button loading:** The "Save" text label is replaced by an inline spinner or a progress indicator. The button is non-interactive (`aria-disabled="true"` or HTML `disabled`) during the loading state. This is required to prevent re-submission while an operation is in progress.
*   **Open (Dropdown):**
    *   Trigger button: Remains visually pressed or highlighted, with `aria-expanded="true"`.
    *   Dropdown menu: Becomes visible, positioned appropriately (e.g., below or adjacent to the trigger), with focus managed within its items.

## Accessibility and implementation notes

**Accessibility Behavior:**

*   **Keyboard Support:** This requires robust focus management and activation:
    *   `Tab`: Focus sequence should move from the primary button to the dropdown trigger button. If the dropdown menu is open, `Tab` should cycle through the menu items before exiting the component.
    *   `Space`/`Enter`:
        *   On primary button: Activates the primary "Save" action.
        *   On dropdown trigger button: Toggles the dropdown menu visibility.
        *   On a dropdown menu item: Activates the selected secondary action.
    *   `Escape`: If the dropdown menu is open, `Escape` must close it and return focus to the dropdown trigger button, allowing for recoverable navigation.
    *   `Arrow Down`/`Arrow Up`: If the dropdown trigger has focus and the menu is closed, `Arrow Down` opens the menu and moves focus to the first item. If the menu is open, `Arrow Down`/`Arrow Up` should navigate between the visible menu items.
    *   `Home`/`End`: (Optional but recommended) Moves focus to the first/last menu item in an open dropdown respectively.
*   **Mobile Touch Targets:** Both the primary action button and the dropdown trigger button must adhere to WCAG 2.1 Success Criterion 2.5.5 (Target Size). This requires a minimum effective touch target size of **44x44 CSS pixels** for each interactive element, to ensure reliable activation on touch devices and for users with motor impairments.
*   **ARIA Attributes:**
    *   Primary button: `role="button"`.
    *   Dropdown trigger button: `role="button"`, `aria-haspopup="menu"` (indicating it controls a menu), `aria-expanded="false"` (when closed) or `aria-expanded="true"` (when open). It should also have an `aria-label` (e.g., "Open save options") since it's icon-only, and `aria-controls` pointing to the ID of the dropdown menu container, to establish a semantic relationship.
    *   Dropdown menu container: `role="menu"`.
    *   Dropdown menu items: `role="menuitem"`.

**Implementation Boundary:**

*   **Interaction Logic:**
    *   A click on the primary button should execute its action directly without impacting the dropdown state.
    *   A click on the dropdown trigger should toggle the dropdown menu. Clicking anywhere outside the open dropdown menu (or pressing `Escape`) must close it, returning focus to the trigger button for intuitive navigation.
    *   Selecting an item from the dropdown should execute its specific action and then close the dropdown menu.
*   **Visual Feedback:** All states (hover, focus, active, disabled, loading, open) must have distinct and high-contrast visual indicators to ensure clear communication of interactivity and status. Disabled states should use `pointer-events: none` and/or the HTML `disabled` attribute to prevent interaction.
*   **Responsive Design:** Beyond touch target sizes, the component must adapt gracefully to different viewport sizes. This means ensuring the layout of the primary and trigger buttons remains coherent, and the dropdown menu positioning is stable and readable on smaller screens.