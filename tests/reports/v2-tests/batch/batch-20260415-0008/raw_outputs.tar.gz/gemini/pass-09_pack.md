A robust color system for a healthcare SaaS dashboard must prioritize clarity, accessibility, and semantic consistency across different contexts, including status communication, data visualization, and dark mode.

## Role model

This color system defines semantic roles for every color token, ensuring that color choice is driven by meaning rather than arbitrary aesthetic preference. This protects accessibility, maintains consistency, and supports future expansion.

*   **Status Colors**:
    *   `Status-Positive`: Indicates success, normal operation, healthy states, or completion. (e.g., patient vital signs within range, task completed, secure connection).
    *   `Status-Warning`: Indicates caution, potential issues, conditions approaching thresholds, or minor errors. (e.g., patient vital sign trending out of range, pending action, degraded connection).
    *   `Status-Critical`: Indicates severe issues, active errors, out-of-range conditions, or danger. (e.g., patient vital sign critical, system error, data loss).
    *   `Status-Informative`: Indicates general information, non-urgent updates, or contextual help. (e.g., system announcements, loading states).
*   **Surface Colors**:
    *   `Background`: Primary canvas color for the application.
    *   `Surface`: Used for cards, panels, and distinct UI elements that sit on the background.
    *   `Border`: Used for separators, outlines, and inactive states.
*   **Text Colors**:
    *   `Text-Primary`: Main body text, headings, and primary labels.
    *   `Text-Secondary`: Less prominent text, helper text, timestamps, and metadata.
    *   `Text-Disabled`: Text in disabled interactive elements or non-actionable elements.
    *   `Text-Inverse`: Text used on dark-colored interactive elements or brand elements to maintain contrast.
*   **Interactive Colors**:
    *   `Interactive-Primary`: Main action color (e.g., primary buttons, links, active states).
    *   `Interactive-Secondary`: Secondary actions or less prominent interactive elements.
    *   `Interactive-Focus`: Visual indicator for keyboard focus states.
    *   `Interactive-Hover`: Visual indicator for hover states.
    *   `Interactive-Active`: Visual indicator for active/pressed states.
    *   `Interactive-Disabled`: Non-actionable interactive elements.
*   **Data Visualization Colors**:
    *   `Data-Category-1` through `Data-Category-5+`: Distinct colors for representing different categorical data series in charts and graphs. These must be visually distinguishable from each other and from status colors.
    *   `Data-Trend-Positive`: For displaying positive trends (e.g., growth, improvement).
    *   `Data-Trend-Negative`: For displaying negative trends (e.g., decline, worsening).

## Token map

This token map establishes a consistent alias structure, mapping semantic roles to specific color values for both light and dark modes. Values are illustrative hex codes; actual implementation will require precise calibration to meet WCAG AA contrast.

**Naming Convention:** `color-[role]-[intent]-[state]` or `color-[role]-[category]`

**Light Mode (Illustrative Hex Values):**

*   **Status**:
    *   `color-status-positive-bg`: `#E6F5EC` (light green background)
    *   `color-status-positive-icon`: `#228B22` (dark green for icons/text)
    *   `color-status-warning-bg`: `#FFF3CD` (light yellow background)
    *   `color-status-warning-icon`: `#D48806` (amber for icons/text)
    *   `color-status-critical-bg`: `#FCE8E8` (light red background)
    *   `color-status-critical-icon`: `#CF1322` (red for icons/text)
    *   `color-status-informative-bg`: `#E6F5FD` (light blue background)
    *   `color-status-informative-icon`: `#1890FF` (blue for icons/text)
*   **Surface**:
    *   `color-background`: `#F5F7FA` (light gray background)
    *   `color-surface`: `#FFFFFF` (white cards/panels)
    *   `color-border`: `#D9D9D9` (subtle gray border)
*   **Text**:
    *   `color-text-primary`: `#262626` (very dark gray)
    *   `color-text-secondary`: `#595959` (medium dark gray)
    *   `color-text-disabled`: `#BFBFBF` (light gray)
    *   `color-text-inverse`: `#FFFFFF` (white, used on dark backgrounds)
*   **Interactive**:
    *   `color-interactive-primary-default`: `#1890FF` (blue)
    *   `color-interactive-primary-hover`: `#40A9FF` (lighter blue)
    *   `color-interactive-primary-active`: `#096DD9` (darker blue)
    *   `color-interactive-secondary-default`: `#F0F2F5` (light gray button)
    *   `color-interactive-secondary-hover`: `#D9DCE0`
    *   `color-interactive-focus`: `#1890FF` (blue outline, same as primary default)
    *   `color-interactive-disabled`: `#D9D9D9` (light gray)
*   **Data Visualization (at least 5 categorical)**:
    *   `color-data-category-1`: `#1890FF` (blue)
    *   `color-data-category-2`: `#52C41A` (green)
    *   `color-data-category-3`: `#FAAD14` (orange)
    *   `color-data-category-4`: `#F5222D` (red)
    *   `color-data-category-5`: `#722ED1` (purple)
    *   `color-data-trend-positive`: `#52C41A` (green)
    *   `color-data-trend-negative`: `#F5222D` (red)

**Dark Mode (Illustrative Hex Values - Inverse Luminance, Maintained Semantics):**

*   **Status**:
    *   `color-status-positive-bg`: `#004F00`
    *   `color-status-positive-icon`: `#52C41A`
    *   `color-status-warning-bg`: `#59420C`
    *   `color-status-warning-icon`: `#FFC53D`
    *   `color-status-critical-bg`: `#590A0C`
    *   `color-status-critical-icon`: `#FF4D4F`
    *   `color-status-informative-bg`: `#002D5C`
    *   `color-status-informative-icon`: `#69C0FF`
*   **Surface**:
    *   `color-background`: `#141414` (dark gray background)
    *   `color-surface`: `#1D1D1D` (darker gray cards/panels)
    *   `color-border`: `#434343` (subtle dark gray border)
*   **Text**:
    *   `color-text-primary`: `#FFFFFF` (white)
    *   `color-text-secondary`: `#BFBFBF` (light gray)
    *   `color-text-disabled`: `#595959` (dark gray)
    *   `color-text-inverse`: `#262626` (very dark gray, used on light backgrounds)
*   **Interactive**:
    *   `color-interactive-primary-default`: `#1890FF` (blue, same as light)
    *   `color-interactive-primary-hover`: `#40A9FF`
    *   `color-interactive-primary-active`: `#096DD9`
    *   `color-interactive-secondary-default`: `#262626`
    *   `color-interactive-secondary-hover`: `#434343`
    *   `color-interactive-focus`: `#1890FF`
    *   `color-interactive-disabled`: `#434343`
*   **Data Visualization**:
    *   Categorical colors should remain consistent or have dark-mode adjusted variants that preserve distinction. For simplicity, often the same hues are used but with adjusted luminance for better contrast on dark backgrounds. *For this example, assume luminance-adjusted versions of the same hues to maintain semantic mapping.*
    *   `color-data-category-1`: `#69C0FF` (lighter blue)
    *   `color-data-category-2`: `#B7EB8F` (lighter green)
    *   `color-data-category-3`: `#FFD666` (lighter orange)
    *   `color-data-category-4`: `#FF7875` (lighter red)
    *   `color-data-category-5`: `#D3ADF7` (lighter purple)
    *   `color-data-trend-positive`: `#B7EB8F` (green)
    *   `color-data-trend-negative`: `#FF7875` (red)

## Contrast and state rules

**WCAG AA Text Contrast**:
All text elements (including placeholder text and text within graphics) must meet a minimum contrast ratio of 4.5:1 against their background. Large text (18pt/24px regular or 14pt/18.66px bold) requires 3:1. This is a non-negotiable `hr_accessibility_floor` requirement. Each color pair (e.g., `color-text-primary` on `color-surface`) must be explicitly validated.

**No Color-Only Semantics (`sr_hollow_compliance`)**:
Color must never be the *sole* means of conveying information, especially status or interactive states. This is crucial for users with color vision deficiencies.
*   **Status**: Always pair status colors with clear iconography (e.g., `✔` for positive, `⚠` for warning, `✕` for critical) and/or explicit text labels (e.g., "Normal," "Warning," "Critical").
*   **Data Visualization**: Use patterns, distinct shapes, or direct labeling/tooltips in addition to categorical colors to differentiate data series.
*   **Interactive States**: Focus indicators (`Interactive-Focus`) must be clearly visible and use a color or outline that provides sufficient contrast. Hover states (`Interactive-Hover`) should involve a change in background, text color, or a subtle lift effect, not just a color change. Disabled states (`Interactive-Disabled`) should have reduced opacity or a grayed-out appearance, alongside non-actionable cursors.

**State Rules**:
*   **Hover**: A subtle luminance shift (darker for lighter elements, lighter for darker elements) or a distinct border/shadow.
*   **Focus**: A 2px solid border/outline in `color-interactive-focus` around the element, ensuring it does not interfere with content.
*   **Active/Pressed**: A more significant luminance shift, often accompanied by a slight depression or darker background.
*   **Disabled**: Reduced opacity (`opacity: 0.4` or `0.5`) applied to the entire component, using `color-text-disabled` and `color-interactive-disabled` as background and text colors.

**Dark Mode Contrast**:
The dark mode palette must be re-validated for WCAG AA contrast. Background colors should be dark, text colors light. The relative contrast and semantic meaning of colors (e.g., positive vs. critical) should be preserved, even if the absolute hue or luminance values differ from light mode. The same contrast rules apply.

## Migration notes

Migrating to a new color system, especially in a critical healthcare SaaS, requires a structured and validated approach to minimize disruption and ensure data integrity.

**1. Audit Current Palette (`ux_research_gap_map`)**:
*   **Inventory**: Document every color currently used in the application, including its context (text, background, border, icon, data vis).
*   **Usage Map**: Map current hex codes to their explicit usage within the codebase and UI. Identify where color is used for status, interactivity, or purely decoratively.
*   **WCAG Check**: Run an automated and manual accessibility audit on the current palette to identify existing contrast failures.
*   **Color-Only Semantics**: Identify instances where color is the *only* indicator of status or interactivity. These are high-risk areas.

**2. Phased Rollout Strategy (`backend_feasibility_review`)**:
*   **Phase 1: Tokenization**: Introduce the new semantic tokens in the codebase without changing any visual colors. Map existing hex codes to temporary `legacy-[role]` tokens, e.g., `color-status-positive-bg: #OLD_GREEN_HEX`. This decouples styling from raw hex values. This is an internal code refactor (`implementation_boundary`).
*   **Phase 2: Core UI Elements**: Update primary surface, text, and interactive colors (buttons, links, form elements) to use the new tokens with their intended accessible values. This should be a component-by-component update, starting with widely used foundational elements.
*   **Phase 3: Status and Feedback**: Implement the new status colors (`Status-Positive`, `Status-Warning`, `Status-Critical`, `Status-Informative`) along with their required non-color indicators (icons, text labels). Prioritize areas with critical status information.
*   **Phase 4: Data Visualization**: Update charts and graphs to use the new `Data-Category` and `Data-Trend` colors. Ensure comprehensive testing for visual distinguishability and accessibility.
*   **Phase 5: Dark Mode Implementation**: Once the light mode is stable, implement the dark mode palette, ensuring all tokens have their dark mode counterparts and validating all contrast ratios. This might start as an opt-in feature for early adopters.
*   **Phase 6: Deprecation and Cleanup**: Systematically remove all old hex codes and `legacy-` tokens from the codebase, ensuring all elements use the new semantic token system.

**3. Verification and Testing (`verification_method`)**:
*   **Automated Testing**: Integrate automated WCAG AA contrast checks into the CI/CD pipeline.
*   **Manual Accessibility Audits**: Conduct manual checks using screen readers, keyboard navigation, and color blindness simulators (e.g., contrast checkers, grayscale views).
*   **User Acceptance Testing (UAT)**: Engage users, including those with accessibility needs, to validate the system's clarity, usability, and aesthetic appeal.
*   **Visual Regression Testing**: Employ visual regression tools to catch unintended visual changes during the migration.
*   **Stakeholder Review**: Regularly review progress with product, design, and engineering teams to ensure alignment and address any unexpected issues.

**4. Documentation and Governance (`component_boundary`)**:
*   **Color System Documentation**: Create comprehensive documentation for the new color system, detailing each token, its role, usage guidelines, and light/dark mode values.
*   **Design System Integration**: Integrate the new color system into the existing design system (e.g., Figma, Storybook) to provide designers and developers with a single source of truth.
*   **Training**: Train design and development teams on the new color system's principles and usage.

This phased, evidence-based approach minimizes the `cost_or_degraded_path` of such a foundational change, ensuring a safer and more compliant outcome for the healthcare SaaS dashboard.

[SESSION_STATE]
{
  "route": "color_system_spec",
  "escalation_level": "standard",
  "decisions_committed": ["role_model: defined", "token_map: provided", "contrast_state_rules: defined", "migration_strategy: outlined"],
  "evidence_classes_cited": ["WCAG threshold", "non-text contrast rule", "dark-mode fallback", "phased rollout strategy", "automated testing", "manual audits", "user acceptance testing", "visual regression testing", "documentation and governance"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]