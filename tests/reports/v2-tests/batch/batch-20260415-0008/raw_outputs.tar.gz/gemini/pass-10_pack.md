This poster design has several core communication and legibility challenges that hinder its effectiveness as an advertisement for a design conference.

### Communication Goal
The primary communication goal for a conference poster is to attract attention, clearly identify the event, and provide essential logistical details (what, when, where, who/how to register) with immediate clarity. The visual elements should support this information delivery, not compete with or obscure it. For a design conference specifically, the poster also acts as a demonstration of design acumen itself.

### Composition Failures
1.  **Hierarchy Inversion**: As you noted, presenting a large, decorative title at the top without establishing context creates an immediate barrier. The audience encounters "what" (the title) before "why" or "what kind of event." The conference logo, while central, also lacks context without a clear event type or compelling hook.
2.  **Legibility and Contrast**:
    *   **Decorative Typeface on Full-Bleed Background**: A decorative typeface is often harder to read even on a solid background. When placed over a busy, full-bleed city skyline photo, legibility is severely compromised due to insufficient contrast and visual clutter. The varying tones and details of the skyline will create unpredictable readability issues.
    *   **Small, Gray Date Text**: Crucial information like the date in small, gray text, especially in a bottom corner, significantly reduces its visibility and importance. This makes it a secondary rather than a primary piece of information, forcing the viewer to search.
    *   **White Logo on Skyline**: While white can stand out, a city skyline has diverse light and dark areas. The white logo likely suffers from insufficient contrast in certain areas, causing it to blend into brighter parts of the photo or appear indistinct.
3.  **Lack of Visual Grounding**: The full-bleed image, decorative title, and central logo, without clear containers or a more deliberate grid, can make the overall composition feel ungrounded and haphazard, especially when text elements are struggling for visibility.

### Rebuild Moves
1.  **Re-establish Information Hierarchy**:
    *   **Lead with Context**: Start with a clear statement of the event type, such as "Design Conference," or a concise, compelling tagline that sets expectations.
    *   **Prominent Event Name/Title**: Use a legible typeface for the main title, ensuring it has strong contrast against its background. Consider placing it after the event type or tagline.
    *   **Prioritize Essential Details**: Elevate the date, time, and (if applicable) location to a more prominent position, using a clear, readable typeface and sufficient size/contrast. These should be easily scannable.
2.  **Improve Legibility and Contrast**:
    *   **Text Containers/Overlays**: For text, introduce solid background blocks, frosted glass effects, or color overlays with sufficient opacity over the skyline photo to create a consistent, high-contrast surface for the typography.
    *   **Typeface Selection**: Reserve decorative typefaces for minimal, high-impact branding elements if truly necessary, and use highly readable, functional typefaces for all informational text (title, date, speakers, etc.).
    *   **Color Strategy**: Ensure text colors meet WCAG contrast guidelines against their backgrounds. The date should be a strong, contrasting color, not small and gray.
3.  **Strategic Use of Imagery**:
    *   **Mute or Blur Background**: If the city skyline photo is essential, consider desaturating it, blurring it, or applying a dark or light color overlay to reduce its visual busyness and allow foreground elements to pop.
    *   **Cropping/Framing**: Use the photo not as a full-bleed distraction, but as a framed element that supports the main information.
4.  **Logo Placement and Presentation**:
    *   **Clear Visibility**: Place the logo in a consistent location, often top-right or bottom-left, where it has guaranteed contrast. It doesn't need to be central to be important.
    *   **Size and Impact**: Balance the logo's size to ensure it's recognizable without overpowering key information.

### Distance and Emphasis Tradeoff
The current design makes a significant tradeoff between aesthetic "coolness" (decorative font, full-bleed photo) and immediate informational utility. From a distance, or with a quick glance, the poster's key details (the date, the nature of the event) are likely to be lost.

*   **Sacrificed**: Legibility, clear information hierarchy, scannability, and the ability for someone to quickly understand what the event is and when it happens. The poster fails as a functional communication tool from any distance.
*   **Preserved**: Potentially a certain "artistic" or "moody" aesthetic, but at the cost of effective communication.

A successful design conference poster needs to be highly scannable and legible from various distances. This design leans too heavily on a visual style that degrades the functional performance of the poster.