## System framing

This backend architecture specification outlines a multi-tenant scheduling platform designed for teams to manage appointments, resources, and projects with built-in approval workflows and external system integrations. The core purpose is to provide a reliable, scalable, and secure foundation that isolates tenant data, ensures consistency across distributed operations, and offers robust eventing for real-time features and integrations.

The platform will operate as a SaaS offering, necessitating strong tenant isolation and an efficient model for resource allocation and billing. Key services will be domain-driven, focusing on Scheduling, Workspaces (teams, users, roles), Approvals, and Notifications/Webhooks. This design prioritizes data integrity and system resilience over immediate eventual consistency in critical paths, with eventual consistency managed for non-blocking operations like activity feeds.

## Core model and authority boundaries

The platform's core model revolves around `Tenant`, `Workspace`, `User`, `Schedule`, `Event`, `Approval`, and `WebhookConfig` entities.

### Authority model

*   **Tenant as the top-level authority:** All data is implicitly scoped to a `TenantId`. Authorization begins by validating the `TenantId` associated with the request against the authenticated user's `TenantId`. Any request failing this check is denied.
*   **Workspace for team organization:** Within a tenant, `Workspaces` are used to group users and schedules, enabling finer-grained access control. A user's access to schedules and events is mediated by their membership and role within a `Workspace`.
*   **Role-based Access Control (RBAC):** Users are assigned roles (e.g., Administrator, Team Lead, Member) within a workspace, which dictate their permissions for creating, modifying, deleting, or approving schedules and events. Permissions are explicit (deny by default).
*   **Scheduling Service Authority:** The Scheduling Service owns the business logic for creating, updating, deleting events, managing recurrences, and detecting conflicts. It is the sole authority for mutating `Schedule` and `Event` state.
*   **Approval Service Authority:** The Approval Service owns the lifecycle and state transitions of approval requests. It gates the finalization of critical scheduling changes, ensuring `Approval` state transitions are atomic and verifiable.

### Consistency stance

*   **Strong Consistency for Critical Paths:** For core scheduling operations (creating, updating, deleting events) and approval status changes, the system prioritizes strong consistency. This means operations are ACID-compliant, often using transactional databases to ensure atomicity and isolation. Without this, scheduling conflicts or workflow bypasses become unavoidable.
*   **Eventual Consistency for Activity Feeds:** The activity feed will be eventually consistent. Events (e.g., `ScheduleCreated`, `EventUpdated`, `ApprovalGranted`) are published asynchronously and consumed by a dedicated Activity Feed Service. This ensures high availability and performance for reads, at the cost of slight latency for updates to appear in feeds.

## Data, consistency, and delivery design

### Data Model

*   **Tenant Partitioning:** Data will be partitioned by `TenantId` at the database level. Options include:
    *   **Separate Schemas/Databases:** Each tenant has its own schema or database. This provides the strongest isolation and performance guarantees but adds operational overhead. Chosen for initial deployment due to security and scaling benefits.
    *   **Shared Schema with TenantId Column:** All tables include a `TenantId` column, and queries always filter by it. Requires rigorous application-level enforcement and is prone to "noisy neighbor" issues.
*   **Database Choice:** PostgreSQL is chosen for its strong transactional guarantees, JSONB support for flexible event metadata, and robust ecosystem for scaling and high availability.
*   **Core Entities:**
    *   `Tenant`: `id`, `name`, `subscription_plan`, `config` (JSONB)
    *   `Workspace`: `id`, `tenant_id`, `name`, `description`
    *   `User`: `id`, `tenant_id`, `email`, `name`, `password_hash`, `status`
    *   `WorkspaceUserRole`: `workspace_id`, `user_id`, `role` (e.g., 'admin', 'member')
    *   `Schedule`: `id`, `workspace_id`, `name`, `type`, `description`, `owner_user_id`
    *   `Event`: `id`, `schedule_id`, `start_time`, `end_time`, `recurrence_rule`, `status` (e.g., 'pending_approval', 'approved', 'canceled'), `metadata` (JSONB)
    *   `ApprovalRequest`: `id`, `event_id`, `approver_user_id`, `status` (e.g., 'pending', 'approved', 'rejected'), `request_details` (JSONB), `created_at`
    *   `ActivityFeedItem`: `id`, `tenant_id`, `workspace_id` (nullable), `event_type`, `entity_id`, `user_id`, `timestamp`, `payload` (JSONB), `cursor`
    *   `WebhookConfig`: `id`, `tenant_id`, `event_type`, `target_url`, `secret`

### Data Delivery & Eventing

*   **Cursor-based Activity Feeds:**
    *   Events (e.g., schedule created, event updated, approval status changed) are captured and published to a message queue (e.g., Kafka or RabbitMQ).
    *   An `ActivityFeedService` consumes these events, transforms them, and stores them in a denormalized `ActivityFeedItem` table (partitioned by `tenant_id`).
    *   The `ActivityFeedItem` table will have a `cursor` column (e.g., a timestamp or a monotonically increasing sequence ID) for efficient pagination (`ORDER BY cursor DESC LIMIT N`).
*   **Outbound Webhooks:**
    *   A dedicated `WebhookPublisherService` subscribes to relevant domain events from the message queue.
    *   For each event, it retrieves `WebhookConfig` entries for the `tenant_id` and matching `event_type`.
    *   Webhooks are delivered asynchronously via a reliable HTTP client (e.g., using a message queue for retry logic). Failed deliveries are retried with exponential backoff. Dead-letter queues (DLQs) are used for persistent failures after max retries.
    *   Each outbound webhook request includes a signature (HMAC-SHA256) using the tenant's `secret` for recipient verification, improving security at the cost of slightly increased payload size.
    *   Webhook payloads are canonical JSON representations of the event, adhering to a predefined schema version.

### Caching Strategy

*   **Read-heavy data:** Tenant configurations, user roles, and static workspace data will be aggressively cached (e.g., Redis) to reduce database load.
*   **Invalidation:** Cache invalidation will be event-driven for critical data (e.g., `UserRoleChanged` event triggers invalidation of user role cache) and time-based for less critical data.

## Observability and failure posture

### Observability Tax

*   **Metrics (Prometheus/Grafana):** Standard application metrics (request rates, error rates, latencies for API endpoints, database queries, external service calls), business metrics (number of active tenants, schedules, events, webhook deliveries/failures).
*   **Structured Logging (ELK/Loki):** All services will emit structured logs (JSON format) with correlation IDs (`trace_id`, `span_id`) for tracing requests across service boundaries. Logs include `tenant_id`, `user_id`, and `workspace_id` where applicable to enable tenant-specific debugging.
*   **Distributed Tracing (Jaeger/OpenTelemetry):** End-to-end request tracing is implemented to visualize the flow of requests through microservices, identify bottlenecks, and diagnose failures across the distributed system. This incurs a small performance overhead but is critical for multi-service debugging.
*   **Alerting (Alertmanager):** Alerts are configured for critical errors, elevated latency, service outages, database issues, webhook delivery failures (DLQ size), and significant deviations in key business metrics.

### Failure Posture

*   **Graceful Degradation:**
    *   If the Activity Feed Service is experiencing issues, the core scheduling platform will continue to function. Users may temporarily see stale feeds, but scheduling operations are unaffected.
    *   If the WebhookPublisherService experiences issues, core scheduling will proceed. Webhooks will be retried and eventually sent to DLQ, but critical user-facing operations are not blocked.
*   **Circuit Breakers:** Implemented on outbound calls to external services (e.g., webhook targets) and potentially between internal services. This prevents cascading failures by "failing fast" when a downstream service is unresponsive, allowing it to recover.
*   **Idempotency:** All state-changing API endpoints will be designed to be idempotent where possible. For webhook deliveries, `idempotency-key` headers will be used to prevent duplicate processing by recipient systems.
*   **Resilience Strategy:**
    *   **Retry Logic:** Transient errors (e.g., network issues, temporary service unavailability) will be handled with exponential backoff and jitter.
    *   **Asynchronous Processing:** Long-running or non-critical operations (e.g., sending webhooks, generating activity feed items) are moved to asynchronous queues to prevent blocking API requests.
    *   **Data Backups & Disaster Recovery:** Regular, automated backups of all data stores with defined Recovery Point Objectives (RPO) and Recovery Time Objectives (RTO). Multi-region deployment for critical services is planned for business continuity.
    *   **Chaos Engineering:** Regular testing of system resilience by introducing failures (e.g., service slowdowns, network partitions) in a controlled environment to identify weaknesses.

### Security Considerations (Implicitly part of failure posture)

*   **Authentication & Authorization:** JWTs for session management, strong password policies, RBAC with least privilege.
*   **Data Encryption:** Data at rest (disk encryption) and in transit (TLS 1.2+ for all network communication).
*   **Vulnerability Scanning:** Regular security audits and automated vulnerability scanning (SAST/DAST).
*   **Secrets Management:** Environment variables or dedicated secrets management service (e.g., HashiCorp Vault, AWS Secrets Manager).

---
[SESSION_STATE]
{
  "route": "backend_architecture_spec",
  "escalation_level": "standard",
  "decisions_committed": ["authority_model: tenant_as_top_level_authority", "consistency_stance: strong_for_critical_eventual_for_feeds", "data_delivery: event_driven_webhooks_activity", "observability_tax: metrics_logs_tracing_alerts", "failure_posture: graceful_degradation_circuit_breakers_idempotency_resilience"],
  "evidence_classes_cited": ["authority_model", "consistency_stance", "data_delivery", "observability_tax", "resilience_strategy"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]