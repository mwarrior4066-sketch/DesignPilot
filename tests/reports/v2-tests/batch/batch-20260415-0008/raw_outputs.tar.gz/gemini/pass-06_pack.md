This task requires a **brand positioning pass** to define a unique and defensible territory for your new fintech startup. The core challenge is to be both trustworthy and approachable for freelancers, differentiating from traditional banks and existing competitors like Stripe, Mercury, and Relay.

## Audience and problem

Your target audience is **freelancers and independent professionals**. This group often struggles with financial instability, variable income, tax complexities, and the administrative burden of managing their own business finances. They need tools that are:
1.  **Trustworthy:** Secure, reliable, transparent with fees, and stable—like a bank, but without the bureaucratic friction.
2.  **Approachable:** Easy to use, empathetic to their unique financial rhythms, supportive of their independence, and not intimidating or overly corporate.
3.  **Specialized:** General business banking solutions (Mercury, Relay) often miss the nuance of solo operations, while payment processors (Stripe) don't offer full banking functionality.

**Competitor analysis:**
*   **Stripe:** Highly powerful and developer-centric, but primarily a payments platform. While robust, its brand isn't "approachable financial partner" for day-to-day banking for a solo freelancer. It feels more like a utility.
*   **Mercury:** Strong for startups and growing businesses, often tech-focused. It's modern and efficient, but can still feel somewhat impersonal or geared towards teams rather than the specific needs of a single independent professional. It's sleek but can lack warmth.
*   **Relay:** More traditional business banking with a modern interface. Focuses on team accounts, budgeting, and expense management. It addresses business needs but doesn't necessarily speak to the unique *lifestyle* or individual financial psychology of a freelancer in the same way.

## Positioning frame

Your opportunity lies in owning the territory of **"The Empathetic, Integrated Financial Partner for Freelancers."** This positions you as more than just a bank; you are a dedicated ally that understands and simplifies the unique financial journey of independent professionals.

**Key differentiators:**
*   **Freelancer-First Design:** Every feature, flow, and communication is explicitly designed with the freelancer's variable income, tax burden, and desire for simplicity in mind. This is not business banking adapted for freelancers; it *is* freelancer banking.
*   **Relational Approachability:** You are easy to interact with, speak their language, and offer support that feels human and understanding, rather than automated or detached. This contrasts with the often transactional feel of Stripe, the cool efficiency of Mercury, and the more corporate tone of Relay.
*   **Proactive Guidance (not just tools):** Offer features or content that help freelancers *thrive* financially, such as automated tax savings, income smoothing insights, or integrated invoicing/payment tracking designed to simplify their workflow, not just store their money.

**This means accepting** that you might not be the most "enterprise-grade" or "hyper-scaled" solution from day one (sacrificing some broad market appeal) **in order to gain** deep loyalty and relevance within the freelancer community (preserving a strong niche).

## Trust and proof burden

Building trust without being a traditional bank requires a different approach, emphasizing transparency, reliability, and modern security over legacy brand recognition.

**Trust logic:**
*   **Transparency over Opacity:** Clear, simple fee structures with no hidden costs. Openly communicate how deposits are protected (e.g., FDIC insurance through partner banks).
*   **Reliability through Technology:** Showcase uptime, fast transaction processing, and robust security measures (encryption, multi-factor authentication) in a way that feels modern and competent, not just compliant.
*   **Human-Centric Support:** Offer responsive customer service staffed by individuals who understand the nuances of freelance work. This builds trust through empathy and practical help.
*   **Privacy Commitment:** Explicitly detail how user data is protected and not monetized in ways that betray trust.
*   **Community Validation:** Encourage testimonials, reviews, and community engagement as social proof that you genuinely serve and empower freelancers.

**Proof burden:**
You must demonstrate, not just claim, that you understand freelancers. This means:
*   Featuring real freelancer stories and use cases.
*   Clearly showing security protocols and partner banks.
*   Providing clear, actionable financial insights rather than generic advice.
*   Highlighting simple, intuitive interfaces that reduce cognitive load.

## Messaging consequences

The messaging must consistently reinforce the "empathetic, integrated partner" positioning.

**Tone:**
*   **Empathetic and Understanding:** Acknowledge the challenges of freelance life (income variability, taxes, admin).
*   **Direct and Clear:** Avoid financial jargon or corporate speak. Use plain language.
*   **Empowering and Enabling:** Focus on how the product helps freelancers gain control, save time, and build financial stability.
*   **Confident and Reliable:** Project competence without arrogance.

**Key themes:**
*   **Financial Flow & Freedom:** Managing money effortlessly to focus on creative work.
*   **Clarity & Control:** Understanding where money goes and what's next.
*   **Tailored Support:** Solutions built specifically for *them*, not a generic business.
*   **Security & Simplicity:** Safe, robust tools that are genuinely easy to use.

**What to avoid:**
*   **"Bank-speak" or overly formal language:** No "accounts payable/receivable," "institutional-grade," unless strictly necessary and explained.
*   **Generic corporate buzzwords:** Avoid vague terms like "synergy," "value-add," "next-gen solutions" without concrete examples.
*   **Pretending to be their "friend":** Be approachable and helpful, but maintain professional competence and authority on financial matters.
*   **Overly complex feature descriptions:** Prioritize clarity and benefit over exhaustive technical detail in primary messaging.

By committing to "The Empathetic, Integrated Financial Partner for Freelancers," you create a distinct identity that addresses core freelancer pain points, builds trust through modern transparency, and stands apart from competitors by deeply understanding and serving this specific, growing market.

[SESSION_STATE]
{
  "route": "brand_positioning_pass",
  "escalation_level": "strategic",
  "decisions_committed": ["audience_frame: freelancers and independent professionals", "differentiation_frame: empathetic, integrated financial partner", "trust_logic: transparency, reliability, human-centric support", "messaging_consequence: empathetic, direct, empowering, clear tone"],
  "evidence_classes_cited": ["category convention demands", "you sacrifice X to gain Y", "proof requires"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]