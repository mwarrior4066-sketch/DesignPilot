## System framing

This architecture specification outlines a backend design for a multi-tenant scheduling platform, building upon an existing REST API and relational database foundation. The core drivers are enabling team workspaces, robust approval workflows, cursor-based activity feeds, and outbound webhooks to customer systems. Critical non-functional requirements include regional data residency, comprehensive audit trails, and a future path for customer-defined automation rules. The current inconsistency in background jobs and eventing necessitates a clear, consistent approach for asynchronous processing and data propagation.

The system will evolve into a distributed architecture, separating core transactional processing from event-driven data propagation and asynchronous work. This shift acknowledges that not all data requires strong consistency at all times, enabling better scalability for feeds and webhooks while preserving transactional integrity for scheduling.

## Core model and authority boundaries

The **authority_model** for this platform is a federated design with tenant-scoped service boundaries, ensuring data isolation and operational independence where critical.

### Key Service Boundaries:
1.  **Core Scheduling Service:** Owns the primary scheduling logic, resources, users, and workspace configuration within a tenant context. This service is the authority for all transactional scheduling operations. It interacts with the Relational Database for state changes and emits events for downstream consumption.
2.  **Workflow & Approvals Service:** Manages the state, transitions, and participants of approval processes. This service holds the authoritative state for pending, approved, and rejected items, interacting with the Core Scheduling Service to enact approved changes. It is event-driven for status updates and notifications.
3.  **Activity Feed Service:** Consumes events from core services and aggregates them into a query-optimized store for cursor-based retrieval. This service is read-optimized and eventually consistent. It does not own primary data; its authority is solely over the presentation of historical activity.
4.  **Webhook & Integration Service:** Manages webhook registrations, event filtering, and reliable delivery to external customer systems. It consumes relevant events, transforms them, and handles retries and error reporting. This service operates asynchronously and owns the contract for outbound communication.
5.  **Audit Trail Service:** An immutable append-only event log consumer. It records critical changes and actions across the system for compliance and debugging. Its authority is the integrity and immutability of historical records, not the operational data itself.
6.  **Tenant & Region Management Service:** A foundational service that manages tenant metadata, including their assigned data residency region. It acts as the routing authority for data access and storage based on tenant configuration.

### Multi-Tenancy and Regional Data Residency:
*   **Tenant Isolation:** All core data entities (schedules, users, approvals) **must** include a `tenant_id` foreign key. Querying for any tenant-specific data will enforce this ID at the database and service layers. This requires the `Tenant & Region Management Service` to provide canonical tenant context for all authenticated requests.
*   **Regional Data Residency:** The `Tenant & Region Management Service` will store each tenant's designated region. Data storage for core transactional services (Core Scheduling, Workflow & Approvals) will be logically partitioned by region. This implies either separate database instances per region, or sharding mechanisms that guarantee data physically resides within the specified region. Read requests for tenant data will be routed to the appropriate regional data store, ensuring compliance **because** access to data for a given tenant must be confined to their designated region.

## Data, consistency, and delivery design

The existing relational database will remain the primary store for transactional data, but a new, consistent eventing backbone and a robust background job system are introduced to address current inconsistencies and support new requirements.

### Data Storage & Partitioning:
*   **Relational Database:** The primary data store for Core Scheduling, Workflow & Approvals, and Tenant Management. Data will be logically partitioned by `tenant_id` and, where regional residency applies, physically partitioned by region. This may involve separate database schemas or instances for each region, or a robust sharding solution.
*   **Activity Feed Store:** A purpose-built, denormalized data store (e.g., NoSQL document database or an optimized relational table) for fast, cursor-based reads. It will store aggregated, transformed events relevant to user activity feeds. Data here is derived, not primary.
*   **Audit Log Store:** An append-only, immutable storage solution (e.g., dedicated database, object storage) for audit events. This is optimized for writes and long-term retention.

### Eventing System (new consistent component):
*   **Purpose:** A central nervous system for propagating state changes, triggering asynchronous actions, and enabling eventual consistency patterns. This replaces inconsistent ad-hoc background jobs.
*   **Technology:** A durable message broker (e.g., Kafka, RabbitMQ, managed cloud event bus).
*   **Event Structure:** Events will be standardized (e.g., CloudEvents or a similar schema) and include `tenant_id`, `user_id` (if applicable), `region_id`, `event_type`, and `timestamp`, alongside specific payload data.
*   **Producers:** All core services (Core Scheduling, Workflow & Approvals, Tenant & Region Management) will produce domain events after successful transactional commits to their primary data stores.
*   **Consumers:** The Activity Feed Service, Webhook & Integration Service, and Audit Trail Service will subscribe to relevant event streams. Future Customer Automation services will also consume events.

### Background Job System (new consistent component):
*   **Purpose:** For reliable execution of asynchronous, long-running, or retryable tasks that don't require immediate user feedback.
*   **Technology:** A queue-based system with workers (e.g., Redis Queue + workers, cloud task queues).
*   **Use Cases:**
    *   **Webhook Delivery:** The Webhook & Integration Service will enqueue outbound webhook calls, ensuring retries and dead-letter queue handling for failures.
    *   **Complex Approvals:** Asynchronous processing of multi-step approval workflows.
    *   **Audit Report Generation:** Scheduled tasks to compile and store audit reports.
    *   **Customer Automation (Future):** Execution of user-defined automation rules.

### **Consistency Stance**:
*   **Core Scheduling & Workflows:** Strong consistency (ACID transactions) is required for state changes in the relational database, **because** conflicting updates to schedules or approvals must be prevented.
*   **Activity Feeds, Webhooks, Audit Trails:** Eventual consistency is acceptable and designed for, **because** a slight delay in updates to these secondary systems does not compromise the transactional integrity of the core platform, and enables greater scalability. The tradeoff here is increased complexity in distributed system reasoning (e.g., handling out-of-order events) in exchange for higher throughput and decoupled services.

### **Data Delivery**:
*   **Activity Feeds:** Events from Core Scheduling and Workflow services are consumed by the Activity Feed Service, transformed, and stored in its optimized read store. Clients query this store with cursors for pagination. The cursor provides a stable point in time for continuous feed retrieval.
*   **Outbound Webhooks:** Relevant events are consumed by the Webhook & Integration Service. This service retrieves customer-defined webhook configurations (URL, subscribed events), filters events, transforms payloads, and enqueues the actual HTTP POST requests into the Background Job System for reliable, retriable delivery. Failed deliveries are logged and routed to dead-letter queues, preventing a single customer webhook failure from blocking other integrations.

## Observability and failure posture

The **observability_tax** for this system design is a significant upfront investment in standardized logging, metrics, tracing, and alerting, **without which** diagnosing issues in a distributed, event-driven, multi-tenant system would be nearly impossible. This tax is accepted to ensure operational stability and provide insights into data residency compliance and event propagation.

### Observability Components:
*   **Centralized Logging:** All services will emit structured logs (JSON) with correlation IDs (trace_id, span_id, tenant_id, request_id) for end-to-end request and event flow tracking. Log aggregation and search are critical.
*   **Metrics & Monitoring:** Prometheus-compatible metrics will be exposed by all services, covering:
    *   Request rates, latencies, error rates (RED metrics).
    *   Queue depths and processing times for event consumers and background job workers.
    *   Webhook delivery success/failure rates and retry counts.
    *   Resource utilization (CPU, memory, database connections).
    *   Regional data transfer volumes (for data residency compliance auditing).
*   **Distributed Tracing:** Implementing OpenTelemetry or a similar standard across all services (API Gateway, Core Scheduling, Workflow, Event Bus, Background Workers, Activity Feed, Webhook Service) to visualize the flow of requests and events, aiding in performance bottleneck identification and debugging asynchronous operations.
*   **Alerting:** Proactive alerts on:
    *   Service errors (e.g., 5xx rate exceeding threshold).
    *   Increased latency for critical paths.
    *   Event queue backlogs.
    *   Persistent webhook delivery failures to specific customers.
    *   Anomalies in regional data access patterns.
    *   Audit log integrity checks.

### Failure Posture & Resilience:
*   **Graceful Degradation:** Core scheduling functionality **must** remain operational even if secondary services (e.g., Activity Feeds, Webhooks) experience issues. For example, if the Webhook Service is down, core scheduling events are still produced to the event bus and attempts to send webhooks will be queued and retried later.
*   **Idempotency:** All operations triggered by events or background jobs (e.g., processing an approval, sending a webhook) **must** be idempotent. This ensures that retrying an operation due to transient failures does not lead to duplicate data or unintended side effects, **because** message delivery guarantees (at-least-once) mean consumers may receive the same event multiple times.
*   **Circuit Breakers & Retries:** Implement circuit breakers for outbound calls to external services (e.g., customer webhook endpoints) to prevent cascading failures. Robust retry mechanisms with exponential backoff and jitter will be in place for transient internal and external communication failures.
*   **Dead-Letter Queues (DLQs):** Event consumers and background job workers will use DLQs for messages that consistently fail processing. This prevents poison pills from blocking queues and allows for manual inspection and re-processing.
*   **Data Residency Compliance Failure:** Automated checks will be in place to verify data storage location against tenant's designated region. Any deviation will trigger immediate critical alerts and potentially block operations for the affected tenant, **because** data residency is a hard compliance requirement.
*   **Audit Trail Integrity:** The Audit Trail Service will implement mechanisms to ensure immutability and detect tampering (e.g., cryptographic hashing, write-once storage).

This architecture provides a robust, scalable foundation for the multi-tenant scheduling platform, addressing the current inconsistencies and preparing for future automation needs while maintaining strict compliance with regional data residency and auditability.