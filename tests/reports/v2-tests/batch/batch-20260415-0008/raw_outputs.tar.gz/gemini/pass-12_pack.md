For a fintech product requiring a modern, trustworthy feel across a marketing site, web app dashboard, and mobile, while handling tabular financial data and supporting robust hierarchy, a carefully selected type system is critical. The design prioritizes clarity, precision, and legibility to build trust and ensure functional integrity.

## Reading Context

The type system must serve distinct but interconnected reading contexts, each with specific constraints:

*   **Marketing Site:** (Medium-to-long form reading) Focus on brand communication, storytelling, and user acquisition. Requires excellent readability for body text, expressive but clean headlines, and clear calls to action. Constraints: brand consistency, visual appeal, SEO friendliness, fast load times.
*   **Web App Dashboard:** (Short-form, dense data reading) Primary context for financial operations, data visualization, and transactional tasks. Requires extreme legibility for numbers, labels, charts, and tables at varying sizes. Constraints: high information density, rapid scanning, precision of data, accessibility for interactive elements, legibility at small sizes, minimal cognitive load.
*   **Mobile App:** (Constrained, on-the-go reading) Similar to the dashboard but with significantly less screen real estate and touch-first interaction. Requires optimized sizes for smaller screens, clear touch targets, and resilient hierarchy. Constraints: touch accessibility, single-column flow, legibility in bright sunlight, efficient use of space.
*   **Tabular Financial Data:** (Precision reading) This is a cross-platform constraint. Financial data requires typefaces with clear, unambiguous numbers (e.g., easily distinguishable '1' from 'l' and 'I', '0' from 'O'), consistent character widths for alignment (tabular figures), and minimal visual noise. This requires careful typeface selection because errors here can lead to significant user distrust or incorrect decisions.

## Scale and Role Map

A single, robust typeface family is recommended across all contexts to ensure visual consistency and reduce cognitive overhead for users transitioning between the marketing site and the product. This approach simplifies maintenance and asset loading.

**Primary Typeface: Inter**

*   **Pairing Rationale:** Inter is a sans-serif typeface designed specifically for user interfaces by Rasmus Andersson. It offers excellent legibility at small sizes, a wide range of weights (Thin to Black), and distinct tabular figures for precise alignment of numbers. Its large x-height, clear differentiation of similar characters, and optimized hinting make it ideal for screen display, especially for dense financial data. It maintains a modern, neutral, and trustworthy aesthetic, aligning perfectly with fintech needs.
*   **Fallback Stack:** `Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif` – this provides common, performant sans-serif fallbacks that preserve legibility and general character.

**Scale and Role Assignments:**

| Role             | Size (Desktop/Web App) | Size (Mobile App) | Weight      | Use Case                                          |
| :--------------- | :--------------------- | :---------------- | :---------- | :------------------------------------------------ |
| **H1 - Display** | 48px                   | 36px              | Bold        | Major marketing headlines, hero sections          |
| **H2 - Section** | 32px                   | 28px              | Semi-Bold   | Primary section titles, dashboard main headings   |
| **H3 - Subtitle**| 24px                   | 22px              | Medium      | Card titles, key module headings                  |
| **H4 - Element** | 20px                   | 18px              | Medium      | Sub-headings, important summary labels            |
| **H5 - Sub-element**| 16px                   | 16px              | Medium      | Form field labels, navigation items               |
| **H6 - Small Header**| 14px                   | 14px              | Medium      | Table column headers, small component titles      |
| **Body Large**   | 18px                   | 16px              | Regular     | Marketing site main body text, longer descriptions|
| **Body Regular** | 16px                   | 14px              | Regular     | Default body text, form input text, detailed data |
| **Body Small**   | 14px                   | 12px              | Regular     | Secondary info, helper text, timestamps           |
| **Button Text**  | 16px                   | 14px              | Medium      | Primary and secondary button labels               |
| **Tabular Data** | 14-16px                | 12-14px           | Regular     | All numeric data in tables, charts, and lists. Use `font-variant-numeric: tabular-nums;` if Inter's default figures are proportional to force tabular alignment. |
| **Legal/Fine Print**| 12px                   | 10px              | Regular     | Footnotes, disclaimers                            |

## Readability Rules

These rules ensure optimal legibility and user experience across all platforms.

*   **Line Length:** For optimal reading flow, body text lines should aim for **45-75 characters per line (CPL)** on desktop/web app. On mobile, this will naturally be shorter, but target **35-50 CPL** as a guide. Exceeding this makes it hard to track the next line; falling too short creates too many line breaks, interrupting flow.
*   **Contrast:** All text must meet or exceed **WCAG 2.1 AA contrast standards**.
    *   Normal text (below 18pt or 14pt bold): **4.5:1 ratio** against its background.
    *   Large text (18pt or larger, or 14pt bold or larger): **3:1 ratio** against its background.
    *   This requires careful selection of color tokens because financial data often uses color for status or categorization, but these must not compromise text legibility.
*   **Leading (Line Height):**
    *   Body text (14-18px): **1.5x to 1.6x** the font size for comfortable reading. For example, 16px text would have a line-height of 24-25.6px. This provides ample vertical spacing for dense content.
    *   Headings: **1.1x to 1.3x** the font size. Larger headings can use tighter line heights to keep them visually cohesive because they are short.
*   **Tracking (Letter Spacing):**
    *   Body text: Default tracking is usually sufficient.
    *   Headings (H1, H2): May be tightened slightly (`-0.02em` to `-0.01em`) to improve compactness, but avoid making characters feel squeezed.
    *   Small text (12px or less): May be loosened slightly (`0.01em` to `0.02em`) to improve legibility, as tight spacing at small sizes can blur characters. This requires caution because excessive loosening can also reduce readability.
*   **Paragraph Spacing:** Add **0.75x to 1x** the line height of the body text as vertical space between paragraphs to clearly delineate blocks of text. This helps readers scan and distinguish sections.
*   **Tabular Data Rules:**
    *   Numbers must be displayed using **tabular figures**, ensuring consistent horizontal alignment in columns regardless of their numerical value (e.g., '1' takes the same width as '8'). Inter supports this well through `font-variant-numeric: tabular-nums;`.
    *   Right-align numeric values in tables for easier comparison of magnitude.
    *   Align decimal points consistently for all values in a column, because this is critical for financial precision.

## Adoption Guidance

Phasing the type system into the product iteratively helps manage complexity and reduces risk.

1.  **Audit Current State:** Begin by conducting a thorough audit of all existing type styles, fonts, sizes, and their usage across the marketing site, web app, and mobile. Document current inconsistencies and pain points because this highlights the highest-impact areas for change.
2.  **Define Design Tokens:** Translate the `Scale and Role Map` into a system of design tokens (e.g., `--font-family-primary`, `--font-size-h1`, `--line-height-body`). These abstract values allow for easier implementation and future updates. This requires clear mapping from semantic roles to specific CSS properties.
3.  **Prioritize Critical Paths:** Focus on applying the new type system to the most critical user flows and high-traffic areas first (e.g., login/onboarding, core dashboard views, key transaction screens). This ensures that the most impactful parts of the product benefit earliest.
4.  **Iterative Rollout (Component by Component):** Instead of a "big bang" update, introduce the new type system incrementally. Start with foundational elements like body text and headings, then move to components like buttons, form fields, and finally complex elements like data tables and charts. This minimizes disruption and allows for continuous testing.
5.  **Develop Component Library:** Update or create a shared component library with all text styles and typographic components built on the new system. This ensures consistency as new features are developed and old ones are refactored. This requires collaboration between design and engineering.
6.  **Comprehensive Testing:** Before full deployment, conduct extensive testing:
    *   **Usability Testing:** Observe users interacting with the new typography across all devices and screen sizes.
    *   **Accessibility Audits:** Verify WCAG compliance for contrast, readability, and text resizing.
    *   **Performance Testing:** Ensure font loading does not negatively impact page load times, because this affects user experience and SEO.
    *   **Visual Regression Testing:** Automate checks to catch unintended visual changes.
7.  **Documentation and Training:** Create clear, accessible documentation for designers, developers, and product managers outlining the rationale, usage guidelines, and implementation details of the new type system. Conduct training sessions to ensure all teams understand how to apply the system correctly. This requires an investment in shared knowledge because misapplication can lead to inconsistencies.

By implementing Inter as the core typeface with a structured scale and strict readability rules, the fintech product can achieve a modern, trustworthy, and highly functional typographic foundation that supports complex data and diverse user needs across all platforms. This approach prioritizes clarity and precision **rather than** incorporating a separate, more decorative typeface for marketing, which would increase complexity and potentially dilute the overall sense of consistency and trustworthiness that a fintech product demands.