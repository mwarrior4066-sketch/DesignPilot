To reconstruct your layout system from the old brand guidelines PDF and translate it into a modern system for new templates, I will use the `layout-reconstruction-expert` skill as the governing route. This will be supported by `grid-system-expert` for interpretation of grid elements and `ui-system-expert` and `front-end-handoff-expert` for modern adaptation.

Here's how I would approach it:

## Problem framing
The task is to extract the underlying layout system—including grids, margins, and column structures—from a 2018 brand guidelines PDF. The goal is to translate these historical specifications into a modern, flexible, and implementable layout system suitable for new digital templates, respecting the original brand intent while introducing modern best practices.

## Findings
I would perform a detailed analysis of the PDF, extracting the following key characteristics:

### Source constraints
The 2018 PDF likely represents a print-first or fixed-width digital design paradigm. Key evidence I would extract includes:

*   **Grid structure:**
    *   **Column count:** The exact number of columns used on various page types (e.g., 12-column for main content, 4-column for sidebars).
    *   **Gutter width:** The consistent spacing between columns.
    *   **Module size:** If a baseline or modular grid is referenced, its unit of measure.
    *   **Baseline grid:** If vertical rhythm is explicitly defined or visually implied.
    *   **Breakpoint logic:** This will likely be *inferred* rather than explicitly stated. Older documents often imply fixed breakpoints through examples (e.g., a "desktop" layout, a "print" layout) rather than defining responsive behavior.
*   **Margins and padding:**
    *   **Page margins:** Consistent top, bottom, left, and right margins for different page types.
    *   **Component padding:** The internal spacing within typical UI elements or content blocks, if visible in examples.
*   **Typography:**
    *   **Type scale:** The hierarchy of font sizes used for headings, body text, captions, etc.
    *   **Line height/leading:** Consistent line spacing rules.
    *   **Paragraph spacing:** The spacing between blocks of text.
*   **Component layout examples:**
    *   How specific elements (e.g., images with captions, pull quotes, sidebars, headers, footers) snap to the grid and use spacing.
    *   Visual hierarchy cues: How emphasis is created through layout rather than just typography or color.

### Reconstruction assumptions
Given the age of the document, I would assume:

*   **Fixed units:** Measurements are likely in print-centric units (e.g., millimeters, points, inches) or fixed pixels. I would infer the underlying base unit.
*   **Print-first mindset:** The grid might be optimized for static page layouts, not dynamic responsive behavior.
*   **Visual fidelity:** The explicit diagrams are reliable, but implied spacing or alignment in visual examples would be noted with medium confidence.
*   **Missing modern concepts:** Responsive design, component-based scaling, dark mode considerations, or accessibility-specific layout rules are unlikely to be explicit.

## Recommendations
Translating these findings into a modern layout system involves a shift in mindset and technical approach.

### Rebuild sequence
1.  **Unit Normalization:**
    *   **Convert to relative units:** Translate all fixed `px` or `pt` values for spacing, margins, and potentially font sizes into relative units like `rem` (based on a browser's root font size) or `em` (relative to the parent element's font size). This allows for easier scaling and accessibility.
    *   **Grid System Abstracting:** Define the original column count and gutter width in a flexible way. For example, a 12-column grid would translate to CSS Grid or Flexbox, with gutters defined using `gap` properties or variable spacing.
2.  **Modular Spacing System:**
    *   Abstract all margin and padding values into a consistent spacing scale (e.g., `space-xs`, `space-sm`, `space-md`, `space-lg`). This encourages reuse and reduces arbitrary values.
    *   If a strong vertical rhythm or baseline grid is evident, define a vertical spacing unit that aligns elements to this rhythm.
3.  **Responsive Breakpoint Definition:**
    *   **Infer breakpoints:** Based on the common desktop screen sizes around 2018 and the visual density observed, I would infer logical breakpoints (e.g., a "desktop" breakpoint at `1280px`, a "tablet" breakpoint at `768px`).
    *   **Establish fluid behavior:** Define how the grid, margins, and component layouts should adapt between these breakpoints, moving from fixed values to fluid `vw` (viewport width) or `calc()` functions where appropriate to ensure adaptability across devices.
4.  **Component-Driven Layout Principles:**
    *   **Layout primitives:** Identify if certain common layouts appear repeatedly (e.g., two-column content block, media object with text). Translate these into reusable layout components or utility classes.
    *   **Tokens for consistency:** All extracted layout rules (grid, spacing, typography) should be defined as design tokens to enable consistent application across diverse platforms and technologies.
5.  **Accessibility Considerations:**
    *   **Readable line lengths:** Ensure that reconstructed text blocks adhere to modern recommendations for line length (e.g., 45-75 characters per line) for optimal readability, especially on larger screens where the original PDF might have wider columns.
    *   **Content reflow:** Verify that the new layout system allows content to reflow gracefully at different screen sizes without horizontal scrolling.

### Verification checkpoints
To ensure the reconstructed system is accurate and effective, I would implement:

*   **Visual comparison:** Generate new templates using the reconstructed system and visually compare them side-by-side with key pages from the original 2018 PDF to ensure core brand look and feel is preserved.
*   **Implementability review:** Work with front-end developers to validate the system's ease of implementation, maintainability, and performance implications.
*   **Responsive testing:** Test new templates across a range of device sizes and resolutions to confirm the responsive behavior functions as intended.
*   **Documentation:** Create clear, updated documentation for the new layout system, including design tokens, grid definitions, and responsive rules, specifying what was inferred versus explicitly defined.
*   **Stakeholder review:** Present the reconstructed system to brand and product stakeholders to ensure it meets current strategic goals while honoring historical brand identity.

## Tradeoffs
*   **Preserved:** The fundamental aesthetic, hierarchy, and brand-specific "feel" of the original layouts will be preserved through careful translation of core measurements and relationships. The original intent for visual organization remains.
*   **Sacrificed:** Strict pixel-perfect replication of a fixed-width, print-oriented layout is sacrificed in favor of flexibility, responsiveness, and modern web best practices. Some minor visual deviations are inevitable during the translation from static to fluid. Interpretive decisions will be made where the 2018 PDF is ambiguous for modern contexts.
*   **Gained:** A more robust, scalable, and adaptable layout system that is easier to maintain, implement across various digital platforms, and inherently more accessible. This means accepting a degree of interpretation to align with current web standards and user expectations.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [],
  "evidence_classes_cited": [],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]