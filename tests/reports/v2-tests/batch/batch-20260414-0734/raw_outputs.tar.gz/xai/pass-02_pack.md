## Split Button Component Spec

I'm defining a split button component with a primary action ("Save") and a dropdown trigger for secondary actions ("Save as draft" and "Save and close"). This spec covers behavior, states, accessibility, and implementation boundaries for a production-ready component.

### Component Boundary
- **Purpose**: A split button combines a primary action with immediate access to related secondary actions, reducing navigation cost while maintaining a clear action hierarchy.
- **Scope**: This component includes two distinct interaction areas: the primary button ("Save") and a dropdown trigger (typically an arrow icon) that reveals a menu with secondary options.
- **Usage**: Intended for forms or workflows where a primary save action is paired with contextual save variants, ensuring users can choose without leaving the current context.
- **Tradeoff**: Prioritizes action clarity over visual minimalism; the split design adds slight visual complexity but preserves discoverability of secondary actions compared to a hidden menu.

### Visual and Layout Definition
- **Structure**: Two adjacent segments—primary button (left, 70-80% width) and dropdown trigger (right, 20-30% width)—visually united as a single button with a subtle internal divider.
- **Size**: Minimum touch target of 44x44 pixels per segment to meet WCAG 2.1 touch target guidelines, ensuring mobile usability.
- **Spacing**: Internal divider is 1px wide with a contrast ratio of at least 3:1 against the button background. Padding inside each segment is 8px vertical, 12px horizontal for readability.
- **Icon**: Dropdown trigger uses a downward chevron (Unicode U+25BC or equivalent) with a minimum size of 16x16 pixels for visibility.
- **Responsive Behavior**: On screens narrower than 320px, the primary button text may truncate with an ellipsis if needed, but the touch targets remain at least 44x44 pixels.

### State Coverage
- **Default State**: Primary button and dropdown trigger are both enabled, with clear visual separation (divider or subtle color shift). Text is "Save" on the primary, and the dropdown shows only the chevron (no text).
- **Hover State**: On desktop, hovering the primary button or dropdown trigger darkens the background by 10-15% or adds an outline (2px, contrast ratio 3:1). Each segment highlights independently to signal separate click areas.
- **Focus State**: Focus indicator (outline or glow) surrounds the active segment with a 2px outline, offset by 2px, meeting WCAG contrast requirements (at least 3:1 against background).
- **Active/Pressed State**: When clicked or tapped, the segment darkens by 20% or shifts background to indicate press, returning to default on release.
- **Disabled State**: Both segments (or individually if contextually relevant) are visually dimmed (opacity 0.5 or grayscale) and non-interactive. Text and icon contrast still meets 3:1 minimum against background to remain legible.
- **Loading State**: Primary button shows a spinner (16x16 pixels, centered) replacing the "Save" text, with the dropdown trigger disabled during the loading state. Spinner animation respects reduced-motion preferences (stops if `prefers-reduced-motion: reduce` is set).
- **Dropdown Open State**: Menu appears below the button (or above if viewport space is constrained), with a minimum width matching the button width. Menu items ("Save as draft", "Save and close") have 8px vertical padding and 44x44 pixel touch targets.

### Accessibility Behavior
- **Semantic Structure**: The component uses a `<div>` or `<button>` wrapper with `role="group"` to indicate a composite control. Primary action is a `<button>` with `aria-label="Save (primary action)"`. Dropdown trigger is a `<button>` with `aria-expanded="true/false"` and `aria-controls` pointing to the menu ID. Menu is a `<ul>` with `role="menu"` and each item as `<li>` with `role="menuitem"`.
- **Keyboard Support**: 
  - Tab moves focus to the primary button, then to the dropdown trigger as separate focus stops.
  - Enter or Space on the primary button triggers the "Save" action.
  - Enter, Space, or Down Arrow on the dropdown trigger opens the menu and focuses the first item.
  - Up/Down Arrows navigate menu items, wrapping at top/bottom.
  - Enter or Space on a menu item triggers its action and closes the menu.
  - Escape closes the menu and returns focus to the dropdown trigger.
- **Focus Management**: Focus remains on the active segment after interaction unless the menu is opened, then focus shifts to the first menu item. Closing the menu returns focus to the dropdown trigger.
- **Touch Targets**: Both segments and menu items meet 44x44 pixel minimums per WCAG 2.2 for touch accessibility.
- **Motion Safety**: Loading spinner and menu open/close animations stop if `prefers-reduced-motion: reduce` is set, defaulting to instant visibility changes.
- **State Feedback**: `aria-busy="true"` on the primary button during loading. `aria-expanded="true/false"` on the dropdown trigger reflects menu state. Screen readers announce menu item focus changes via standard ARIA roles.

### Interaction Behavior
- **Primary Action**: Clicking or tapping the primary segment triggers the "Save" action immediately, with no effect on the dropdown menu state.
- **Dropdown Trigger**: Clicking or tapping opens the menu if closed, closes it if open. Menu closes automatically after selecting an item or clicking outside.
- **Menu Selection**: Selecting "Save as draft" or "Save and close" triggers the respective action and closes the menu.
- **Loading Interaction**: During loading, the primary button is non-interactive except to visually indicate loading. Dropdown trigger is disabled until loading completes.
- **Mobile Behavior**: Touch events are handled with a 300ms debounce to prevent double-tap issues. Menu positioning accounts for viewport edges to avoid occlusion by mobile keyboards or edges.

### Implementation Boundary
- **Rendering Model**: This component is client-rendered for menu interactivity but can be server-rendered initially with progressive enhancement for non-JS contexts. Menu state management (open/close) and loading state are handled client-side.
- **State Ownership**: Parent component or form owns the "Save" action result and loading state, passing it as props (e.g., `isLoading`, `onSave`). Dropdown menu state (`isOpen`) is managed internally unless overridden by a parent for controlled behavior.
- **Event Contracts**: Emits distinct events for primary action (`onSave`), dropdown selection (`onSaveAsDraft`, `onSaveAndClose`), and menu state changes if controlled (`onToggleMenu`).
- **CSS Tokens**: Exposes design tokens for background color, hover/active color shifts, divider color, focus outline, and spacing to allow theme customization without breaking accessibility minimums.
- **Dependencies**: Requires a11y-compliant focus management (e.g., `focus-trap` for menu) and click-outside detection for menu dismissal. No external animation library needed—CSS transitions suffice for menu and spinner.
- **Cost Consideration**: Client-side menu state adds minimal JS overhead (under 1KB minified). Avoid over-rendering on state change by memoizing static segments.
- **Fallback Path**: In non-JS contexts, the primary button submits as a form action. Dropdown trigger can render as a hidden or no-op element if JS fails to load, preserving the primary action.

### Risks and Mitigation
- **Risk**: Users might miss the dropdown trigger due to its smaller size or visual subtlety.
  - **Mitigation**: Ensure the divider and chevron contrast meet 3:1 minimum. Consider a subtle animation or tooltip on first interaction for discoverability (respecting reduced-motion).
- **Risk**: Keyboard users could get trapped in the menu or lose focus context.
  - **Mitigation**: Implement Escape to close and return focus. Test focus order with screen readers to confirm ARIA roles behave as expected.
- **Risk**: Mobile touch targets might overlap or misfire due to cramped layouts.
  - **Mitigation**: Enforce 44x44 pixel minimums even under truncation. Add touch event debouncing to prevent accidental double activations.

This spec balances usability, accessibility, and implementation clarity. Let me know if you'd like me to adjust the visual design, add specific framework details (e.g., React, Vue), or refine any state behavior.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: split button with primary and dropdown segments", "state_coverage: default, hover, focus, active, disabled, loading, dropdown open", "accessibility_behavior: keyboard navigation, ARIA roles, touch targets", "implementation_boundary: client-rendered menu, server-rendered fallback"],
  "evidence_classes_cited": ["touch_target_threshold", "wcag_contrast_ratio", "aria_roles"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]