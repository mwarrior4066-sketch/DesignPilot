I’ve put together a type system for your fintech product that meets the needs of a marketing site, web app dashboard, and mobile interfaces. It prioritizes modernity, trustworthiness, and readability for tabular financial data while supporting multiple weights for clear hierarchy. Below is the recommendation with specific choices, rationale, and implementation guidance.

### Type System Recommendation

#### Primary Typeface: Inter
- **Role**: Body text, UI elements, tabular data, and primary hierarchy (headings, subheadings).
- **Why**: Inter is a modern sans-serif designed for screen readability, with a neutral yet professional tone that conveys trust. It’s optimized for UI and financial data with clear numerals, distinct letterforms (like “I” vs. “l”), and a wide range of weights (Thin to Black, 9 weights total) for flexible hierarchy. It’s also open-source under the SIL Open Font License, ensuring cost-free usage and broad compatibility.
- **Reading Context**: Excellent for dense dashboards and mobile screens due to its legibility at small sizes (down to 12px on desktop, 14px on mobile) and balanced proportions for tabular data.
- **Scale Decision**: Body text at 16px (desktop) / 14px (mobile) with a leading ratio of 1.5 for readability. Headings scale from 1.25x to 2.5x body size depending on hierarchy level.
- **Pairing Rationale**: Inter’s neutrality pairs well with itself across weights, reducing visual noise in data-heavy contexts. It avoids overly decorative or quirky traits that could undermine trust in a fintech context.

#### Secondary Typeface: IBM Plex Mono (Optional for Code/Technical Elements)
- **Role**: Monospace text for transactional IDs, account numbers, or code snippets in dashboards.
- **Why**: IBM Plex Mono offers a clean, modern monospace option with clear distinction for financial codes and data fields. It aligns with Inter’s modern aesthetic while providing functional contrast for technical content. Also open-source under SIL Open Font License.
- **Reading Context**: Used sparingly at 14px (desktop) / 13px (mobile) for specific data fields to maintain scanability in tables.
- **Scale Decision**: Matches body text size to avoid visual disruption in tables.

#### Fallback Stack
- **Stack**: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif
- **Rationale**: This stack prioritizes system fonts with similar metrics to Inter, ensuring consistent rendering if the primary font fails to load. For monospace, fallback to "Courier New", Courier, monospace if IBM Plex Mono is not used.

#### Variable Font Usage
- **Approach**: Use Inter Variable (the variable font version of Inter) where supported (modern browsers and mobile OS) to reduce file size and enable fine-grained weight adjustments for responsive design. Define weights dynamically between 300-800 for subtle hierarchy shifts at different breakpoints.
- **Fallback**: Serve static Inter weights (Light 300, Regular 400, Medium 500, SemiBold 600, Bold 700) for older browsers or unsupported environments.

#### Hierarchy and Weights
- **H1 (Marketing Hero / Dashboard Title)**: Inter Bold (700), 2.25x-2.5x body size (36-40px desktop, 28-32px mobile)
- **H2 (Section Headings)**: Inter SemiBold (600), 1.75x-2x body size (28-32px desktop, 22-24px mobile)
- **H3 (Subheadings)**: Inter Medium (500), 1.25x-1.5x body size (20-24px desktop, 18-20px mobile)
- **Body Text (Paragraphs, Labels)**: Inter Regular (400), 16px desktop, 14px mobile
- **Captions / Fine Print**: Inter Light (300), 14px desktop, 12px mobile
- **Tabular Data**: Inter Regular (400) for values, Inter Medium (500) for headers, 14-16px desktop, 13-14px mobile
- **Rationale**: Multiple weights create clear visual hierarchy without relying on size alone, critical for dashboards where space is constrained. Light weights for captions prevent visual heaviness, while Bold ensures marketing headlines stand out.

#### Line Length and Leading
- **Target Line Length**: 50-75 characters for body text on desktop (marketing site), 30-50 on mobile to ensure readability.
- **Leading Ratio**: 1.5 for body text (24px line-height on 16px text), 1.2-1.3 for headings to keep hierarchy tight, 1.6 for tabular data to separate rows visually.
- **Rationale**: These ratios balance density and scanability, especially for financial data where users need to parse numbers quickly.

#### Adoption Sequence
1. **Marketing Site**: Start with Inter for headlines and body copy, using Bold and Regular weights to establish trust and clarity in messaging. Implement variable fonts for hero text animations or responsive scaling if supported.
2. **Web App Dashboard**: Deploy Inter across UI labels, navigation, and tabular data, leveraging Medium and SemiBold for hierarchy in data tables. Use IBM Plex Mono for transaction IDs or account numbers to distinguish them visually.
3. **Mobile**: Optimize with Inter Variable for smaller file sizes, adjusting weights dynamically for screen size (e.g., lighter weights at smaller sizes to avoid clutter). Test readability at 14px for body text and 12px for captions on iOS and Android.
4. **Testing**: Verify numeral clarity in tables (no confusion between 0, O, 1, I) and ensure contrast meets WCAG AA (4.5:1 for normal text, 3:1 for large text) across dark and light themes.

### Tradeoffs
- **Preserved**: Readability and trust through a neutral, modern sans-serif with excellent numeral clarity for financial data. Multiple weights ensure hierarchy across platforms without overloading the design system.
- **Sacrificed**: A more distinctive or branded typeface (e.g., a custom or premium font) is deprioritized to favor functional clarity and licensing simplicity. This means accepting a less unique visual identity in exchange for reliability and cost efficiency.

### Next Steps
- If you have a specific brand direction or existing typeface in use, I can adjust this to integrate or pair with it.
- I can provide a detailed CSS implementation for web and mobile, including variable font setup and fallback behavior, if you’d like to move to code handoff.
- Let me know if you want to test this system with sample dashboard data or marketing copy to refine the scale or weights.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": ["reading_context: screen readability for UI and financial data", "scale_decision: body 16px desktop/14px mobile, headings 1.25x-2.5x", "pairing_rationale: Inter’s neutrality for minimal noise", "adoption_sequence: marketing → dashboard → mobile → testing"],
  "evidence_classes_cited": ["threshold", "artifact"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]