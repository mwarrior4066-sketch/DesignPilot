I'll write a component spec for a split button with primary action, dropdown secondary actions, and full accessibility support.

---

## Component Spec: Split Button

### Component Boundary
**Name:** `SplitButton`
**Purpose:** A compound button that separates a primary action from a dropdown of secondary actions, maintaining clear hierarchy while saving space.

**When to use:**
- Primary action is clear and frequently used
- Secondary actions are related but less common
- Space is constrained but hierarchy matters
- User needs quick access to primary action with discoverable alternatives

**When not to use:**
- All actions are equally important (use button group)
- Only one action exists (use regular button)
- Secondary actions are unrelated (use separate buttons)
- Mobile-only interfaces where split interaction is awkward

### State Coverage

#### 1. **Default State**
- Primary button: filled, prominent styling
- Divider: subtle visual separator
- Dropdown trigger: chevron or caret icon
- Hover states distinct for each segment

#### 2. **Disabled State**
- Entire component disabled OR primary-only disabled
- Visual: reduced opacity, no pointer events
- Keyboard: skip in tab order
- Screen reader: `aria-disabled="true"` on disabled elements

#### 3. **Loading State**
- Primary button shows spinner, preserves text label
- Dropdown remains interactive unless primary action is loading
- `aria-live="polite"` announces loading status
- Prevents double-submission

#### 4. **Active/Dropdown Open State**
- Dropdown trigger visually pressed
- Dropdown menu positioned below (preferred) or aligned to component
- Focus moves to first menu item
- Escape key closes dropdown, returns focus to trigger

#### 5. **Focus States**
- Separate focus rings for primary button and dropdown trigger
- Visual distinction between keyboard and mouse focus
- `:focus-visible` for keyboard navigation
- Focus trap within dropdown when open

### Accessibility Behavior

#### Keyboard Support
```
Tab: Focus primary button → Tab: Focus dropdown trigger
Enter/Space on primary: Activate primary action
Enter/Space on dropdown: Open/close menu
Arrow Down/Up on dropdown (when open): Navigate menu items
Enter/Space on menu item: Activate item
Escape: Close menu, return focus to dropdown trigger
Tab (when menu open): Close menu, move to next focusable element
Shift+Tab (when menu open): Close menu, move to previous focusable element
```

#### Screen Reader Semantics
```html
<div role="group" aria-label="Save actions">
  <button aria-label="Save">
    Save
    <span class="visually-hidden">(primary action)</span>
  </button>
  
  <span aria-hidden="true" class="divider"></span>
  
  <button 
    aria-haspopup="menu" 
    aria-expanded="false"
    aria-label="More save options"
  >
    <svg aria-hidden="true">...</svg>
  </button>
  
  <ul role="menu" hidden>
    <li role="menuitem">Save as draft</li>
    <li role="menuitem">Save and close</li>
  </ul>
</div>
```

#### Touch Target Compliance
- Minimum 44×44px touch targets for both segments
- 8px spacing between touch targets (prevents mis-taps)
- Visual hit area extends beyond visible bounds
- Press-and-hold on dropdown for touch devices without hover

### Implementation Boundary

#### Props Interface
```typescript
interface SplitButtonProps {
  // Required
  primaryAction: {
    label: string;
    onAction: () => void | Promise<void>;
  };
  
  // Secondary actions
  secondaryActions: Array<{
    id: string;
    label: string;
    onAction: () => void;
    icon?: ReactNode;
    disabled?: boolean;
  }>;
  
  // States
  disabled?: boolean;
  loading?: boolean;
  
  // Accessibility
  ariaLabel?: string;
  menuPosition?: 'below' | 'end' | 'start';
  
  // Styling
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'small' | 'medium' | 'large';
}
```

#### CSS Architecture
```css
/* Base component */
.split-button {
  display: inline-flex;
  position: relative;
  border-radius: var(--radius-md);
}

/* Primary segment */
.split-button__primary {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-right: none;
}

/* Divider */
.split-button__divider {
  width: 1px;
  background: var(--color-border);
  margin: 0;
}

/* Dropdown trigger */
.split-button__trigger {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  padding: 0 var(--spacing-sm);
  min-width: 44px; /* Touch target */
}

/* Dropdown menu */
.split-button__menu {
  position: absolute;
  top: 100%;
  right: 0;
  min-width: 200px;
  z-index: var(--z-index-dropdown);
}

/* Touch optimization */
@media (pointer: coarse) {
  .split-button__primary,
  .split-button__trigger {
    min-height: 44px;
    padding: var(--spacing-sm) var(--spacing-md);
  }
}
```

#### React Implementation Notes
```typescript
// Key considerations:
1. Use React.Children.map for composition if supporting slots
2. Implement proper promise handling for async primary actions
3. Use floating-ui or @popperjs for robust dropdown positioning
4. Implement focus management with react-focus-lock or native DOM
5. Support controlled/uncontrolled dropdown state
6. Add keyboard event handlers with proper preventDefault
```

### Variants and Sizes

#### Variants
- **Primary:** Filled button with accent color (default)
- **Secondary:** Outline style for less prominence
- **Ghost:** Minimal styling for toolbar contexts

#### Sizes
- **Small:** 32px height, compact for dense interfaces
- **Medium:** 40px height (default)
- **Large:** 48px height for mobile/touch emphasis

### Error States and Edge Cases

#### Loading State Failures
- If primary action fails, show error state on button
- Allow retry without closing dropdown
- Maintain dropdown accessibility during error

#### Overflow Handling
- Menu items truncate with ellipsis
- Menu width matches longest item + padding
- Scrollable menu if more than 6 items (not recommended)

#### Mobile Considerations
- On narrow viewports, consider collapsing to single dropdown
- Touch feedback with `:active` states
- Prevent keyboard overlap on iOS/Android

### Testing Requirements

#### Unit Tests
- Primary click triggers callback
- Dropdown opens/closes correctly
- Keyboard navigation works
- Disabled state prevents interaction
- Loading state shows spinner

#### Integration Tests
- Works within form contexts
- Focus management with surrounding elements
- Screen reader announces all states
- Touch events work on mobile devices

#### Visual Regression
- All states captured
- Cross-browser rendering
- High contrast mode compatibility

### Usage Examples

#### Basic Implementation
```jsx
<SplitButton
  primaryAction={{
    label: "Save",
    onAction: handleSave
  }}
  secondaryActions={[
    { id: "draft", label: "Save as draft", onAction: saveDraft },
    { id: "close", label: "Save and close", onAction: saveAndClose }
  ]}
/>
```

#### With Loading State
```jsx
<SplitButton
  primaryAction={{
    label: "Publishing...",
    onAction: publishArticle
  }}
  secondaryActions={[...]}
  loading={isPublishing}
  disabled={isPublishing}
/>
```

### Accessibility Verification Method
1. **Keyboard-only navigation** through all states
2. **Screen reader** (NVDA/JAWS/VoiceOver) announces:
   - Role and label
   - Expanded/collapsed state
   - Menu item labels
   - Loading/disabled status
3. **Color contrast** meets WCAG 2.1 AA (4.5:1 for text)
4. **Touch target** validation on real mobile devices
5. **Focus indicator** visible in high contrast mode

### Tradeoffs and Constraints

**What this spec preserves:**
- Clear action hierarchy (primary vs secondary)
- Space efficiency compared to separate buttons
- Full keyboard and screen reader accessibility
- Mobile touch compatibility

**What this spec sacrifices:**
- Simplicity of a single button
- Immediate visibility of all actions
- Some screen real estate for proper touch targets
- Implementation complexity over basic button

**Implementation cost:** Medium-high due to:
- Robust focus management
- Cross-platform touch handling
- Accessible dropdown semantics
- State synchronization

**Maintenance surface:** Medium - dropdown positioning and focus behavior require careful testing across browsers and assistive technologies.

---

**Component decision rationale:** A split button makes sense here because "Save" is clearly the primary action with predictable alternatives. The dropdown keeps the interface clean while maintaining discoverability. The accessibility implementation ensures no user is excluded, and touch targets guarantee mobile usability. The loading state prevents double submissions while keeping secondary actions available.