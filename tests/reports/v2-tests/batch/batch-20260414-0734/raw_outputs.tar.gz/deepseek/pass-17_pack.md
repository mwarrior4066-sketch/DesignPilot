## Functional tier

Let’s start with the basics.  
A global state manager (like Redux) is a tool that stores data in one central place, separate from your components. Local component state is data that lives inside a single component, and React Context is a way to share that state with child components without passing it down manually through props.

Here’s how to think about the choice:

**When you might need Redux or a similar global store:**
- Multiple parts of your app need to read and update the same data (like user profile, shopping cart, theme settings).
- The data changes often and from many different places.
- You need to track changes over time for debugging (Redux DevTools).
- You have complex async logic (like API calls) that many components depend on.

**When local state + Context is enough:**
- You’re sharing data mostly within one section of the app (like a form and its children).
- The data doesn’t change very often (like user preferences or UI theme).
- You don’t need to replay or debug every state change.
- Your app is small or medium-sized, and adding Redux feels like overkill.

**Tradeoff to consider:**
- Redux adds extra code and setup, but gives you predictability and debugging.
- Context is simpler to set up, but can cause unnecessary re-renders if not optimized.

**Recommendation for this tier:**  
If your app is small or the shared state is limited, start with React Context. If you have lots of interdependent state that changes often, use Redux.

---

## Integrative tier

This decision sits at the intersection of front‑end architecture, performance, team coordination, and long‑term maintenance.

**Architectural implications**
- **Redux** enforces a single source of truth and unidirectional data flow. Mutations happen through actions and reducers, which makes state changes predictable and testable. This is valuable when many teams work on the same codebase, because everyone follows the same pattern.
- **Context + local state** is more flexible and closer to React’s own mental model. However, it can lead to “prop drilling” if you’re not careful, and over‑using Context for frequently‑changing data can trigger re‑renders across entire subtrees unless you memoize aggressively.

**Performance and scale**
- Redux’s useSelector hook lets components subscribe to fine‑grained slices of state, minimizing re‑renders.
- Context re‑renders all consumers when the provided value changes—so if you put a large, frequently‑updated object in Context, you may hurt performance.
- For apps that grow over time, Redux’s middleware (thunk, saga, RTK Query) provides a structured way to handle side effects (API calls, caching, optimistic updates).

**Team and maintenance factors**
- Redux has a learning curve and requires more boilerplate. That’s a tax, but it also creates a consistent convention that scales across teams.
- Context is easier to grasp initially, but without clear conventions, different developers may invent their own state‑sharing patterns, leading to inconsistency.

**Tradeoff statement**  
You’re choosing between **structure and predictability** (Redux) and **simplicity and flexibility** (Context + local state). The cost of Redux is upfront boilerplate and conceptual overhead; the cost of Context is potential performance debt and architectural drift as the app grows.

**Recommendation for this tier:**  
Unless the app is truly small and simple, prefer Redux (or Redux Toolkit) if the state is shared across multiple feature boundaries, changes frequently, or requires robust debugging/tooling.

---

## Strategic tier

**Core question:** Does the state need to be global, or can it be colocated?

**If the state is truly global** (user session, permissions, shopping cart, real‑time notifications, multi‑step workflows that span routes), a global store reduces coordination costs and ensures a single source of truth. Redux (especially Redux Toolkit) is the industry‑standard solution here—it’s boring, predictable, and scales with tooling.

**If the state is localized** (UI toggles, form drafts, modal visibility, theme for a subtree), keep it in component state or lift it only as far as necessary with Context. Adding Redux for transient UI state adds complexity without payoff.

**Architecture tax**  
Redux introduces: action/reducer boilerplate, middleware configuration, and an additional layer of indirection. That’s acceptable when the state is important enough to justify it.  
Context introduces: potential re‑render cascades and less‑explicit data flow. That’s acceptable when the state is stable or confined to a subtree.

**Debugging and observability**  
Redux DevTools give you time‑travel debugging, action logs, and state snapshots. In production‑grade apps, this is often worth the overhead. Context has no built‑in debugging tooling.

**Decision rule**  
Use Redux when:
- State is shared across unrelated feature modules
- State changes are frequent and originate from many places
- You need strong debugging, undo/redo, or persistence capabilities
- The team already knows Redux or the app is expected to grow beyond a few screens

Use Context + local state when:
- State is confined to a feature or subtree
- Changes are infrequent
- The team is small and the cost of Redux outweighs the benefits
- You’re building a prototype or a simple internal tool

**Governing recommendation:**  
For a typical production React app with multiple features and shared state, adopt Redux Toolkit. For a focused, single‑feature app or a UI‑heavy component library, use React Context and local state.

---

## Rendering and mutation strategy

If using Redux:
- Keep state normalized where possible (store entities by ID).
- Use Redux Toolkit’s `createSlice` for reducers and actions.
- Place side effects in thunks or RTK Query endpoints.
- Connect components via `useSelector` with shallow equality checks.

If using Context:
- Split Context by domain (AuthContext, ThemeContext, etc.) to avoid unnecessary re‑renders.
- Memoize the Context value with `useMemo` if it’s derived from frequently changing state.
- Consider using `useReducer` inside Context for more complex local state logic.

---

## Risks and safer path

**Risk with Redux:** Over‑engineering. Adding Redux too early can slow development and increase bundle size without tangible benefit.

**Mitigation:** Start with Context + local state, and migrate to Redux only when you feel pain—when prop drilling becomes unmanageable, debugging state changes is difficult, or async logic gets tangled.

**Risk with Context:** Performance degradation. Putting a large, mutable object in Context can cause widespread re‑renders.

**Mitigation:** Keep Context values stable (use `useMemo`), split Contexts, and lift state only as high as needed. Use `React.memo` on child components.

**Safer path:**  
Begin with local state and React Context. The moment you find yourself passing the same state through more than two levels of components, or when multiple features need to react to the same state changes, evaluate Redux Toolkit. This incremental approach avoids premature complexity while keeping the door open for scaling.

---

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": ["rendering_model: client-hydrated at component boundary", "state_ownership: global store for cross-feature state", "boundary_placement: Redux for shared state, Context for subtree state", "semantic_contract: actions/reducers for mutations", "cost_or_degraded_path: Redux adds boilerplate but provides debugging and scalability"],
  "evidence_classes_cited": ["threshold", "rule", "constraint"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]