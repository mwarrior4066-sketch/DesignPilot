I’ll recommend a type system for a fintech product that works across marketing site, web app dashboard, and mobile, with modern/trustworthy feel, good tabular data support, and multiple weights for hierarchy.

---

## Recommended type system

**Primary typeface: Inter**  
**Secondary/display option: Source Serif Pro** (for marketing headlines and trust cues)  
**Monospace: JetBrains Mono** (for code snippets, data values, or tabular precision)

---

### Why Inter
- **Neutral, highly readable sans-serif** designed for UI and screens.
- **Excellent legibility at small sizes** (crucial for dashboards and mobile).
- **Multiple weights** (Thin to Black) with true italics — supports strong hierarchy.
- **Open-source and free** (no licensing friction).
- **Variable font available** (Inter Variable) — reduces file size, enables fine‑tuned weight/width adjustments.
- **Strong tabular figures** (monospaced numbers) built‑in — essential for financial data alignment.
- **Widely adopted in tech/fintech** (Stripe, Linear, etc.) — feels modern and credible.

### Why Source Serif Pro (optional, for marketing)
- **Adds warmth and editorial trust** in headlines, quotes, and landing pages.
- **Pairs cleanly with Inter** — complementary but not distracting.
- **Also open-source** and has variable font version.
- Use sparingly in the app — only for high‑impact trust moments (e.g., onboarding statements, legal footers).

### Why JetBrains Mono (optional, for data/code)
- **Excellent character distinction** (0/O, 1/l/I).
- **Free, open-source**, designed for developers and data‑dense interfaces.
- Use for:
  - Monospace tables (transaction IDs, account numbers)
  - Code examples in documentation
  - In‑app console/export previews

---

## Hierarchy scale (modular scale: 1.25)

| Role | Web size (px) | Mobile size (px) | Weight | Use |
|------|---------------|------------------|--------|-----|
| Display (marketing) | 48–64 | 32–40 | Semibold (600) | Hero headlines, campaign titles |
| H1 | 36 | 28 | Semibold (600) | Page titles, major sections |
| H2 | 28 | 22 | Semibold (600) | Section headings |
| H3 | 22 | 18 | Semibold (600) | Sub‑section headings |
| H4 | 18 | 16 | Medium (500) | Card titles, panel headers |
| Body large | 18 | 17 | Regular (400) | Lead paragraphs, intro text |
| Body | 16 | 15 | Regular (400) | Primary UI text, paragraphs |
| Small | 14 | 13 | Regular (400) | Labels, captions, helper text |
| X‑small | 12 | 11 | Regular (400) | Legal, fine print, table footers |
| Tabular/data | 15 | 14 | Medium (500) monospace | Numbers, IDs, financial figures |

---

## Implementation notes

1. **Use variable fonts where possible**  
   Load `Inter.var.woff2` and `SourceSerifVariable-Roman.woff2` — one file per family, adjustable via `font-variation-settings`.

2. **Enable tabular figures for financial data**  
   ```css
   .financial-table {
     font-feature-settings: "tnum"; /* tabular numbers */
     font-variant-numeric: tabular-nums;
   }
   ```

3. **Mobile adjustments**  
   Slightly reduce line‑height on mobile (e.g., 1.4 instead of 1.5) to manage vertical rhythm in dense dashboards.

4. **Dark mode**  
   Inter holds up well in dark themes; ensure contrast ≥ 4.5:1 for body text, ≥ 3:1 for large text.

5. **Fallback stack**  
   ```css
   font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
   ```

6. **Pairing rule**  
   Use Source Serif only for:
   - Marketing headlines
   - Pull quotes
   - Trust statements
   - Legal/disclosure blocks
   
   Avoid mixing serif and sans in the same UI block unless you’re deliberately signaling “this is different.”

---

## What this gives you

- **Trustworthy + modern** — Inter is professional and neutral; Source Serif adds warmth where needed.
- **Tabular readiness** — built‑in tabular figures and monospace option for data.
- **Hierarchy range** — 9 weights (Thin to Black) plus variable fine‑tuning.
- **Cross‑platform consistency** — works on web, iOS, Android (Inter is available via system fonts on some platforms).
- **No licensing cost** — fully open‑source, safe for product use.

---

## Tradeoffs

- **Inter is ubiquitous** — you won’t stand out typographically, but that’s often a strength in fintech (familiarity → trust).
- **Source Serif is a secondary voice** — it adds character but requires clear rules to avoid visual noise.
- **Variable font support** is excellent in modern browsers, but test fallbacks for older environments.

---

## Next steps

1. Test the scale in your actual dashboard with real data tables.
2. Check contrast in both light and dark themes.
3. Define a limited set of allowed weights (e.g., Regular, Medium, Semibold) to keep the system manageable.

Would you like me to generate the CSS variable setup or a Figma text‑style spec for this system?