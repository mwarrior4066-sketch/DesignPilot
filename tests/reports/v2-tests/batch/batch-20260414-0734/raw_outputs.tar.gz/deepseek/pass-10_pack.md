**Hierarchy failure:** The decorative title is visually dominant but semantically empty—it’s a style statement before the audience understands what the event is, why they should care, or who it’s for. This creates cognitive friction: viewers must work backward from the logo and small date to piece together the purpose.

**Communication goal mismatch:** A conference poster’s job is to attract the right attendees, convey credibility, and prompt action (register, save the date). Here, the visual drama of the skyline and decorative typeface overshadows the information needed to make a decision.

**Structural rebuild move:**
1. **Lead with the conference name or a clear value proposition**—not a decorative title. If the decorative type is the conference name, it must be immediately recognizable as such; if it’s a tagline, it should be subordinate.
2. **Pull key details into the visual hierarchy:** date, location, and call-to-action (e.g., “Register now,” “Early bird ends…”) need visual weight proportional to their importance.
3. **Use the skyline as context, not competition:** ensure text has consistent contrast against the varying background (white logo works, but small gray text may disappear).
4. **Test the 3‑second scan:** what does someone across the room see first? It should be “what” and “why,” not just “looks cool.”

**Tradeoff:** You sacrifice some stylistic purity for clarity and conversion. The current design prioritizes atmosphere over communication; a rebuilt version would prioritize audience comprehension while keeping the skyline and logo as atmosphere.

**Recommendations:**
- **Option A (minimal change):** enlarge the conference logo and place it above or beside the decorative title, so the relationship is immediate. Increase date/location size and contrast.
- **Option B (structural shift):** lead with the conference name in a strong, readable typeface. Use the decorative typeface for a short tagline or the date/location block. Add a clear call-to-action.
- **Check visibility:** ensure all text meets WCAG contrast requirements against the skyline photo (white on dark areas may pass; gray likely fails).

**What to do next:**
- If you have the source file, adjust the layout to test these hierarchy changes.
- If you want a quick visual mockup of the revised hierarchy, I can describe a layout grid and type sizes.
- If you’re also considering the audience’s journey (how they hear about the conference, where posters are displayed), we could map the poster’s role in the broader campaign.

---

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": ["communication_goal: attract and inform", "hierarchy_failure: title before context", "rebuild_move: lead with conference name or value prop", "distance_tradeoff: clarity over stylistic purity"],
  "evidence_classes_cited": ["visual_scan_test", "wcag_contrast_threshold"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]