I’ll write a backend architecture spec for this multi-tenant scheduling platform.  
First, I’ll load the governing route and contract, then the relevant backend architecture skill, and structure the spec according to the required output sections.

---

**Governing route:** `rt_backend_architecture_spec`  
**Supporting skill:** `back-end-systems-architect.md`  
**Task weight:** `compound` (multi-tenant, eventing, data residency, audit, automation)

---

## Backend Architecture Spec: Multi‑Tenant Scheduling Platform

### 1. Core Services & Data Boundaries

**Tenant Isolation Model**  
- Each tenant is a **team workspace** with its own users, resources, schedules, and workflows.  
- Data residency is enforced at the **tenant level** via a `region` column in the `tenants` table; all child records inherit this region for storage and processing.  
- Database schemas use **tenant‑id partitioning** (`tenant_id` on every table`) plus region‑aware sharding for cross‑region compliance.

**Service Breakdown**

| Service | Responsibility | Data Boundary |
|---------|----------------|---------------|
| **Tenant & Identity Service** | Tenant onboarding, user management, SSO, role‑based access control (RBAC), region assignment. | `tenants`, `users`, `roles`, `permissions`, `sessions`. |
| **Scheduling Engine** | Resource availability, conflict detection, recurrence, time‑zone handling, calendar integrations. | `resources`, `slots`, `bookings`, `recurrence_rules`. |
| **Workflow Service** | Approval chains, state transitions, escalations, user‑task assignment. | `approval_workflows`, `approval_instances`, `tasks`. |
| **Activity Feed Service** | Generates and serves cursor‑paginated activity events (create/update/approval/completion). | `activity_events`, feed cursors, tenant‑scoped materialized views. |
| **Webhook Dispatcher** | Reliable, retry‑safe delivery of outbound events to customer‑defined endpoints. | `webhook_subscriptions`, `webhook_deliveries`, dead‑letter queue. |
| **Automation Rules Engine** | Customer‑defined rules (event‑condition‑action) evaluated on scheduling/workflow events. | `automation_rules`, `rule_executions`. |
| **Audit Service** | Immutable log of all data mutations and sensitive actions for compliance. | `audit_logs` (append‑only, indexed by tenant, actor, resource). |
| **Background Job Coordinator** | Unified job queue for all async work: conflict‑checking, feed aggregation, webhook delivery, rule evaluation, report generation. | `jobs` table with priority, tenant‑id, region‑affinity. |

**Data Residency Implementation**  
- Each region runs a separate **database cluster**; the `region` field in the tenant record determines which cluster to query.  
- Cross‑region queries are prohibited at the application layer; all services include a **region‑aware data‑access layer** that routes queries to the correct cluster.  
- Background jobs are pinned to the region of the tenant that triggered them.

### 2. Contracts & APIs

**Internal Service Contracts**  
- Events are published via a **tenant‑scoped, region‑local message bus** (e.g., Kafka with regional clusters).  
- Each service emits domain events (e.g., `BookingCreated`, `ApprovalRequested`) that other services can subscribe to.  
- The **Activity Feed Service** consumes these events to build the feed; the **Webhook Dispatcher** listens for events that match customer subscriptions.

**External API Contracts**  
- REST APIs follow **RFC 9457** for error responses (`type`, `title`, `status`, `detail`, `instance`).  
- **Cursor‑based pagination** for activity feeds:  
  ```
  GET /api/v1/activity?cursor=<base64>&limit=50
  Response includes `next_cursor` and `prev_cursor`; cursors are opaque, time‑sorted, tenant‑scoped.
  ```
- **Webhook delivery contract**:  
  - `POST` to customer endpoint with `X-Webhook-Signature` (HMAC).  
  - Payload includes `event_id`, `event_type`, `tenant_id`, `timestamp`, `data`.  
  - Retry with exponential backoff + jitter; dead‑letter after 72 hours.  
- **Idempotency** for booking and approval actions via `Idempotency‑Key` header (stores result for 24 hours).

**Multi‑Tenancy API Enforcement**  
- Every request is tagged with `tenant_id` from the authenticated user’s session.  
- Database queries **always** include `WHERE tenant_id = ?`; ORM/query‑builder enforces this at the middleware layer.  
- Row‑level security (RLS) in PostgreSQL as a defense‑in‑depth measure.

### 3. Operational Concerns

**Observability**  
- Each log line includes `tenant_id`, `region`, `trace_id`.  
- Metrics per tenant: API latency, error rates, webhook delivery success, job‑queue depth.  
- Dashboards show per‑region health and tenant‑level activity spikes.

**Background Job Consistency**  
- Single job‑queue table per region, with priority levels (high for conflict‑checking, medium for webhooks, low for feeds).  
- Job workers are **tenant‑aware** and process jobs in batches by tenant to improve cache locality.  
- Idempotent job handling: job payload includes a unique key; duplicates are discarded.

**Audit Trail Guarantees**  
- Audit service subscribes to all mutation events and writes to an **append‑only table** with `tenant_id`, `actor_id`, `action`, `resource_type`, `resource_id`, `old_values`, `new_values`, `ip_address`, `timestamp`.  
- Audit logs are stored in the same region as the tenant’s data; exports are available via secure API.

**Webhook Reliability**  
- Webhook dispatcher uses a **dedicated job queue** with exponential backoff (max 10 attempts).  
- Success/failure states are recorded in `webhook_deliveries`; failures are alerted after the 4th attempt.  
- Customers can view delivery status via API.

**Automation Rules Scalability**  
- Rules are evaluated in a **tenant‑isolated sandbox** (JavaScript or a DSL).  
- Rule‑execution timeouts (e.g., 2 seconds) to prevent tenant‑level DoS.  
- Execution logs are stored with the audit trail.

**Regional Deployment**  
- Each region runs a full stack of microservices connected to its own database and message bus.  
- Global tenant‑routing service directs API requests to the correct region.  
- Cross‑region replication is limited to **non‑resident data** (e.g., aggregated global metrics, support tickets).

### 4. Risks & Safer Path

**Risk: Event‑driven complexity**  
- If event‑handling becomes inconsistent, the system can lose feed items or webhook deliveries.  
**Safer path**: Start with a **synchronous activity‑feed write** (in the same transaction as the booking/approval) and a **simple job queue** for webhooks. Add event‑driven decoupling only after consistency is proven.

**Risk: Multi‑region data leakage**  
- A bug in the region‑routing layer could expose one tenant’s data to another region.  
**Safer path**: Use **physical database separation** (different clusters) and enforce region checks at the ORM level; add automated tests that verify no cross‑region queries.

**Risk: Customer‑defined rules can break tenant isolation**  
- A poorly written rule could access other tenants’ data or overload the system.  
**Safer path**: Run rules in a **strictly sandboxed interpreter** (no I/O, memory limits, timeout), and initially offer only a limited set of pre‑built automation templates.

**Risk: Cursor‑based feed pagination with high churn**  
- If activities are deleted or modified, cursors may skip or repeat items.  
**Safer path**: Use **immutable activity events** (soft‑delete only) and cursor keys based on `(timestamp, id)`; never allow clients to paginate by arbitrary offsets.

**Risk: Webhook delivery backlog under load**  
- A slow customer endpoint can block deliveries for other tenants.  
**Safer path**: Implement **per‑tenant concurrency limits** and priority‑based job scheduling; monitor queue depth per tenant.

---

## Summary of Key Decisions

| Decision | Rationale |
|----------|-----------|
| **Tenant‑id on every table** | Simplifies partitioning, auditing, and backup/restore per tenant. |
| **Region‑local databases** | Meets data‑residency requirements; avoids cross‑border latency and compliance risk. |
| **Cursor‑based pagination for activity feeds** | Stable, scalable pagination that works with real‑time inserts. |
| **Centralized background job queue per region** | Replaces inconsistent job systems; enables tenant‑aware scheduling and monitoring. |
| **Append‑only audit logs** | Immutable trail for compliance; can be streamed to external SIEM. |
| **Webhook dispatcher as a dedicated service** | Isolates reliability concerns from core scheduling logic. |
| **Sandboxed automation rules** | Prevents tenant‑level security and performance issues. |

---

**Next steps**  
1. Implement the region‑aware data‑access layer and tenant‑id middleware.  
2. Build the unified job queue and migrate existing async tasks.  
3. Design the activity‑feed schema and cursor‑pagination API.  
4. Add webhook subscription management and delivery tracking.  
5. Pilot the automation‑rules engine with a limited DSL before allowing custom JavaScript.

---

[SESSION_STATE]
{
  "route": "rt_backend_architecture_spec",
  "escalation_level": "compound",
  "decisions_committed": ["authority_model: tenant‑id + region‑sharding", "consistency_stance: region‑local eventual consistency", "data_delivery: cursor‑based pagination + webhook dispatcher", "observability_tax: per‑tenant metrics + audit logs"],
  "evidence_classes_cited": ["threshold", "constraint", "artifact"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]