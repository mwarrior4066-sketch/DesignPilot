[SESSION_STATE]
{
  "route": "rt_api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": ["problem_details_contract: RFC 9457", "authorization_perimeter: object-level", "idempotency_contract: required", "async_job_model: not required", "resilience_strategy: retry safety"],
  "evidence_classes_cited": ["RFC 9457", "BOLA", "idempotency_key"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]

## Architectural Review: POST /api/v1/projects/{id}/members

**Governing decision: This endpoint fails the authorization, error handling, and idempotency contracts required for a production API.** It is not safe to deploy in its current form.

### 1. Authorization Perimeter
**Decision: Authorization must enforce object-level access control (BOLA).**
*   **Rationale:** The endpoint checks if the caller is logged in (authentication) but does not verify if they are a project admin (authorization). This is a Broken Object Level Authorization (BOLA) vulnerability. Any authenticated user could add members to any project they know the ID of.
*   **Required fix:** Add a server-side check that the authenticated user has the `admin` role (or equivalent permission) for the specific project identified by `{id}`. The rule is **deny by default**.

### 2. Problem Details Contract
**Decision: Error responses must follow RFC 9457 (Problem Details for HTTP APIs).**
*   **Rationale:** Returning a plain string for errors is not machine-readable, lacks a standard `type` URI for classification, and provides no structured way for clients to handle different failure modes (e.g., "project not found" vs. "user not found" vs. "user already a member").
*   **Required fix:** All error responses (4xx, 5xx) must return a JSON object with `type`, `title`, `status`, and optionally `detail` and `instance`. This allows clients and API gateways to reliably parse and react to failures.

### 3. Idempotency Contract
**Decision: POST operations that mutate state must be idempotent using a client-supplied idempotency key.**
*   **Rationale:** Without idempotency, network retries or client double-clicks can lead to duplicate members being added. The current 200 response on success makes retry logic unsafe.
*   **Required fix:** Require an `Idempotency-Key` header (e.g., a UUID) from the client. The server must:
    1.  Store the key with the request's intended outcome.
    2.  For a duplicate key within the window (e.g., 24 hours), return the stored response (e.g., 200 with the original member list) without executing the operation again.
    3.  Use `409 Conflict` if the idempotency key is provided but the request parameters differ.

### 4. Async Job Model
**Decision: A synchronous 200 response is acceptable for this operation.**
*   **Rationale:** Adding a member is typically a fast, atomic database operation. There is no clear need for a long-running background job, so a 202 Accepted with a status URL would add unnecessary complexity.
*   **Note:** If the operation involved complex provisioning, external system calls, or could take >1-2 seconds, the decision would change to **require a 202 Accepted response with a job status endpoint.**

### 5. Resilience Strategy
**Decision: The current design lacks retry safety and conflict detection.**
*   **Rationale:** Beyond idempotency, the endpoint does not define behavior for concurrent requests (e.g., two admins adding the same user simultaneously) or for idempotency key replay windows.
*   **Required fix:** Implement the idempotency key system as above. Additionally, use a unique constraint in the database on `(project_id, user_id)` to guarantee data integrity and return a `409 Conflict` (with a proper Problem Details body) if a duplicate membership is attempted.

---

## Summary of Required Changes

1.  **Authorization:** Add object-level check: `caller must be admin of project {id}`.
2.  **Error Format:** Adopt RFC 9457 Problem Details JSON for all error responses.
3.  **Idempotency:** Require an `Idempotency-Key` header, implement server-side deduplication, and use `409 Conflict` for parameter mismatches.
4.  **Data Integrity:** Enforce a database unique constraint on the membership table and return a structured `409` on duplicates.

**What is preserved:** The simple, synchronous success flow (200 OK with member list) remains valid for fast operations.
**What is sacrificed:** The simplicity of a naive implementation. You accept the complexity of implementing authorization logic, structured errors, and idempotency storage to gain security, reliability, and client resilience.