Here’s how I would approach reconstructing the layout system from your 2018 brand guidelines PDF, translating it into a modern, implementation-ready system:

---

### **1. Extract Core Layout Specifications**
**From the PDF:**
- **Grid diagrams**: Identify the base grid (e.g., 12-column, 8-column), gutter width, and margin sizes. Note if the grid is fixed, fluid, or hybrid.
- **Margin specifications**: Record absolute values (e.g., "20mm margins") or relative rules (e.g., "5% of viewport width").
- **Column layouts**: Document examples of how columns are used (e.g., "3-column for body text, 4-column for imagery").
- **Baseline grid**: If present, note the leading increment (e.g., "16px baseline") for vertical rhythm.
- **Breakpoints**: Extract any responsive rules (e.g., "stack columns at 768px").
- **Safe zones**: Note areas reserved for critical content (e.g., "no text within 10mm of edges").

**Confidence notes**:
- Flag inferred values (e.g., "gutter width estimated at 24px based on spacing between columns").
- Highlight mismatches (e.g., "diagram shows 12-column grid, but examples use 8-column").

---

### **2. Reconstruct the Grid System**
**Modern translation**:
- **CSS Grid/Flexbox**: Convert the grid into a reusable CSS system. Example:
  ```css
  .container {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 24px; /* gutter */
    padding: 40px; /* margins */
  }
  ```
- **Responsive adjustments**: Add breakpoints to adapt the grid (e.g., collapse to 6 columns on mobile).
- **Normalization**: Standardize units (e.g., convert mm to px/rem for digital use).

**Preservation rules**:
- Keep legacy constraints (e.g., "max-width: 1200px for print compatibility").
- Document deviations (e.g., "modern gutters widened by 8px for touch targets").

---

### **3. Document Layout Rules**
**Key outputs**:
- **Grid template**: A visual diagram of the reconstructed grid with modern annotations.
- **Component mappings**: How legacy layouts (e.g., "hero section") translate to the new grid.
- **Edge cases**: Rules for handling oversized content (e.g., "images may bleed into gutters if >3 columns").
- **Accessibility checks**:
  - Ensure gutters meet minimum touch target sizes (48px).
  - Verify text remains readable at all breakpoints (WCAG 2.1 AA).

---

### **4. Validation and Testing**
**Methods**:
- **Visual regression**: Overlay the reconstructed grid on legacy examples to check alignment.
- **Implementation test**: Apply the grid to a new template and verify consistency.
- **Proof artifacts**:
  - Screenshots of the grid applied to modern designs.
  - Code snippets for the CSS/design token implementation.

---

### **5. Deliverables**
1. **Grid specification doc**:
   - Column/gutter/margin values.
   - Breakpoint rules.
   - Example layouts (e.g., "2-column text + 1-column image").
2. **CSS/design tokens**:
   ```css
   :root {
     --grid-columns: 12;
     --gutter-width: 24px;
     --margin-width: 40px;
   }
   ```
3. **Figma/Adobe XD template**: A reusable grid component for designers.
4. **Migration guide**: How to adapt legacy templates to the new system.

---

### **Governing Route**
- **Primary**: `rt_layout_reconstruction_plan` (inferring and extending existing layouts).
- **Supporting skills**:
  - `grid-system-expert` (modern grid logic).
  - `pdf-layout-expert` (document integrity).
  - `front-end-handoff-expert` (implementation safety).

**Evidence classes cited**:
- `observed` (grid diagrams, margin specs).
- `inferred` (breakpoint logic, responsive behavior).
- `unverified` (interaction rules not visible in static PDF).

**Tradeoffs**:
- Preserved: Legacy brand consistency, print compatibility.
- Sacrificed: Rigid fixed-width constraints (replaced with fluid/responsive rules).

---

### **Next Steps**
1. Upload the PDF for a visual pre-pass to confirm grid details.
2. Generate a grid template (CSS/Figma) for your review.
3. Test the grid on a new template to validate alignment.