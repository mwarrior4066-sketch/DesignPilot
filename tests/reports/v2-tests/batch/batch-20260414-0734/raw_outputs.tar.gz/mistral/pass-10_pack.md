Here’s a structured critique of the poster design, grounded in hierarchy, communication goals, and audience needs:

---

### **1. Hierarchy Failure (Governing Issue)**
**Problem:**
The title dominates before the audience understands *what* the event is or *why* it matters. Decorative typefaces often sacrifice readability for style, and when placed at the top without context, they force the viewer to decode the text before grasping the event’s purpose.

**Evidence:**
- The title is the largest element, yet it lacks immediate supporting information (e.g., a tagline, host organization, or value proposition).
- The full-bleed skyline photo competes with the title for attention, diluting the primary message.
- The logo (a branding element) is centered but secondary to the title, which should serve the *audience’s* needs first.

**Tradeoff:**
- *Preserved:* The decorative typeface may align with the conference’s creative identity.
- *Sacrificed:* Clarity and immediate comprehension for the viewer.

**Fix:**
- **Invert the hierarchy:** Lead with a concise tagline (e.g., "A conference for [audience] on [topic]") in a highly readable typeface, followed by the decorative title. This gives context before demanding attention.
- **Reduce title size** to balance with the logo and date, ensuring the skyline photo supports (not competes with) the message.

---

### **2. Information Architecture**
**Problem:**
Critical details (date, location, host) are either buried or overshadowed.
- The date is in small gray text at the bottom, risking invisibility.
- The logo is overlaid on the photo, which may reduce its legibility if the background lacks contrast.

**Evidence:**
- Viewers often scan posters in seconds; low-contrast or peripheral details are easily missed.
- The skyline photo, while visually striking, doesn’t reinforce the conference’s theme or location (unless the city is relevant).

**Tradeoff:**
- *Preserved:* The full-bleed photo creates visual impact.
- *Sacrificed:* Functional clarity and accessibility of key details.

**Fix:**
- **Group critical info** (date, location, host) in a high-contrast "info block" (e.g., white or colored box) near the bottom or side.
- **Ensure the logo** has a solid background or outline if overlaid on the photo.
- **Replace the skyline** with an image that ties to the conference theme (e.g., design tools, speakers, or abstract visuals).

---

### **3. Accessibility and Readability**
**Problem:**
- Decorative typefaces often fail at smaller sizes or for viewers with visual impairments.
- Gray text on a potentially busy background (skyline) may lack sufficient contrast (WCAG recommends at least 4.5:1 for normal text).
- The white logo overlay may blend into light areas of the photo.

**Evidence:**
- Low-contrast text is a common barrier to accessibility (WCAG 2.1 AA).
- Decorative fonts can reduce readability, especially for non-native speakers or dyslexic viewers.

**Tradeoff:**
- *Preserved:* The title’s stylistic choice.
- *Sacrificed:* Inclusivity and ease of reading.

**Fix:**
- **Use a readable sans-serif** for the tagline and details, reserving the decorative font for the title *after* context is established.
- **Test contrast** with tools like [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/).
- **Add a subtle drop shadow or outline** to the logo if overlaid on the photo.

---

### **4. Graphic Communication**
**Problem:**
The skyline photo is generic and doesn’t communicate the conference’s focus or energy.
- It competes with the title and logo for attention.
- It doesn’t reinforce the theme (e.g., design, innovation, collaboration).

**Evidence:**
- Visuals should support the message, not just fill space. A skyline is neutral and may feel corporate or impersonal.

**Tradeoff:**
- *Preserved:* Visual impact.
- *Sacrificed:* Thematic relevance and emotional connection.

**Fix:**
- **Replace the skyline** with an image that reflects the conference’s content (e.g., design tools, speaker headshots, abstract patterns, or a collage of past attendee work).
- **Use a gradient or color overlay** on the photo to unify it with the brand palette and improve text legibility.

---

### **5. Brand Alignment**
**Problem:**
The logo’s placement (centered over the photo) suggests it’s the focal point, but the title is larger. This creates mixed signals about what’s most important.

**Evidence:**
- Logos are branding elements, not primary content. They should support, not compete with, the message.

**Tradeoff:**
- *Preserved:* Brand visibility.
- *Sacrificed:* Clear communication hierarchy.

**Fix:**
- **Move the logo** to a corner (e.g., top-left or bottom-right) to reduce competition with the title.
- **Ensure the logo’s color** contrasts with the background (e.g., white logo on a dark overlay).

---

### **Recommended Rebuild Moves**
1. **Lead with context:** Add a tagline (e.g., "Join 500 designers for a day of [topic]") in a readable font above the decorative title.
2. **Simplify the background:** Replace the skyline with a thematically relevant image or abstract pattern, and add a semi-transparent overlay to improve text contrast.
3. **Group critical info:** Create a dedicated "info block" for the date, location, and host in a high-contrast area.
4. **Test readability:** Use a contrast checker and squint test to ensure all text is legible at a glance.
5. **Clarify the logo’s role:** Move it to a corner and ensure it doesn’t compete with the title.

---

### **Validation Checklist**
- [ ] **Hierarchy:** Tagline → Title → Logo → Details (date/location).
- [ ] **Accessibility:** Contrast ratio ≥ 4.5:1 for all text; readable fonts for critical info.
- [ ] **Information Architecture:** All key details (date, location, host) are grouped and visible.
- [ ] **Visual Relevance:** Background image reinforces the conference theme.
- [ ] **Tradeoffs Named:** What’s preserved (brand style) vs. sacrificed (immediate clarity).

**Next Step:** If this is a real project, I’d recommend creating a revised mockup with these changes and testing it with a small audience for feedback. Would you like me to generate a revised layout sketch?