Here’s a **backend architecture spec** for your multi-tenant scheduling platform, structured as a **governing route** (`rt_backend_architecture_spec`) with supporting skills (`back-end-systems-architect`, `api-reliability-security-expert`). The spec prioritizes **data residency**, **audit trails**, **eventual automation**, and **operational consistency** while preserving your existing REST/relational stack.

---

## **1. Core Services & Boundaries**
### **Service Model**
| Service               | Responsibility                                                                 | Data Boundary                          | Tenancy Model          |
|-----------------------|-------------------------------------------------------------------------------|----------------------------------------|------------------------|
| **Tenant Service**    | Tenant provisioning, metadata, regional residency, auth/identity.            | `tenants` table + regional replicas    | Single-tenant per row  |
| **Workspace Service** | Team workspaces, membership, roles, and workspace-level settings.            | `workspaces`, `members`, `roles`       | Workspace-scoped       |
| **Scheduling Service**| Core scheduling (events, availability, conflicts, approvals).                | `events`, `availability`, `approvals`  | Workspace-scoped       |
| **Activity Service**  | Cursor-based feeds, real-time updates, and activity log.                     | `activity_log`, `feeds`                | Workspace-scoped       |
| **Webhook Service**   | Outbound webhooks (retries, idempotency, payload signing).                   | `webhook_subscriptions`, `deliveries`  | Tenant-scoped          |
| **Automation Service**| Customer-defined rules (future).                                             | `automation_rules`, `triggers`         | Workspace-scoped       |
| **Audit Service**     | Immutable audit trails (who, what, when, where).                             | `audit_log` (append-only)              | Tenant-scoped          |
| **Job Service**       | Background jobs (retries, observability, regional queues).                   | `jobs`, `job_events`                   | Tenant-scoped          |

### **Key Decisions**
- **Tenant Service** owns **regional residency** (e.g., `tenant.region = "eu-west-1"`).
- **Workspace Service** enforces **team isolation** (e.g., `workspace.tenant_id`).
- **Scheduling Service** is **stateless** (relies on `events` table for state).
- **Activity Service** uses **cursor-based pagination** (e.g., `?cursor=12345&limit=50`).
- **Webhook Service** implements **RFC 9457** (structured errors) + **idempotency keys**.
- **Audit Service** is **append-only** (no deletes; soft-deletes via `is_deleted` flag).
- **Job Service** uses **regional queues** (e.g., `jobs-eu`, `jobs-us`).

---

## **2. Data Boundaries & Residency**
### **Regional Residency Rules**
1. **Tenant metadata** (name, region, auth keys) is **globally replicated** (low write volume).
2. **Workspace and scheduling data** is **regionally isolated** (e.g., `events` table partitioned by `tenant.region`).
3. **Audit logs** are **regionally stored** but **globally queryable** (via a read replica).
4. **Webhook payloads** are **regionally signed** (e.g., `X-Signature: region=eu;key=abc123`).

### **Database Schema Highlights**
```sql
-- Tenants (global)
CREATE TABLE tenants (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  region TEXT NOT NULL, -- e.g., "eu-west-1", "us-east-1"
  auth_provider TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

-- Workspaces (tenant-scoped)
CREATE TABLE workspaces (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  settings JSONB NOT NULL DEFAULT '{}'
);

-- Events (workspace-scoped)
CREATE TABLE events (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  tenant_id UUID NOT NULL, -- Denormalized for residency checks
  title TEXT NOT NULL,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft', 'pending', 'approved', 'cancelled')),
  created_by UUID NOT NULL, -- User ID
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

-- Activity Log (workspace-scoped, cursor-based)
CREATE TABLE activity_log (
  id BIGSERIAL PRIMARY KEY, -- Cursor key
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  event_id UUID REFERENCES events(id),
  action TEXT NOT NULL, -- e.g., "event.created", "approval.requested"
  actor UUID NOT NULL, -- User ID
  metadata JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);

-- Audit Log (tenant-scoped, append-only)
CREATE TABLE audit_log (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  entity_type TEXT NOT NULL, -- e.g., "event", "workspace"
  entity_id UUID NOT NULL,
  action TEXT NOT NULL, -- e.g., "create", "update", "delete"
  actor UUID NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  metadata JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Webhook Subscriptions (tenant-scoped)
CREATE TABLE webhook_subscriptions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  url TEXT NOT NULL,
  events TEXT[] NOT NULL, -- e.g., ["event.created", "approval.approved"]
  secret TEXT NOT NULL, -- For payload signing
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Jobs (tenant-scoped, regional queues)
CREATE TABLE jobs (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  type TEXT NOT NULL, -- e.g., "webhook.delivery", "automation.rule"
  payload JSONB NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'completed', 'failed')),
  attempts INT NOT NULL DEFAULT 0,
  max_attempts INT NOT NULL DEFAULT 3,
  queue TEXT NOT NULL, -- e.g., "jobs-eu", "jobs-us"
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);
```

---

## **3. Contracts & APIs**
### **Key API Contracts**
#### **1. Tenant Provisioning**
```http
POST /tenants
{
  "name": "Acme Corp",
  "region": "eu-west-1",
  "auth_provider": "okta"
}
```
**Response**:
```json
{
  "id": "tenant_123",
  "region": "eu-west-1",
  "auth": {
    "issuer": "https://acme.okta.com",
    "client_id": "abc123"
  }
}
```

#### **2. Workspace Creation**
```http
POST /workspaces
Authorization: Bearer <tenant_token>
{
  "name": "Engineering Team"
}
```
**Response**:
```json
{
  "id": "workspace_456",
  "tenant_id": "tenant_123",
  "members": []
}
```

#### **3. Event Scheduling (with Approval)**
```http
POST /events
Authorization: Bearer <user_token>
{
  "workspace_id": "workspace_456",
  "title": "Team Sync",
  "start_time": "2024-06-01T09:00:00Z",
  "end_time": "2024-06-01T10:00:00Z",
  "attendees": ["user_789"]
}
```
**Response**:
```json
{
  "id": "event_789",
  "status": "pending", -- Requires approval
  "approvals": [
    {
      "required": ["user_approver_1"],
      "received": []
    }
  ]
}
```

#### **4. Activity Feed (Cursor-Based)**
```http
GET /activity?workspace_id=workspace_456&cursor=12345&limit=50
Authorization: Bearer <user_token>
```
**Response**:
```json
{
  "items": [
    {
      "id": 12346,
      "action": "event.created",
      "actor": "user_789",
      "metadata": { "event_id": "event_789" },
      "created_at": "2024-06-01T08:00:00Z"
    }
  ],
  "next_cursor": 12396
}
```

#### **5. Webhook Delivery (Idempotent)**
```http
POST /webhooks/deliver
Idempotency-Key: wh_delivery_123
{
  "event": "event.created",
  "payload": {
    "event_id": "event_789",
    "workspace_id": "workspace_456"
  }
}
```
**Response**:
```json
{
  "status": "queued", -- or "delivered", "failed"
  "delivery_id": "wh_delivery_123"
}
```

---

## **4. Operational Concerns**
### **1. Regional Data Residency**
- **Tenant metadata** is replicated globally (low write volume).
- **Workspace/scheduling data** is **regionally partitioned** (e.g., `events_eu`, `events_us`).
- **Audit logs** are **regionally stored** but queryable via a **global read replica**.
- **Webhook payloads** are **signed with regional keys** (e.g., `X-Signature: region=eu;key=abc123`).

### **2. Audit Trail Immutability**
- **Audit logs** are **append-only** (no updates/deletes).
- **Soft-deletes** use `is_deleted` flag (e.g., `events.is_deleted = TRUE`).
- **All writes** log to `audit_log` (who, what, when, where).

### **3. Background Jobs**
- **Job Service** uses **regional queues** (e.g., `jobs-eu`, `jobs-us`).
- **Retries** use **exponential backoff** (max 3 attempts).
- **Observability**:
  - `jobs` table tracks status (`queued`, `running`, `completed`, `failed`).
  - `job_events` table logs attempts (e.g., `{ "attempt": 1, "status": "failed", "error": "..." }`).

### **4. Webhook Reliability**
- **Idempotency**: `Idempotency-Key` header ensures **exactly-once delivery**.
- **Retries**: Failed deliveries retry with **exponential backoff**.
- **Payload signing**: `X-Signature` header verifies regional origin.
- **Structured errors**: RFC 9457 (e.g., `{ "type": "webhook.failed", "title": "Delivery failed", "status": 500 }`).

### **5. Eventual Automation Rules**
- **Future-proofing**: `automation_rules` table stores customer-defined rules (e.g., `IF event.status == "approved" THEN notify_slack`).
- **Triggers**: Rules are evaluated **asynchronously** (via `Job Service`).

---

## **5. Tradeoffs & Risks**
### **Preserved**
- **Regional residency**: Data stays in the tenant’s region.
- **Audit immutability**: No tampering with logs.
- **Webhook reliability**: Idempotency + retries.
- **Future automation**: Rules table is ready.

### **Sacrificed**
- **Global queries**: Cross-region queries require **read replicas** (latency tradeoff).
- **Real-time sync**: Activity feeds are **cursor-based** (not WebSocket).
- **Complexity**: Regional partitioning adds **operational overhead**.

---

## **6. Next Steps**
1. **Implement regional partitioning** for `events`, `activity_log`, and `jobs`.
2. **Build the `Audit Service`** (append-only logs).
3. **Enhance `Job Service`** with regional queues.
4. **Add webhook signing** (regional keys).
5. **Design automation rule DSL** (future).

---

### **Evidence Classes Cited**
- **Regional residency**: `tenant.region` partitioning.
- **Audit immutability**: Append-only `audit_log` table.
- **Webhook reliability**: Idempotency keys + RFC 9457.
- **Cursor-based feeds**: `activity_log.id` as cursor.
- **Background jobs**: Regional queues + exponential backoff.

This spec balances **immediate needs** (residency, audit, webhooks) with **future flexibility** (automation rules).