Here’s a **type system recommendation** for your fintech product, balancing **modern trustworthiness**, **hierarchy clarity**, **tabular data legibility**, and **cross-platform consistency** (marketing site, web app dashboard, mobile).

---

### **Core Type System: "Fintech Trust Stack"**
#### **Primary Typeface: *Inter***
- **Why?**
  - **Modern, neutral, and highly legible**—designed for UI/digital use.
  - **Open-source** (free for commercial use) with **extensive weights** (100–900) for hierarchy.
  - **Optimized for tabular data**: Numeric forms are **monospace-aligned** (e.g., `1` and `0` take equal width), improving readability in tables/charts.
  - **Supports variable fonts** (Inter Variable) for fluid scaling across breakpoints.
  - **Trustworthy neutrality**: Avoids "playful" or "corporate" connotations; feels **professional but approachable**.

- **Implementation**:
  - Use **Inter Variable** (single file, lighter than loading multiple weights).
  - **Weights**:
    - **400 (Regular)** – Body text, tables, UI labels.
    - **500 (Medium)** – Subheadings, card titles.
    - **600 (SemiBold)** – Primary buttons, KPIs, key metrics.
    - **700 (Bold)** – Section headers, dashboard titles.
    - **300 (Light)** – Secondary UI (e.g., placeholders, captions).
  - **Fallback stack**:
    ```css
    font-family: 'InterVariable', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    ```

---

#### **Secondary Typeface (Optional): *IBM Plex Mono***
- **Why?**
  - **Monospace for financial data**: Use **sparingly** for:
    - Transaction IDs, account numbers, or code snippets (e.g., API keys).
    - Tables with **aligned decimals** (e.g., currency columns).
  - **Trust signal**: Monospace conveys **precision** and **technical rigor** in fintech.
  - **Pairs well with Inter**: Similar x-height and neutrality.

- **Implementation**:
  - Use **IBM Plex Mono** (400 or 500 weight) for:
    - Data-heavy tables (e.g., transaction histories).
    - Input fields for numeric/alphanumeric codes.
  - **Fallback stack**:
    ```css
    font-family: 'IBM Plex Mono', 'SF Mono', 'Menlo', monospace;
    ```

---

### **Typography Scale & Hierarchy**
#### **1. Marketing Site**
| Element               | Typeface       | Weight | Size (Desktop) | Line Height | Use Case                          |
|-----------------------|----------------|--------|----------------|-------------|-----------------------------------|
| Hero Headline         | Inter          | 700    | 48–60px        | 1.1         | Primary value prop (e.g., "Secure your future"). |
| Subheadline           | Inter          | 500    | 24–32px        | 1.3         | Supporting messaging.             |
| Body Text             | Inter          | 400    | 16–18px        | 1.5         | Paragraphs, feature descriptions. |
| CTA Button            | Inter          | 600    | 16–18px        | 1.4         | Primary actions (e.g., "Get Started"). |
| Caption/Footnote      | Inter          | 300    | 14px           | 1.4         | Legal disclaimers, small print.   |

#### **2. Web App Dashboard**
| Element               | Typeface       | Weight | Size (Desktop) | Line Height | Use Case                          |
|-----------------------|----------------|--------|----------------|-------------|-----------------------------------|
| Dashboard Title       | Inter          | 700    | 24–30px        | 1.2         | Page title (e.g., "Accounts").    |
| KPI/Metric            | Inter          | 600    | 32–48px        | 1.1         | Key numbers (e.g., "$12,345.67"). |
| Section Header        | Inter          | 600    | 18–20px        | 1.3         | Card/panel titles.                |
| Body Text             | Inter          | 400    | 14–16px        | 1.5         | Labels, descriptions.             |
| Table Data            | Inter          | 400    | 14px           | 1.4         | Transaction rows, lists.          |
| Table Header          | Inter          | 500    | 14px           | 1.4         | Column headers.                   |
| Input Field           | Inter          | 400    | 16px           | 1.4         | Form inputs.                      |
| Alert/Notification    | Inter          | 500    | 14px           | 1.4         | Error/success messages.           |

#### **3. Mobile App**
| Element               | Typeface       | Weight | Size (Mobile)  | Line Height | Use Case                          |
|-----------------------|----------------|--------|----------------|-------------|-----------------------------------|
| Screen Title          | Inter          | 600    | 20–24px        | 1.2         | Top of screen (e.g., "Payments"). |
| KPI/Metric            | Inter          | 600    | 28–36px        | 1.1         | Key numbers.                      |
| Body Text             | Inter          | 400    | 14–16px        | 1.5         | Labels, descriptions.             |
| Button                | Inter          | 600    | 16px           | 1.4         | Primary actions.                  |
| Tab Bar               | Inter          | 500    | 12px           | 1.3         | Bottom navigation.                |

---

### **Key Design Principles**
1. **Trust Signals**:
   - **Avoid decorative fonts** (e.g., script or display typefaces) for core UI/data.
   - **Use monospace for precision**: IBM Plex Mono in tables or numeric inputs reinforces **accuracy**.
   - **Limit weights**: Stick to **400–700** for most UI; avoid ultra-light/black weights (harder to read).

2. **Tabular Data Optimization**:
   - **Align numbers by decimal point** (use `text-align: right` for currency).
   - **Increase letter-spacing slightly** for tables (e.g., `letter-spacing: 0.5px`).
   - **Use tabular lining figures** (Inter’s default) for consistent numeral width.

3. **Cross-Platform Consistency**:
   - **Variable fonts**: Inter Variable scales smoothly across desktop/mobile.
   - **Responsive sizing**: Use `clamp()` for fluid typography (e.g., `clamp(16px, 2vw, 18px)`).
   - **Mobile adjustments**:
     - Reduce line height slightly (e.g., `1.4` instead of `1.5`).
     - Increase touch targets for buttons (e.g., `min-height: 48px`).

4. **Accessibility**:
   - **Minimum contrast**: Ensure **4.5:1** for body text (WCAG AA).
   - **Dark mode support**: Test Inter in dark mode (it works well, but adjust opacity for secondary text).
   - **Reduced motion**: Use `prefers-reduced-motion` to disable animations for users who opt out.

---

### **Example CSS Snippet**
```css
/* Base variables */
:root {
  --font-primary: 'InterVariable', sans-serif;
  --font-mono: 'IBM Plex Mono', monospace;
  --text-base: 16px;
  --line-height-base: 1.5;
}

/* Typography scale */
.h1 { font-size: clamp(2.5rem, 5vw, 3.75rem); font-weight: 700; line-height: 1.1; }
.h2 { font-size: clamp(1.75rem, 4vw, 2.5rem); font-weight: 600; line-height: 1.2; }
.h3 { font-size: 1.5rem; font-weight: 600; line-height: 1.3; }
.body { font-size: 1rem; font-weight: 400; line-height: var(--line-height-base); }
.caption { font-size: 0.875rem; font-weight: 300; line-height: 1.4; }

/* Tabular data */
table {
  font-family: var(--font-primary);
  font-variant-numeric: tabular-nums;
}
td, th {
  font-size: 0.875rem;
  letter-spacing: 0.5px;
  text-align: right;
}
th {
  font-weight: 500;
}

/* Mobile adjustments */
@media (max-width: 768px) {
  .h1 { font-size: 2rem; }
  .body { font-size: 0.9375rem; line-height: 1.4; }
}
```

---

### **Alternatives Considered**
| Typeface          | Pros                          | Cons                          | Best For                     |
|-------------------|-------------------------------|-------------------------------|------------------------------|
| **Inter**         | Free, UI-optimized, variable  | Neutral (may feel "generic")  | **Primary choice**           |
| **Roboto**        | Google’s default, widely used | Less refined for tabular data | Legacy systems               |
| **San Francisco** | Apple’s system font           | iOS/macOS only                | Apple-centric apps           |
| **Helvetica Now** | Classic, corporate            | Expensive license             | High-budget projects         |
| **Figtree**       | Modern, geometric             | Less numeric alignment        | Marketing-heavy fintech      |

---

### **Adoption Roadmap**
1. **Audit current typography**:
   - Replace any decorative/playful fonts with Inter.
   - Ensure numeric data uses `tabular-nums`.
2. **Implement variable font**:
   - Load Inter Variable via Google Fonts or self-host.
3. **Test tabular data**:
   - Verify decimal alignment in tables/charts.
4. **Dark mode testing**:
   - Adjust opacity for secondary text (e.g., `rgba(0, 0, 0, 0.6)`).
5. **Mobile refinements**:
   - Increase touch targets and reduce line height slightly.

---

### **Why This Works for Fintech**
- **Trust**: Inter’s neutrality avoids "gimmicky" vibes; monospace signals precision.
- **Hierarchy**: Clear weight distinctions (400–700) guide users through complex data.
- **Tabular data**: Inter’s numeric alignment improves readability for financial tables.
- **Cross-platform**: Variable fonts and responsive sizing ensure consistency.
- **Cost**: Free and open-source (no licensing fees).