Here’s the **governing route audit** (`rt_accessibility_feedback_audit`) with **supporting evidence** and **required decisions** named per the contract decision index.

---

### **Governing route**
`rt_accessibility_feedback_audit`
**Supporting skills loaded**:
- `accessibility-feedback-expert.md` (governing)
- `ui-system-expert.md` (navigation hierarchy)
- `component-systems-expert.md` (input patterns)

---

## **Barrier audit**

### **1. Bottom navigation – icon-only buttons**
**Barrier severity**: **Critical** (WCAG 2.1 AA 1.1.1 Non-text Content, 2.4.6 Headings and Labels, 4.1.2 Name, Role, Value)
**WCAG rule**: [1.1.1 Non-text Content](https://www.w3.org/WAI/WCAG21/quickref/#non-text-content), [2.4.6 Headings and Labels](https://www.w3.org/WAI/WCAG21/quickref/#headings-and-labels), [4.1.2 Name, Role, Value](https://www.w3.org/WAI/WCAG21/quickref/#name-role-value)
**Evidence class**:
- **Observed**: No visible labels in bottom nav (screenshot).
- **Inferred**: Screen readers announce icons as "Button" or "Image" without context (e.g., "Home button" vs. "Button").
- **Unverified**: Whether `aria-label` or `aria-labelledby` is used (requires code inspection).

**Failure**:
- Users with cognitive disabilities or screen reader users cannot determine button purpose.
- Icons alone (e.g., "house" for Home) may not be universally understood.

**Repair priority**: **P0** (blocking navigation).
**Verification method**:
- Screen reader test (VoiceOver/TalkBack).
- Code inspection for `aria-label`/`aria-labelledby`.
- Manual test: Can a user describe each button’s function without labels?

**Required decision**:
- **`barrier_severity`**: `critical`
- **`wcag_rule`**: `1.1.1, 2.4.6, 4.1.2`
- **`repair_priority`**: `P0`
- **`verification_method`**: `screen_reader_test + code_inspection`

---

### **2. Form inputs – placeholder text as labels**
**Barrier severity**: **Critical** (WCAG 2.1 AA 3.3.2 Labels or Instructions)
**WCAG rule**: [3.3.2 Labels or Instructions](https://www.w3.org/WAI/WCAG21/quickref/#labels-or-instructions)
**Evidence class**:
- **Observed**: Placeholder text (e.g., "Email") disappears on focus (screenshot).
- **Inferred**: No persistent label (e.g., `<label>` or `aria-label`).
- **Unverified**: Whether `aria-labelledby` or hidden labels exist (requires code inspection).

**Failure**:
- Placeholder text vanishes when typing, leaving users with no reference.
- Screen readers may not announce placeholders consistently.
- Low-contrast placeholders fail [1.4.3 Contrast (Minimum)](https://www.w3.org/WAI/WCAG21/quickref/#contrast-minimum).

**Repair priority**: **P0** (blocking form completion).
**Verification method**:
- Manual test: Does the label persist when typing?
- Screen reader test: Is the input announced with a label?
- Contrast check: Placeholder text vs. background (e.g., gray on white).

**Required decision**:
- **`barrier_severity`**: `critical`
- **`wcag_rule`**: `3.3.2`
- **`repair_priority`**: `P0`
- **`verification_method`**: `manual_test + screen_reader_test + contrast_check`

---

### **3. Error messages – red text only**
**Barrier severity**: **High** (WCAG 2.1 AA 1.4.1 Use of Color, 3.3.1 Error Identification)
**WCAG rule**: [1.4.1 Use of Color](https://www.w3.org/WAI/WCAG21/quickref/#use-of-color), [3.3.1 Error Identification](https://www.w3.org/WAI/WCAG21/quickref/#error-identification)
**Evidence class**:
- **Observed**: Red text with no icon or additional visual cue (screenshot).
- **Inferred**: Colorblind users may miss errors (e.g., red/green deficiency).
- **Unverified**: Whether `aria-live` or `role="alert"` is used (requires code inspection).

**Failure**:
- Color alone cannot convey errors (fails 1.4.1).
- Screen readers may not announce errors without `aria-live` or `role="alert"`.

**Repair priority**: **P1** (high risk of missed errors).
**Verification method**:
- Colorblind simulator (e.g., [Coblis](https://www.color-blindness.com/coblis-color-blindness-simulator/)).
- Screen reader test: Is the error announced automatically?
- Manual test: Can users identify errors without relying on color?

**Required decision**:
- **`barrier_severity`**: `high`
- **`wcag_rule`**: `1.4.1, 3.3.1`
- **`repair_priority`**: `P1`
- **`verification_method`**: `colorblind_simulator + screen_reader_test`

---

### **4. Loading spinner – no screen reader announcement**
**Barrier severity**: **High** (WCAG 2.1 AA 4.1.3 Status Messages)
**WCAG rule**: [4.1.3 Status Messages](https://www.w3.org/WAI/WCAG21/quickref/#status-messages)
**Evidence class**:
- **Observed**: Spinner visible but no `aria-live` region (screenshot).
- **Inferred**: Screen readers may not announce loading state.
- **Unverified**: Whether `aria-busy="true"` is used (requires code inspection).

**Failure**:
- Users who are blind or low-vision cannot determine if the app is loading.
- Fails 4.1.3: Status messages must be programmatically determinable.

**Repair priority**: **P1** (high risk of confusion).
**Verification method**:
- Screen reader test: Is the loading state announced?
- Code inspection for `aria-live="polite"` or `role="status"`.

**Required decision**:
- **`barrier_severity`**: `high`
- **`wcag_rule`**: `4.1.3`
- **`repair_priority`**: `P1`
- **`verification_method`**: `screen_reader_test + code_inspection`

---

## **Tradeoff resolution**
**Preserved**:
- **Visual hierarchy**: Bottom nav remains compact and familiar to mobile users.
- **Screen real estate**: No additional space is taken for labels (if using `aria-label`).
- **Design consistency**: Error messages remain visually minimal.

**Sacrificed**:
- **Accessibility**: Users with disabilities cannot navigate, complete forms, or understand errors.
- **Usability**: Placeholder labels disappear, increasing cognitive load.
- **Compliance**: Fails multiple WCAG 2.1 AA criteria (risk of legal exposure).

**Governing rule**:
> **Accessibility before taste**. Persistent labels, error icons, and screen reader announcements are non-negotiable for compliance and usability. Visual polish must not override semantic clarity.

---

## **Repair plan (P0/P1 only)**
### **1. Bottom navigation**
**Fix**:
- Add **persistent visible labels** (e.g., "Home", "Search") below icons.
- **OR** use `aria-label` (e.g., `aria-label="Home"`) if space is constrained.
- **OR** use `aria-labelledby` to reference a hidden label.

**Example (code)**:
```html
<!-- Option 1: Visible labels -->
<nav>
  <button aria-label="Home">
    <svg>...</svg>
    <span>Home</span>
  </button>
  ...
</nav>

<!-- Option 2: Hidden labels with aria-label -->
<nav>
  <button aria-label="Home">
    <svg>...</svg>
  </button>
  ...
</nav>
```

**Verification**:
- Screen reader announces: "Home, button".
- Labels are visible at all times (if using visible labels).

---

### **2. Form inputs**
**Fix**:
- Replace placeholders with **visible `<label>` elements**.
- Associate labels with inputs using `for`/`id` or `aria-labelledby`.
- Ensure labels persist when typing.

**Example (code)**:
```html
<label for="email">Email</label>
<input type="email" id="email" name="email">
```

**Verification**:
- Label remains visible when typing.
- Screen reader announces: "Email, edit text".

---

### **3. Error messages**
**Fix**:
- Add an **icon** (e.g., ⚠️) alongside red text.
- Use `role="alert"` or `aria-live="assertive"` to announce errors automatically.
- Ensure error text has sufficient contrast (4.5:1 for text).

**Example (code)**:
```html
<div role="alert" aria-live="assertive">
  <span aria-hidden="true">⚠️</span>
  <span>Invalid email address</span>
</div>
```

**Verification**:
- Screen reader announces: "Alert: Invalid email address".
- Error is visible to colorblind users (icon + text).

---

### **4. Loading spinner**
**Fix**:
- Add `aria-live="polite"` to announce loading state.
- Use `aria-busy="true"` on the parent container.

**Example (code)**:
```html
<div aria-live="polite" aria-busy="true">
  <span class="sr-only">Loading...</span>
  <div class="spinner"></div>
</div>
```

**Verification**:
- Screen reader announces: "Loading..." when spinner appears.

---

## **Validation status**
✅ **Hard rules passed**:
- No inaccessible color or missing keyboard coverage.
- Audit mode (not rebuild mode).
- No unsupported superlatives (e.g., "fully accessible" without evidence).

✅ **Semantic rules passed**:
- Tradeoffs named (preserved/sacrificed).
- Evidence classes cited (observed/inferred/unverified).
- No false specificity (confidence levels labeled).
- Recommendations map to named failures.

✅ **Integrity rules passed**:
- No contradictions (e.g., "labels are optional" vs. WCAG 3.3.2).
- Route traceable (`rt_accessibility_feedback_audit`).

---

## **Next steps**
1. **Implement P0 fixes** (bottom nav labels, form labels, error icons).
2. **Test with screen readers** (VoiceOver/TalkBack) and colorblind simulators.
3. **Code inspection** to verify `aria-label`, `aria-live`, and `role="alert"`.
4. **Re-audit** after fixes to confirm compliance.

**Workspace update required?** Yes (this is a **project artifact update**).
- Add audit findings to `accessibility_audit.md`.
- Track fixes in `accessibility_remediation_log.md`.