Here’s a **component spec** for a **Split Button** with the requested functionality, following production-level accessibility, interaction, and state requirements.

---

# **Component Spec: Split Button**
**Component ID**: `SplitButton`
**Purpose**: A compound button that combines a primary action (`Save`) with a dropdown trigger for secondary actions (`Save as draft`, `Save and close`). Must support keyboard navigation, disabled/loading states, and mobile touch targets.

---

## **1. Component Boundary**
- **Primary action button**: Triggers the default action (`Save`).
- **Dropdown trigger button**: Opens a menu of secondary actions (`Save as draft`, `Save and close`).
- **Menu**: A floating list of secondary actions, positioned below the split button.

---

## **2. States & Variants**
| State               | Primary Button | Dropdown Trigger | Menu Visibility | Notes |
|---------------------|----------------|------------------|-----------------|-------|
| **Default**         | Enabled        | Enabled          | Hidden          | Ready for interaction. |
| **Hover (Primary)** | Hovered        | Default          | Hidden          | Visual feedback on primary button. |
| **Hover (Dropdown)**| Default        | Hovered          | Hidden          | Visual feedback on dropdown trigger. |
| **Focus (Primary)** | Focused        | Default          | Hidden          | Keyboard focus on primary button. |
| **Focus (Dropdown)**| Default        | Focused          | Hidden          | Keyboard focus on dropdown trigger. |
| **Active (Primary)**| Pressed        | Default          | Hidden          | Primary action is being triggered. |
| **Active (Dropdown)**| Default      | Pressed          | Visible         | Menu opens on click/keydown. |
| **Disabled**        | Disabled       | Disabled         | Hidden          | Both buttons disabled. |
| **Loading**         | Loading spinner| Disabled         | Hidden          | Primary action is in progress. |
| **Menu Open**       | Default        | Active           | Visible         | Menu is displayed. |

---

## **3. Accessibility & Keyboard Support**
### **Keyboard Navigation**
| Key               | Behavior |
|-------------------|----------|
| **Tab**           | Moves focus between primary button and dropdown trigger. |
| **Enter/Space**   | Triggers the focused button (primary or dropdown). |
| **↓ (Down Arrow)**| Opens the menu and moves focus to the first menu item. |
| **↑ (Up Arrow)**  | Moves focus to the previous menu item. |
| **Esc**           | Closes the menu without selection. |
| **Home/End**      | Moves focus to first/last menu item. |

### **ARIA Attributes**
- **Primary Button**:
  - `role="button"`
  - `aria-label="Save"` (or dynamic label if loading)
  - `aria-disabled="true"` (when disabled)
  - `aria-busy="true"` (when loading)
- **Dropdown Trigger**:
  - `role="button"`
  - `aria-label="More save options"`
  - `aria-expanded="true/false"` (menu open/closed)
  - `aria-haspopup="menu"`
  - `aria-controls="[menu-id]"`
- **Menu**:
  - `role="menu"`
  - `aria-labelledby="[dropdown-trigger-id]"`
- **Menu Items**:
  - `role="menuitem"`
  - `tabindex="-1"` (focusable only via keyboard navigation)

---

## **4. Touch Targets (Mobile)**
- **Minimum touch target size**: **48×48px** (WCAG 2.5.5).
- **Primary button** and **dropdown trigger** must each meet this requirement.
- **Menu items** must also meet **48×48px** when opened.

---

## **5. Loading State**
- **Primary button** shows a spinner (inline or overlay) when saving.
- **Dropdown trigger** is **disabled** while loading.
- **ARIA**: `aria-busy="true"` on the primary button.

---

## **6. Disabled State**
- Both buttons are **visually grayed out** and **non-interactive**.
- **ARIA**: `aria-disabled="true"` (prevents keyboard interaction).

---

## **7. Menu Behavior**
- **Positioning**: Opens below the split button (or above if space is constrained).
- **Dismissal**: Closes on:
  - Clicking outside the menu.
  - Pressing **Esc**.
  - Selecting a menu item.
- **Focus Management**:
  - On open, focus moves to the first menu item.
  - On close, focus returns to the dropdown trigger.

---

## **8. Implementation Boundary**
### **HTML Structure (Example)**
```html
<div class="split-button">
  <button
    class="split-button__primary"
    aria-label="Save"
    aria-busy="false"
  >
    Save
  </button>
  <button
    class="split-button__dropdown"
    aria-label="More save options"
    aria-expanded="false"
    aria-haspopup="menu"
    aria-controls="save-menu"
  >
    ▼
  </button>
  <ul id="save-menu" class="split-button__menu" role="menu" hidden>
    <li role="menuitem" tabindex="-1">Save as draft</li>
    <li role="menuitem" tabindex="-1">Save and close</li>
  </ul>
</div>
```

### **CSS Considerations**
- **Visual separation**: Primary button and dropdown trigger should have a clear divider (e.g., border or spacing).
- **Hover/focus states**: Clear visual feedback for both buttons.
- **Menu styling**: Follows design system dropdown/menu patterns.

### **JavaScript Requirements**
- **Event handling**:
  - Primary button: Triggers `onSave()`.
  - Dropdown trigger: Toggles menu visibility.
  - Menu items: Trigger respective actions (`onSaveAsDraft()`, `onSaveAndClose()`).
- **Focus management**: Ensures keyboard navigation works as specified.
- **State management**: Updates `aria-expanded`, `aria-busy`, and `aria-disabled` dynamically.

---

## **9. Validation Checklist**
✅ **Accessibility**:
- Keyboard navigation works as specified.
- ARIA attributes are correctly applied.
- Touch targets meet **48×48px** minimum.

✅ **States**:
- Disabled state prevents interaction.
- Loading state disables dropdown trigger.
- Menu opens/closes correctly.

✅ **Mobile**:
- Touch targets are large enough.
- Menu positioning works on small screens.

✅ **Semantics**:
- Correct `role` attributes (`button`, `menu`, `menuitem`).
- No missing `aria` labels.

---

## **10. Tradeoffs & Considerations**
- **Preserved**:
  - Clear primary action (`Save`).
  - Accessible keyboard and touch support.
  - Visual feedback for all states.
- **Sacrificed**:
  - Slightly more complex DOM structure than a single button.
  - Requires JavaScript for full functionality (no pure-CSS fallback).

---

### **Next Steps**
- Implement in Storybook/Figma for visual QA.
- Test with screen readers (VoiceOver, NVDA, JAWS).
- Validate touch targets on mobile devices.

---
**Evidence Classes Cited**:
- `component_boundary` (defined structure)
- `state_coverage` (all required states)
- `accessibility_behavior` (keyboard, ARIA, touch)
- `implementation_boundary` (HTML/JS requirements)