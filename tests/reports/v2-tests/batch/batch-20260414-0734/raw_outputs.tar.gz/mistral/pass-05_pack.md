Here’s a **PDF remediation plan** that preserves the two-column layout while fixing reading order, tagging, and accessibility for screen readers and export. The plan follows the **governing route** `rt_pdf_remediation` with supporting skills `document-accessibility-expert` and `layout-reconstruction-expert`.

---

### **1. Reading Order & Semantic Structure**
**Problem:**
- Two-column text flows are likely tagged as left-to-right blocks, breaking logical reading order.
- Pull quotes and decorative images are untagged or misplaced in the tag tree.
- TOC links are broken (likely due to InDesign’s hyperlink export issues).

**Fixes:**
#### **A. Rebuild the Tag Tree**
- **Root tag:** `<Document>` (PDF/UA standard).
- **Primary structure:**
  ```xml
  <Document>
    <TOC> (Table of Contents)
    <Sect> (Body content)
      <H1>, <H2>, etc. (Headings)
      <P> (Paragraphs)
      <Figure> (Images with alt text)
      <Quote> (Pull quotes, tagged as asides)
      <Table> (Data tables with headers)
  ```
- **Two-column logic:**
  - Tag each column as a `<Sect>` with `Placement: Block` and `Column: Left/Right`.
  - Use `RoleMap` to map InDesign’s `<Art>` or `<TextFrame>` tags to semantic PDF tags (e.g., `<P>`, `<H1>`).
  - **Confidence:** High (observed from InDesign exports).

#### **B. Pull Quotes**
- Tag as `<Quote>` with `Placement: Block` and `Background: None`.
- Add `aria-label="Pull quote"` for screen readers.
- **Reading order:** Place *after* the paragraph they reference (not mid-flow).

#### **C. Decorative Images**
- Tag as `<Figure>` with `Artifact="Decorative"` (no alt text).
- Remove from reading order via `Mcid="0"` (marked content ID).

#### **D. Table of Contents**
- Rebuild hyperlinks using **PDF’s link annotations**:
  - Target: Page numbers + XY coordinates (use InDesign’s "Bookmarks" panel to regenerate).
  - Text: Ensure TOC entries match exact headings in the body.
  - **Verification:** Test with Adobe Acrobat’s "Read Out Loud" tool.

---

### **2. Accessibility Metadata**
**Problem:**
- Missing title, language, and document structure metadata.

**Fixes:**
- **Title:** Set via `Document Properties > Title` (match the report’s `<H1>`).
- **Language:** `en-US` (or relevant language) in `Document Catalog`.
- **Headings:** Map InDesign’s paragraph styles to PDF tags:
  - `Heading 1` → `<H1>`
  - `Heading 2` → `<H2>`
  - `Body Text` → `<P>`
- **Tables:** Add `<TH>` (table headers) with `Scope="Column"` or `Scope="Row"`.

---

### **3. Export-Safe Artifacts**
**Problem:**
- InDesign’s PDF export may split text frames or misalign columns.

**Fixes:**
- **Pre-export checks in InDesign:**
  1. **Overprint Preview:** Disable overprint for text (Window > Output > Overprint Preview).
  2. **Liquid Layout:** Use "Object-Based" liquid layout rules for columns to prevent reflow issues.
  3. **Hyperlinks:** Rebuild TOC links using `Hyperlinks` panel (not manual text links).
- **Post-export fixes in Acrobat:**
  - Use **Tags Panel** to reorder content.
  - Use **Order Panel** to verify visual vs. logical order.
  - **Tool:** Adobe Acrobat Pro’s "Accessibility Checker" (Full Check).

---

### **4. Verification Method**
**Tools:**
1. **Screen Reader Test:**
   - NVDA/JAWS: Read the document aloud. Verify:
     - Pull quotes are announced as "quote" and placed logically.
     - TOC links jump to correct headings.
     - Decorative images are skipped.
2. **Export Test:**
   - Export to Word/HTML using Acrobat’s "Export" tool. Verify:
     - Two-column layout is preserved.
     - Reading order matches the PDF.
     - Tables retain headers.
3. **Automated Check:**
   - Adobe Acrobat’s **Accessibility Checker** (Full Check).
   - PAC 3 (PDF Accessibility Checker) for WCAG compliance.

---

### **5. Destructive Shortcuts Rejected**
- **Do not:**
  - Flatten the PDF (loses tagging).
  - Convert to single-column (destroys layout intent).
  - Use OCR (risks introducing errors in born-digital text).
- **Tradeoff:**
  - *Preserved:* Two-column layout, pull quotes as design elements.
  - *Sacrificed:* Manual effort to retag (automated tools like InDesign’s "Export Tags" are unreliable for complex layouts).

---

### **6. Implementation Steps**
| Step | Tool | Action |
|------|------|--------|
| 1 | InDesign | Rebuild TOC hyperlinks. Disable overprint. |
| 2 | InDesign | Export PDF with "Create Tagged PDF" enabled. |
| 3 | Acrobat Pro | Open Tags Panel. Reorder `<Quote>`, `<Figure>`, and `<TOC>`. |
| 4 | Acrobat Pro | Set document title/language. Add table headers. |
| 5 | Acrobat Pro | Run Accessibility Checker. Fix errors. |
| 6 | NVDA/JAWS | Test reading order and links. |
| 7 | Acrobat Pro | Export to Word/HTML. Verify layout. |

---

### **7. Evidence Artifacts**
- **Observed:** Two-column layout, pull quotes, decorative images (from provided PDF).
- **Inferred:** InDesign’s default tagging behavior (medium confidence).
- **Standards:** PDF/UA-1 (ISO 14289-1), WCAG 2.1 (AA).

**Required Decisions (from Contract Decision Index):**
- `semantic_failure`: Pull quotes interrupting flow → tagged as `<Quote>`.
- `reading_order_or_extraction`: Two-column text → tagged as `<Sect>` with column roles.
- `verification_method`: Screen reader + export test.
- `destructive_shortcut_rejected`: Flattening PDF → rejected.