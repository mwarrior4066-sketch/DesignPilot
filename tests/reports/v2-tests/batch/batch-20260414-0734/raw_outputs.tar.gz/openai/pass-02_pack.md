## Split Button — Component Specification

### Component Boundary

- The **Split Button** is a composite component comprised of:
  - A primary button (labeled **Save**) that immediately triggers the main action.
  - An adjacent dropdown trigger (icon-only or chevron) that exposes secondary actions: **Save as draft** and **Save and close**.
- The dropdown items invoke distinct, isolated actions.
- The Split Button is presented as a single interactive unit, grouped visually and semantically for accessibility.
- It must support independent `disabled` and `loading` states for the entire component (i.e., both the primary and dropdown, *not* independent states per item).

### State Coverage

- **Default:** Both Save and dropdown trigger enabled.
- **Disabled:** Both Save and dropdown trigger are non-interactive.
  - Inaccessible via keyboard, mouse, or touch.
  - Uses `aria-disabled="true"` for accessibility.
  - Visual appearance communicates the disabled state (desaturated, reduced contrast, pointer-events: none).
- **Loading:** Save button (optionally the dropdown as well) shows a spinner or progress indicator.
  - While loading: disables all input, including keyboard navigation and dropdown opening.
  - Loading should not trap focus nor disrupt visible tab order.
- **Focus & Hover:** Clear visual states must differentiate keyboard focus ring and hover indication on both buttons and dropdown options.
- **Dropdown Open:** When open, the dropdown menu overlays below (or above if space-constrained), and secondary options are accessible via keyboard and tap.

### Accessibility Behavior

- **Role and ARIA:**
  - The Split Button group uses `role="group"` with an accessible label if needed ("Save options").
  - Primary button uses `aria-label="Save"` and triggers Save on press/activation.
  - Dropdown trigger uses `aria-haspopup="menu"`, `aria-expanded`, and describes the menu state.
- **Keyboard Support:**
  - Tab focuses the group; each button within the Split Button is reachable with tab:
    - Tab: Moves from the group to the next focusable element.
    - Left/Right arrows (or Shift+Tab/Tab depending on directionality): Move between Save and the dropdown trigger when grouped.
  - **Enter/Space:** On Save — triggers main action. On dropdown — opens menu.
  - **Down Arrow:** On dropdown trigger — opens the menu and moves focus to the first item.
  - **Escape:** Closes the dropdown and returns focus to the dropdown trigger.
  - **Arrow keys/first letter navigation:** Navigate dropdown items.
  - **Enter/Space:** On dropdown item — triggers the corresponding action.
- **Screen Reader:**
  - All labels are programmatically announced.
  - Dropdown manages focus invisibly and returns focus after closure.
- **Disabled State:** Both controls are **not** tabbable or focusable when disabled.
- **Loading State:** Announce loading via `aria-busy` and/or with a live region update ("Saving…").

### Implementation Boundary

- Responsive, touch-friendly: Minimum 44px touch target for each button (includes dropdown trigger on mobile).
- Menu opens on tap, click, or Enter/Space; closes automatically on outside click, Escape, or after selection.
- Dropdown displays below unless space is insufficient (then above).
- Menu items use clear hit areas and highlight on active/hover/focus.
- Touch feedback provided for mobile (highlight, brief delay for clarity).
- No independent loading/disabled state per dropdown item — applies to the full split button as a unit.
- Style and variant tokens must adhere to the component system for consistency.

### Tradeoff Resolution

- **Preserved:** Maximum clarity and directness for Save as the main action, fast access on desktop and mobile.
- **Sacrificed:** No independent state-control for secondary actions (simplifies API, guarantees consistent behavior); dropdown does not open if disabled/loading.

### Verification Method

- Manual and automated checks:
  - Keyboard navigation with and without dropdown states.
  - Screen reader navigation in NVDA, JAWS, and VoiceOver on desktop/mobile.
  - Touch navigation on mobile; verify 44px rule via device testing.
  - Visual confirmation of loading/disabled/focus/hover states.
  - Accessibility audit to confirm ARIA/role labeling and semantic grouping.

---

#### Notes:
- **Component boundary:** Entire split button, not separately sourceable buttons.
- **State coverage:** No orphaned focus. No partial disablement.
- **Accessibility:** Menu structure is critical; do not implement as two unconnected buttons for users of assistive tech.
- **Mobile-first touch targets** require careful padding/margin to preserve 44px.
- **Loading/Disabled is atomic**: if either state is active, user cannot trigger any actions until the state clears.

---

**Component Spec Decisions:**
- component_boundary: Split button group — primary button + dropdown — acts as one unit.
- state_coverage: default, disabled, loading, focus, open.
- accessibility_behavior: keyboard (tab, arrow, enter/escape), semantic grouping, ARIA roles, screen reader labels.
- implementation_boundary: atomic loading/disabled, mobile touch targets, no per-item state, responsive, menu placement.