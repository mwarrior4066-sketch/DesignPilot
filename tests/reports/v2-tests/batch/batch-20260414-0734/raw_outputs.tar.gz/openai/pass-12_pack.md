To recommend a type system for your fintech product spanning a marketing site, web app dashboard, and mobile, I'll ensure it meets your core needs: modern/trustworthy tone, clarity in tabular financial data, flexible hierarchy, and cross-platform performance.

---

## 1. Type System Recommendation

**Primary Typeface:**  
**Inter** ([Google Fonts link](https://fonts.google.com/specimen/Inter))  
- **Why:** Inter is designed for digital interfaces—clear, modern, and highly readable at a range of sizes. It includes multiple weights, excellent numerals, and strong OpenType features (like tabular numerals for data).
- **Trust:** Widely adopted by fintech and SaaS products, Inter’s neutral geometry projects professionalism and trustworthiness without feeling cold or generic.
- **Weights:** Available in 9 weights (Thin to Black) for building flexible hierarchies.

**Fallbacks:**  
- For systems without Inter loaded: `system-ui, Arial, sans-serif`
- This stack ensures a safe, readable default everywhere in degraded situations.

**Supporting Alternative (If you need a Serif accent for brand headlines):**  
**DM Serif Display** for marketing headlines  
- Adds a distinctive, confident character. Avoid in data-dense app or dashboard contexts—keep these sans-serif for clarity.

---

## 2. Key Considerations and Rationale

### a. **Tabular & Financial Data**
- **Tabular numerals:** Inter includes `tnum` (tabular/proportional numbers), ensuring columns of numbers align cleanly—essential for fintech dashboards and tables.
- **Clear delimiters:** Distinct punctuation (commas, periods), currency symbols, and differentiable 1/I/l and 0/O are well drawn.

### b. **Hierarchy & Weights**
- Inter’s wide weight family supports varied captions, body, subheaders, and display sizes.
- Pair regular, medium, semibold, and bold for a clear typographic scale.

### c. **Modern & Trustworthy Feel**
- Inter’s design balances neutrality with warmth.
- It avoids overused “tech” fonts (Roboto, Open Sans) and looks current without chasing trends.

### d. **Cross-platform Consistency**
- Inter: Available on web (easy to self-host or use via Google Fonts), desktop, and mobile (variable font support).
- Consistent appearance ensures brand unity across site, web app, and native mobile interfaces.

### e. **Accessibility**
- Good x-height and open shapes aid readability.
- Meets legibility standards at small sizes, benefiting users on mobile and those with vision impairments.

---

## 3. Sample CSS Stack

```css
font-family: 'Inter', system-ui, Arial, sans-serif;
font-variant-numeric: tabular-nums;
```

- Use `font-variant-numeric: tabular-nums` on tables, dashboards, and anywhere numbers appear in columns.

---

## 4. Implementation Notes

- **Marketing Site:** Use broader tracking (letter-spacing) and larger sizes for hero headlines. Consider adding a serif for very prominent headlines if you want more brand personality, but don’t overuse.
- **Web App Dashboard:** Stick to Inter for all interface and data. Use bold for section headers, regular for body text, and medium/semibold for data emphasis.
- **Mobile:** Inter is available for iOS/Android (as a variable font if preferred), preserving hierarchy and clarity at all viewport sizes.

---

## 5. Tradeoffs

- **Preserved:** Consistency, modern UI feel, data clarity, strong hierarchy, and trust.
- **Sacrificed:** If you want a highly distinctive, branded typeface for marketing, you’ll trade off a degree of seamlessness across platforms and data tables may become harder to read if you opt for a less-neutral font.

---

## 6. Next Steps

1. Prototype with Inter on site, dashboard, and mobile (Google Fonts or self-hosted for best performance).
2. Ensure numeric tables use `font-variant-numeric: tabular-nums`.
3. Test small text for legibility and review brand alignment.  
4. If you need a more unique marketing splash, consider carefully layering in a secondary accent for hero headings only.

---

**Summary:**  
_Inter_ is your best-fit primary typeface: modern, highly readable, trustworthy, great for numbers, and extremely flexible across all your platforms. Keep it as the backbone of your system for a strong, professional fintech presence.