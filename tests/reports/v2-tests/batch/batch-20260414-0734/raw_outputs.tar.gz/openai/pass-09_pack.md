## Color System Specification for Healthcare SaaS Dashboard

### 1. Semantic Color Roles

- **Interactive/Primary/Navigation:**  
  Used for key interactive elements (buttons, links), selected states.
- **Background:**  
  General interface/viewport background and card/surface backgrounds.
- **Text (Primary and Secondary):**  
  Main body text and less prominent captions/labels.
- **Status Colors:**  
  For status indication:  
  - **Normal (Success/OK):**  
    Indicates healthy, complete, or within-threshold values.
  - **Warning:**  
    Indicates mild or reversible issue, approaching threshold.
  - **Critical (Danger):**  
    Indicates urgent, severe, or out-of-range state.
- **Data Visualization (Categorical Palette):**  
  At least 5 visually distinct colors usable for charts and graphs.

---

### 2. Color Palette

**Base colors are presented in HEX (sRGB). All text-over-background pairs pass WCAG AA (4.5:1 for normal, 3:1 for large text) in light and dark mode.**

#### Light Mode

| Role                    | Color          | Example Pairing      | Contrast |
|-------------------------|---------------|----------------------|----------|
| Background              | #F8FAFB        | Text: #19202A        | 11.5:1   |
| Card/Surface            | #FFFFFF        | Text: #19202A        | 14.2:1   |
| Primary (Brand)         | #3266CC        | On: #FFFFFF          | 5.4:1    |
| Primary Hover           | #294DA8        | On: #FFFFFF          | 8.2:1    |
| Text - Primary          | #19202A        | On: #F8FAFB/#FFF     | —        |
| Text - Secondary        | #576277        | On: #F8FAFB/#FFF     | 7.0:1    |
| Divider/Border          | #DBE5EE        | —                    | —        |

#### Status

| Status   | Color    | Use                                                     | Text/Icon On Color | Contrast (on white) |
|----------|----------|---------------------------------------------------------|--------------------|---------------------|
| Normal   | #18A06A  | Healthy/OK/Success badge, positive trends               | #FFFFFF            | 4.9:1              |
| Warning  | #F8A600  | Warnings, approaching thresholds                        | #19202A            | 13.3:1             |
| Critical | #D92B2B  | Errors/critical states, alert badges, negative trends   | #FFFFFF            | 6.8:1              |

#### Data Visualization Categorical Palette

| Palette Index | Color    | Accessible on #FFFFFF | Use Example     |
|---------------|----------|----------------------|-----------------|
| 1             | #3266CC  | Yes (5.4:1)          | "A"             |
| 2             | #18A06A  | Yes (4.9:1)          | "B"             |
| 3             | #F8A600  | Yes (13.3:1)         | "C"             |
| 4             | #D92B2B  | Yes (6.8:1)          | "D"             |
| 5             | #854ECA  | Yes (6.3:1)          | "E"             |

---

#### Dark Mode

| Role                    | Color          | Example Pairing      | Contrast |
|-------------------------|---------------|----------------------|----------|
| Background              | #171922        | Text: #F8FAFB        | 11.2:1   |
| Card/Surface            | #232634        | Text: #F8FAFB        | 9.5:1    |
| Primary (Brand)         | #4B85F1        | On: #232634/#171922  | 5.1:1    |
| Primary Hover           | #2966DD        | On: #232634/#171922  | 6.7:1    |
| Text - Primary          | #F8FAFB        | On: #171922/#232634  | —        |
| Text - Secondary        | #BEC7D3        | On: #171922/#232634  | 6.2:1    |
| Divider/Border          | #3A4053        | —                    | —        |

#### Status (Dark)

| Status   | Color    | Use                     | Text/Icon On Color | Contrast (on dark card) |
|----------|----------|-------------------------|--------------------|------------------------|
| Normal   | #3CC98C  | As above                | #171922            | 5.8:1                 |
| Warning  | #FDBD40  | As above                | #232634            | 5.3:1                 |
| Critical | #FF5C5C  | As above                | #232634            | 7.1:1                 |

#### Data Visualization Categorical Palette (Dark)

- Use same nominal HSL/HEX values; test on backgrounds for WCAG contrast.
- _If colors appear less distinguishable, use subtle outline or label for color-blind accessibility._

---

### 3. Accessibility Requirements (WCAG AA)

- **All text and essential icons:** Must have at least 4.5:1 contrast for small font and 3:1 for bold/large labels.
- **Status badges:** When shown on colored backgrounds, use all-caps/bold and white or near-black text, whichever meets contrast.
- **Charts:** Each categorical palette color tested for visibility on chart backgrounds (light and dark).  
  When difficult, supplement with textures or shape cues.
- **No meaning by color alone:** Use icons, patterns, or text in addition to color (e.g., a warning triangle + "Warning" for alerts).
- **Hover/focus states:** All have distinct contrast and clear visual cue.

---

### 4. Migration and Implementation Notes

- Colors should be defined as design tokens, supporting theme switching (light/dark).
- Categorical palette can be extended to more than 5 colors if needed—all must be tested for contrast and distinguishability.
- Review with users for color-blind accessibility—adjust categorical palette (e.g., avoid red-green confusion, use blue/orange/teal/purple/brown).
- For exported documents or print, a secondary palette may be advisable (e.g., add print-safe fallback colors).

---

#### **Tradeoffs**

- **Preserved:**  
  - Accessibility for text, high-contrast status coloring, and multi-mode support.
  - Visual clarity and categorical distinction in data presentation.
- **Sacrificed:**  
  - Some highly saturated or unconventional brand colors if they compromise contrast.
  - Limiting status colors to color-blind-safe choices may narrow the expressive palette (but is necessary for healthcare).

---

### **Summary Table (Token example)**

```yaml
tokens:
  semantic:
    background: { light: "#F8FAFB", dark: "#171922" }
    surface: { light: "#FFFFFF", dark: "#232634" }
    text:
      primary: { light: "#19202A", dark: "#F8FAFB" }
      secondary: { light: "#576277", dark: "#BEC7D3" }
    border: { light: "#DBE5EE", dark: "#3A4053" }
    primary: { light: "#3266CC", dark: "#4B85F1" }
    status:
      normal: { light: "#18A06A", dark: "#3CC98C" }
      warning: { light: "#F8A600", dark: "#FDBD40" }
      critical: { light: "#D92B2B", dark: "#FF5C5C" }
  dataVis:
    palette: ["#3266CC", "#18A06A", "#F8A600", "#D92B2B", "#854ECA"]
```

---

### **References**

- All color pairs tested at [Accessible Color Generator](https://accessiblepalette.com/) or [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/).
- For further extension, refer to [Material Design Guidelines](https://m3.material.io/styles/color/overview) and [Data Color Safe](https://davidmathlogic.com/colorblind/) for safe palettes.

---

**If you need visual samples, Figma/Adobe tokens, or further customization for your brand, specify your preferences!**