Here is the component specification for your split button.

The split button is a compound UI component that provides a primary, frequently used action alongside a menu of less frequent, secondary actions, all within a single visual element. This design aims to streamline common workflows while keeping related options discoverable.

### Component Boundary

The split button consists of three distinct, yet coupled, parts:

1.  **Primary Action Button:** The main clickable area (e.g., "Save"). This button performs the default action instantly upon click/tap/activation.
2.  **Dropdown Trigger Button:** A smaller, visually distinct button (often with a chevron icon) adjacent to the primary action. Its sole purpose is to open/close the associated dropdown menu.
3.  **Dropdown Menu:** A flyout panel containing a list of secondary actions (e.g., "Save as draft", "Save and close"). This menu appears when the dropdown trigger is activated.

**Inclusions:** All visual elements, interaction logic, and accessibility attributes for these three parts are within this component's boundary.
**Exclusions:** The content or logic of the individual secondary actions (e.g., how "Save as draft" actually works on the backend) is outside this component's scope; it only defines how they are presented and accessed.

### State Coverage

Both the Primary Action Button and the Dropdown Trigger Button will support the following states:

*   **Enabled:** Default, interactive state.
*   **Hover:** Visual feedback when a pointer is over the button.
*   **Focus:** Visual feedback when the button receives keyboard focus.
*   **Active/Pressed:** Visual feedback when the button is being clicked/tapped or activated by keyboard.
*   **Disabled:** Non-interactive state, visually muted. `state_coverage` for disabled elements means they cannot be activated.
*   **Loading:** Indicates an ongoing operation. The button may display a spinner or other loading indicator, and `state_coverage` for the loading state means it should prevent further interaction.

The Dropdown Menu will support:

*   **Closed:** Not visible.
*   **Open:** Visible, with menu items interactive. The dropdown trigger reflects this open state (e.g., chevron rotation, different background).

### Accessibility Behavior

`accessibility_behavior` is critical to ensure inclusive interaction.

**Keyboard Support:**

*   **Tab Order:** The split button (as a composite component) should receive a single tab stop. When focused, the primary action button receives initial focus.
*   **Primary Action Activation:**
    *   `Enter` or `Space` key activates the primary action when it has focus.
*   **Dropdown Trigger Activation:**
    *   When the primary action button has focus, `Right Arrow` moves focus to the dropdown trigger.
    *   When the dropdown trigger has focus, `Enter`, `Space`, or `Down Arrow` opens the dropdown menu.
    *   `Escape` key closes an open dropdown menu and returns focus to the dropdown trigger.
*   **Menu Navigation:**
    *   Once the menu is open, `Up Arrow` and `Down Arrow` navigate between menu items.
    *   `Home` and `End` keys move focus to the first and last menu items, respectively.
    *   `Enter` or `Space` activates a focused menu item.
*   **Dismissal:** Clicking outside the menu or pressing `Escape` closes the menu and returns focus to the dropdown trigger.

**Screen Reader Semantics:**

*   The split button should be marked as an `aria-haspopup="menu"` on the dropdown trigger.
*   The primary action button will have `role="button"`.
*   The dropdown trigger will have `role="button"` and `aria-expanded="true/false"` reflecting its open/closed state.
*   The dropdown menu will be `role="menu"` with `aria-labelledby` pointing to the dropdown trigger.
*   Individual menu items will be `role="menuitem"`.
*   Descriptive `aria-label` or visible text for both buttons to clarify their purpose to assistive technologies.

**Touch Targets:**

*   Both the Primary Action Button and the Dropdown Trigger Button must meet a minimum `target-size threshold` of 44x44 CSS pixels to ensure usability on mobile touch devices, in compliance with WCAG 2.1 Success Criterion 2.5.5.
*   Interaction with the dropdown menu items must also respect a minimum touch target size.

### Implementation Boundary

`implementation_boundary` defines the technical contract for front-end development.

*   **Semantic Structure:** Use native HTML `<button>` elements where appropriate. If `<div>` elements are used for styling reasons, ensure appropriate ARIA roles are applied (`role="button"`). The menu should ideally be an unordered list (`<ul>`) with list items (`<li>`) or `<a>` tags for navigation, or `<div>` elements with `role="menuitem"`.
*   **Event Handling:** Separate event listeners for the primary action click and the dropdown trigger click. Keyboard events (`keydown`, `keyup`) will be handled for navigation and activation.
*   **Attribute Management:** Dynamic updates to ARIA attributes (`aria-expanded`, `aria-disabled`) based on component state.
*   **State Management:** The component should accept `disabled` and `loading` props/attributes.
    *   When `disabled` is true, both buttons are non-interactive and visually muted.
    *   When `loading` is true, the primary button displays its loading state, and the dropdown trigger is typically disabled until the loading state resolves.
*   **Styling:** Provide clear CSS tokens for various states (hover, focus, active, disabled, loading, open).
*   **Data Flow:** Menu items will be passed as an array of objects, each containing a label, an action handler, and potentially a `disabled` state.

### Tradeoffs and Rationale

The use of a split button, `rather than` separate primary and secondary buttons or a standalone dropdown menu, offers a compact solution for presenting related actions. `At the cost of` increased implementation complexity (due to its composite nature and comprehensive accessibility requirements), it improves discoverability for secondary actions while prioritizing the most common action. `This means accepting` that the primary action is visually prominent, while secondary actions are nested. The `tradeoff_resolution` here favors speed for the primary task for a majority of users, balanced by accessibility for all users to access secondary options.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": ["component_boundary: defined", "state_coverage: enabled, disabled, loading, open/closed", "accessibility_behavior: keyboard_support, touch_targets, screen_reader_semantics", "implementation_boundary: semantic_structure, event_handling, state_management"],
  "evidence_classes_cited": ["target-size threshold", "WCAG rule", "role map", "keyboard rule", "focus rule", "state rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]