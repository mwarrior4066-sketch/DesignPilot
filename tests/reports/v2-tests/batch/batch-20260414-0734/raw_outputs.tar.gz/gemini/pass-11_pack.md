Okay, this is a clear task for `rt_layout_reconstruction_plan`. I will act as a `layout-reconstruction-expert` and `grid-system-expert` to extract the existing rules and then propose how to translate them into a modern, implementable system for new templates.

First, a quick visual pre-pass would be crucial given the PDF input, separating observed evidence from inferred structure.

## Layout System Reconstruction Plan from 2018 Brand Guidelines

From your PDF, I would systematically extract the following elements and then translate them into a modern layout system suitable for new templates.

### 1. Extracted Elements (Observed vs. Inferred)

I will distinguish clearly between directly specified rules and patterns inferred from examples.

**Core Grid Specifications (Observed - High Confidence):**
*   **Columns:**
    *   **Observed:** Number of columns (e.g., 12-column, 6-column, or hybrid).
    *   **Observed:** Column widths (fixed or percentage-based) and gutter widths.
    *   **Inferred:** How columns are used for different content types (e.g., text spans 8, images span 4).
*   **Margins & Padding:**
    *   **Observed:** Document-level page margins (top, bottom, left, right).
    *   **Observed:** Internal padding values (e.g., space around components, between text blocks).
    *   **Inferred:** If there's a base spacing unit (e.g., all spacing is a multiple of 8px).
*   **Baseline Grid (Observed/Inferred - Medium-High Confidence):**
    *   **Observed:** If an explicit vertical baseline grid is mentioned (e.g., 4px or 8px increment).
    *   **Inferred:** If leading (line-height) values for body text and headings snap to a consistent vertical rhythm.
*   **Breakpoints (Inferred - Low Confidence for 2018 PDF):**
    *   **Inferred:** Examine examples for variations in layout that might imply adaptive behavior for different formats (e.g., print vs. assumed digital, though likely static). If none, assume a single fixed canvas.

**Key Layout Patterns & Component Structure (Inferred - Medium Confidence):**
*   **Information Hierarchy:**
    *   **Inferred:** How major sections are visually separated and prioritized.
    *   **Inferred:** Treatment of headers, sub-headers, and body copy in relation to the grid.
*   **Content Block Proportions:**
    *   **Inferred:** Common width ratios for text blocks, images, and other content within the column structure.
    *   **Inferred:** How images are cropped or scaled to fit the grid (e.g., full-column width, half-column, floating).
*   **Component Placement:**
    *   **Inferred:** Consistency in how elements like callouts, sidebars, or captions are positioned relative to the main content and the grid.
*   **Typography's Grid Relationship:**
    *   **Inferred:** How type sizes and line heights align with the baseline grid (if any) and overall vertical rhythm.
*   **Visual Confidence Boundary:** I will explicitly note any layout behaviors that are only visually suggested by examples but not explicitly defined, such as implied alignment rules or specific spacing used in one-off instances.

### 2. Translation to a Modern Layout System

This is where the extracted rules are codified and adapted for flexibility, responsiveness, and modern implementation.

*   **Governing Rule: Tokenization and Responsiveness.** The old fixed values will be translated into a flexible, token-based system that allows for responsiveness and easier maintenance.

#### a) Grid System Foundation (`preserved_elements: core_grid_structure, base_spacing_unit`)

*   **Grid Framework:**
    *   Translate the observed columns and gutters into a CSS Grid or Flexbox-compatible system. This means defining `grid-template-columns` using `fr` units or percentages for flexibility, and `gap` for gutters.
    *   **Tradeoff:** Strict adherence to fixed pixel widths (common in 2018) will be sacrificed for fluid, percentage-based or `fr` units to enable responsiveness across various screen sizes.
*   **Spacing Scale:**
    *   Establish a modular spacing scale (e.g., `space-xs`, `space-sm`, `space-md`, `space-lg`, `space-xl`) using `rem` units, derived from the most common padding/margin values and any baseline grid. This replaces arbitrary pixel values.
    *   **Causal Grounding:** This ensures consistent vertical rhythm and horizontal alignment, making layout decisions predictable and reducing visual noise.
*   **Breakpoints:**
    *   Introduce explicit breakpoints (e.g., `sm`, `md`, `lg`, `xl` for mobile, tablet, desktop, large desktop) even if not present in the original PDF. Define how the column structure and content flow adapt at each breakpoint.
    *   **This requires:** assuming a target device landscape that likely didn't exist in 2018.

#### b) Layout Patterns & Components (`reconstruction_order: grid_then_spacing_then_component_integration`)

*   **Column Span Utilities:**
    *   Create utility classes or component props (e.g., `col-span-6`, `col-start-3`) that allow components to easily occupy specific column ranges within the new grid system.
*   **Component Alignment Rules:**
    *   Define how components (e.g., cards, content blocks, forms) align with the grid and consume spacing tokens.
    *   **Inference Boundary:** This relies heavily on inferring the *intent* of the original layout rather than literal pixel translation.
*   **Vertical Rhythm:**
    *   Ensure all text elements (headings, body, captions) have `line-height` values that snap to the established baseline grid or the modular spacing scale.
    *   **Tradeoff:** Minor adjustments to original type sizes or line heights may be necessary to achieve perfect vertical rhythm in a digital context.

#### c) Type System Integration (`inference_boundary: type_relationship_to_grid`)

*   **Type Scale & Line Length:**
    *   Review the original type scale and ensure line lengths for body text are optimal for readability (e.g., 45-75 characters per line). Adjust `font-size` and `line-height` as needed to align with the new spacing scale while maintaining readability.
    *   **Causal Grounding:** Readability is critical; an old print-optimized line length might be too long for web.
*   **Typographic Grid Alignment:**
    *   Specify how headings and key text elements should align to the new base grid, potentially using `margin-top`/`margin-bottom` values from the spacing scale.

#### d) Documentation and Verification (`verification_method: cross_reference, visual_consistency, responsiveness_testing`)

*   **Design Token Specification:**
    *   Document all grid (columns, gutters, breakpoints), spacing, and typography scale values as design tokens (`$grid-columns`, `$space-md`, `$font-size-body`).
*   **Usage Guidelines:**
    *   Provide clear examples of how to apply these new layout rules to common template types (e.g., hero sections, content pages, landing pages).
*   **Verification Steps:**
    *   **Cross-reference:** Build out a few of the *original* PDF's layout examples using the new system and compare them side-by-side to ensure visual fidelity where intended.
    *   **Visual Consistency:** Conduct visual QA on new templates across target breakpoints to ensure the system is robust.
    *   **Responsiveness Testing:** Validate that layouts adapt gracefully to different screen sizes without breaking or losing hierarchy.

### 3. Tradeoffs & Considerations

*   **Original Precision vs. Modern Flexibility:** We will sacrifice some of the pixel-perfect, fixed-width precision of a 2018 print-first document for the flexibility and maintainability of a responsive, token-based digital system.
*   **Implicit Rules:** Many subtle layout choices in the old PDF might be implicit rather than explicit. These will be inferred and then codified, acknowledging the `inference_boundary`.
*   **Accessibility:** The original PDF might not have considered modern accessibility requirements. The new layout system will inherently build in best practices for responsive scaling, touch targets (if applicable), and readable content flow.

By following this plan, we can systematically deconstruct your old brand guidelines' layout and confidently apply its core principles to robust, modern templates.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: core_grid_structure, base_spacing_unit",
    "inference_boundary: what_is_observed_vs_inferred_for_type_relation_and_patterns",
    "reconstruction_order: grid_then_spacing_then_component_integration",
    "verification_method: cross_reference, visual_consistency, responsiveness_testing"
  ],
  "evidence_classes_cited": ["artifact", "inference_label", "rule"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]