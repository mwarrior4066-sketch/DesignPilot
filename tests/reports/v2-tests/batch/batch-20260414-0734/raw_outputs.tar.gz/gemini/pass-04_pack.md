Adding real-time collaboration like Google Docs to an existing REST/PostgreSQL React application is a significant architectural undertaking, not a simple feature extension. This review identifies the hidden backend system requirements, explicit blockers, and a phased, safer implementation path.

## Hidden System Requirements

The core challenge is the fundamental shift from a request/response model (REST) to a persistent, bidirectional, event-driven model necessary for real-time synchronization.

*   **Dedicated Real-time Service (`system_surface_dependency`):** A separate service (e.g., using Node.js, Go, or a framework like Phoenix LiveView) optimized for WebSocket connections and real-time logic will be required. This service will host the core synchronization engine.
*   **Operational Transformation (OT) or Conflict-free Replicated Data Types (CRDTs) Implementation (`system_surface_dependency`):** This is the most crucial hidden requirement. To handle simultaneous edits and resolve conflicts, the backend must implement or integrate a robust algorithm like OT (e.g., Google Docs, ShareDB) or CRDTs (e.g., Yjs, Automerge). This is a complex algorithmic challenge far beyond typical CRUD logic.
*   **Ephemeral State Management for Presence (`data_dependency`):** Visible cursor positions and user presence require a fast, volatile data store (e.g., Redis) that can be quickly updated and broadcast.
*   **New Data Model for Operations/Deltas (`data_dependency`):** Instead of storing the full document state directly for every change, the system will need to track and apply small, atomic "operations" or "deltas" in sequence. PostgreSQL, while suitable for the final document state, is not ideal for managing high-volume, real-time operation streams unless a specialized schema and indexing strategy are meticulously designed.
*   **Message Broker for Scalability and Durability (`system_surface_dependency`):** For resilience and horizontal scaling, a message queue (e.g., Kafka, RabbitMQ) would likely sit between the real-time service and other components (like the document persistence layer) to ensure operations are processed reliably and can be replayed or recovered.
*   **Robust WebSocket Infrastructure (`system_surface_dependency`):** Managing many concurrent, long-lived WebSocket connections requires a specialized server, often distinct from a traditional REST server, with considerations for load balancing, connection pooling, and heartbeat mechanisms.
*   **Extended Authentication & Authorization (`permissions_dependency`):** The existing REST authentication/authorization will need to extend to WebSocket connections and to individual real-time operations, ensuring users can only edit documents they have permissions for (`authorization_perimeter`).
*   **Idempotency and Resilience for Operations (`idempotency_contract`, `resilience_strategy`):** Operations sent from clients must be either idempotent or deterministically handled by the OT/CRDT algorithm to prevent data corruption if network issues cause duplicates. The real-time service must also gracefully handle client disconnections and server restarts.
*   **Observability (`observability_tax`):** Tracing individual operations across clients and the real-time service is critical for debugging and maintaining state consistency.

## Feasibility Assessment and Explicit Blockers

Integrating real-time collaboration is **feasible**, but it comes with **significant architectural and complexity costs** that make it a `compound` task.

*   **Architectural Mismatch (`blocking_constraint`):** The existing REST-based backend is not designed for real-time, bidirectional communication or complex state synchronization algorithms. Trying to force this into the current REST architecture will lead to an unmaintainable system and a poor user experience. This requires a dedicated, distinct architectural component.
*   **OT/CRDT Implementation Complexity (`blocking_constraint`):** Building a correct and robust OT or CRDT engine from scratch is notoriously difficult and error-prone, even for experienced teams. This is a common pitfall that can lead to subtle data corruption, inconsistencies, and difficult-to-debug issues. This demands using (and deeply understanding) well-vetted libraries.
*   **Data Persistence Challenges (`blocking_constraint`):** PostgreSQL's row-based model is not optimized for the high-frequency, small-delta updates characteristic of real-time collaboration. Storing every operation in PostgreSQL could lead to performance bottlenecks, and rebuilding document state from an operations log can be slow. A specialized data strategy is needed.
*   **Scalability Concerns (`blocking_constraint`):** Scaling WebSockets, the real-time processing engine, and the underlying message broker requires careful design and infrastructure investment, which will be an `architecture tax`.

## Safer Implementation Path with Phased Recommendations

The safest path introduces a new, isolated real-time service and leverages proven libraries.

### Phase 0: Proof of Concept (PoC) with Off-the-Shelf Solution

*   **Objective:** Validate core real-time sync with minimal effort, demonstrate feasibility, and understand an chosen OT/CRDT library.
*   **Recommendation (`intervention_order`):**
    1.  **Select a Real-time Collaboration Library:** Investigate established libraries like **ShareDB** (OT-based, often paired with Node.js/MongoDB/Redis) or **Yjs / Automerge** (CRDT-based, language-agnostic, can work with various backends and persistence layers). These libraries abstract away the complexities of OT/CRDT algorithms.
    2.  **Build a Minimal, Isolated Service:** Create a barebones real-time service (e.g., in Node.js for ShareDB, or a Go/Python service integrating Yjs) with WebSocket support. Focus on a single, simplified document model (e.g., plain text or a simple JSON object).
    3.  **Basic Persistence:** Integrate a simple database (e.g., a temporary Redis instance or a separate small PostgreSQL table for this PoC) to save the final document state and demonstrate recovery.
    4.  **Client Integration:** Develop a minimal React component to connect to this PoC service and demonstrate collaborative editing and cursor presence.
*   **Tradeoff (`tradeoff_resolution`):** By using an off-the-shelf library, you sacrifice some architectural control and potentially bind to a specific technology stack, but you gain a massive reduction in development time and algorithmic risk. This phase focuses on proving the concept rather than production readiness.

### Phase 1: Isolated Real-time Microservice Integration

*   **Objective:** Introduce the real-time capability as a distinct, decoupled microservice.
*   **Recommendation (`intervention_order`):**
    1.  **Develop a Dedicated Real-time Service:** Build out the real-time service identified in Phase 0 as a separate microservice. This service will be the sole authority for real-time document state (`authority_model`).
    2.  **WebSockets for Real-time Communication:** Implement secure WebSocket endpoints for clients to connect.
    3.  **Document Synchronization Logic:** Integrate the chosen OT/CRDT library into this service to manage document state, operations, and conflict resolution. This service will hold the "source of truth" for the active document.
    4.  **Initial Document Load & Final Save:** The existing REST API will call this new service to fetch the document's initial state for editing and to trigger the final save back to the main PostgreSQL database.
    5.  **Ephemeral Presence Store:** Implement Redis for tracking and broadcasting user cursor positions and presence in real-time. This is typically a very fast, volatile key-value store.
*   **Tradeoff (`tradeoff_resolution`):** This increases overall architectural complexity with a new service and potentially a new data store. However, it completely decouples the real-time logic from the existing monolithic REST application, significantly reducing risk to the core app and allowing independent scaling.

### Phase 2: Robust Data Persistence Strategy

*   **Objective:** Ensure durability, history, and efficient recovery of document states.
*   **Recommendation (`intervention_order`):**
    1.  **Operations Log (OpLog):** Implement a robust mechanism to persist every real-time operation. This could be a dedicated table in PostgreSQL (with careful schema design and indexing for performance), a message queue (Kafka) for durable event streaming, or a specialized document database. This ensures a complete history for auditing and recovery.
    2.  **Periodic Snapshots to PostgreSQL:** Configure the real-time service to periodically take "snapshots" of the current document state and persist these to the existing PostgreSQL database. This allows for faster document loading than replaying an entire operations log and maintains `consistency_stance` for the final state.
    3.  **Data Recovery Mechanism:** Establish a process to rebuild a document's state by replaying operations from the OpLog onto the last known snapshot, for disaster recovery or analytics.
*   **Tradeoff (`tradeoff_resolution`):** This introduces a more complex data pipeline and potentially more databases. It ensures data integrity and recovery capabilities at the cost of operational overhead.

### Phase 3: Enhanced Security and Scalability

*   **Objective:** Secure real-time interactions and prepare for higher user loads.
*   **Recommendation (`intervention_order`):**
    1.  **WebSocket Authentication (`permissions_dependency`):** Implement robust authentication for WebSocket connections, likely using JWTs exchanged after initial REST authentication. The real-time service must validate user identity and permissions for specific documents (`authorization_perimeter`).
    2.  **Fine-grained Authorization:** Extend permissions checks to individual real-time operations, ensuring users can only perform allowed actions (e.g., read-only users cannot edit).
    3.  **Load Balancing for WebSockets:** Deploy WebSocket-aware load balancers to distribute connections across multiple instances of the real-time service.
    4.  **Horizontal Scaling:** Design the real-time service for horizontal scaling, allowing new instances to be added as user load increases. This typically involves making the service stateless (or using sticky sessions managed by the load balancer) and relying on the message broker for inter-service communication.
    5.  **Rate Limiting and Quotas (`resilience_strategy`):** Implement rate limiting on WebSocket operations to protect against abuse and ensure fair resource usage.
*   **Tradeoff (`tradeoff_resolution`):** Increases infrastructure complexity and introduces more security considerations. Necessary for a production-grade, reliable system.

### Phase 4: Monitoring and Observability

*   **Objective:** Gain insight into real-time system health and debug complex synchronization issues.
*   **Recommendation (`intervention_order`):**
    1.  **Distributed Tracing (`observability_tax`):** Implement distributed tracing (e.g., OpenTelemetry) to track individual operations across clients, the real-time service, the message broker, and persistence layers.
    2.  **Real-time Metrics & Alerts:** Set up metrics (e.g., number of active connections, operations/second, conflict rates, latency) and alerting for the real-time service and its dependencies.
    3.  **Detailed Logging:** Implement structured logging within the real-time service to capture crucial events, state changes, and error conditions, providing granular visibility into `problem_details_contract`.
*   **Tradeoff (`tradeoff_resolution`):** Adds operational overhead and requires dedicated tooling. Essential for effective troubleshooting and maintaining system reliability.

This multi-phased approach prioritizes **containing risk** and **building a dedicated architectural component** for real-time collaboration, rather than attempting to shoehorn it into the existing REST/PostgreSQL paradigm. You sacrifice initial simplicity for long-term maintainability, scalability, and correctness.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "data_dependency: new data models for operations, ephemeral state for presence",
    "permissions_dependency: extending auth to WebSocket connections and real-time operations",
    "system_surface_dependency: dedicated real-time service, WebSockets, OT/CRDT implementation, message broker, ephemeral state store",
    "blocking_constraint: architectural mismatch (REST vs. real-time), complexity of OT/CRDT, data persistence challenges, scalability concerns",
    "problem_details_contract: data corruption, inconsistencies, complex debugging, performance bottlenecks",
    "authorization_perimeter: securing WebSocket connections and individual operations",
    "idempotency_contract: operations must be idempotent or deterministically handled by OT/CRDT",
    "async_job_model: event stream processing has async characteristics, operations treated as async workflows",
    "resilience_strategy: handling disconnections, server restarts, rate limiting",
    "authority_model: new real-time service becomes the authority for active document state",
    "consistency_stance: eventual consistency managed by OT/CRDT algorithms with periodic strong consistency for snapshots",
    "data_delivery: WebSockets for real-time operations, message queues for robustness and inter-service communication",
    "observability_tax: tracing, metrics, and logging for real-time events and state changes"
  ],
  "evidence_classes_cited": ["blocking_constraint", "system_surface_dependency", "data_dependency", "permissions_dependency", "intervention_order", "tradeoff_resolution", "authority_model", "consistency_stance", "observability_tax", "problem_details_contract", "authorization_perimeter", "idempotency_contract", "async_job_model", "resilience_strategy"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]