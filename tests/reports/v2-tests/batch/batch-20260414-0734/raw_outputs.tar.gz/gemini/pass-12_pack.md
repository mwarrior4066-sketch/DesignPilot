For a fintech product requiring a modern and trustworthy type system across a marketing site, a web app dashboard, and mobile, with strong support for tabular financial data and hierarchical weights, I recommend prioritizing a highly versatile, accessible, and robust sans-serif typeface.

This approach ensures a unified, professional, and readable experience across all platforms, which is critical for trust and usability in financial contexts.

### Type System Strategy

**Overall Strategy (reading_context):**
A single, well-chosen sans-serif family will serve as the primary typeface across all three contexts: the marketing site, the web app dashboard, and mobile interfaces. This provides consistency in brand perception and user experience, which is paramount for trustworthiness. While a serif could be considered for marketing headlines, the benefits of a unified, high-performing sans-serif for a fintech product generally outweigh the desire for stylistic variation, *because* it simplifies implementation and reinforces a consistent sense of reliability.

### Primary Font Family Recommendation

**Inter** is an excellent choice for this purpose.

**Rationale (pairing_rationale):**

*   **Modern & Trustworthy Feel:** Inter possesses a clean, professional, and neutral aesthetic. Its functional design avoids overly decorative elements, contributing to a modern and trustworthy perception crucial for fintech.
*   **Excellent for Tabular Financial Data:** Inter includes dedicated **tabular figures** (monospaced numbers) which ensure perfect vertical alignment in tables, spreadsheets, and data visualizations. This is a critical feature for presenting financial data clearly and reducing interpretation errors. It also has strong legibility at small sizes, important for dense dashboards.
*   **Multiple Weights for Hierarchy (scale_decision):** Inter comes with a comprehensive range of weights (Thin, Light, Regular, Medium, Semi Bold, Bold, Extra Bold, Black) and even variable font support. This allows for rich typographic hierarchy and clear distinction between headings, body text, data labels, and interactive elements, enhancing scanability and comprehension across all interfaces.
*   **Cross-Platform Compatibility:** Designed for UI, Inter performs exceptionally well on screens, supporting high readability on web, mobile, and app environments. It is optimized for pixel hinting and includes a large character set.
*   **Accessibility:** Inter is designed with readability in mind, featuring clear letterforms, generous x-height, and good contrast. This directly contributes to WCAG compliance for text legibility.

### Alternative Consideration

**IBM Plex Sans** is another strong contender. It offers excellent readability, a wide range of weights, and a professional, modern feel. Its focus on a clear, open design makes it highly effective for data-heavy applications. The entire Plex family (including Serif and Mono) offers stylistic consistency if future needs expand.

### Scale & Hierarchy Decisions (scale_decision)

1.  **Base Size:** Establish a comfortable base font size (e.g., 16px or 18px for body text) with a robust line-height (e.g., 1.5-1.6) to ensure readability, especially on mobile.
2.  **Responsive Scale:** Implement a fluid type scale that adapts across breakpoints using CSS `clamp()` or similar techniques. This ensures optimal reading experience on diverse screen sizes without rigid, fixed steps.
3.  **Key Steps for Hierarchy:** Define 5-7 distinct steps for the type scale.
    *   **Body Text:** Regular weight, base size.
    *   **Subheadings/Labels:** Medium or Semi Bold, slightly smaller than base for secondary info, or slightly larger for key UI labels.
    *   **Dashboard Values:** Regular or Medium weight, often at base size or slightly larger. Tabular figures are key here.
    *   **Primary Headings (App):** Bold or Extra Bold, 2-3 steps larger than base.
    *   **Marketing Headings (Site):** Extra Bold or Black, 3-5 steps larger, designed for impact and readability at a distance.
    *   **Fine Print/Captions:** Light or Regular weight, 1-2 steps smaller than base.

### Implementation Considerations (adoption_sequence)

1.  **Prioritize Core UI:** Implement Inter (or chosen primary) across the web app dashboard and mobile first, establishing a strong, consistent foundation.
2.  **Marketing Site Adaptation:** For the marketing site, leverage Inter's full range of weights and sizes for visual distinction. You might use larger, bolder headings to capture attention, while maintaining the same readable body text for consistency. Avoid introducing a second typeface unless a distinct brand personality is critically needed and carefully evaluated against implementation complexity and visual dissonance. If a second typeface is considered, ensure it *complements* Inter and doesn't conflict with its modern/trustworthy feel.
3.  **Variable Fonts:** Utilize Inter's variable font capabilities to reduce file size and provide precise control over weight, if supported by your build pipeline and target browsers.
4.  **Web Font Loading:** Implement efficient web font loading strategies (e.g., `font-display: swap`, preloading) to minimize layout shifts and ensure fast rendering.
5.  **Accessibility Testing:** Verify text contrast ratios (WCAG 2.1 AA or AAA) for all font sizes and colors, and ensure readability across different weights.

### Tradeoffs

The chosen approach means **you sacrifice** the highly distinct typographic personality that a well-paired serif or decorative typeface might offer on the marketing site **to gain** significant advantages in consistency, technical performance, and a unified sense of trustworthiness across all product surfaces. This focus on functional clarity and reliability is a critical choice for a fintech product.

***

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": ["reading_context: marketing_site, web_app_dashboard, mobile", "scale_decision: multiple_weights, fluid_responsive_scale", "pairing_rationale: modern_trustworthy, tabular_data_focus, single_family_simplicity", "adoption_sequence: prioritize_core_ui_then_marketing"],
  "evidence_classes_cited": ["benchmark: wcag_2_1_aa", "constraint: tabular_figures", "constraint: multiple_weights", "artifact: variable_fonts", "constraint: legibility_at_small_sizes", "constraint: web_font_loading_efficiency"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]