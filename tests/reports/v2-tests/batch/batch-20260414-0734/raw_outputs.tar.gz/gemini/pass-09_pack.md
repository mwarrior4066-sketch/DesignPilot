Here is a color system definition for your healthcare SaaS dashboard, designed to meet your requirements for status communication, dark mode support, data visualization, and WCAG AA accessibility.

### Color System for Healthcare SaaS Dashboard

The color system prioritizes clarity, semantic meaning, and accessibility to ensure critical health data is always interpretable and usable under varying conditions.

#### I. Semantic Color Roles

The system defines colors by their functional purpose to reduce ambiguity and ensure consistent interpretation across the dashboard.

*   **UI Base Colors**: Used for backgrounds, primary/secondary text, borders, and general iconography. These colors will have distinct light and dark mode variations.
*   **Status Colors**: Dedicated to communicating immediate state or urgency (Normal, Warning, Critical, Informational). These are highly visible and consistent across modes.
*   **Categorical Data Visualization Colors**: A distinct palette designed for differentiating various data series in charts without conflicting with status meanings.
*   **Interaction States**: Colors for hover, focus, active, and disabled states, ensuring clear feedback for user interactions.

#### II. Color Palette Definitions (Conceptual Examples)

**A. UI Base Colors**

*   **Light Mode:**
    *   `UI-Background-Primary`: `#FFFFFF` (Page/Card background)
    *   `UI-Background-Secondary`: `#F8F8F8` (Alternate background, e.g., table headers)
    *   `Text-Primary`: `#212121` (Main body text, headings)
    *   `Text-Secondary`: `#616161` (Helper text, secondary labels)
    *   `Text-Disabled`: `#BDBDBD`
    *   `Border-Primary`: `#E0E0E0` (Dividers, input field borders)

*   **Dark Mode (Conceptual Inversion):**
    *   `UI-Background-Primary`: `#1A1A1A`
    *   `UI-Background-Secondary`: `#2C2C2C`
    *   `Text-Primary`: `#F5F5F5`
    *   `Text-Secondary`: `#CCCCCC`
    *   `Text-Disabled`: `#757575`
    *   `Border-Primary`: `#424242`

**B. Status Colors (`state_mapping`)**

These colors are chosen for immediate recognition and will maintain high contrast in both light and dark environments.

*   **Normal / Success**:
    *   Light Mode: `#4CAF50` (Green)
    *   Dark Mode: `#66BB6A` (Slightly brighter green)
    *   *Use Case*: Healthy, stable, no action required, positive trend.

*   **Warning / Caution**:
    *   Light Mode: `#FFC107` (Amber)
    *   Dark Mode: `#FFD54F` (Slightly brighter amber)
    *   *Use Case*: Potential issue, review recommended, moderate risk.

*   **Critical / Alert**:
    *   Light Mode: `#F44336` (Red)
    *   Dark Mode: `#EF5350` (Slightly brighter red)
    *   *Use Case*: Urgent action required, high risk, error state.

*   **Informational**:
    *   Light Mode: `#2196F3` (Blue)
    *   Dark Mode: `#42A5F5` (Slightly brighter blue)
    *   *Use Case*: General information, neutral updates.

**C. Categorical Data Visualization Colors (Minimum 5)**

This palette is designed for visual distinctiveness across multiple data series in charts, minimizing confusion with status indicators. Exact hues would be refined with a color-blindness check.

*   `Data-Category-1`: `#673AB7` (Deep Purple)
*   `Data-Category-2`: `#00BCD4` (Cyan)
*   `Data-Category-3`: `#FF5722` (Deep Orange - distinct from warning)
*   `Data-Category-4`: `#8BC34A` (Light Green - distinct from normal)
*   `Data-Category-5`: `#795548` (Brown)
*   `Data-Category-6`: `#E91E63` (Pink)
*   `Data-Category-7`: `#607D8B` (Blue-Gray)

*Note: For the data visualization palette, ensure colors are perceptually uniform and provide sufficient contrast against both light and dark mode backgrounds for any associated labels or legends.*

#### III. Dark Mode Adaptation Strategy (`migration_strategy`)

Dark mode support is integrated at the system level:

1.  **Luminance Inversion for UI**: Base UI colors (backgrounds, text, borders) will be swapped to a lower luminance scale, maintaining appropriate contrast ratios. Dark mode backgrounds will be dark, and primary text will be light.
2.  **Semantic Hue Preservation**: Status colors and categorical data colors will retain their core hue to preserve their meaning. Their luminance may be slightly adjusted (often brightened against a dark background) to maintain sufficient contrast.
3.  **Contrast Recalibration**: All color pairings will be re-evaluated in dark mode to ensure they continue to meet WCAG AA standards. This may involve slightly adjusting saturation or brightness for optimal readability.
4.  **System-level Toggle**: The application will implement a global theme toggle, allowing users to switch between light and dark modes, or respect system preferences.

#### IV. Contrast Boundaries and Accessibility (WCAG AA) (`contrast_boundary`)

All color usage will strictly adhere to WCAG 2.1 AA standards.

*   **Text Contrast**:
    *   **Normal Text (under 18pt regular or 14pt bold)**: Minimum contrast ratio of **4.5:1** against its background.
    *   **Large Text (18pt regular or larger, or 14pt bold or larger)**: Minimum contrast ratio of **3:1** against its background.
*   **Non-Text Contrast**:
    *   **UI Components (e.g., input field borders, button outlines, icons)**: Minimum contrast ratio of **3:1** against adjacent colors. This ensures interactive elements and graphical objects are clearly discernible.
*   **Color-Blindness**: The categorical data palette, in particular, will be evaluated using color-blindness simulators (e.g., for Protanopia, Deuteranopia, Tritanopia) to ensure distinctiveness for the widest possible audience.

#### V. Implementation & Governance Notes

*   **Token-Based System**: Implement colors as design tokens (e.g., `$color-status-critical`, `$color-data-category-purple`) to ensure consistency, facilitate easy changes, and manage light/dark mode adaptations centrally.
*   **Contextual Usage**: Avoid using status colors for purely decorative purposes or for general data categories to prevent false alarms or misinterpretations.
*   **Tradeoff**: Balancing the need for **distinct categorical data visualization colors** with the imperative to **prevent confusion with the fixed semantic status colors** can be challenging. This means sacrificing some potentially appealing hues for data series if they too closely resemble a warning or critical state, ensuring clarity for critical health data over aesthetic variety.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "standard",
  "decisions_committed": ["semantic_roles: defined", "state_mapping: defined", "contrast_boundary: wcag_aa_defined", "migration_strategy: dark_mode_defined"],
  "evidence_classes_cited": ["wcag_rule", "color_role_map", "contrast_boundary"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]