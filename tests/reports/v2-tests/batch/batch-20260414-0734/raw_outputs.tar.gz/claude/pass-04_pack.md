## Backend Feasibility Review: Real-Time Collaboration on REST + PostgreSQL

---

### Hidden System Requirements

Before any code changes, these dependencies must be acknowledged. Each one is a commitment, not a detail.

**Persistent bidirectional transport**
REST is request-response. Real-time collaboration requires a persistent connection — WebSocket, SSE, or a managed channel. This means a dedicated connection server (or managed service) that stays alive between edits, not a stateless HTTP handler. Your existing REST infrastructure does not cover this.

**Operational Transform or CRDT engine**
Simultaneous edits from multiple clients will conflict. You need a merge strategy with mathematical guarantees, not optimistic last-write-wins. The two credible options are Operational Transforms (OT) — used by Google Docs — and CRDTs (Conflict-free Replicated Data Types) — used by Figma and Notion. Both require a shared algorithm running identically on the client and the server. Your current REST + PostgreSQL stack has no layer for this.

**Authoritative server state**
With multiple clients writing simultaneously, PostgreSQL cannot be treated as the only authority during a live session. You need an in-memory operation log that the server can apply, rebase, and broadcast in sequence before writes are committed to the database. Skipping this means clients will diverge under concurrent edits.

**Presence and cursor state**
Cursor positions are ephemeral — they should not live in PostgreSQL. They need a fast, expiring key-value store (Redis is the standard choice) with a pub/sub channel per document. Writing cursor positions to your relational database will create write amplification that degrades performance and is structurally wrong.

**Session and document-level authorization**
REST session tokens are typically validated per-request. WebSocket connections are long-lived. You need object-level authorization — only users who have document-level read/write permission may join the collaboration channel for that document, enforced at connection time and re-checked on reconnect. A middleware that only checks "is this user authenticated" is not sufficient.

**Operation persistence and replay**
For conflict resolution to be auditable and for late-joining clients to catch up, every operation must be persisted in sequence before it is acknowledged. This requires an append-only operation log — either a separate operations table in PostgreSQL or an event store — with a monotonically increasing sequence per document.

**Merge and conflict resolution strategy**
Last-write-wins at the row level is not acceptable for collaborative text. You need an explicit conflict resolution contract: which client's version wins, under which conditions, and how diverged state is rebased. This decision must be made before implementation begins, because it shapes the operation log schema, the client merge logic, and the server broadcast sequence.

---

### Feasibility Assessment

**What your current stack handles well**

PostgreSQL can store the canonical document state, the operation log, and user permission records. Your existing REST API can handle non-realtime operations: document creation, deletion, access control, export, and history retrieval. React can run a CRDT or OT client library without architectural rework.

**Explicit blockers**

*Blocking constraint:* Your REST-only transport cannot carry real-time operations. WebSocket or SSE infrastructure must be added before any collaborative feature can function. This is not a configuration change — it requires a new connection layer.

*Blocking constraint:* PostgreSQL row-level locks will not protect against concurrent edits at the character or operation level. Without an authoritative in-memory operation sequencer, two clients editing the same paragraph simultaneously will produce irreconcilable state. Standard PostgreSQL transactions are not the right tool here.

*Blocking constraint:* Without a CRDT or OT library running consistently on both client and server, conflict resolution cannot be guaranteed to converge. Ad hoc merge logic will fail under concurrent edits and will be extremely difficult to debug or repair.

*System surface dependency:* Cursor and presence state cannot be handled by PostgreSQL alone without causing write amplification and latency problems. A fast ephemeral store (Redis or equivalent) is a real infrastructure dependency, not an optimization.

*Authorization perimeter risk:* WebSocket connections bypass your per-request REST auth middleware by default. Without explicit connection-time and reconnect-time authorization checks against document-level permissions, any authenticated user could potentially join a document channel they should not access. Object-level authorization must be enforced — not just "is the user logged in."

**What you sacrifice to gain real-time collaboration**

You gain: live multi-user editing, visible presence, and a persistent edit history that supports undo and audit.

You sacrifice: architectural simplicity. REST + PostgreSQL is a low-moving-part stack. Adding WebSockets, an operation sequencer, Redis, and a CRDT or OT engine increases operational surface area meaningfully. Each new component adds a failure mode, a deployment dependency, and an observability cost.

Rather than treating this as a single feature addition, treat it as a new subsystem that runs alongside your existing product.

---

### Safer Implementation Path

#### Phase 1 — Infrastructure and authorization foundation (do this before any visible feature work)

Add WebSocket support to your backend, using a library like `ws` with Node, or a managed service like Ably, Liveblocks, or PartyKit if you want to avoid owning the connection infrastructure yourself. Do not skip this step to shortcut to features.

Add Redis (or equivalent) for ephemeral presence and pub/sub. One Redis channel per document. Cursor positions expire after a short TTL — they are not persisted to PostgreSQL.

Enforce object-level authorization at WebSocket connection time. Only users with document-level write permission may join the collaboration channel for that document. Deny by default. Re-validate on reconnect. This is not optional — without it, your authorization perimeter is meaningfully broken.

Add an `operations` table to PostgreSQL: `document_id`, `sequence_number`, `user_id`, `operation_payload`, `applied_at`. This is your append-only operation log. It is the source of truth for audit, replay, and late-join catch-up.

**Phase 1 output:** WebSocket transport working, document channels isolated by permission, cursor presence moving through Redis, operation log schema in place. No collaborative merge logic yet.

#### Phase 2 — Operation sequencing and merge strategy

Choose your merge strategy before writing any merge code. The practical choice for most product teams:

- **Yjs** (CRDT, open source) — easier to adopt, well-supported in the React ecosystem, handles most document types with minimal custom logic. The safer default for most teams.
- **ShareDB** (OT-based) — more established for JSON documents, battle-tested, requires more careful operation schema design.

Do not build your own OT or CRDT engine. The convergence proofs are non-trivial and bugs in merge logic produce data corruption, not just visual glitches.

Integrate the chosen library on both the server (operation sequencer) and the client (local merge). The server applies and broadcasts operations in sequence. Clients apply incoming operations against their local state using the library's merge function. Every operation is persisted to the `operations` log before the server acknowledges it.

**Phase 2 output:** Multi-user editing converges correctly under concurrent edits. Operations are logged. Late-joining clients can replay from the log.

#### Phase 3 — Presence, UX, and hardening

Render cursor positions and user presence using the ephemeral Redis state, not the operation log. Cursors are cosmetic and must never block a write path.

Add reconnection logic with exponential backoff and jitter on the client. When a client reconnects, it requests operations since its last known sequence number and replays them locally before re-entering the live channel.

Add observability: a `trace_id` on all WebSocket errors, a per-document connection count metric, operation queue depth, and a divergence alert if client sequence numbers fall too far behind the server. Without this, you will have no visibility into whether the system is healthy under real load.

Define your graceful degradation path explicitly: if the WebSocket connection is lost, the client falls back to read-only mode with a visible indicator rather than silently allowing edits that will be lost or will conflict on reconnect.

**Phase 3 output:** Production-safe feature with visible presence, resilient reconnection, observable state, and a defined degraded mode.

---

### Decision That Must Be Made Before Phase 2 Starts

**CRDT (Yjs) or OT (ShareDB)?**

This shapes the operation log schema, the client library, and the server sequencing logic. Changing this mid-implementation is expensive. Yjs is the safer default for most teams because it has a larger active ecosystem, handles more document types without custom operation schema design, and the client library integrates naturally with React. ShareDB is preferable if your document model is strictly JSON-structured and your team has experience with OT semantics.

Name this decision explicitly before any merge logic is written.

[SESSION_STATE]
{
  "route": "rt_backend_feasibility_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "transport_layer: WebSocket or SSE required — REST cannot carry real-time operations",
    "merge_strategy: CRDT or OT required — last-write-wins is not acceptable",
    "presence_store: Redis required for ephemeral cursor and pub/sub state",
    "authorization_perimeter: object-level document permission enforced at WebSocket connection time",
    "operation_log: append-only operations table required before merge logic begins",
    "graceful_degradation: read-only fallback on connection loss, not silent edit loss"
  ],
  "evidence_classes_cited": [
    "blocking_constraint",
    "system_surface_dependency",
    "authorization_perimeter",
    "object_level_authorization",
    "idempotency_and_sequencing_contract",
    "async_job_model",
    "resilience_strategy",
    "observability_tax"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Has the team evaluated managed real-time services (Liveblocks, Ably, PartyKit) vs. owning WebSocket infrastructure?",
    "Is Redis already in the stack, or does it need to be provisioned as a new dependency?",
    "What is the document model — is it rich text, JSON-structured, or something else? This affects the CRDT vs. OT decision."
  ],
  "turn": 1
}
[/SESSION_STATE]