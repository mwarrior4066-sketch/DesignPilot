Tabular financial data is the shaping constraint here. It forces the type system before aesthetic preferences can enter.

---

## The governing constraint

Financial tables need **tabular (monospaced) figures** — numbers that occupy equal horizontal space so columns align regardless of digit count. Not all typefaces include this feature, and not all that claim "modern and trustworthy" actually ship it.

This filters the candidate pool before anything else.

---

## Recommended system: Inter + a pairing decision

**Primary: Inter**

Inter is the right anchor for this system because:
- Ships tabular figures as an OpenType feature (`tnum`, `lnum`)
- Covers the full weight range needed: Regular 400, Medium 500, SemiBold 600, Bold 700 — enough for dashboard hierarchy without inventing new levels
- Designed specifically for screen legibility at small sizes, which matters for dense financial UI
- Has a variable font version, which reduces HTTP requests across the marketing site, dashboard, and mobile web views
- System-level familiarity reads as "competent and stable" in fintech contexts rather than flashy — appropriate trust register
- Supported natively on most platforms, which simplifies mobile rendering

**The pairing decision**

You have two honest options:

**Option A: Inter only (recommended for most teams)**
Use Inter across all three surfaces. Marketing gets the heavier weights and larger scales. The dashboard runs medium and regular at tight leading. Mobile inherits the same scale logic. This costs you some headline personality on the marketing site, but it dramatically reduces font management complexity, licensing overhead, and the risk of a display font behaving badly at small sizes.

You sacrifice brand distinctiveness at the top of the marketing funnel. You gain system coherence, lower maintenance cost, and zero cross-surface font mismatches.

**Option B: Inter + a display pairing for marketing only**
If the marketing site needs more character, pair Inter with a humanist serif or a geometric sans at display sizes (48px and above), used only for hero headlines. Good candidates: **DM Serif Display** (warm, approachable, works with financial services), **Playfair Display** (more editorial, higher contrast), **Sohne** (premium, clean, but licensed and not free).

The pairing must be constrained to display sizes only. The display font never enters the dashboard or mobile app. If your team cannot enforce that boundary, use Option A.

---

## Scale and hierarchy

Apply one scale, adapted per surface:

| Role | Size | Weight | Feature |
|---|---|---|---|
| Dashboard label | 11–12px | 500 Medium | `tnum lnum` |
| Dashboard body / table cell | 13–14px | 400 Regular | `tnum lnum` on numbers |
| Dashboard sub-heading | 16px | 600 SemiBold | — |
| Dashboard heading | 20–24px | 700 Bold | — |
| Mobile body | 15–16px | 400 Regular | — |
| Mobile heading | 22–24px | 600–700 | — |
| Marketing body | 17–18px | 400 Regular | — |
| Marketing section heading | 32–40px | 700 | — |
| Marketing hero | 48–72px | 700 (or display font if Option B) | — |

The minimum body size on the dashboard is 13px at normal pixel density. Below that, Inter starts losing x-height advantage and financial labels become ambiguous.

Leading for table rows: 1.4 to 1.5 is the range. Tighter than 1.4 causes row bleeding on dense data. Looser than 1.55 wastes vertical space without improving readability.

---

## OpenType feature contract

For tabular data, these features must be explicitly set in CSS — they do not activate by default:

```css
.table-cell--numeric {
  font-variant-numeric: tabular-nums lining-nums;
  /* or */
  font-feature-settings: "tnum" 1, "lnum" 1;
}
```

`tnum` — tabular figures, equal horizontal advance
`lnum` — lining figures, uniform cap height (required for alignment; oldstyle figures drop below baseline)

If these are not explicitly set, columns will drift on varying digit strings. This is the most common implementation failure in fintech tables.

---

## Fallback stack

```css
font-family: "Inter", "SF Pro Text", system-ui, -apple-system, sans-serif;
```

SF Pro Text on Apple devices is an acceptable visual neighbor. `system-ui` is the floor. This stack keeps rendering coherent when Inter is not yet cached.

For the variable font, load only the axes you use. If you are not using slant, do not include it.

---

## Licensing and deployment

Inter is SIL Open Font License — free for commercial use, including SaaS products. No per-seat or per-domain fees. Self-host or load from Google Fonts (GDPR consideration applies if you are serving EU users from a third-party CDN).

---

## What this system does not solve

- If the product has a native iOS or Android app (not mobile web), type rendering is different. Inter on mobile web is fine. A native app should evaluate the system font at each OS version and only override when the product explicitly needs cross-platform visual parity.
- If the product expands to Arabic, Hebrew, or Devanagari, Inter has limited coverage. That is a separate script-extension decision, not a system failure — but plan for it before lock-in.
- Color, spacing, and contrast sit outside this recommendation. Adequate type size and weight are necessary but not sufficient for accessible financial data displays.

[SESSION_STATE]
{
  "route": "rt_type_system_recommendation",
  "escalation_level": "standard",
  "decisions_committed": [
    "reading_context: dashboard, marketing site, mobile web",
    "scale_decision: Inter variable font with explicit tnum/lnum for tabular data",
    "pairing_rationale: Option A single-family recommended; Option B display-only pairing constrained to marketing hero sizes",
    "adoption_sequence: Inter as anchor, fallback stack defined, OpenType features explicit in CSS"
  ],
  "evidence_classes_cited": [
    "threshold: 13px minimum body on dashboard",
    "threshold: leading 1.4–1.5 for table rows",
    "standard_reference: OpenType tnum lnum features",
    "constraint: tabular figures required for column alignment",
    "license: SIL OFL"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there a native mobile app (iOS/Android) or is the mobile surface web-only?",
    "Are there non-Latin script requirements (Arabic, Hebrew, Devanagari)?",
    "Has a display font for marketing already been selected, or is that still open?"
  ],
  "turn": 1
}
[/SESSION_STATE]