## Split Button Component Spec

---

### Component boundary

A split button is a single logical control composed of two interactive segments: a primary action button and a secondary trigger that opens a contextual action menu. The two segments share a visual container and a semantic relationship but are independently focusable, independently disabled, and independently keyboard-operable.

This spec covers the Save split button specifically. The pattern is reusable.

---

### Anatomy

| Part | Role | Notes |
|---|---|---|
| Primary segment | `<button>` | Executes Save directly |
| Divider | `aria-hidden` decorative rule | Visual separator only, not interactive |
| Trigger segment | `<button>` | Opens the dropdown menu; does not save |
| Dropdown menu | `role="menu"` | Contains secondary actions |
| Menu item: Save as draft | `role="menuitem"` | |
| Menu item: Save and close | `role="menuitem"` | |

The two buttons are siblings inside a wrapping `<div role="group" aria-label="Save options">`. The group role associates them semantically without implying a single control.

---

### Variants and sizes

| Variant | Use case |
|---|---|
| Default | Standard form save context |
| Destructive | Reserved for future — not applicable to Save |
| Disabled (full) | Both segments non-interactive |
| Disabled (primary only) | Trigger still available; save blocked |
| Disabled (trigger only) | Save available; secondary options unavailable |
| Loading (primary) | Save in progress |
| Loading (trigger) | Not used — the trigger itself does not execute async work |

Sizes follow the existing button token scale. The trigger segment is narrower than the primary segment; it contains only the chevron icon plus its touch-safe padding.

---

### States

#### Primary segment states

| State | Visual | Behavior |
|---|---|---|
| Default | Brand fill, label visible | Executes Save on click or Enter/Space |
| Hover | 10–15% darkened fill | — |
| Focus-visible | 2px offset focus ring | Keyboard-visible only |
| Active | Pressed state | Momentary |
| Loading | Spinner replaces label; button width locked | Segment disabled during request; trigger also disabled while loading |
| Disabled | 40% opacity, `not-allowed` cursor | `aria-disabled="true"`; no pointer or keyboard events |
| Success (transient) | Optional checkmark flash, max 1.5s | Returns to default; only use if the save is not immediately confirmed elsewhere |

#### Trigger segment states

| State | Visual | Behavior |
|---|---|---|
| Default | Chevron icon, matches primary fill | Opens menu on click, Enter, Space, or ArrowDown |
| Hover | Same darkened fill as primary | — |
| Focus-visible | 2px offset focus ring, independent of primary | — |
| Open | Chevron rotates 180° | `aria-expanded="true"` on the trigger button |
| Disabled | Same opacity treatment as primary | `aria-disabled="true"` |

Loading state on the primary segment disables the trigger automatically. You are saving. The menu is not meaningful mid-request.

---

### Accessibility behavior

#### ARIA contract

```
<div role="group" aria-label="Save options">
  <button type="submit" id="btn-save">Save</button>
  <button
    type="button"
    id="btn-save-trigger"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="save-menu"
    aria-label="More save options"
  >
    <svg aria-hidden="true" focusable="false"><!-- chevron --></svg>
  </button>
  <ul role="menu" id="save-menu" aria-labelledby="btn-save-trigger">
    <li role="none">
      <button role="menuitem">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem">Save and close</button>
    </li>
  </ul>
</div>
```

`aria-label="More save options"` on the trigger prevents screen readers from announcing an unlabeled chevron button. Without it, VoiceOver announces "button" with no context.

#### Focus behavior

- Tab moves focus to the primary segment.
- A second Tab press moves focus to the trigger segment.
- Tab from the trigger (menu closed) exits the component entirely.
- When the menu is open, Tab closes the menu and moves focus forward past the component. The user does not tab through menu items.

#### Keyboard map

| Key | Focus location | Action |
|---|---|---|
| Enter / Space | Primary segment | Executes Save |
| Enter / Space | Trigger segment | Opens menu; focus moves to first menu item |
| ArrowDown | Trigger segment | Opens menu; focus moves to first menu item |
| ArrowDown | Menu item | Moves to next item; wraps to first at bottom |
| ArrowUp | Menu item | Moves to previous item; wraps to last at top |
| Escape | Any menu item | Closes menu; focus returns to trigger segment |
| Enter / Space | Menu item | Executes action; closes menu; focus returns to trigger segment |
| Tab | Menu item | Closes menu; focus exits component |

This follows the ARIA Authoring Practices Guide menu button pattern. Deviating from it breaks established screen reader conventions without providing a measurable benefit.

---

### Disabled state rules

Three independent disabled configurations exist because context determines which is appropriate.

**Full disable** (`disabled-full`): Set `aria-disabled="true"` and `tabindex="-1"` on both segments. Add a tooltip or helper text explaining why saving is unavailable. Do not rely on color alone to communicate the disabled state.

**Primary-only disable**: Only the primary segment carries `aria-disabled="true"`. The trigger remains operable. This is appropriate when Save is blocked by validation but Save as draft remains allowed.

**Trigger-only disable**: Only the trigger carries `aria-disabled="true"`. The primary Save is available; secondary options are not. This may apply when the current context produces only one valid save destination.

Use `aria-disabled="true"` rather than the native `disabled` attribute when you need the element to remain focusable and reachable by keyboard. Native `disabled` removes the element from tab order entirely, which causes disorientation on dynamic form pages where the button toggles back to enabled.

---

### Loading state rules

Loading applies only to the primary segment. The pattern:

1. On click: lock primary segment width to its current rendered width (prevents layout shift as the spinner replaces the label).
2. Replace label with a spinner (`role="status"` on a visually hidden sibling: `<span class="sr-only" aria-live="polite">Saving...</span>`).
3. Set `aria-disabled="true"` on both segments.
4. On resolution: restore label, remove `aria-disabled`, optionally flash success indicator for no more than 1.5 seconds.

Width-locking is necessary because a spinner is narrower than the word "Save." Without it, the button visibly collapses and shifts adjacent layout on every save action.

---

### Touch targets

Minimum touch target: 44 × 44px (WCAG 2.5.5 AAA target; WCAG 2.5.8 AA minimum is 24 × 24px with adequate spacing, but 44px is the safer production floor for a primary action control).

The primary segment will naturally meet this threshold if it carries standard button padding. The trigger segment is the risk. It is visually narrow because it contains only the chevron icon.

Two compliant approaches:

**Option A — Extend hit area with padding:** Add `padding-inline: 12px` or greater to the trigger so the rendered height and width clear 44px. The visual appearance can remain compact if the outer padding is transparent.

**Option B — Use `min-width: 44px` on the trigger:** Slightly widens the visual trigger, which is acceptable and typically the cleaner implementation.

Do not use a pseudo-element overlap to secretly extend the hit area into the primary segment's space. It creates overlapping interactive regions and breaks touch disambiguation.

On mobile viewports, consider whether the split button should simplify to a single Save button with an overflow sheet rather than maintaining the split form. The dropdown menu pattern works on touch but introduces a two-tap cost for secondary actions. This is worth a usability tradeoff decision per product context.

---

### Component token contracts

```
--split-btn-height: 40px (desktop) / 48px (mobile override)
--split-btn-primary-padding-inline: 16px
--split-btn-trigger-min-width: 44px
--split-btn-trigger-padding-inline: 12px
--split-btn-radius: var(--radius-sm)
--split-btn-divider-color: color-mix(in srgb, var(--color-btn-fg) 30%, transparent)
--split-btn-focus-ring-width: 2px
--split-btn-focus-ring-offset: 2px
--split-btn-focus-ring-color: var(--color-focus)
--split-btn-disabled-opacity: 0.4
--split-btn-loading-spinner-size: 16px
```

The divider uses `color-mix` to derive from the foreground token rather than introducing a separate color decision. This keeps it compliant in dark mode and high-contrast modes without explicit overrides.

---

### Implementation boundary

What this spec owns:
- Structure, ARIA contract, keyboard behavior, state model, token interface.

What this spec does not own:
- The menu positioning logic (owned by the overlay/popover system).
- The icon asset for the chevron (owned by the icon library).
- The spinner asset (owned by the loading indicator component).
- The `aria-live` region strategy for async feedback beyond the loading state (owned by the notification or toast system).
- Form submission behavior of the primary segment (owned by the form or page-level handler).

The split button component is responsible for its own state transitions and ARIA contract. It is not responsible for what happens after the action is dispatched.

---

### Tradeoffs named

**Two tab stops vs. one:** A single-tab composite control is possible using `roving tabindex`, but it sacrifices keyboard discoverability because the trigger becomes invisible to linear navigation unless the user knows to press ArrowDown. Two tab stops are accepted here to gain explicit, predictable keyboard access to both segments.

**Full-disable with `aria-disabled` vs. native `disabled`:** `aria-disabled` keeps the element in tab order and allows tooltip or context delivery to keyboard users. The cost is that you must also block pointer and keyboard event handlers manually. Native `disabled` is simpler but removes the element from the accessibility tree in ways that break context for dynamic forms.

**44px touch target on the trigger via padding vs. visual expansion:** Padding extension preserves the visual compactness of the chevron segment. The cost is that the invisible tap zone may surprise developers inspecting the DOM. Document it in the token comment.

[SESSION_STATE]
{
  "route": "rt_component_spec",
  "escalation_level": "standard",
  "decisions_committed": [
    "component_boundary: split button = primary segment + trigger segment + dropdown menu, independently operable",
    "state_coverage: default, hover, focus-visible, active, loading, disabled-full, disabled-primary-only, disabled-trigger-only, open",
    "accessibility_behavior: ARIA group + menu button pattern, two tab stops, roving ArrowDown in menu, Escape returns focus to trigger",
    "implementation_boundary: component owns ARIA contract and state transitions; does not own overlay positioning, icon assets, spinner asset, form submission, or async notification"
  ],
  "evidence_classes_cited": [
    "WCAG 2.5.5 AAA 44px touch target",
    "WCAG 2.5.8 AA 24px minimum",
    "ARIA APG menu button pattern",
    "aria-disabled vs native disabled tab-order behavior"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Should the split button collapse to a single Save + overflow sheet on mobile viewports? Depends on product context."
  ],
  "turn": 1
}
[/SESSION_STATE]