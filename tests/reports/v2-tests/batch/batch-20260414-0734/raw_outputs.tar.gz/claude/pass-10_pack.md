## Poster critique

The hierarchy problem you named is real, and it compounds with the other choices. Here is what is failing and why, with a rebuild direction.

---

### Hierarchy failure

A decorative title at the top asks the reader to invest in a name before they know the category, the audience, or the reason to care. Conference posters succeed when the scan order is: **what is this** → **who it is for** → **when and where** → **name/brand**.

Your current order is roughly: name → logo (buried) → date (invisible).

The "what is this" layer is missing entirely. There is no descriptor, tagline, or category signal. First-time viewers cannot determine whether this is a music event, an art exhibition, or a design conference without already knowing the brand.

---

### Logo placement and contrast failure

Centering the white logo over a full-bleed city skyline photo creates a contrast problem that shifts by content zone. A white mark over a bright sky area becomes invisible. Over darker building silhouettes it reads, but only conditionally. Conditional legibility is not legibility.

Placing identity in the center also fractures the composition. The eye moves to center, finds a logo with no supporting information, and has nowhere to go. The logo earns center position when it is surrounded by elements that give it scale and hierarchy context. Here it floats.

---

### Date legibility

Small gray text in a corner over a photo is the most common poster mistake. Gray on a complex photographic background produces unpredictable contrast. The date is arguably the most action-driving piece of information on the poster: it determines whether anyone can attend. It should not be the hardest thing to read.

---

### Background photo

A city skyline is visually busy in exactly the zones where you need clear text areas. Skylines also do not carry a specific meaning for a design conference. The photo's job is to create atmosphere and location signal. If it is doing location work, it needs a clear compositional zone that stays dark or light enough to hold text reliably. If it is doing atmosphere work only, it needs to be toned down enough to function as texture rather than competing imagery.

Right now it is doing neither job cleanly because no text zone has been cleared for it.

---

### Decorative typeface

Decorative type at large scale for an event title is defensible, but only when contrast and a cleared background make it legible at a distance. On a photo background, a decorative typeface adds stroke variation and irregular counters that fight the image detail beneath it. At distance, it dissolves before a clean sans would.

---

### Rebuild direction

The core move is to **separate information layers from image layers** rather than stacking them all in the same plane.

One approach: treat the bottom third as a solid or gradient panel in a brand color, anchor the date, descriptor, and logo there, and reserve the image for the upper portion as atmosphere only. This clears contrast problems, creates a readable information zone, and lets the photo do visual work without competing with type.

Hierarchy within the cleared zone should run: **descriptor or tagline** (what this is) → **title** (the event name) → **date and location** → **logo**. The title can still use the decorative face, now with a surface that supports it.

The logo does not belong in the center of a poster where it competes with the title. Anchor it at the bottom with the event details or top-left as a small identity mark. Let the title be the visual hero.

---

### What this preserves vs. what you sacrifice

Separating image from text zone **preserves the photo's atmospheric value and the decorative type** while gaining reliable legibility at distance. You sacrifice the "full-bleed at all costs" look. Full-bleed only works when the image is low-contrast enough to hold text, or the text is large and bold enough to overpower it. Neither is true here.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "communication_goal: event identity and attendance conversion",
    "hierarchy_failure: title before category context, date buried, logo floating without anchor",
    "rebuild_move: separate image and text layers, cleared panel for information zone",
    "distance_tradeoff: decorative type trades distance legibility for character at scale"
  ],
  "evidence_classes_cited": ["hierarchy_scan_order", "contrast_threshold", "distance_legibility", "composition_zone_logic"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the city skyline tied to the conference location, or is it generic atmosphere?",
    "Is there a brand color system to draw the information panel from?",
    "What is the primary display context — print, digital, or both?"
  ],
  "turn": 1
}
[/SESSION_STATE]