# Backend Architecture Spec: Multi-Tenant Scheduling Platform

---

## Governing route and scope

This is a compound backend systems architecture task. The governing route is `backend_architecture_spec`, supported by `api_reliability_security_expert` for webhook delivery contracts and idempotency, and `back_end_aware_planner` for feasibility sequencing. The evidence burden sits with the architecture spec throughout.

The existing REST + relational foundation is preserved. What changes: authority model, consistency stance, data delivery contracts, eventing backbone, and observability tax. You sacrifice development velocity in the short term to gain correctness, regional compliance, and automation extensibility you cannot retrofit cheaply later.

---

## 1. Authority model

### Tenant isolation as a first-class boundary

Multi-tenancy is not a filter — it is a structural guarantee. Every data read, write, event emission, and webhook delivery must be scoped to a tenant before any other logic runs.

**Row-level security (RLS) as the enforcement layer.** Your relational database enforces tenant isolation via RLS policies keyed to `tenant_id`. Application-level filtering is insufficient: one missing `WHERE tenant_id = ?` clause produces a cross-tenant data leak. RLS makes that failure structurally impossible rather than discipline-dependent.

```sql
-- Every table inheriting this policy cannot return rows for the wrong tenant
CREATE POLICY tenant_isolation ON schedules
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

Set `app.tenant_id` on the session at connection time in your API middleware, before any query runs. Deny by default: if the setting is absent, no rows are returned.

**Regional data residency.** Tenant records carry a `home_region` field. A routing layer (API gateway or thin router service) maps incoming requests to the correct regional deployment before the request reaches application logic. Regional deployments share no storage with each other. Cross-region calls are prohibited except for control-plane operations (billing, provisioning, global audit aggregation), and those must be explicitly declared and audited.

```
tenant table
  id            uuid PK
  home_region   enum('us-east', 'eu-west', 'ap-southeast', ...)
  plan_tier     enum
  created_at    timestamptz
```

### Authorization perimeter

Authorization is object-level, not just role-level. BOLA (broken object-level authorization) is the primary API vulnerability class here because workspaces, schedules, and approval workflows all have nested ownership.

```
Only [workspace_member] may read a workspace resource.
Only [workspace_admin] may modify workspace membership.
Only [approver_role] may resolve an approval request.
Only the [session owner or workspace_admin] may view audit entries.
```

Implement authorization as a reusable middleware layer that accepts `(actor, action, resource_id, tenant_id)` and resolves against your permission model before handler logic runs. Do not scatter `if user.role == 'admin'` checks through handlers.

---

## 2. Core services

Define service boundaries by data ownership and mutation authority, not by team convenience. Services that share a write path will produce coupling you cannot untangle.

### 2a. Scheduling service

**Owns:** schedules, schedule versions, slots, recurrence rules, booking state.

**Writes:** schedule CRUD, slot reservation, conflict detection, recurrence expansion.

**Does not:** send notifications, resolve approvals, or emit webhooks directly. It publishes domain events. Downstream services own reactions.

**Conflict detection must be serializable.** Slot reservation under concurrent load requires a database-level lock or a serializable isolation level for the conflict check + insert transaction. Optimistic locking on `version` columns is insufficient for double-booking prevention.

```sql
-- Pessimistic lock on slot during reservation
SELECT * FROM slots WHERE id = $1 FOR UPDATE;
-- Then check + insert in the same transaction
```

### 2b. Team workspace service

**Owns:** workspaces, workspace members, roles, invitations, workspace settings.

**Writes:** member provisioning, role assignment, invitation lifecycle.

**Key constraint:** workspace membership changes must produce audit events synchronously within the same transaction that commits the membership change. This cannot be an afterthought. Use transactional outbox (see section 4) to guarantee the audit event is never lost.

### 2c. Approval workflow service

**Owns:** approval requests, approval steps, approver assignments, resolution state, escalation rules.

**Writes:** request creation, step resolution, escalation triggers, terminal state transitions.

**State machine contract:**

```
pending_review
  → approved (by required approver)
  → rejected (by required approver)
  → escalated (by timer or rule)
  → expired (by deadline)
  → withdrawn (by requestor with permission)
```

All state transitions are append-only in the `approval_events` table. The current state is derived or materialized, never mutated directly. This gives you an inherent audit trail without a separate audit write.

**Approval steps are ordered.** A multi-step workflow must complete step N before step N+1 begins. The service enforces this sequencing; callers cannot skip steps.

### 2d. Activity feed service

**Owns:** activity events, feed cursors, feed subscriptions.

**Writes:** none — this service is append-only from its consumers' perspective. It reads from the event store and materializes a per-workspace, per-user feed.

**Cursor-based pagination contract:**

```
GET /workspaces/{id}/activity?cursor={opaque_cursor}&limit=50

Response:
{
  "items": [...],
  "next_cursor": "eyJ0cyI6MTcwMDAwMDAwMCwiaWQiOiJ1dWlkIn0=",  // base64 JSON: {ts, id}
  "has_more": true
}
```

The cursor encodes `(created_at, event_id)` as a composite key. This handles ties at the same timestamp without skipping events. Offset-based pagination is prohibited because it is unstable under concurrent inserts.

**Feed fanout strategy.** For most tenants, pull-on-read is sufficient: the feed query runs on demand against the indexed event store. Only when a workspace has extremely high event volume (configurable threshold) does push-fanout to per-user materialized feeds become warranted. Do not optimize prematurely. The cost of this approach at low volume is a query that scans a bounded index range. Under load with large workspaces this degrades: plan the threshold and the fanout path now, activate it later.

### 2e. Webhook delivery service

**Owns:** webhook endpoint registration, delivery attempts, delivery logs, retry state, signing keys.

**Writes:** endpoint CRUD, delivery scheduling, attempt records.

**This is the highest-risk service for customer trust.** A missed delivery is a broken integration. An unreliable delivery order is a broken integration. A delivery without a verifiable signature is a security problem.

Full contract in section 5.

### 2f. Audit service

**Owns:** immutable audit log, audit query API, retention rules.

**Writes:** append-only from other services via the event bus. No service writes directly to the audit log via direct DB call.

**Immutability guarantee.** Audit rows have no `UPDATE` path. The database user that owns the audit table has `INSERT` and `SELECT` but not `UPDATE` or `DELETE`. Retention-based deletion runs via a separate privileged job with explicit audit of the deletion itself.

**Regional note.** Audit data lives in the tenant's home region. Global audit aggregation for compliance reporting runs as a control-plane operation with explicit cross-region read authority, logged separately.

### 2g. Automation rules service (future, design now)

**Owns:** rule definitions, trigger subscriptions, action templates, rule execution history.

**Do not build this now. Design the contracts now.**

The event bus schema and the approval workflow state machine must accommodate automation triggers from day one, or you will face a schema migration under live customer automations later. Every domain event published to the bus must include enough context for a rule evaluator to act on it without a secondary API call. Define `event_schema_version` on every event type now.

---

## 3. Data boundaries

### Ownership rules

No service reads another service's primary tables directly. All cross-service reads go through the owning service's API or a shared read model populated by events.

```
Scheduling service  →  owns schedules, slots
Workspace service   →  owns workspaces, members
Approval service    →  owns approval_requests, approval_events
Activity service    →  owns feed materialization (reads from event store)
Webhook service     →  owns endpoints, delivery_attempts
Audit service       →  owns audit_log (append-only)
```

If the scheduling service needs to know whether an actor is a workspace member, it calls the workspace service's authorization endpoint or resolves against a cached membership claim in the JWT. It does not join against the workspace service's tables.

### Shared data contracts

Tables shared across services are read-only projections, not mutable shared state. The only true shared primitives are:

- `tenants` table — owned by the provisioning/control plane
- `users` table — owned by the identity layer
- Domain event schema definitions — owned by this spec

### Schema versioning

Every table has:
```sql
created_at   timestamptz NOT NULL DEFAULT now()
updated_at   timestamptz NOT NULL DEFAULT now()
schema_version  integer NOT NULL DEFAULT 1
```

Domain events add:
```json
{ "event_schema_version": 1, "event_type": "schedule.slot_reserved", ... }
```

When you introduce a breaking change to an event schema, increment the version and maintain a consumer-side migration handler for the old version until all consumers are updated. Never silently change the shape of a published event.

---

## 4. Eventing backbone

### Problem with the current state

Background jobs and eventing are inconsistent — meaning some side effects are fire-and-forget HTTP calls, some are synchronous DB writes, and some are queued jobs with no delivery guarantee. This is the central architectural liability. It means audit events can be lost, webhooks can be skipped, and approval escalations can silently fail.

The fix is a single eventing pattern enforced across all services: transactional outbox.

### Transactional outbox pattern

Every service that produces a domain event writes the event to an `outbox` table within the same database transaction as the primary write. A separate relay process reads unpublished outbox rows and publishes them to the message bus. The relay marks rows as published only after the bus confirms receipt.

```sql
CREATE TABLE outbox_events (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL,
  aggregate_id  uuid NOT NULL,
  event_type    text NOT NULL,
  event_schema_version integer NOT NULL DEFAULT 1,
  payload       jsonb NOT NULL,
  published_at  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);
```

**Why this matters:** if your application crashes after committing a schedule reservation but before dispatching the event, the outbox row survives. The relay picks it up on restart. No event is lost because an in-memory dispatch failed.

**The relay is at-least-once, not exactly-once.** Consumers must be idempotent. Every consumer that handles a domain event must check `event_id` against a processed-events table before acting, and commit the processed-events write in the same transaction as the effect. This is the deduplication contract.

### Message bus topology

```
domain_events exchange (fanout per tenant_region)
  ├── audit_log_queue          (audit service)
  ├── activity_feed_queue      (activity service)
  ├── approval_triggers_queue  (approval service)
  ├── webhook_dispatch_queue   (webhook delivery service)
  └── automation_rules_queue   (future — subscribe now, handle later)
```

Use a durable message bus (RabbitMQ with persistent queues, or a managed alternative like SQS + SNS, or Kafka if event retention and replay matter). The specific technology is less important than the contract: durable, at-least-once, consumer-idempotent.

### Event schema example

```json
{
  "event_id": "01HQZ3K8...",
  "event_type": "schedule.slot_reserved",
  "event_schema_version": 1,
  "tenant_id": "tenant-uuid",
  "workspace_id": "workspace-uuid",
  "actor_id": "user-uuid",
  "occurred_at": "2025-05-12T14:00:00Z",
  "aggregate_id": "slot-uuid",
  "aggregate_type": "slot",
  "payload": {
    "schedule_id": "...",
    "slot_id": "...",
    "booked_by": "...",
    "starts_at": "...",
    "ends_at": "..."
  },
  "correlation_id": "request-trace-id"
}
```

All fields after `payload` are envelope-level and must never be omitted. Consumers may not assume payload shape without checking `event_schema_version`.

---

## 5. Webhook delivery contracts

### Delivery model

Webhooks are asynchronous and unreliable by nature. The service must treat each delivery as a job with terminal states, not a fire-and-forget HTTP call.

**Job lifecycle:**

```
queued → attempting → delivered
                   → failed (retriable)
                   → dead (max retries exhausted)
```

The customer sees `delivered` or `dead`. Your operations team sees all intermediate state.

### Retry strategy

Exponential backoff with jitter. Do not use fixed-interval retries — they produce thundering-herd behavior on recovering customer endpoints.

```
Attempt 1:  immediate
Attempt 2:  30s ± jitter
Attempt 3:  2m ± jitter
Attempt 4:  10m ± jitter
Attempt 5:  1h ± jitter
Attempt 6+: max 6h ± jitter
Max retries: 10
After max:  mark dead, emit dead_letter event, notify workspace admin
```

Circuit breaker per endpoint: if N consecutive deliveries to the same endpoint fail, open the circuit and stop attempting until the endpoint is manually re-enabled or a health probe succeeds. This prevents your infrastructure from hammering a customer's broken endpoint indefinitely.

### Signature contract

Every outbound webhook payload is signed. Customers verify the signature to confirm the payload came from your system and was not tampered with.

```
Header: X-Signature-256: sha256=<hmac_hex>
Header: X-Delivery-Id: <uuid>
Header: X-Event-Type: schedule.slot_reserved
Header: X-Timestamp: <unix_epoch>

Signature input: X-Timestamp + "." + raw_request_body
HMAC key: per-endpoint signing secret (stored encrypted, rotatable)
```

Customers should reject payloads where `X-Timestamp` is more than 5 minutes old, to prevent replay attacks. Document this requirement explicitly.

### Idempotency contract

Every delivery has a stable `delivery_id`. If a customer's endpoint returns a non-2xx response but the payload was in fact processed (network timeout case), the next retry delivers the same `delivery_id`. Customers must deduplicate on `delivery_id`, not on payload content.

```
409 on duplicate: if a customer's system returns 409 for a duplicate delivery_id,
treat this as successful delivery — not a failure requiring retry.
```

### Delivery log

```sql
CREATE TABLE webhook_delivery_attempts (
  id               uuid PRIMARY KEY,
  endpoint_id      uuid NOT NULL REFERENCES webhook_endpoints(id),
  delivery_id      uuid NOT NULL,
  event_type       text NOT NULL,
  payload_hash     text NOT NULL,
  attempt_number   integer NOT NULL,
  http_status      integer,
  response_body    text,
  attempted_at     timestamptz NOT NULL,
  duration_ms      integer,
  outcome          enum('delivered','failed','timeout','circuit_open')
);
```

Retain delivery logs for 30 days. Expose the last 100 delivery attempts per endpoint in the customer-facing UI. This is the primary debugging surface for broken integrations.

---

## 6. Audit trail

### What must be audited

At minimum, every event in this list must produce an immutable audit record:

```
auth:     login, logout, token issued, token revoked, MFA change
iam:      member added, member removed, role changed, invitation sent
data:     schedule created/updated/deleted, slot reserved/cancelled
approval: request created, step resolved, escalation triggered, outcome
webhook:  endpoint registered, secret rotated, delivery dead-lettered
admin:    tenant settings changed, data export requested, region changed
automation: rule created, rule fired, rule disabled (future)
```

### Audit record schema

```sql
CREATE TABLE audit_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL,
  workspace_id  uuid,
  actor_id      uuid,
  actor_type    enum