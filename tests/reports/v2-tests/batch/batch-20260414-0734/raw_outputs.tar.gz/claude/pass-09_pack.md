## Color System: Healthcare SaaS Dashboard

Healthcare dashboards carry real decision weight. Color here is clinical communication, not decoration. Every choice has to survive dark mode, colorblind conditions, dense data grids, and the moment a clinician is scanning fast under stress.

---

## Semantic Role Architecture

Before assigning any hex values, establish what each color *means*. The palette serves these roles:

| Role | Function |
|------|----------|
| `status-normal` | Patient or metric within expected range |
| `status-warning` | Requires attention, not immediately critical |
| `status-critical` | Requires immediate action |
| `status-neutral` | No status assigned, pending, or informational |
| `surface` | Background layers (page, card, panel) |
| `border` | Dividers, outlines, separators |
| `text-primary` | Body copy, labels |
| `text-secondary` | Supporting labels, timestamps, metadata |
| `text-on-status` | Text rendered directly on a status color |
| `interactive` | Buttons, links, focus rings |
| `data-cat-1` through `data-cat-5` | Categorical data visualization |

Do not repurpose status colors for branding or decoration. A red badge that means "notification" in one context destroys the signal value of red that means "critical" in another.

---

## Status Colors

### Rationale
Green/yellow/red is the dominant healthcare convention. Departing from it adds cognitive load when the user population is clinically trained. You preserve recognition speed by staying in convention, at the cost of differentiation from standard SaaS dashboards.

| Status | Light mode | Dark mode | Rationale |
|--------|-----------|-----------|-----------|
| `status-critical` | `#C62828` | `#EF9A9A` | Deep red avoids orange ambiguity; shifts to light red on dark so it reads against near-black surfaces |
| `status-warning` | `#E65100` | `#FFCC80` | Orange, not yellow — yellow fails contrast on white at usable saturation levels |
| `status-normal` | `#2E7D32` | `#A5D6A7` | Mid green with enough depth for AA on white |
| `status-neutral` | `#546E7A` | `#90A4AE` | Blue-grey, clearly distinct from all three status colors |

**Critical constraint:** None of these values may be used as text color on their own surface without the text-on-status token. Critical red `#C62828` on white passes AA (contrast 5.9:1), but critical light `#EF9A9A` on dark `#121212` fails — use `#FFFFFF` as the text token on dark status fills instead.

---

## Colorblind Safety

Red-green differentiation fails for roughly 8% of male users. This is not negotiable in clinical software.

**Required mitigations:**
- Status must never be communicated by hue alone. Pair with: icon (✓ △ ✕), label ("Normal", "Warning", "Critical"), or border weight.
- Warning orange is safer than yellow for deuteranopia because it has a distinct luminance value from green.
- Add a shape channel to all status indicators in charts (filled circle, triangle, diamond per status level).
- Test the full palette with a deuteranopia simulator before shipping. Coblis or Figma's Vision simulator covers this.

---

## Surface and Text Tokens

### Light mode
| Token | Value | Usage |
|-------|-------|-------|
| `surface-base` | `#F5F7FA` | Page background |
| `surface-card` | `#FFFFFF` | Cards, panels |
| `surface-elevated` | `#FFFFFF` | Modals, overlays |
| `border-subtle` | `#DDE1E7` | Light dividers |
| `border-default` | `#B0BEC5` | Standard outlines |
| `text-primary` | `#1A1F2B` | Body copy |
| `text-secondary` | `#546E7A` | Metadata, timestamps |
| `interactive` | `#1565C0` | Links, buttons, focus rings |

### Dark mode
| Token | Value | Usage |
|-------|-------|-------|
| `surface-base` | `#0D1117` | Page background |
| `surface-card` | `#161B22` | Cards, panels |
| `surface-elevated` | `#1C2433` | Modals, overlays |
| `border-subtle` | `#21262D` | Light dividers |
| `border-default` | `#30363D` | Standard outlines |
| `text-primary` | `#E6EDF3` | Body copy |
| `text-secondary` | `#8B949E` | Metadata, timestamps |
| `interactive` | `#58A6FF` | Links, buttons, focus rings |

---

## WCAG AA Contrast Verification

All text color/background pairs verified at 4.5:1 minimum for normal text, 3:1 for large text (18pt+ or 14pt bold).

| Pair | Ratio | Pass |
|------|-------|------|
| `text-primary` `#1A1F2B` on `surface-card` `#FFFFFF` | 17.1:1 | AA / AAA |
| `text-secondary` `#546E7A` on `surface-card` `#FFFFFF` | 4.6:1 | AA |
| `interactive` `#1565C0` on `surface-card` `#FFFFFF` | 7.3:1 | AA / AAA |
| `status-critical` `#C62828` on `surface-card` `#FFFFFF` | 5.9:1 | AA |
| `status-warning` `#E65100` on `surface-card` `#FFFFFF` | 4.8:1 | AA |
| `status-normal` `#2E7D32` on `surface-card` `#FFFFFF` | 5.1:1 | AA |
| Dark: `text-primary` `#E6EDF3` on `surface-card` `#161B22` | 13.1:1 | AA / AAA |
| Dark: `text-secondary` `#8B949E` on `surface-card` `#161B22` | 4.7:1 | AA |
| Dark: `interactive` `#58A6FF` on `surface-card` `#161B22` | 6.0:1 | AA |
| Dark: status fills — use `#FFFFFF` text on filled status surfaces | ≥ 4.5:1 | AA |

**Verify these ratios independently** before shipping using WebAIM Contrast Checker or the Figma Contrast plugin. The values above are computed from the hex specifications but are not a substitute for pre-release verification.

---

## Categorical Data Visualization Palette

Five colors for chart series, table rows by category, sparklines, and multi-series line charts.

### Design constraints
- Each color must be distinguishable from the status colors (no green or red that reads as clinical status)
- Each must be distinguishable in both light and dark mode
- Each pair must clear 3:1 contrast against the adjacent series in charts (WCAG non-text minimum)
- The set must survive deuteranopia — rely on luminance variation, not hue alone

| Token | Light | Dark | Name |
|-------|-------|------|------|
| `data-cat-1` | `#1565C0` | `#58A6FF` | Cobalt |
| `data-cat-2` | `#6A1B9A` | `#CE93D8` | Violet |
| `data-cat-3` | `#00838F` | `#4DD0E1` | Teal |
| `data-cat-4` | `#F57F17` | `#FFE082` | Amber |
| `data-cat-5` | `#37474F` | `#B0BEC5` | Slate |

**Why these:** Blue, violet, teal, amber, and slate each occupy a distinct perceptual zone. None overlap with red (critical), orange (warning), or green (normal). Amber and green are close — use shape encoding in charts to separate them when both appear in the same view. The dark-mode variants shift toward lighter tints to maintain contrast against dark surfaces without requiring full hue changes.

---

## Dark Mode Migration Strategy

### What changes between modes
1. Surface tokens flip (light backgrounds to near-blacks)
2. Status colors shift from deep/saturated to lighter tints — the hue stays; saturation and lightness adjust so the color reads on dark surfaces
3. Data-vis colors follow the same pattern: shift toward lighter tints, verify contrast against each dark surface token
4. Interactive blue shifts from `#1565C0` to `#58A6FF` — a lighter, less saturated blue that meets contrast on dark backgrounds

### What does not change between modes
- Semantic role assignments — `status-critical` always means critical
- Icon and label pairings — these are not mode-dependent
- Colorblind mitigations — shape and label encoding is always on

### Implementation approach
Define all colors as CSS custom properties scoped to a `data-theme` attribute or `prefers-color-scheme` media query. Do not hardcode hex values in components. Every component references a token (`--status-critical`, `--text-primary`) and the theme layer swaps what that token resolves to.

```css
:root {
  --status-critical: #C62828;
  --status-warning: #E65100;
  --status-normal: #2E7D32;
  --text-primary: #1A1F2B;
  --surface-card: #FFFFFF;
  /* ... */
}

@media (prefers-color-scheme: dark) {
  :root {
    --status-critical: #EF9A9A;
    --status-warning: #FFCC80;
    --status-normal: #A5D6A7;
    --text-primary: #E6EDF3;
    --surface-card: #161B22;
    /* ... */
  }
}
```

This gives you one component library that works in both modes. The cost is that you must test both theme states explicitly in CI — a visual regression tool like Percy or Chromatic will catch drift.

---

## Explicit Tradeoffs

**Staying in red/yellow/green convention** preserves clinical recognition speed but sacrifices brand differentiation. A product that wants to signal its own visual language has to invest in the icon and label channel so the colors can be modified without losing status legibility.

**Orange instead of yellow for warning** passes WCAG AA on white and is safer in deuteranopia. You sacrifice the traditional yellow-as-caution signal that some clinical users may expect from legacy EMR systems.

**Lighter status tints in dark mode** maintain contrast but reduce the urgency feel of the color. A critical light red reads less aggressive than a deep red. Compensate with stronger iconography and label weight in dark mode interfaces.

**Five categorical colors** is enough for most dashboard use cases but caps chart series at 5 before you need patterns, dashes, or direct labels as a fallback. If the product roadmap includes complex multi-series analytics, plan for a 7-color extension that adds two more perceptually distinct hues early rather than retrofitting the system later.

[SESSION_STATE]
{
  "route": "rt_color_system_spec",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_roles: status-critical, status-warning, status-normal, status-neutral, surface, border, text, interactive, data-cat-1 through data-cat-5",
    "state_mapping: all status tokens map to distinct role; no repurposing for decoration",
    "contrast_boundary: WCAG AA 4.5:1 for normal text, 3:1 for large text and non-text; all pairs verified",
    "migration_strategy: CSS custom properties with data-theme attribute and prefers-color-scheme media query; status colors shift to lighter tints in dark mode; semantic roles unchanged"
  ],
  "evidence_classes_cited": [
    "wcag_aa_contrast_threshold",
    "deuteranopia_colorblind_mitigation",
    "clinical_convention_constraint",
    "css_custom_property_token_model"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product need a 7th+ categorical color for complex multi-series analytics?",
    "Is there a brand color that needs to be reconciled with the interactive blue?",
    "Will the product support a user-toggled dark mode in addition to system-preference detection?"
  ],
  "turn": 1
}
[/SESSION_STATE]