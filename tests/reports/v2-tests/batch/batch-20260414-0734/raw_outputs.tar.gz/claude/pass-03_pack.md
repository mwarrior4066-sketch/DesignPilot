## Dashboard audit

### Dashboard role

This is a monitoring dashboard, not an analytical one. The job of the first view is to give an operator a fast, confident read on system health — then route them to the right place for deeper work. Every element on this screen should be optimized for that scan, not for data completeness.

Right now, none of the three primary zones are doing that job.

---

### KPI row failures

**Missing reference values** are the central failure here. A large number with a trend arrow is not a signal — it is a fact without context. DAU: 14,200 with an upward arrow tells an operator nothing about whether that is good, bad, or normal. The number only becomes actionable when paired with at minimum one of: a target, a prior-period baseline (DAU last 30 days: 12,800), or a threshold band.

Churn rate is the highest-stakes tile on this row. It is also the one most likely to need a red/amber/green threshold, not just a direction arrow. An arrow pointing down is not the same as "churn is within acceptable range." These are different facts and the dashboard is conflating them.

**Repair priority:**
1. Add a baseline or target value beneath each primary metric. Format: `12,800 last 30d` or `Target: 15,000`. Small, secondary weight.
2. Replace or augment trend arrows on churn and MRR with a status indicator tied to a named threshold. The arrow stays but it needs a pass/warn/fail state so an operator can act without doing mental arithmetic.
3. Lock the three KPI tiles to a fixed number of decimal places and consistent unit formatting. Mixed formatting (14.2K vs 14,200 vs $12.4M vs $12,400,000) silently increases scan cost.

You preserve immediate metric visibility. You sacrifice a minimal aesthetic, because you are adding secondary lines to each tile. That is the right tradeoff for a monitoring surface.

---

### 30-day line chart failures

Two separate problems here, both serious.

**No Y-axis label** means the chart is not self-interpreting. A reader must already know what the Y-axis represents to read the chart correctly. On a monitoring dashboard, that is a gap in the chart's contract with the reader, not just a style omission. Label the axis with unit and scale: "Monthly Active Users (thousands)" or "% of cohort."

**Legend below the fold** is a functional break. Four colored lines with no visible legend forces the user to scroll before they can interpret any of the data. The chart is not readable as presented. This is not a preference issue — the chart is broken until the legend is co-located with the chart.

**Repair priority:**
1. Move the legend inside the chart area or immediately adjacent to it above the fold. Inline labels at the line endpoints are better than a separated legend if space allows, because they eliminate the lookup step entirely.
2. Add the Y-axis label. While doing so, decide whether the four segments share a Y-axis scale or need dual axes. If segment volumes differ by an order of magnitude, a single Y-axis is compressing the lower-volume lines into noise. Name that decision explicitly before building.
3. Add a visible baseline reference line if you have a target or a prior-period average. A horizontal reference on a time-series chart gives the operator the "above or below" read in under a second.

You preserve the multi-segment view in a single chart. You sacrifice some whitespace and minimal chart elegance. That is the right tradeoff — a chart that requires a scroll to interpret has failed its primary job.

---

### Left sidebar nav failures

12 ungrouped items is not a navigation problem — it is an information architecture problem that navigation is making visible. At 12 items with no grouping, a user cannot form a mental model of the product. They can only memorize or scan.

The cognitive model of the product lives in the sidebar. If the sidebar has no structure, the product has no legible structure.

**Repair priority:**
1. Group nav items into 3 to 5 conceptual clusters before doing anything else. Typical SaaS analytics groupings: Monitor (health/alerts), Analyze (deep dives, segments), Configure (settings, integrations), and Admin (team, billing). The exact grouping is product-specific, but the principle is fixed: items should be co-located by job, not by the order they were added to the codebase.
2. Use section headers or visual dividers between groups. Do not rely on spacing alone — spacing gets eroded over time as items are added.
3. Audit whether all 12 items belong in primary navigation at all. Secondary, admin, and configuration items belong in a settings sub-section, a user menu, or a secondary nav layer — not in the same visual weight as Monitor and Analyze.

You sacrifice the flat-list simplicity, which was never actually serving anyone. You preserve all 12 items as accessible destinations. The cost is one design decision about grouping logic that requires product knowledge, not just visual judgment.

---

### Intervention order

Fix in this sequence because each fix unblocks the next decision:

1. **Sidebar IA** — until groups are defined, you do not know what this dashboard is the home screen *of*. That scopes the KPI decisions.
2. **KPI reference values** — once the dashboard role is clear, you know which metrics need targets vs baselines vs thresholds.
3. **Legend and Y-axis label** — fast fixes but depend on confirming what the four segments are and whether the axis needs splitting.
4. **Chart baseline reference** — only meaningful once the Y-axis unit and segment definitions are confirmed.

---

### What this audit does not resolve

- Whether DAU, MRR, and churn are the right KPIs for the first view, or whether one of them belongs further down the page — that requires a decision about primary user jobs, which is a product question.
- Whether four line segments is the right chart choice or whether a small-multiple view would be cleaner — that depends on segment volume variance, which needs the actual data.
- Whether the chart should be 30 days by default or whether that default is meaningful for any of the four segments.

These are not polish questions. They are open decisions that affect the structure of the repair.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_role: monitoring, not analytical",
    "kpi_failure: missing reference values and threshold states",
    "chart_failure: legend below fold breaks chart readability; no Y-axis label",
    "density_or_navigation_decision: 12 ungrouped nav items require IA grouping before visual repair"
  ],
  "evidence_classes_cited": [
    "wcag_threshold",
    "scan_cost_constraint",
    "information_architecture_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are DAU, MRR, and churn the correct primary KPIs for this user role, or does one belong further down the page?",
    "Do the four line segments share a comparable Y-axis scale, or do volumes differ by an order of magnitude?",
    "Is 30 days the appropriate default time window for all four segments?"
  ],
  "turn": 1
}
[/SESSION_STATE]