## Functional tier

State is information your app needs to remember — which user is logged in, what's in a cart, whether a modal is open. The question is where that information lives.

**Local state** means each component manages its own memory. A dropdown knows if it's open. A form knows what the user typed. Nothing else needs to know.

**Context** is a way to pass information down through many layers of components without threading it through every parent manually. It works well for things that don't change often — the current theme, the logged-in user's name, the selected language.

**Redux** is a separate system that sits outside your components and holds a central copy of all shared state. Every component that needs the same information reads from that central copy. When something changes, every connected component updates together.

The practical problem: Redux requires extra setup for every piece of state — you write actions, reducers, and selectors even for simple things. That overhead is worth paying when many disconnected parts of your app need to stay in sync. It becomes a tax when most of your state is local anyway.

If your app is a form, a content page, or a small tool where each screen mostly manages its own data, local state and context handle it cleanly. If your app has a shopping cart that affects the header, the sidebar, the checkout page, and an analytics tracker all at once — that synchronization problem is exactly what Redux exists to solve.

**Governing recommendation:** Use local component state with context for now; introduce Redux or a comparable global store only when you have more than two unrelated parts of the UI that must stay synchronized with shared mutable data.

---

## Integrative tier

The real decision isn't "global vs. local" in the abstract — it's about where state ownership lives relative to the components that consume and mutate it, and what the cost of synchronization bugs would be.

**Local state** (`useState`, `useReducer`) is owned by the component tree that needs it. The data lives close to its consumers. Refactoring is contained. The failure mode is prop drilling — passing state down through many layers of components that don't use it, just to reach a child that does.

**Context** solves prop drilling for stable, low-frequency data. The important constraint: Context re-renders every consumer when the value changes. Using it for high-frequency state — filtered lists, form values, cursor position — creates invisible performance problems. Context is appropriate for identity, theme, locale, and feature flags. It is not a global state manager; it's a dependency injection channel.

**Redux** (or Zustand, Jotai, Recoil depending on scale) provides a normalized external store with explicit update rules. The structural benefit is predictability: state transitions are traceable, testable, and consistent across the whole app. The structural cost is indirection — every state change travels through actions and reducers before anything updates. That indirection pays off when you have complex derived state, optimistic updates, undo history, or strict audit requirements.

The real diagnostic question is: do you have state that is **shared, mutable, and distant**? Shared means multiple disconnected components care about it. Mutable means it changes at runtime in response to user actions or API responses. Distant means those components don't share a close common ancestor.

If you have two out of three, context may be enough. If you have all three — and especially if you have multiple pieces of state that interact with each other — a global store earns its overhead.

A common mistake is adopting Redux because the app "might grow" into needing it. The migration cost from local-plus-context to a global store is lower than the daily overhead of maintaining unnecessary Redux infrastructure for an app that never needed it.

**Governing recommendation:** Default to local state with context; migrate to a global store when you can identify at least one concrete case of shared, mutable, distant state where synchronization bugs have already appeared or where optimistic updates, undo, or cross-cutting state interactions make manual synchronization unreliable.

---

## Rendering and mutation strategy

This decision has direct consequences for how React renders your app — which matters for performance and correctness, not just code organization.

Context triggers a re-render in every consumer when the context value changes, because React cannot partially subscribe to a context object. If you store a large object in context and one field changes, every component reading that context re-renders. Mitigation options include splitting contexts by update frequency, memoizing context values, or using a selector-aware library.

Redux and similar stores support **selective subscriptions** — components subscribe to slices of state, and only components whose slice changes re-render. This is the primary performance argument for a global store, and it only matters when you have many consumers of frequently-changing shared state.

For server-fetched data specifically, this is often the wrong decision tree entirely. Libraries like React Query or SWR handle caching, revalidation, deduplication, and loading/error states more precisely than either Redux or Context, because they are purpose-built for async server state rather than client-side synchronization.

**Governing recommendation:** Separate client state (UI state, form state, local interaction state) from server state (fetched data) before choosing a global store; if most of your "shared state" is actually server data, a server-state library eliminates the synchronization problem that would have justified Redux.

---

## Risks and safer path

**Risk 1 — premature Redux adoption.** Teams adopt Redux early because it feels like the "serious" choice. The actual cost: boilerplate that slows feature development, indirection that makes debugging harder for smaller teams, and a system optimized for problems the app doesn't yet have. You sacrifice development velocity to gain infrastructure you don't need yet.

**Risk 2 — context overuse.** Using context as a lightweight Redux substitute without understanding re-render behavior produces invisible performance regressions. High-frequency state in a single context value will cause unnecessary re-renders across the component tree.

**Risk 3 — mixing responsibilities.** Storing server-fetched data in Redux or context when a caching library would handle it better creates synchronization logic you now own and must maintain. You sacrifice simplicity to gain control you didn't need.

**Safer path:** Start with local state. Promote to context only when prop drilling spans three or more layers and the value changes infrequently. Add a server-state library (React Query, SWR) when fetching data from an API. Add a global client-state store only when you have a confirmed synchronization problem that the above tools cannot cleanly solve — meaning you can name the specific state, the specific consumers, and the specific failure that occurred without the store.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: local component state with context as default",
    "state_ownership: promote to global store only when state is shared, mutable, and distant with confirmed synchronization failure",
    "boundary_placement: separate server state (React Query / SWR) from client state before evaluating Redux",
    "cost_or_degraded_path: premature Redux adoption sacrifices development velocity; context overuse creates re-render regressions"
  ],
  "evidence_classes_cited": [
    "rendering_model",
    "state_ownership",
    "boundary_placement",
    "cost_or_degraded_path"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the app already have confirmed synchronization bugs that local state cannot resolve?",
    "What proportion of shared state is server-fetched vs. client-only interaction state?"
  ],
  "turn": 1
}
[/SESSION_STATE]