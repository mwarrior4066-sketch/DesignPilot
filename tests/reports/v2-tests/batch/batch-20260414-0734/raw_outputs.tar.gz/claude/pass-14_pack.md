The proposal has four structural problems that compound each other. Here is the diagnosis, then the safer architecture.

---

## What is actually broken

**Rendering model is wrong for this surface.**
A large client-rendered page for a permissions-heavy, server-driven dashboard means the server's authority over what a user may see is not enforced until JavaScript loads and fires a data request. During that window the shell renders, which leaks structure even if data is hidden. For role-based visibility, rendering decisions should happen at or before the server boundary, not after hydration.

**Separate boolean flags for loading and error state are an impossible-state machine.**
`isLoading: true` and `isError: true` can coexist. `isLoading: false` and `isError: false` and `data: null` is a fourth state with no name. The UI branches on combinations that were never designed, and the result is either a blank screen, a stale render, or a flash of wrong content. This is the most common source of "it works until it doesn't" bugs in dashboards.

**Custom `div` buttons for filter chips break keyboard access and assistive technology.**
A `div` has no implicit role, no keyboard activation, no focus behavior, and no announced state. Screen reader users cannot operate the filters. Keyboard-only users cannot either. This is not a polish gap — it is a WCAG 2.1 Level A failure under Success Criterion 4.1.2 (Name, Role, Value). The fix is not cosmetic; it requires replacing the element type and adding state attributes.

**Optimistic updates for recurring event edits are dangerous without a clear scope boundary.**
Optimistic updates are safe when the mutation is self-contained and easily reversible. Recurring event edits are neither. The server must decide whether the edit applies to this instance, this-and-future, or all occurrences. That decision cannot be pre-answered client-side because the server holds the recurrence rule and the conflict state. Applying an optimistic update before the scope is confirmed means the UI shows a result the server may refuse, revert, or partially apply — and rolling back a recurring mutation that has already re-rendered a multi-week calendar produces visible, jarring inconsistency.

---

## Safer architecture

### Rendering and mutation strategy

Use server rendering for all permission-gated surfaces. The server resolves the user's role before any response leaves the origin. Content that the role cannot see is never included in the HTML. Client JavaScript hydrates interaction only — it does not re-resolve permissions.

Structure the page as a server component shell with narrow client islands:

```
Server component (resolves role, fetches initial data, renders table shell)
  └── Client island: filter chip bar (interaction only, no data ownership)
  └── Client island: table row actions (inline edit, quick status change)
  └── Client island: recurring-edit modal (scope selection + mutation)
```

The table itself renders server-side. Pagination and filter changes hit a server action or a route handler, not a client fetch. This keeps the server as the single authority on what data a role may receive.

### State model: replace boolean flags with a discriminated union

Replace `isLoading` / `isError` / `data` with a single typed state that can only be in one valid configuration at a time:

```typescript
type FetchState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T; staleAt?: number }
  | { status: 'error'; error: AppError; retryable: boolean };
```

Every branch of your UI switches on `status`. There is no combination that is simultaneously loading and errored. There is no unnamed fourth state. The `staleAt` field supports showing a stale-data banner without a separate boolean. If you are using React Query or SWR, their query state already implements this model — use it directly rather than wrapping it in additional booleans.

For permission-gated data, add a fifth status:

```typescript
  | { status: 'forbidden'; reason: 'role' | 'ownership' | 'schedule_locked' }
```

This lets the UI render a meaningful explanation rather than an empty table that looks like a loading failure.

### Filter chip accessibility

Replace every `div` filter chip with a `<button>` carrying explicit ARIA state:

```html
<button
  type="button"
  role="checkbox"
  aria-checked="true"
  aria-label="Filter: Confirmed shifts"
  class="chip chip--active"
>
  Confirmed
</button>
```

If chips are mutually exclusive (one active at a time), use `role="radio"` inside a `role="radiogroup"` instead. If chips are multi-select toggles, use `role="checkbox"`. The element must be focusable via Tab, activatable via Space or Enter, and must announce its checked state on change. Do not rely on visual color alone to communicate active state — the `aria-checked` value is the machine-readable truth.

For server-driven filters specifically: when a chip change triggers a server request, set `aria-busy="true"` on the table region and announce the result count via a live region when the response arrives:

```html
<div role="status" aria-live="polite" aria-atomic="true">
  <!-- inject: "24 results for Confirmed shifts" -->
</div>
```

### Recurring edit: block optimistic updates, use a scoped commit model

Do not apply optimistic updates to recurring event mutations. The correct model is:

1. User initiates edit on an event instance.
2. Client opens a scope-selection modal: this event / this and following / all events.
3. User confirms scope. Client sends the mutation with scope included.
4. Server validates: checks for conflicts, locked periods, role permissions on affected instances.
5. Server responds with the actual affected range and any conflicts.
6. Client re-renders from server response only.

The mutation is not reflected in the UI until step 6. The loading state on the modal button communicates that work is in progress. If the server rejects or partially applies the edit, the response carries the reason and the client renders it inline — no rollback logic required because nothing was pre-applied.

This accepts the tradeoff: the user waits for server confirmation before seeing the result. That is the correct behavior here. The alternative — optimistic apply then rollback — produces visible calendar churn for a class of mutations where the server outcome is genuinely unpredictable.

### Role-based visibility: server enforces, client reflects

Permissions should never be a client-side conditional. The pattern to avoid:

```typescript
// Do not do this
if (user.role === 'manager') {
  return <DeleteButton />;
}
```

This hides the button visually but the component is still shipped to the client. A determined user can trigger the action. The correct pattern: the server action itself checks the role and returns a 403, and the UI only renders the action control if the server's initial data response includes it as an allowed action for that resource:

```typescript
// Derived from server response, not from a client role check
if (resource.allowedActions.includes('delete')) {
  return <DeleteButton />;
}
```

The server controls what appears in `allowedActions`. The client renders what it is told. Role logic lives in exactly one place.

---

## Implementation sequence

Address these in order because each one is a prerequisite for the next:

1. **State model first.** Fix the boolean flags. Every subsequent layer depends on knowing what state the UI is actually in.
2. **Server rendering boundary.** Move the table and initial data fetch server-side. This is the structural change that makes permission enforcement honest.
3. **Filter chip semantics.** Replace `div` elements with `button` elements carrying correct ARIA roles and state. This is a blocking accessibility failure.
4. **Recurring edit scope model.** Remove optimistic updates from this mutation path. Replace with the scoped commit flow.
5. **`allowedActions` server contract.** Audit every role-gated UI control and verify it derives from server-supplied permissions, not client-side role comparisons.

---

## What you are accepting with this approach

You are trading faster perceived interaction on recurring edits for correctness and rollback-free behavior. The scoped commit model adds one round trip before the calendar updates. That is the right tradeoff for a scheduling surface where incorrect optimistic renders erode user trust faster than a short wait does.

You are also trading flexibility in filter chip markup for keyboard and screen reader parity. Using `button` constrains the styling surface slightly compared to a `div`, but the accessibility floor is non-negotiable here — server-driven filters operated only by mouse are not a viable production feature.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: server-rendered shell with narrow client hydration islands",
    "state_ownership: discriminated union FetchState<T> replacing boolean flags",
    "mutations_owned_by: server confirms before client reflects — no optimistic updates on recurring edits",
    "boundary_placement: server component for table and data; client islands for filter interaction and modal",
    "semantic_contract: button with aria-checked/role=checkbox replaces div filter chips",
    "cost_or_degraded_path: one extra round trip on recurring edits accepted in exchange for rollback-free correctness"
  ],
  "evidence_classes_cited": [
    "wcag_sc_4.1.2_name_role_value",
    "impossible_state_machine_boolean_flags",
    "server_authority_model_for_permissions",
    "discriminated_union_state_type",
    "allowedActions_server_contract_pattern"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the filter chip interaction mutually exclusive (radio) or multi-select (checkbox)? This changes the ARIA role used.",
    "Does the recurring edit scope decision need conflict preview before confirmation, or is post-commit conflict reporting sufficient?",
    "Is the stack Next.js App Router, Remix, or another SSR framework? The server component boundary implementation differs."
  ],
  "turn": 1
}
[/SESSION_STATE]