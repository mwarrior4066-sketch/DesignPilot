## API Reliability and Security Audit: POST /exports

**Route:** `rt_api_reliability_security` | **Weight:** compound

---

## Failure Semantics and Error Contract

**Findings:**

The endpoint returns HTTP 200 for all responses including failures. This breaks the HTTP semantic contract entirely. Callers cannot distinguish success from failure without parsing the response body, which means every client, proxy, load balancer, retry middleware, and monitoring tool that relies on status codes will misclassify errors as successes.

Internal enum values leaking in error messages is a separate failure class. It gives callers a map of your internal state machine, which aids enumeration attacks and makes refactoring the backend a breaking change for clients who have started pattern-matching on those strings.

**Required fixes:**

- `4xx` for client errors (invalid params, auth failure, quota exceeded), `5xx` for server faults, `202` for accepted async jobs, `200` only for synchronous success with a completed payload
- Adopt **RFC 9457** (`application/problem+json`) for all error responses

Minimum RFC 9457 shape:
```json
{
  "type": "https://api.yourapp.com/problems/export-quota-exceeded",
  "title": "Export quota exceeded",
  "status": 429,
  "detail": "Your plan allows 10 exports per hour. Retry after the window resets.",
  "instance": "/exports/req_abc123",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736"
}
```

Map internal enums to a stable public vocabulary before the response leaves the server. Internal states like `PDF_RENDER_FAILED_LAYOUT_ENGINE_V2` become `"type": ".../problems/render-failure"` with a human-readable `detail`. The internal enum never crosses the wire.

`trace_id` on all errors is non-negotiable for support and post-incident analysis.

---

## Authorization and Resource Protection

**Findings:**

A PDF export endpoint has a non-obvious authorization perimeter that is easy to underspecify. The obvious question is whether the caller is authenticated. The more dangerous question is whether authenticated callers can trigger exports for data they do not own, and whether export results are scoped correctly on retrieval.

Three specific risks:

1. **Object-level authorization gap.** If the export is parameterized by resource IDs (report ID, dataset ID, date range over another user's data), the endpoint must verify that the requesting principal owns or has explicit access to every referenced object. A missing object-level check here is a **BOLA (Broken Object Level Authorization)** vulnerability: authenticated but unauthorized callers retrieve other users' data.

2. **Resource exhaustion.** A 3-minute synchronous render with no rate limit or quota is a denial-of-service surface. Any authenticated user can exhaust server capacity with concurrent requests. This does not require an attacker; ordinary usage spikes are sufficient.

3. **Export result access.** If the generated PDF is stored and retrieved via a URL or job ID, that retrieval endpoint must also enforce object-level authorization. A shareable download URL without a scoped access check is a second authorization hole even if the generation step was gated correctly.

**Required fixes:**

- **Object-level authorization** on every resource ID in the request body: only the session owner or an explicitly granted principal may export that resource
- **Deny by default**: if authorization cannot be confirmed, return `403`, not an empty result
- **Rate limit + quota**: hard cap on concurrent exports per user and per tenant; return `429` with `Retry-After` when the limit is hit
- Export result retrieval gated by the same authorization perimeter as generation

---

## Idempotency and Async Lifecycle

**Findings:**

A synchronous operation that blocks for up to 3 minutes has two compounding problems.

First, it will time out. Clients, API gateways, load balancers, and CDNs all have connection timeout defaults well under 3 minutes. A client that does not get a response within their timeout will retry, producing duplicate export jobs if the server does not enforce idempotency. Without an **idempotency-key header**, there is no mechanism to detect or suppress the duplicate.

Second, the synchronous model means the server holds an open connection, a worker thread, and likely a render process for the full duration. At any meaningful concurrency, this collapses the thread pool and makes the service unavailable for all other operations.

**Required fixes:**

Convert to an async job model:

```
POST /exports
  Body: { report_id, format, filters }
  Header: Idempotency-Key: <client-generated UUID>

→ 202 Accepted
  Body: {
    "job_id": "job_abc123",
    "status": "queued",
    "status_url": "/exports/job_abc123",
    "estimated_completion_seconds": 90
  }
```

**Job lifecycle** with terminal states:
```
queued → running → completed | failed
```

Client polls `GET /exports/{job_id}` or receives a webhook when the job reaches a terminal state. The status endpoint returns the current state and, on `completed`, a scoped download URL with a TTL.

**Idempotency contract:** if an `Idempotency-Key` header has been seen within the deduplication window (typically 24 hours), return the existing job record rather than creating a new one. Return `409 on duplicate` only when the same key is reused with a materially different request body, which signals a client error rather than a safe retry.

This means accepting a polling or webhook integration on the client side. The tradeoff is: you sacrifice the simplicity of a single blocking call to gain timeout safety, retry safety, horizontal scalability, and the ability to surface partial progress.

---

## Resilience and Observability

**Findings:**

A blocking synchronous endpoint with no retry contract has no safe failure path. When the PDF renderer fails at 2 minutes 50 seconds, the caller gets either a timeout or a 200 with an error body (under the current design). There is no way to distinguish a transient renderer failure from a permanent one, so clients cannot know whether to retry.

No `trace_id` on errors means a support request for a failed export requires log correlation by timestamp and user ID, which is slow and unreliable.

**Required fixes:**

**Retry safety:** With the async model, retries are safe because the idempotency key deduplicates the job creation request. Document this explicitly in the API contract. Retrying `POST /exports` with the same `Idempotency-Key` is always safe.

**Backoff guidance:** Document **exponential backoff with jitter** for polling and for retrying failed jobs. A failed job should include a `retry_after` timestamp in the job record when the failure is known to be transient (renderer overload, downstream timeout) versus permanent (invalid template, malformed data).

**Circuit breaker:** If the PDF renderer is a downstream dependency, wrap it with a circuit breaker. When the renderer is unavailable, the endpoint should return `503` with a `Retry-After` header rather than queuing jobs that will all fail and exhaust the retry budget.

**Observability floor:**

Every export request must emit:
- `trace_id` on all errors and all job creation responses, correlated through the full async lifecycle
- Duration instrumentation: job queue time, render start, render duration, total time to completed state
- Failure reason classification: renderer failure vs. authorization failure vs. quota hit vs. data fetch failure. These need different alerting thresholds
- Export volume and p95/p99 render duration as dashboard metrics. A sudden p99 spike is your first signal that the renderer is degrading before jobs start failing

**Graceful degradation:** If the renderer is overloaded, return `503` with `Retry-After` rather than accepting the job and silently failing it. A rejected request the client can retry is better than an accepted job that will never complete.

---

## Summary

| Area | Current state | Required fix |
|---|---|---|
| Error semantics | 200 for all responses | RFC 9457, correct status codes, `trace_id` on all errors |
| Enum leakage | Internal states on the wire | Map to stable public vocabulary server-side |
| Authorization | Unspecified object-level check | BOLA check on every resource ID, deny by default |
| Resource protection | No rate limit | Per-user and per-tenant quota, `429` with `Retry-After` |
| Idempotency | None | `Idempotency-Key` header, `409 on duplicate` for conflicting reuse |
| Async lifecycle | 3-minute synchronous block | `202 Accepted`, job model with terminal states, polling or webhook |
| Retry safety | No retry contract | Documented safe retry via idempotency key, backoff guidance |
| Resilience | No circuit breaker or degraded path | Circuit breaker on renderer, `503` with `Retry-After` |
| Observability | None specified | `trace_id` correlation, duration metrics, failure classification |

The synchronous blocking design is the architectural root cause for the timeout, retry, and resilience failures. The error contract and authorization gaps are independent and require fixes regardless of the sync-to-async migration.

[SESSION_STATE]
{
  "route": "rt_api_reliability_security",
  "escalation_level": "compound",
  "decisions_committed": [
    "async_job_model: 202 Accepted + status URL with terminal states queued → running → completed | failed",
    "idempotency_contract: Idempotency-Key header required, 409 on conflicting duplicate",
    "problem_details_contract: RFC 9457 application/problem+json, trace_id on all errors",
    "authorization_perimeter: object-level BOLA check on every resource ID, deny by default",
    "resilience_strategy: circuit breaker on renderer, exponential backoff with jitter, 503 with Retry-After on overload"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "202 Accepted + status URL",
    "terminal states: queued → running → completed | failed",
    "idempotency-key header",
    "409 on duplicate",
    "object-level authorization",
    "BOLA check",
    "deny by default",
    "rate limit + quota",
    "circuit breaker",
    "exponential backoff with jitter",
    "trace_id on all errors",
    "Retry-After"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the export result retrieval endpoint enforce the same authorization perimeter as generation?",
    "Is the PDF renderer an internal service or a third-party dependency? This affects circuit breaker placement.",
    "What is the expected polling or webhook delivery model for the client integration?"
  ],
  "turn": 1
}
[/SESSION_STATE]