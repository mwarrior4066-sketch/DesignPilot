## API Review: POST /api/v1/projects/{id}/members

---

### 1. Status code — return 201, not 200

**Governing decision:** A successful resource creation must return 201 Created, not 200 OK.

200 signals that an existing resource was retrieved or updated. Creating a membership is a net-new resource creation. Returning 200 misrepresents the operation's semantic, which breaks clients that branch on status code — including retry logic, caches, and audit consumers. You sacrifice the trivial convenience of reusing a generic success handler, and you gain correct HTTP semantics that every standard-compliant client can interpret without guessing.

---

### 2. Response body — return the created member, not the full list

**Governing decision:** A creation endpoint should return the created resource, not a collection side effect.

Returning the full updated member list couples the caller to collection state they did not ask for, bloats the response payload for large teams, and forces the client to scan a list to find what was just created. Return the new membership object — with its ID, role, timestamps, and status — so the caller has exactly what they need to act on the result. If the full list is also needed, that belongs to GET /api/v1/projects/{id}/members.

---

### 3. Idempotency — this endpoint needs an idempotency key

**Governing decision:** Any non-idempotent state-mutating endpoint exposed to network conditions requires an idempotency contract.

Without an `Idempotency-Key` header, a network timeout forces the caller to guess: did the membership get created or not? A retry creates a duplicate or returns an ambiguous error. The contract should be: accept an `Idempotency-Key` header, store the result keyed to that value for a defined window (24 hours is a reasonable default), and return 409 Conflict on a duplicate request that differs in payload rather than being a true replay. This means accepting a small storage cost for the key cache. You sacrifice simplicity of a stateless handler, and you gain safe retry behavior across clients, mobile networks, and automation pipelines.

---

### 4. Error response — error bodies must follow RFC 9457

**Governing decision:** Error responses must carry structured, machine-readable problem details — plain strings are not an acceptable error contract.

A plain string error message cannot be parsed reliably by any client. RFC 9457 (Problem Details for HTTP APIs) defines the standard envelope:

```json
{
  "type": "https://api.example.com/problems/member-already-exists",
  "title": "Member already exists",
  "status": 409,
  "detail": "User 42 is already a member of project 7.",
  "instance": "/api/v1/projects/7/members"
}
```

`type` is a stable URI clients can route on. `detail` is human-readable context. `instance` ties the error to the specific resource. Without this, every error handler in every client becomes a string-parsing guess. You sacrifice the speed of returning a simple message, and you gain a contract that clients, logging systems, and monitoring tools can all consume without interpretation.

---

### 5. Authorization — BOLA vulnerability, object-level check is missing

**Governing decision:** Authorization must verify the caller's relationship to the target resource, not just their authenticated identity.

Checking that the caller is logged in is authentication, not authorization. This endpoint has a direct BOLA (Broken Object-Level Authorization) exposure: any authenticated user can add members to any project they know the ID of, regardless of whether they own or administer it. The fix is an explicit object-level authorization check:

- only a project admin or owner may add members
- the check must happen server-side against the project record, not inferred from a token claim alone
- deny by default: if the caller's role on the specific project cannot be confirmed, reject with 403 Forbidden

The authorization perimeter here is: `only [project admin or owner] may POST to /api/v1/projects/{id}/members`. Missing this check is not a design preference issue — it is a security failure that belongs in the critical fix column before this endpoint ships.

---

### 6. Summary table

| Concern | Current state | Required change | Severity |
|---|---|---|---|
| Status code | 200 | 201 Created | Medium |
| Response body | Full member list | Created membership resource | Medium |
| Idempotency | None | `Idempotency-Key` header + 409 on conflict | High |
| Error format | Plain string | RFC 9457 problem details | High |
| Authorization | Login check only | Object-level: project admin or owner only | Critical |

The authorization gap and missing idempotency contract are the two issues that must be resolved before this endpoint is safe to expose. The status code and response body changes improve correctness but carry lower operational risk.

[SESSION_STATE]
{
  "route": "api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "status_code: 201 Created for resource creation",
    "response_body: created membership resource, not full list",
    "idempotency_contract: Idempotency-Key header required, 409 on duplicate",
    "error_format: RFC 9457 problem details",
    "authorization_perimeter: object-level check, only project admin or owner may add members"
  ],
  "evidence_classes_cited": [
    "RFC 9457",
    "idempotency-key header",
    "409 on duplicate",
    "BOLA check",
    "object-level authorization",
    "deny by default",
    "authorization perimeter"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is there a defined retention window for idempotency keys?",
    "Should role validation come from a token claim, a project membership table, or both?",
    "Is there a rate limit on this endpoint to prevent membership enumeration?"
  ],
  "turn": 1
}
[/SESSION_STATE]