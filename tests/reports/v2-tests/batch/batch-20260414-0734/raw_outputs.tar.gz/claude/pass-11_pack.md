## What to Extract from the 2018 PDF

Before translating anything, the extraction pass separates what the PDF actually shows from what must be inferred. A 2018 brand guidelines PDF is a visual artifact — it carries layout diagrams and specified values, but its semantic reliability depends on how it was built. Treat it as evidence with confidence levels, not as a living spec.

---

### Extraction targets and confidence levels

**Margin specifications**
Extract the stated margin values — typically shown as labeled dimensions on a page diagram. These are usually the highest-confidence numbers in old brand guides because they appear as explicit callouts.

Watch for: whether margins are defined as absolute measurements (12mm, 0.5in) or as proportional rules (10% of page width). Absolute values need to be re-examined against your new output media. Proportional rules survive scaling better.

**Column system**
Extract the number of columns, the gutter width, and whether the system uses a fixed grid or a fluid/fractional grid. Most 2018 brand guides used fixed-column layouts because they were built primarily for print or fixed-size PDF output.

Also note whether the column count changes across page types (cover vs. body page vs. spread vs. sidebar layout) — many guides show one canonical diagram but implicitly use a different column structure on section openers or callout pages.

Confidence note: column diagrams in PDFs are sometimes illustrative rather than mathematically precise. If the diagram was drawn by hand in InDesign without a live grid, the visual column spacing may not match any stated value. Flag this when you see it.

**Baseline grid**
If the PDF shows horizontal rules or text sitting on a consistent rhythm, extract the baseline increment. This is typically derived from body text leading — if body copy is set at 10/14 (10pt size, 14pt leading), the baseline grid is 14pt or a half-increment of 7pt.

This is often implicit, not stated. If no baseline grid is shown, infer it from the body text specification and flag it as inferred.

**Type scale**
Extract every specified type size and style: body, caption, heading levels, pull quotes, labels, footnotes. Note whether sizes are in points (print), pixels (screen), or both. A 2018 print-first brand guide will almost certainly be in points.

**Spacing and clearance rules**
Look for minimum clearance zones around logos, headers, and images. These are layout constraints, not decoration — they define a minimum white-space contract. Extract these as constraints you will map to a spacing scale, not just copy as raw numbers.

**Color values**
Extract CMYK, Pantone, and RGB values if present. Note that 2018 brand guides frequently lack hex values or HSL/HSB equivalents for digital use. You will need to derive those if screen use is a target.

---

### What cannot be reliably extracted from the PDF alone

**Source grid math.** InDesign grids are defined in the document settings, not in the visual output. If you cannot open the source file, you can estimate the grid from diagrams, but you cannot verify whether the actual column spacing was what the spec claims.

**Responsive or adaptive intent.** A 2018 brand PDF is almost certainly a fixed-format artifact. There is no responsive behavior to extract — you are inferring what the system *would* have wanted at different sizes, which is reconstruction, not extraction.

**Interactive states, hover, focus, or motion rules.** Not present and not implied by a static PDF. These are yours to define.

**Accessibility intent.** A 2018 brand guide predates most serious accessibility mandates for brand systems. Contrast ratios may not meet WCAG 2.1 AA. Do not assume compliance — test every color combination against current thresholds.

---

## How to Translate Into a Modern Layout System

The governing principle: preserve the spatial logic, not the unit system.

A 2018 print-first brand guide defines a proportional rhythm. That rhythm — the relationship between margins, columns, gutters, and type scale — is what deserves to survive. The raw point or millimeter values do not need to survive unchanged.

---

### Step 1: Normalize the unit system

Convert extracted measurements to a shared base unit before doing anything else. Choose your base unit based on your primary new output medium:

- Web/app: base 4px or 8px grid (most common)
- Slide/presentation: base 8px or a fractional percentage of slide dimensions
- Print continuation: keep points or mm, but verify against the new output size

Map the extracted margin, gutter, and spacing values to the nearest clean multiple of your base unit. The goal is a coherent spacing scale, not slavish numerical fidelity. If the original spec says 11mm and your base unit conversion produces 41.7px, round to 40px and note the rounding decision.

---

### Step 2: Reconstruct the column system

From the extracted column count and gutter width, define:

- Column count per output medium (the original print column count may need to change for screen)
- Gutter width as a base-unit multiple
- Margin as a base-unit multiple
- Whether the grid is fixed-width (print, slide) or fluid (web)

For web use, map the original fixed column structure to a responsive grid. A common 12-column web grid can absorb most print column counts: a 3-column print layout maps to 4 columns each in a 12-column grid; a 4-column print layout maps to 3 columns each.

Document which column spans correspond to which original layout zones — this is what keeps the visual intention alive across media.

---

### Step 3: Establish a spacing scale

Do not carry forward a list of one-off spacing values. Map every extracted margin, gutter, clearance zone, and padding value onto a named spacing scale. A simple 4px-base scale works for most UI systems:

```
space-1:  4px   (tight)
space-2:  8px   (small)
space-3: 12px
space-4: 16px   (default paragraph gap)
space-6: 24px   (section breathing room)
space-8: 32px
space-12: 48px  (major section break)
space-16: 64px  (page-level margin)
```

Name each original spacing value against its closest scale step, and note where the original value falls between scale steps. This gives you a principled system instead of a registry of legacy numbers.

---

### Step 4: Rebuild the type scale for the new medium

Convert the extracted point sizes to the new unit system and apply a type scale with consistent ratio. Do not simply divide print points by 1.333 (the common print-to-screen approximation) without checking the result for readability.

For each type role (body, caption, heading H1–H3, label, display), specify:
- Font size in the new unit
- Line height (leading)
- Letter spacing if relevant
- Maximum line length (character count or column span)

If the 2018 guide used a custom typeface, verify licensing covers your new output media. Print licenses and screen licenses are frequently separate.

---

### Step 5: Define the clearance and proximity rules as design tokens

Convert minimum clearance zones and logo exclusion zones from the original spec into named constraints in your token system. For example:

```
--logo-clearance-min: var(--space-4)
--section-header-clearance: var(--space-8)
--image-caption-gap: var(--space-2)
```

This makes the brand spatial logic enforceable in code rather than dependent on someone reading a PDF.

---

### Step 6: Document inference boundaries explicitly

In your new layout spec, mark each value as one of:

- **Extracted directly** from the PDF (high confidence)
- **Derived** by conversion from the original system (medium confidence, conversion shown)
- **Inferred** from visual evidence without a stated spec (low confidence, verify with stakeholders or the original designer if accessible)
- **New** — not present in the original, added for the new medium

This prevents the new system from being treated as fully authoritative when parts of it are reconstructed assumptions. It also makes future audits tractable.

---

### The core tradeoff

You preserve the proportional DNA and spatial rhythm of the original brand system. You sacrifice exact numerical fidelity and direct backward compatibility with legacy documents. The new system will look like the original brand and behave consistently, but it will not produce identical measurements — because the output medium has changed and a coherent modern system is worth more than frozen historical numbers.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "preserved_elements: spatial rhythm, column proportions, margin logic, clearance zones, type hierarchy",
    "inference_boundary: source grid math unverifiable from PDF output alone; baseline grid inferred from type spec if not stated; responsive intent absent",
    "reconstruction_order: normalize units -> reconstruct columns -> establish spacing scale -> rebuild type scale -> define clearance tokens -> document confidence levels",
    "verification_method: mark each value as extracted / derived / inferred / new in the output spec; test all color values against WCAG 2.1 AA before adopting"
  ],
  "evidence_classes_cited": [
    "threshold: WCAG 2.1 AA contrast",
    "constraint: print-to-screen unit conversion",
    "artifact: 2018 brand guidelines PDF",
    "inference_label: baseline grid flagged as inferred when not explicitly stated"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the primary new output medium web, presentation/slide, or print continuation?",
    "Is the original InDesign source file accessible for grid math verification?",
    "Are the original typefaces licensed for screen use?",
    "Are there specific page types or templates that need to be prioritized in reconstruction?"
  ],
  "turn": 1
}
[/SESSION_STATE]