The governing failure here is document semantics, not layout aesthetics, so PDF remediation owns this with document accessibility in close support.

---

## What you're actually dealing with

InDesign-exported PDFs carry a common cluster of accessibility failures. Your description maps to four distinct problems, each with a different repair method and verification step. They are not equally urgent.

---

## Semantic failure map

**1. Reading order does not follow column logic**
InDesign's automatic tag export reads frames in creation order, not visual reading order. In a two-column layout, this usually means the reader finishes column one, jumps to a pull quote or sidebar in the middle of the page, then continues with column two — or worse, it interleaves left and right column paragraphs. Screen readers and most export tools follow the tag tree, not the visual position.

Root cause: the `Articles` panel was either not used or not set up before export.

**2. Pull quotes interrupt the tag flow**
Pull quotes are typically text frames placed on top of body copy. Their tag position in the tree matches when the frame was created, which is often mid-flow. This causes the screen reader to read the pull quote text a second time (it already appeared in the body) at an arbitrary position in the stream.

Root cause: the pull quote frames need to be explicitly tagged as `Artifact` so assistive technology skips them entirely. They carry no unique semantic content.

**3. Decorative images are not tagged**
Untagged images cause screen readers to announce something like "Figure" or an empty alt-text string. Decorative images should be marked as `Artifact` so they are passed over silently.

Root cause: InDesign's image export does not automatically distinguish decorative from informational images. Every placed image exports as a `Figure` unless you intervene.

**4. Table of contents links are broken**
InDesign TOC links are PDF internal hyperlinks. They break when the tag tree or page structure shifts during Acrobat remediation, when the PDF is re-saved without preserving link data, or when the original InDesign file used text anchors rather than paragraph-style-based TOC generation.

Root cause: depends on export settings. Links generated from InDesign's `Layout > Table of Contents` feature and exported with `Create Tagged PDF` and `Include Hyperlinks` both checked should survive. If they did not survive, the links were either re-exported without those settings or were manually placed anchors that did not translate.

---

## Repair priority and method

Work in this order. Each step changes the tag tree, so doing them out of sequence creates rework.

### Step 1 — Fix reading order in Acrobat Pro (Reading Order panel + Tags panel)

The cleanest source fix is to use the **Articles panel in InDesign** before re-exporting. If re-export is available:

- Open the Articles panel (`Window > Articles`)
- Thread your content frames into one Article in the correct reading order: column 1 top to bottom, column 2 top to bottom, pull quotes excluded
- Mark decorative images and pull quote frames as excluded from the Article
- Re-export with `Create Tagged PDF`, `Use Structure for Tab Order`, and `Include Hyperlinks` all checked

If you cannot re-export from InDesign, repair in Acrobat Pro:

- Open `View > Show/Hide > Navigation Panes > Tags`
- Open `View > Show/Hide > Navigation Panes > Order` (the reading order panel)
- Drag tag elements in the Order panel to match correct column-then-column flow
- Verify by running `View > Read Out Loud` in Acrobat and listening to the page sequence

The Order panel is more forgiving for resequencing. The Tags panel is required for marking artifact status.

### Step 2 — Artifact pull quotes

In Acrobat Pro Tags panel:

- Find each pull quote `<P>` tag (search for the pull quote text if the tag tree is large)
- Right-click the tag > `Change Tag to Artifact`
- Choose `Decorative` or `Page` artifact type depending on your preference; both cause screen readers to skip the element

Pull quotes contain no unique information that is not already in the body text. Marking them as artifacts is the correct semantic decision, not a workaround. You sacrifice visual-to-semantic parity (the pull quote no longer exists in the reading experience) to gain a clean, non-repetitive reading stream.

### Step 3 — Artifact decorative images

In Acrobat Pro Tags panel:

- Locate each `<Figure>` tag associated with a decorative image
- If the image is purely decorative (no data, no diagram content, no caption that requires context), right-click > `Change Tag to Artifact`
- If any image is informational, keep the `<Figure>` tag and add alt text: right-click > `Properties > Tag` tab > `Alternate Text` field

Do not add empty alt text (`alt=""`) through Acrobat's properties dialog as a shortcut for decoration. Use the artifact tag. Empty alt text is a document accessibility anti-pattern in PDF: it announces the figure element silently rather than suppressing the node entirely, which some screen readers handle inconsistently.

### Step 4 — Restore TOC links

Check the failure mode first before attempting a repair:

- Open the TOC in Acrobat, click a link, and note what happens
- If the link goes to the wrong page: the page numbering shifted during remediation. Correct by re-exporting with TOC regenerated, or by manually re-assigning link destinations in Acrobat Pro under `Tools > Edit PDF > Link`
- If the link produces no response: the hyperlink was not exported. Re-export with `Include Hyperlinks` checked, or rebuild the TOC links manually as named destinations
- If the link worked before Acrobat remediation and broke after: your tag-tree restructuring moved the destination anchor. Use `View > Tools > Edit PDF > Link` to repoint each link to the correct page or named destination

For structural TOC links at the document level, consider adding `<TOC>` and `<TOCI>` tags in the tag tree so assistive technology can also navigate them as a list, not just as hyperlinks. This is a WCAG 2.1 Level AA improvement, not strictly required for PDF/UA, but it materially improves the screen reader navigation experience.

---

## Verification method

Do not trust a visual pass or a simple Acrobat accessibility check alone.

Run these three checks in sequence:

**1. Acrobat Accessibility Checker**
`Tools > Accessibility > Accessibility Check`
This catches tag structure issues, missing alt text, and some reading order flags. It does not catch semantically wrong tag assignments or out-of-order flow that Acrobat cannot verify against your intended reading order.

**2. Listen with Read Out Loud or NVDA**
`View > Read Out Loud > Activate Read Out Loud` in Acrobat, or open the PDF in Adobe Reader and test with NVDA or JAWS. Listen for:
- Column interleaving
- Pull quote text appearing twice
- Figure announcements where decorative images should be silent
- TOC links responding to Enter key

**3. Export to plain text and read the sequence**
`File > Export To > Text (Plain)` from Acrobat. Read the output. The text sequence should match how a sighted reader would consume the content. If column text interleaves, or pull quotes appear mid-sentence, the tag tree is still wrong.

---

## Destructive shortcuts rejected

These approaches are sometimes suggested and should not be used here:

- **Flattening all tags and re-tagging from scratch in Acrobat** — This destroys any structural work already present and creates a maintenance liability. Only do this if the existing tag tree is so corrupt that incremental repair is longer than a full rebuild.
- **Using the Accessibility checker's auto-repair for reading order** — Acrobat's auto-reorder uses bounding box heuristics, not semantic knowledge of your layout. On a two-column layout with pull quotes, it will produce plausible-looking but incorrect results.
- **Removing the TOC entirely to avoid fixing links** — A working TOC is a navigation mechanism, not decorative structure. Removing it fails users who rely on screen readers to navigate long documents by section.

---

## Re-export vs. repair in Acrobat

If InDesign source files are available, fixing the Articles panel and re-exporting is more durable than Acrobat remediation. Acrobat remediation applied to a broken export will need to be repeated every time the document is re-exported. The InDesign Articles panel approach bakes correct reading order into the export pipeline.

If source files are not available, the Acrobat Pro route above is the correct approach and produces a conformant result when done completely.

[SESSION_STATE]
{
  "route": "rt_pdf_remediation",
  "escalation_level": "compound",
  "decisions_committed": [
    "semantic_failure: reading order from frame creation order not Articles panel",
    "reading_order_or_extraction: repair via InDesign Articles panel on re-export or Acrobat Order panel drag-resequencing",
    "verification_method: Acrobat Accessibility Checker + Read Out Loud + plain text export sequence check",
    "destructive_shortcut_rejected: auto-reorder heuristics, full tag-tree flatten, TOC removal"
  ],
  "evidence_classes_cited": [
    "wcag_rule: WCAG 2.1 Level AA TOC tagging improvement",
    "pdf_ua_tag_contract: Figure artifact vs decorative artifact distinction",
    "indesign_export_settings: Create Tagged PDF + Include Hyperlinks + Use Structure for Tab Order",
    "screen_reader_test: NVDA/JAWS + Read Out Loud behavioral verification"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the InDesign source file available for re-export, or is Acrobat-only remediation required?",
    "Are any of the decorative images also used in captions or cross-references that would make them informational?"
  ],
  "turn": 1
}
[/SESSION_STATE]