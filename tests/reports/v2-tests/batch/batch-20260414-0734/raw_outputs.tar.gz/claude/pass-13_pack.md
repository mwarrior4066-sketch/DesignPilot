## Research Gap Map: B2B Project Management Redesign

### What the evidence actually tells you

Before mapping gaps, it's worth being precise about what you have and what you can honestly claim from it.

**3 stakeholder interviews**
Tells you: business goals, internal priorities, assumed user pain points, and political constraints.
Does not tell you: what end users actually experience. Stakeholder mental models routinely diverge from user behavior, sometimes by a wide margin.

**2 usability tests on the current product**
Tells you: observable friction on specific tasks, surface-level confusing patterns, and moments where users hesitated or failed.
Does not tell you: whether those problems are representative, why users made the choices they made, or what they do outside that test context.

**60% drop-off on project creation**
Tells you: a majority of users who start the flow do not complete it. This is a real, measurable failure signal.
Does not tell you: whether they abandoned because the flow is confusing, because they weren't ready to create a project yet, because they realized they needed information they didn't have, or because the concept of "project" in your product doesn't match their mental model.

**Net honest claim:** You have confirmation that a problem exists and some surface evidence of where friction shows up. You do not yet have causal explanation for any of it.

---

### Gap map by priority

#### Gap 1 — Abandonment cause (Highest priority, blocks causal design decisions)

**What you know:** 60% drop-off.
**What you're missing:** The reason. Confusion, unreadiness, missing information, wrong mental model, and premature entry are all structurally different problems. They require different interventions, and building for the wrong one will make things worse, not better.

**Why this is the blocking gap:** Every design decision about the project creation flow depends on understanding this. If users abandon because the form is too long, shorten it. If they abandon because they don't understand what a "project" is in your system, the form length is irrelevant. You cannot make a confident design decision here without this evidence.

**Research method:** Session recording review (Hotjar, FullStory, or equivalent) to see where in the flow abandonment concentrates. Pair with 5-8 brief exit interviews or intercept surveys with users who recently abandoned. Aim to distinguish confusion, unreadiness, and conceptual mismatch as three separate hypotheses.

---

#### Gap 2 — End-user behavioral context (High priority, affects scope and structure)

**What you know:** Stakeholder intent and surfaced usability friction.
**What you're missing:** How real users work outside your product. What does their actual workflow look like? What other tools are they using? At what point in their own process do they turn to your product? This shapes whether the project creation flow is the right place to intervene at all.

**Why this matters:** B2B tools are embedded in larger work contexts. Users rarely come to a product management tool cold. They have spreadsheets, emails, verbal agreements, and prior decisions already in motion. If you don't know where your tool sits in that workflow, you will optimize a local step inside a system you don't understand.

**Research method:** Contextual inquiry or structured workflow interviews with 6-10 current users across at least two account sizes. Focus on a full work episode, not just in-product behavior. Document the hand-offs, tools, and decision points that precede and follow product use.

---

#### Gap 3 — Power user needs and ceiling (High priority for retention and long-term value)

**What you know:** Nothing about this segment.
**What you're missing:** What heavy users depend on, what workarounds they've built, and what they'd lose or break in a redesign. This matters for two reasons: power users are often the economic anchors of B2B accounts, and redesigns that optimize for onboarding frequently degrade the experience for people who use the tool daily.

**Why this matters:** If you optimize the project creation flow for first-time clarity without knowing how power users move through it, you risk removing shortcuts, adding confirmation steps, or restructuring a flow that experienced users have already internalized. The resulting design will be accessible and annoying simultaneously.

**Research method:** Diary study or structured depth interviews with 4-6 identified power users (high session frequency, high project count, or high seat role). Specifically probe for workarounds, keyboard shortcuts, missing features, and what they would not want changed. Run this in parallel with, not after, abandonment research.

---

#### Gap 4 — Competitive and category conventions (Medium priority, affects benchmarking and trust)

**What you know:** Nothing.
**What you're missing:** What the category has normalized. B2B project management users have prior experience with Linear, Jira, Asana, Monday, or similar products. If your creation flow diverges sharply from established patterns without good reason, users will experience it as broken even when it isn't. You also don't know which competitors are addressing the abandonment problem well and which are not.

**Why this matters:** Competitive analysis is not about copying. It is about understanding the convention space you're operating in, so that deviations are intentional rather than accidental. An unconventional flow needs to earn its deviation; a conventional flow benefits from familiarity.

**Research method:** Structured competitive teardown across 3-4 direct competitors. Focus specifically on project creation flows, onboarding sequences, and how each product handles the concept-definition moment (naming, structuring, assigning ownership). This is secondary research, not user research, so it is faster and cheaper than the other gaps. Do it first to inform interview design.

---

### Research sequence

**Do these before design decisions:**

1. Competitive teardown (fastest, informs interview guide design)
2. Session recording review (answers where abandonment concentrates, shapes interview targets)
3. Abandonment exit interviews alongside workflow interviews (answer why)

**Run in parallel or immediately after:**

4. Power user depth interviews (protects existing value while you improve onboarding)

**Evidence bar to clear before major redesign work begins:**

You should be able to answer these three questions with real data, not assumptions:
- Why do users abandon project creation specifically?
- Where in a user's actual workflow does this product sit?
- What do high-frequency users depend on that must not break?

Until those three are answered, treat design decisions on the project creation flow as hypotheses, not commitments.

---

### Known-evidence vs. gap summary

| What you have | Honest claim | Proxy or measured |
|---|---|---|
| 3 stakeholder interviews | Business intent and internal priorities | Proxy for user experience |
| 2 usability tests | Observable friction on specific tasks | Proxy for representative behavior |
| 60% drop-off analytics | Abandonment signal is real and significant | Measured — causal explanation is absent |
| **What you lack** | | |
| Abandonment cause | No data | Open gap |
| End-user workflow context | No data | Open gap |
| Power user behavior and needs | No data | Open gap |
| Competitive conventions | No data | Open gap |

---

### One honest constraint to carry into design

The 60% drop-off is real evidence. Everything else is directional. Until you have causal data on abandonment and workflow context, the redesign should be structured so that interventions are reversible, because you are making informed bets, not confirmed decisions.

[SESSION_STATE]
{
  "route": "rt_ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": [
    "known_evidence: stakeholder interviews proxy user experience not measure it",
    "known_evidence: usability tests proxy representative behavior not confirm it",
    "known_evidence: 60pct dropoff is measured abandonment signal without causal explanation",
    "gap_priority: abandonment cause is blocking gap for project creation flow decisions",
    "gap_priority: power user needs high priority to protect existing value during redesign",
    "method_mapping: session recording plus exit interviews for abandonment cause",
    "method_mapping: contextual inquiry for workflow context",
    "method_mapping: depth interviews for power users",
    "method_mapping: competitive teardown first to inform interview guide",
    "research_sequence: competitive teardown then recording review then interviews then power user depth"
  ],
  "evidence_classes_cited": [
    "measured_signal: 60pct drop-off analytics",
    "proxy_evidence: stakeholder interviews standing in for user experience",
    "proxy_evidence: two usability tests standing in for representative behavior",
    "open_gap: abandonment cause",
    "open_gap: end_user_workflow_context",
    "open_gap: power_user_behavior",
    "open_gap: competitive_conventions"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What account sizes or roles are represented in the existing usability tests?",
    "Are the stakeholder interviews internal stakeholders only, or do they include customer-side decision makers?",
    "Is the 60% drop-off calculated from all users who land on the creation flow, or only those who actively start filling it out?"
  ],
  "turn": 1
}
[/SESSION_STATE]