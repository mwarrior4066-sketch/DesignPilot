## Pricing Page Audit

The page has one structural problem, one color/contrast failure, and several hierarchy gaps worth fixing in sequence — structure first, then color, then supporting details.

---

### Structural failures, in priority order

**1. The hero is working against the page's actual job**

A pricing page's job is to remove doubt and move someone to a decision. A hero with a large background image and a generic headline ('Everything your team needs') is doing the same job as a marketing landing page, not a pricing page.

Visitors landing on pricing have already decided they're interested. They're comparing plans, looking for the catch, and calculating whether this fits their budget. Delaying the pricing table with a full hero adds scroll cost and signals uncertainty about whether the company is confident in its price.

The headline also doesn't orient users around a choice. It restates the product's value proposition rather than framing the decision they're about to make.

**What this costs you:** Users read the headline, skip the CTA, scroll to pricing, and the hero buys you nothing. The CTA is small and isolated, which makes it easy to miss entirely.

**Fix:** Compress the hero into a short orientation band (40–60px top padding, not a full viewport section). Replace the background image with a solid surface or a subtle tonal background. Reframe the headline to support decision-making: "Simple pricing for teams of any size" or "Choose the plan that fits how your team works." Let the pricing table own the visual priority on this page.

---

**2. The CTA is undersized relative to the hero it's embedded in**

A large hero with a small CTA creates a hierarchy inversion. The visual weight of the background image outcompetes the interactive element it's supposed to support. On a pricing page specifically, the primary CTA is conversion-critical.

**Fix:** If you keep any hero section, the CTA should be at minimum 44px tall (WCAG 2.5.5 target size), visually dominant relative to the headline, and unambiguous in its label. "Start free trial" or "Try Pro free for 14 days" beats "Get started." If you compress the hero as recommended above, a single persistent CTA or one per pricing tier will perform better than one isolated button.

---

**3. The pricing table hierarchy is unclear at a glance**

Color-coding the Pro tier is the right instinct. It's your most likely conversion point for B2B SaaS. But using color alone as the signal fails two ways: it fails users with color vision deficiencies, and it fails the structural job because color doesn't communicate *why* Pro is the recommended tier.

**Fix:** Combine color with structural differentiation: elevate the Pro card with a subtle drop shadow or a 4–8px border on all four sides, add a "Most popular" label at the top of the card (not just a color fill), and use a size increase of 4–8% on the price figure. This creates hierarchy legible without color.

---

**4. The feature comparison table needs a scan path**

Comparison tables are dense by nature. Without a clear scan path, users read them linearly, which is slow and cognitively expensive. B2B buyers typically scan vertically by feature row, not horizontally by tier.

**Fix:** Use alternating row fills (at minimum 3:1 contrast against the row baseline, not decorative) to create vertical rhythm. Pin the tier headers. Use explicit check, dash, and × tokens with text labels ("Included," "Not included") — do not use color or icon alone for feature availability signals.

---

**5. The testimonials strip is structurally low-priority**

Testimonials support a purchase decision, but on a pricing page they carry more weight if they appear close to the CTA or pricing tiers, not below a feature comparison table. By the time a user has read pricing and compared features, they are close to a decision; testimonials here can either close the deal or be ignored entirely depending on placement and format.

**Fix:** Consider moving one or two short testimonials — ideally from company names your target segment recognizes — to sit directly below the pricing table and above the comparison table. Save the full testimonials strip for a social-proof page or a marketing landing page.

---

### Color accessibility failure

The Pro tier color-coding is failing accessibility. This is a hard stop, not a polish note.

**Why it matters:** WCAG 2.1 SC 1.4.1 (Use of Color) prohibits using color as the only visual means of conveying information. SC 1.4.3 requires 4.5:1 contrast for text against any background. If the highlighted tier uses a colored card background without meeting these thresholds, it fails both rules.

**What to check:**
- Background color vs. card surface: non-text contrast must meet 3:1 (WCAG SC 1.4.11)
- Any text inside the highlighted card: 4.5:1 minimum, 7:1 preferred for body text
- The "Most popular" label if it uses only a color fill: must have a text or icon alternative

**Tooling:** Contrast Grid (Eightshapes), APCA Contrast Calculator for anything interactive or nuanced, Stark or Axe in browser for quick validation.

**Fix:** Audit the exact hex values in use against WCAG thresholds. If the brand color for Pro fails 4.5:1 against white text, either darken the background or switch to a dark text color. Add the structural differentiation described above so color is supporting the signal, not carrying it alone.

---

### Structural recommendation order

Fix these in sequence — each one is cheaper and more effective when the structural layer is solid first:

1. Compress or remove the hero. Let the pricing table lead.
2. Fix CTA size and label specificity.
3. Add structural tier differentiation (elevation, border, label).
4. Fix color contrast for the Pro tier.
5. Add scan path to the comparison table.
6. Reposition testimonials closer to the decision point.

---

### One explicit tradeoff to name

Compressing the hero sacrifices brand storytelling real estate on this page. You gain: faster time-to-pricing, reduced scroll cost, better hierarchy alignment with user intent, and a higher-priority CTA. What you give up is one more surface to reinforce the product's value framing before the user sees a number. If brand trust is low or the product is in a crowded category, a single strong supporting statement directly above the pricing table covers that job without requiring a full hero.

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "hierarchy_winner: pricing table leads, hero compressed",
    "intervention_order: structure → CTA → tier differentiation → color contrast → comparison scan path → testimonial placement",
    "tradeoff_resolution: brand storytelling real estate sacrificed to reduce scroll cost and time-to-pricing",
    "visual_confidence_boundary: audit based on described layout, not rendered artifact"
  ],
  "evidence_classes_cited": [
    "WCAG 2.1 SC 1.4.1 Use of Color",
    "WCAG 2.1 SC 1.4.3 Contrast Minimum",
    "WCAG 2.1 SC 1.4.11 Non-text Contrast",
    "WCAG 2.5.5 Target Size",
    "structural_failure: hierarchy inversion CTA vs hero",
    "structural_failure: color-only tier signal"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What are the exact hex values used for Pro tier highlighting? Contrast cannot be verified without them.",
    "Is there a free trial or is the primary CTA a demo request? Label specificity depends on this.",
    "What is the primary B2B buyer segment? Determines whether testimonial company names carry meaningful recognition."
  ],
  "turn": 1
}
[/SESSION_STATE]