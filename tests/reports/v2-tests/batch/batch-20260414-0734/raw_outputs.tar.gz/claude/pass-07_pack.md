Here's a rewritten version that earns its claims rather than asserting them, and builds a clear problem-to-outcome arc.

---

## Onboarding Redesign
**UX Design · Research · Prototyping**

---

### The problem

New users were dropping out of the onboarding flow before completing setup. The experience asked too much too soon, without giving users enough context to understand what they were committing to.

### Research findings

Moderated sessions and exit-survey analysis surfaced a consistent pattern: users could not map the setup steps to any outcome they cared about. The interface led with configuration decisions before establishing value, which created friction at the point where trust is most fragile.

### What I designed

I restructured the flow around a single principle: show the payoff before asking for the investment. That meant reordering steps so users reached a meaningful "aha" moment earlier, reducing the number of required decisions at entry, and surfacing inline context at the exact moments users were most likely to stall.

Wireframes went through two rounds of moderated testing with five users each before moving to high-fidelity prototypes. Engineering was involved from the first review cycle, which kept the interaction decisions grounded in what was actually feasible to ship.

### Outcome

Completion rate through the onboarding flow increased by 40% after launch. The structural change, rather than visual polish, drove the improvement.

### What I'd do differently

Instrumentation came in late. A clearer measurement plan before the first prototype would have sharpened which specific steps were responsible for the drop-off, and made the post-launch story easier to tell.

---

**A note on the 40% figure:** If you have a denominator, time window, or comparison baseline for that number, add it. "40% increase in completion rate over the 30 days following launch, compared to the prior 30-day baseline" is a claim a hiring panel can trust. Without it, the number still reads as credible here, but a recruiter may ask.

[SESSION_STATE]
{
  "route": "rt_case_study_rewrite",
  "escalation_level": "standard",
  "decisions_committed": [
    "claim_vs_proof_boundary: 40% completion rate increase named, with a note prompting the user to add denominator and time window",
    "proxy_vs_measured: exit surveys and moderated sessions named as research methods",
    "narrative_order: problem first, then research, then design rationale, then outcome, then reflection",
    "honesty_tradeoff: instrumentation gap named in retrospective section rather than omitted"
  ],
  "evidence_classes_cited": ["moderated_sessions", "exit_survey_analysis", "named_research_rounds"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the user have a denominator, time window, or comparison baseline for the 40% figure?",
    "Were the five-user rounds separate cohorts or overlapping participants?"
  ],
  "turn": 1
}
[/SESSION_STATE]