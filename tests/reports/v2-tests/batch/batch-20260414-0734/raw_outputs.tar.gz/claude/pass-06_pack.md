## Brand Positioning Pass

### Audience frame

Freelancers are not small businesses pretending to be enterprises. Their core anxieties are different: income unpredictability, client payment delays, tax opacity, and the feeling that financial tools were built for someone else. Trust for this audience does not come from gravitas or institutional signals. It comes from the tool visibly understanding how their work actually flows.

Stripe, Mercury, and Relay all index toward the founding team or the growing startup. Even Mercury's "for ambitious companies" framing assumes trajectory and team. Relay leans into organized finances for operators. Stripe is infrastructure, not identity.

The freelancer is consistently under-addressed as a primary audience, not a secondary one.

### Differentiation frame

The territory to own: **financial calm for people who work alone.**

Not empowerment. Not hustle amplification. Calm.

The competitors compete on capability and growth signals. None of them credibly own the emotional register of reduced anxiety for solo operators. That gap is real and defensible because it requires a product and communication posture that growth-focused fintechs structurally resist. A tool built for teams cannot easily pivot to feeling like it was built for one person.

Operational translation: every touchpoint should reduce the number of decisions a freelancer has to make about money. Not give them more dashboards. Not surface more data. Fewer, clearer answers to the questions that actually keep them up at night: did I get paid, do I owe taxes, is my cushion safe?

### Trust logic

The trust signal here is competence-in-context, not institutional weight.

Traditional bank trust = scale, permanence, regulation theater.
Mercury/Relay trust = clean UI, startup credibility, YC signaling.
The target trust for this brand = "this tool was built by someone who understands how a Tuesday in February feels when a client is 30 days late."

That trust is built through specificity, not through certifications or premium aesthetics. It means naming real freelancer situations rather than using generic financial language. It means the product does not ask the user to translate their work life into a business structure it was designed for.

Trust constraint: this only holds if the underlying product actually reduces friction for solo income flows. Positioning that outruns the product breaks trust faster in this audience than it would for a startup audience, because freelancers have lower switching costs and higher skepticism toward financial tools that have failed them before.

### Messaging consequence

The brand should not claim to be "not a bank." That framing centers the competitor and invites the comparison it wants to avoid.

Instead, the brand should talk fluently about the texture of freelance work: project cycles, payment timing, tax seasons, dry months. When a brand can name your situation without you explaining it, it earns trust before the product even loads.

Avoid: empowerment language, hustle adjacency, growth metrics as primary signals, "your business" framing that implies headcount.

Use: specific timeframes, income rhythm language, tax clarity as a feature not an afterthought, language that treats one person as a complete customer not a waiting-to-scale customer.

### Positioning territory summary

Own the specific emotional and operational territory that the competitors' growth orientation structurally prevents them from occupying: financial tools that were genuinely designed around how freelancers earn, not adapted from tools designed for teams.

The primary claim is not "we are friendlier." It is "we actually understand the problem you have."

That is a harder claim to fake, which is what makes it defensible.

### What you preserve and what you sacrifice

You preserve a real differentiation gap that incumbent fintechs cannot easily close without undermining their core positioning. You preserve emotional resonance with an audience that is underserved and vocal.

You sacrifice the credibility shorthand that comes with enterprise or startup adjacency. Freelancer-first positioning will read as small to some investors and growth-stage observers. If the company eventually wants to expand to small teams, the brand will need a deliberate bridge rather than a natural extension.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: freelancers as primary, not secondary audience",
    "differentiation_frame: financial calm for solo operators, not empowerment or growth",
    "trust_logic: competence-in-context, specificity over institutional weight",
    "messaging_consequence: avoid anti-bank framing, use income-rhythm language"
  ],
  "evidence_classes_cited": [
    "competitor_positioning_analysis",
    "audience_anxiety_model",
    "trust_logic_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the product currently reduce friction for solo income flows, or does positioning outrun capability?",
    "Is there an eventual expansion path to small teams that needs a brand bridge?"
  ],
  "turn": 1
}
[/SESSION_STATE]