## Dashboard Audit

**Dashboard role:** Operational/monitoring overview. The first view is meant to give a decision-maker a fast read on health and surface anything that needs attention. Right now it fails at the first scan.

---

### Key failures

**1. KPI row: numbers without context**

DAU, MRR, and churn rate as raw numbers with trend arrows tell the user the direction but not whether to care. A 3% churn arrow pointing up means something very different against a target of 1% versus a baseline of 4%. Without reference values, targets, or period-over-period comparisons, the user cannot convert the number into a decision. This is the highest-priority failure on the view because it corrupts the entire KPI row's signal quality.

*Fix:* Add a reference value next to or below each metric. The minimum viable version is a percentage change from the prior period with a clearly labeled comparison ("vs. last 30 days"). A stronger version adds a target or threshold line so the user can immediately see pass/fail status. Even a simple `3.2% / target 2.5%` removes the ambiguity.

**2. Line chart: four unnamed lines, legend below the fold**

Four colored lines on a 30-day chart are uninterpretable when the legend is not visible. The user has to scroll, map colors back mentally, then return to the chart. That is three cognitive round-trips for what should be a single glance. The missing Y-axis label compounds this: the user cannot tell if the axis represents raw count, percentage, or an indexed value, which changes how every line is read.

*Fix:* Move the legend inline, either directly labeling each line at its terminal point or placing the legend inside the chart frame above the lines. Add a Y-axis label. If four segments are genuinely all equal priority on the first view, confirm that with the product intent. If they are not all equal, consider surfacing the most critical segment as the primary line and using a "show all" expand for the rest.

**3. Sidebar: 12 ungrouped nav items**

Twelve flat nav items give the user no chunking signal. They all carry equal visual weight, which means the user must read every label linearly to find their destination. This is a scan-cost problem, not just an aesthetics problem. At 12 items, a user doing this four or five times a day will feel the friction.

*Fix:* Group into 3 to 5 logical clusters with a short header label per group (e.g., "Analytics," "Settings," "Reports"). This reduces the active scan from 12 individual items to 3 to 5 cluster reads. Secondary items can be hidden by default and revealed on hover or expand if some are low-frequency.

---

### Evidence and rationale

The KPI-row failure is a **signal quality** problem. Trend direction without a reference value is a display artifact, not a KPI. The minimum threshold for a useful KPI card is a value plus a comparison anchor.

The chart failure is a **scan-cost** problem. Placing a legend below the fold on a chart with four undifferentiated lines violates basic data-vis practice: the key that decodes the chart must be co-located with the chart. The missing Y-axis label introduces an **interpretation ambiguity**: the chart shape conveys trend but not magnitude or unit, which changes what conclusions are safe to draw.

The sidebar failure is a **cognitive load** problem. Research on menu chunking consistently shows that grouped items with labeled categories outperform flat lists above 7 items for navigation time and error rate. Twelve ungrouped items exceed that threshold by a meaningful margin.

---

### Recommended rebuild path

These should be addressed in order, not all at once:

1. **KPI context first.** Add reference values and period labels to all three KPI cards. This is low implementation cost and has the highest decision-quality payoff. Confirm what the right comparison anchors are with the product or data team before shipping.

2. **Chart legend and axis label.** Relocate the legend into the chart frame and add the Y-axis label. These are both presentation-layer changes and should not require data-model work. While doing this, confirm whether all four segment lines belong on the default view or whether one is primary.

3. **Sidebar grouping.** Group nav items into labeled clusters. This will require a short information-architecture decision about which items belong together, but it should not require any routing or permissions changes.

---

### Tradeoffs

Fixing the KPI row means committing to a comparison anchor. That choice is a product decision, not just a design decision: the team must agree on what "good" looks like before a target line can be honest. The cleaner path in the short term is period-over-period comparison, which requires no target agreement and can ship faster. The stronger path is target-based, which requires product alignment but delivers higher decision quality. Start with period-over-period, leave the target line as a planned upgrade.

Inlining the chart legend trades a little vertical space for a large gain in first-scan legibility. If vertical space is constrained on this view, end-of-line labels are more space-efficient than an inline box legend and still eliminate the scroll problem.

[SESSION_STATE]
{
  "route": "rt_dashboard_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "dashboard_type: operational/monitoring overview",
    "kpi_priority: KPI row is highest-priority failure due to missing reference values",
    "density_strategy: chart legend must be co-located; sidebar needs grouping into 3-5 clusters",
    "drilldown_or_filter_logic: four-segment line chart requires legend visibility and Y-axis label before filter/drill-down design is useful",
    "visual_confidence_boundary: findings based on user description only; no screenshot provided"
  ],
  "evidence_classes_cited": [
    "measurable_threshold",
    "state_or_behavior_rule",
    "comparison_artifact",
    "visual_structure_rule"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "What is the intended comparison anchor for each KPI card: period-over-period, target, or both?",
    "Are all four chart segments equal priority on the first view, or is one primary?",
    "Which nav items are high-frequency vs low-frequency, to inform grouping and possible progressive disclosure?"
  ],
  "turn": 1
}
[/SESSION_STATE]