Layout reconstruction from a legacy PDF is a specific evidence problem. Here is how to work through it systematically.

---

## What to extract from the PDF

### 1. Grid geometry

From the grid diagrams, extract:

- **Column count** per page format (A4, letter, or custom)
- **Gutter width** between columns (measure from diagram or stated spec)
- **Margin values** for all four sides (top, right, bottom, left — they are often asymmetric in brand documents, especially if binding was a consideration)
- **Column width** as either a stated value or a derivable value: `(page width − left margin − right margin − (gutters × (columns − 1))) ÷ columns`
- Whether the grid is **fixed-width** or **proportional** (percentage-based), which matters enormously for digital translation

### 2. Baseline and vertical rhythm

- **Baseline grid increment** — often 8pt, 10pt, or 12pt in 2018-era brand systems
- **Leading values** for body text, headings, and captions
- Whether type was set to sit **on** the baseline or **aligned optically**
- Any stated cap-height or x-height alignment rules

### 3. Typographic scale

Even if your goal is purely layout, extract the size relationships shown in examples. A type scale implies spacing logic. If 36pt display and 16pt body are the two sizes used, that ratio tells you something about breathing room expectations.

### 4. Spacing system

Look for:
- Minimum inter-element clearance values (often stated as "minimum white space around logo" or "minimum margin from edge")
- Whether spacing is expressed in **absolute units** (mm, pt) or **proportional** (10% of page width, etc.)
- Any named zones — safe areas, live areas, exclusion zones

### 5. Layout examples

For each layout example diagram in the PDF:
- Note the **column span** each element uses
- Note whether elements bleed, sit flush to margin, or sit inset from margin
- Look for a **text-to-image relationship** — does body copy always span a certain column range relative to image columns?
- Note whether there are fixed anchor points (e.g., page numbers always in the same position regardless of layout variant)

---

## What to flag as uncertain

Static diagrams carry ambiguity. Mark these as inferred until you can verify:

- **Stated values vs. measured values** — measure from diagrams only when values are not stated, and flag the measurement as estimated
- **Print-to-screen unit mapping** — a 20mm margin in a print system does not directly translate to pixels without a reference DPI and format decision
- **Whether the grid was descriptive or prescriptive** — some 2018 brand docs showed idealized layouts that no one actually followed consistently
- **Screen resolution context** — 2018 brand docs rarely included digital grid specs; if the document is print-only, you are building a digital interpretation, not a faithful port

---

## How to translate to a modern layout system

### Step 1: Choose your reference format

Decide the primary new format first. If you are building web templates, your reference is viewport width. If you are rebuilding print or presentation templates, keep the original page dimensions as the base.

For web:
- Map the original column count to a **standard grid token** (12 or 16 columns for complex layouts, 4 or 6 for simpler content-focused work)
- Convert absolute margins to **relative equivalents** using the original proportion, not the raw value

For print/presentation continuity:
- Keep original dimensions if the format is unchanged
- Rebuild in your authoring tool using the extracted column count, gutter width, and margin values directly

### Step 2: Build a unit translation table

| Source unit | Context | Modern equivalent |
|---|---|---|
| mm or pt | Print grid | Convert using 1pt = 1.333px at 96dpi, then round to nearest 4px increment |
| % of page | Proportional rule | Carry the percentage directly; express as CSS `%` or viewport units |
| Baseline grid increment | Vertical rhythm | Map to a spacing scale: 8pt baseline → 8px spacing unit |
| Leading ratio | Line height | Express as unitless ratio (e.g., 1.5 for body, 1.2 for headings) |

### Step 3: Validate proportions, not just raw numbers

The most reliable thing to carry forward from a 2018 system is **the proportional logic**, not the pixel-precise numbers. Ask:

- What fraction of the page width is margin? (If margins were 12.5% each side, preserve that ratio.)
- What is the gutter-to-column-width ratio? (A tight system has gutters at roughly 20–25% of column width; a generous system runs 33–50%.)
- What is the ratio of text column width to line length in characters? (Body copy should land between 45 and 75 characters per line regardless of the original unit system.)

### Step 4: Name the layout tokens

Translate extracted values into named design tokens rather than hardcoded values. This makes the reconstructed system usable as a system, not just a visual match.

Example token structure:
```
layout.margin.horizontal.default
layout.gutter.column
layout.grid.columns.default
layout.grid.columns.narrow
spacing.baseline
```

### Step 5: Write down the inference boundary

Document explicitly:
- What was stated in the source PDF
- What was measured and estimated
- What was inferred from layout examples
- What was designed new to fill gaps the 2018 doc did not address (digital, responsive behavior, small-screen behavior)

This matters later. When someone questions why the new grid uses 24px gutters instead of the "original" 6mm, you need to show the translation decision, not just the result.

---

## Common failure modes to avoid

**Do not port absolute values blindly.** A 20mm print margin at A4 width is about 7.5% of page width. At 1440px screen width that is roughly 108px — too large for a web layout. The proportion is valid; the raw number is not.

**Do not assume the diagram is exact.** Brand docs were often laid out in InDesign or Illustrator and the diagram might have been drawn roughly for illustration rather than measured precisely. If a stated value and a measured value disagree, trust the stated value and flag the discrepancy.

**Do not skip the vertical rhythm translation.** Most reconstructions focus on horizontal grid and miss baseline logic entirely. If the 2018 system had a disciplined 8pt baseline, rebuilding the horizontal grid without the vertical rhythm produces templates that look right at first glance but break when content varies.

**Do not treat this as a full-fidelity port if the format changes.** If the original was print and the output is digital, you are building a descendant system inspired by the original, not a replica. That is a legitimate design decision — but label it honestly.

---

## Practical next step

Once you have extracted the values, build one single reference template at your primary format using the reconstructed tokens. Overlay it against a scanned or exported page from the original PDF. Measure the visual alignment. That overlay is your verification receipt before you build out the full template set.

If you want, share the PDF or specific measurements you have already extracted and I can help you do the unit translation and token mapping directly.

[SESSION_STATE]
{
  "route": "rt_layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "governing_route: layout_reconstruction_plan",
    "inference_boundary: stated values preferred over measured estimates",
    "unit_translation: proportional logic preserved over raw value