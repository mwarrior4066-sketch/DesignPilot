## Front-End Architecture Review: Permissions-Heavy Scheduling Dashboard

**Route:** `frontend_implementation_review` | **Escalation:** compound
**Supporting skills:** accessibility-feedback-expert, back-end-aware-planner

---

### Architectural Framing

The current proposal treats this as a display problem with a big component. It is an authority problem with a rendering model. Role-based visibility, server-driven filters, and table-heavy screens are signals that most of the page's valid shape is determined before it reaches the browser. Defaulting to client-side rendering means the browser fetches data, discovers permissions, and then conditionally renders, which produces flash-of-wrong-content risk, inflated bundle cost, and state that must be re-derived on every load. The deeper problem is that separate boolean flags for loading and error state make impossible states representable, which means the code will silently reach `loading: false, error: false, data: undefined` and render ambiguously.

---

### Boundary and State Model

**Server/client split**

The permissions layer belongs on the server. Role-based visibility should be resolved at the data layer and reflected in what the server component receives, not handled with conditional renders in a client tree. The scheduling table rows and column visibility that change by role should come from the server as already-shaped data, not as a full dataset that the client then masks.

Recommended split:

| Layer | Ownership |
|---|---|
| Permission-gated row and column shape | Server component, resolved via session/auth context |
| Server-driven filters (active state, available options) | Server component, passed as props or via URL search params |
| Table render with stable shape | Server component with Suspense boundary |
| Optimistic edit mutations | Client component, isolated to the mutation surface only |
| Filter chip interaction (toggle UI state) | Client component, scoped to filter bar only |

The `use client` boundary should sit at the mutation surface and the interactive filter bar, not at the page root. A page-root `use client` directive forces every table row, every column header, and every permission gate into the client bundle.

**State model**

Replace the separate boolean pattern with a status union. This is not optional for a scheduling dashboard with recurring edits, because the boolean pattern cannot safely represent the transition from a failed optimistic update back to the confirmed server state.

```typescript
type ScheduleViewState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: ScheduleData }
  | { status: 'error'; error: ApiError }
  | { status: 'mutating'; optimisticData: ScheduleData; previousData: ScheduleData };
```

The `mutating` variant carries both the optimistic projection and the rollback surface explicitly. When the server rejects the recurring edit, `previousData` is what you restore, not a stale ref.

For React 19 / Next.js App Router: `useOptimistic` handles the optimistic projection, `useActionState` owns the async action lifecycle, and `useFormStatus` drives pending state for submit controls. None of these require a separate loading boolean.

---

### Rendering and Mutation Strategy

**Rendering**

Use Partial Prerendering (PPR) if on Next.js 15, or static shell with Suspense streaming otherwise. The static shell carries navigation, column headers, and the filter bar skeleton. The dynamic slot is the table data, which streams in behind a Suspense boundary. This keeps Time to First Byte low and separates the permission-gated content from the structural chrome.

For the table specifically: if row count is large and permission-gated columns vary by role, consider server-side pagination with keyset cursors rather than loading the full dataset and filtering in the client. The client should not need to know which rows it was not supposed to see.

**Optimistic updates for recurring edits**

This is the highest-risk surface in the proposal. Recurring edits have fan-out: editing one instance can affect a series. The optimistic update must be scoped correctly or it will show a false state for the entire series when only one instance was confirmed.

Safe approach:

1. Scope `useOptimistic` to the single event instance being edited, not the series.
2. Server action resolves the recurrence rule on the server and returns the canonical updated shape.
3. On confirmation, revalidate the relevant date range with `revalidatePath` or `revalidateTag`, replacing the optimistic projection with the server truth.
4. On rejection, roll back to `previousData` and surface the error through `useActionState` state, not a separate error boolean.

Do not apply optimistic updates to the full recurring series client-side. The server owns recurrence logic.

**Server-driven filters**

Filters belong in URL search params, not component state. This keeps filter state shareable, bookmarkable, survivable across navigation, and readable by the server component without a client fetch. The filter bar client component reads from `searchParams`, writes to `router.push` or `router.replace`, and the server component re-renders with the new filter shape without a client-side data fetch.

---

### Risks and Safer Path

**Custom div buttons for filter chips**

This is a hard stop. `div` elements with click handlers are not keyboard reachable by default, do not announce their toggled state to screen readers, and do not receive focus on tab. A filter chip is a toggle button. Use `<button>` with `aria-pressed` to communicate the on/off state, and ensure the focus ring is visible. If the chip represents a checkbox-style multi-select, use `role="checkbox"` with `aria-checked`. Either way, the semantic element must carry the interaction contract.

```tsx
// Correct pattern
<button
  type="button"
  aria-pressed={isActive}
  className={isActive ? styles.chipActive : styles.chip}
  onClick={() => toggleFilter(filter.id)}
>
  {filter.label}
</button>
```

**Role-based visibility cost**

If role resolution happens in the client, you are shipping filtered data plus the filtering logic to every browser session, including the ones that should never see certain rows. Role gates belong on the server or at the API layer, not in a `{userRole === 'admin' && <Column />}` conditional.

**Identified cost surfaces**

| Risk | Cost |
|---|---|
| Page-root `use client` | Full table in client bundle, no streaming |
| Boolean loading/error flags | Impossible states, silent render ambiguity |
| Div filter chips | Keyboard unreachable, ARIA state missing |
| Optimistic update on full series | False series state on rejection |
| Client-side role filtering | Permission data leak risk, bundle inflation |

**Safer build order**

1. Establish auth/role resolution at the data layer before any UI work starts.
2. Define the status union and server action shape before building the table.
3. Build the server component table shell with Suspense boundary.
4. Add the filter bar as an isolated client component writing to search params.
5. Add optimistic edit as a scoped client component on the single-event mutation surface only.
6. Verify keyboard navigation and `aria-pressed` on filter chips before shipping the filter bar.
7. Run a focused screen reader pass on the table after role-gating is wired.

---

**Tradeoff being made:** Splitting the `use client` boundary and moving role resolution to the server costs some initial setup complexity in the data layer. What it preserves is a smaller client bundle, no permission-leak risk, correct streaming behavior, and a state model that cannot silently reach an ambiguous render. The optimistic scope constraint sacrifices the feel of instant series-wide feedback in exchange for correctness when the server rejects a recurrence rule.

[