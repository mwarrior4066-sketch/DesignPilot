## API Review: POST /api/v1/projects/{id}/members

Route: `api_reliability_security_review` | Supporting: `backend_architecture_spec`

---

### 1. Authorization perimeter

**Governing decision: deny by default at the object level, not the session level.**

Checking that the caller is authenticated is a session-level gate. It is not an authorization check. This endpoint mutates project membership, which means the caller must also be verified as a project admin (or equivalent role) for *that specific project* before the operation proceeds.

The current design has a BFLA exposure: any authenticated user can POST to any project they know the ID of. If project IDs are sequential or guessable, the surface is wide. Even with opaque IDs, insider enumeration is trivial.

Fix: add an explicit object-level check. Before writing anything, verify that `caller.id` holds the `admin` (or `member:invite`) permission on `project:{id}`. Deny with `403 Forbidden` if not. The auth layer should not be able to be satisfied by login state alone.

---

### 2. Status code contract

**Governing decision: a mutation that creates a new resource relationship must return 201 Created, not 200 OK.**

Returning `200` on a successful POST that adds a member implies the state was already correct or that this is an idempotent update. Adding a member is a resource creation event (a membership record). `201 Created` is the correct signal. Include a `Location` header pointing to the new membership resource or the updated member list.

This distinction also matters for client retry logic. A client that receives `200` on first attempt and then retries has no signal about whether the second call created a duplicate or was a no-op.

---

### 3. Idempotency

**Governing decision: mutations that create records must carry an idempotency key so retries do not duplicate state.**

No idempotency key means a network timeout followed by a client retry creates a second membership record (or triggers a second invite, a second email, a second audit event). The server has no way to detect the replay.

Fix: require a client-generated `Idempotency-Key` header. The server stores the key with a TTL (typically 24 hours). On first receipt it executes and stores the result. On replay it returns the stored result with the same status code, without re-executing. Return `409 Conflict` if the same key is reused with a different body (fingerprint mismatch). Return `422 Unprocessable` if the key is malformed.

This is especially important for a membership endpoint where side effects (emails, webhooks, audit logs) are common.

---

### 4. Error envelope

**Governing decision: structured failure semantics using RFC 9457 Problem Details, not plain strings.**

A plain string error response means:

- The client cannot branch on error type programmatically without string parsing.
- Monitoring and alerting cannot classify failure categories without custom log parsing.
- Localization is impossible without re-engineering the response contract.

Replace with `application/problem+json`:

```json
{
  "type": "https://api.example.com/problems/forbidden",
  "title": "Insufficient permissions",
  "status": 403,
  "detail": "Caller does not hold the member:invite permission on this project.",
  "instance": "/api/v1/projects/abc123/members"
}
```

Required fields for this endpoint: `type` (machine-readable URI), `title` (human-readable summary), `status` (HTTP code repeated), `detail` (specific context), `instance` (request path). The `type` URI does not need to resolve but should be stable and documented.

---

### 5. Response body design

**Governing decision: return the created membership record, not the full updated member list.**

Returning the full member list on every add has two problems. First, it leaks the full membership roster to any caller who can successfully add a member, which may include users who should not enumerate all project members. Second, it does not scale: a project with hundreds of members returns a large payload on every single mutation.

Return the created membership object instead:

```json
{
  "id": "membership:xyz",
  "project_id": "abc123",
  "user_id": "user:789",
  "role": "member",
  "added_by": "user:001",
  "added_at": "2025-01-15T10:30:00Z"
}
```

If the caller genuinely needs the full list, that belongs on a separate `GET /api/v1/projects/{id}/members` endpoint with its own authorization check and pagination.

---

### 6. Tradeoff summary

| Concern | Current state | Required fix | What you preserve |
|---|---|---|---|
| Authorization | Session-level only | Object-level admin check on `project:{id}` | Blocks BFLA without changing the route structure |
| Status code | 200 | 201 + Location header | Correct retry signal and resource semantics |
| Idempotency | None | `Idempotency-Key` header with fingerprint + TTL | Prevents duplicate memberships on retry |
| Error shape | Plain string | RFC 9457 `application/problem+json` | Enables programmatic error handling and observability |
| Response body | Full member list | Created membership record only | Prevents membership enumeration and payload bloat |

No single fix here is cosmetic. The authorization gap is the highest-risk item and should be resolved before the endpoint ships. The idempotency and error shape changes can follow in the same sprint with low implementation cost.

[SESSION_STATE]
{
  "route": "api_reliability_security_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "authorization_perimeter: object-level admin check required on project:{id}, deny by default",
    "problem_details_contract: RFC 9457 application/problem+json replaces plain string errors",
    "idempotency_contract: client-generated Idempotency-Key with fingerprint, TTL, 409 on mismatch",
    "async_job_model: not applicable for this synchronous mutation",
    "status_code: 201 Created with Location header replaces 200 OK",
    "response_body: created membership record only, not full member list"
  ],
  "evidence_classes_cited": [
    "failure_semantics_rule",
    "permission_rule",
    "async_lifecycle_rule",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the platform have an existing idempotency-key store or does this need to be built?",
    "What is the intended authorization model for the project: RBAC, ABAC, or ReBAC?",
    "Should member addition trigger async side effects (email, webhook, audit log) that need their own job lifecycle?"
  ],
  "turn": 1
}
[/SESSION_STATE]