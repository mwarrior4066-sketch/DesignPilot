## Split Button — Component Specification

---

### Purpose and Scope

The split button serves a primary action (Save) alongside a disclosed set of secondary actions (Save as draft, Save and close) via a separate dropdown trigger. It exists wherever a user has one clear primary intent but may need one of a small number of related alternatives.

The component owns: the primary action button, the dropdown trigger button, the dropdown menu panel, and the state machine that governs both halves. It does not own: the save logic itself, the page-level form state, or the modal/sheet layer that may appear on Save and close.

---

### Anatomy

| Part | Role | Notes |
|---|---|---|
| Primary button | Executes the default action (Save) | Full label visible; carries the main interactive weight |
| Divider | Visual and semantic separator | Not interactive; present in all non-loading states |
| Dropdown trigger | Opens the secondary action menu | A standalone button with its own focus stop and aria contract |
| Dropdown panel | Contains the secondary action list | Positioned below, left-aligned to the trigger; governed by the popover/menu pattern |
| Menu items | Save as draft, Save and close | Each is a `menuitem` role inside a `menu` role container |

The two buttons are siblings, not nested. The primary button and dropdown trigger must each be a real `<button>` element. Do not use a single button with split regions and click-zone detection.

---

### State Matrix

| State | Primary button | Dropdown trigger | Dropdown panel | Notes |
|---|---|---|---|---|
| Default | Active, labeled Save | Active, chevron icon + aria-label | Closed | Normal resting state |
| Primary hover | Elevated background | — | Closed | Hover applies to each half independently |
| Trigger hover | — | Elevated background | Closed | |
| Primary focus | Focus ring visible | — | Closed | Must meet WCAG 2.1 SC 2.4.11: focus not obscured |
| Trigger focus | — | Focus ring visible | Closed | |
| Menu open | Active, receives no focus | Active, aria-expanded=true | Open, first item focused | Focus moves into the menu on open |
| Menu item focus | Active | Active | Item highlighted | Arrow key navigation within menu |
| Primary loading | Spinner replaces label, aria-busy=true | Disabled, dimmed | Closed, not openable | Both halves are read-only while saving |
| Both disabled | Disabled, aria-disabled=true | Disabled, aria-disabled=true | Closed, not openable | Full component disabled |
| Primary disabled only | Disabled | Active | Operable | Uncommon; use only when the primary action is specifically unavailable |
| Error (after save attempt) | Active, error state | Active | — | Error feedback lives outside the component; component reverts to default |

**Edge states to specify in implementation:**
- If Save completes while the menu is open, close the menu and resolve loading.
- If the user clicks away from an open menu without selecting, close the panel and return focus to the dropdown trigger.
- Do not allow the menu to open while the primary loading state is active.

---

### Keyboard Support

| Key | Context | Behavior |
|---|---|---|
| `Tab` | Any | Moves focus to the primary button, then to the dropdown trigger, then out of the component. Two tab stops total. |
| `Enter` or `Space` | Primary button focused | Executes Save. |
| `Enter` or `Space` | Dropdown trigger focused | Opens the menu; moves focus to the first menu item. |
| `↓` Arrow | Menu open | Moves focus to the next menu item; wraps from last to first. |
| `↑` Arrow | Menu open | Moves focus to the previous menu item; wraps from first to last. |
| `Enter` or `Space` | Menu item focused | Executes that action; closes the menu. |
| `Escape` | Menu open | Closes the menu; returns focus to the dropdown trigger. |
| `Tab` | Menu open | Closes the menu; moves focus forward past the component. Do not trap. |
| `Shift+Tab` | Menu open | Closes the menu; moves focus backward. |

The menu follows the [ARIA Authoring Practices Guide Menu Button pattern](https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/). Do not implement a combobox or listbox pattern for this use case.

---

### ARIA Contract

```html
<!-- Default state -->
<div role="group" aria-label="Save options">

  <button type="submit" id="split-btn-primary">
    Save
  </button>

  <button
    type="button"
    id="split-btn-trigger"
    aria-haspopup="menu"
    aria-expanded="false"
    aria-controls="split-btn-menu"
    aria-label="More save options"
  >
    <span aria-hidden="true">▾</span>
  </button>

  <ul
    role="menu"
    id="split-btn-menu"
    aria-labelledby="split-btn-trigger"
    hidden
  >
    <li role="none">
      <button role="menuitem">Save as draft</button>
    </li>
    <li role="none">
      <button role="menuitem">Save and close</button>
    </li>
  </ul>

</div>

<!-- Loading state -->
<button type="submit" aria-busy="true" aria-label="Saving…" disabled>
  <span aria-hidden="true"><!-- spinner svg --></span>
</button>

<!-- Disabled state -->
<button type="submit" aria-disabled="true" disabled>Save</button>
```

Use `role="group"` on the wrapper, not `role="toolbar"`. A toolbar implies a collection of controls for editing; this is a single action group.

When loading, `aria-label="Saving…"` on the primary button provides the live announcement. Do not rely solely on a visual spinner.

---

### Accessibility and Implementation Notes

**Touch targets.** Each button half must meet a minimum interactive target of 44×44px (WCAG 2.5.5) or 24×24px minimum with no adjacent target closer than 24px (WCAG 2.5.8). On mobile, prefer 48×48px targets. The divider region must not register as a hit target.

**Color and non-color distinction.** The divider between halves must be visible at 3:1 contrast against the button surface (WCAG 1.4.11, non-text contrast). Do not use the divider color as the only indicator that two separate controls exist — the two-stop tab order and the distinct aria-label on the trigger also establish this.

**Focus ring.** Use `:focus-visible` for keyboard focus rings. Do not suppress focus rings globally. The ring must not be obscured by sticky headers or overlapping containers.

**Loading state.** When loading begins, set `aria-busy="true"` and `disabled` on both buttons. Announce the completion via a live region or by updating the label (e.g., Saved), not by relying on visual state change alone. Reverting the label back to Save after confirmation is acceptable.

**Disabled behavior.** Use `disabled` on the `<button>` element rather than `aria-disabled` alone when the button is truly inoperable. Use `aria-disabled="true"` without the `disabled` attribute only when you need the element to remain focusable for context (for example, when a tooltip explains why it is disabled).

**Token boundaries.**
- `