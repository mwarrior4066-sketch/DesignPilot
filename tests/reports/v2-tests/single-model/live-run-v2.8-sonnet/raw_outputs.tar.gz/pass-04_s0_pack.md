## Backend Feasibility Review: Real-Time Collaboration on a REST/PostgreSQL Stack

---

### Requested capability

Add Google Docs-style simultaneous editing with visible cursors, conflict resolution, and persistent state to an existing React app backed by REST APIs and PostgreSQL.

The visible ask is straightforward. The hidden system requirements are substantial and touch every layer of the stack.

---

### Hidden system requirements

**1. Persistent bidirectional transport**

REST is request-response. Real-time collaboration requires a persistent connection so the server can push to clients without polling. Your options are WebSockets (most common), Server-Sent Events (server-push only, simpler but one-way), or a long-polling fallback. This is not a REST endpoint addition. It is a new transport layer that needs its own connection lifecycle, auth handshake, reconnection logic, and scalability model.

**2. Operational Transformation or CRDT merge layer**

When two users edit the same character position simultaneously, "last write wins" produces data loss. You need a merge algorithm. The two credible options are:

- **OT (Operational Transformation):** Operations are transformed against each other before applying. Deterministic but requires a central server authority to serialize and apply operations in order. The server must be stateful for the duration of the document session.
- **CRDT (Conflict-free Replicated Data Type):** Data structures that merge without coordination. Eventual consistency is guaranteed mathematically. Better for peer-to-peer or eventually-consistent scenarios, but adds storage and memory overhead per document. Libraries like Yjs (Y.Doc) and Automerge are mature options.

For a PostgreSQL-backed app, OT with a central relay is simpler to reason about. Yjs with a Yjs WebSocket provider (y-websocket) is the most common production path and handles both.

**3. Document state model changes**

Your PostgreSQL schema currently stores document content as a flat field (likely a text column or JSON blob). Real-time collaboration requires storing:

- An authoritative document state (the current merged snapshot)
- An operation log or CRDT state vector for each document session
- Cursor/presence records (ephemeral, not necessarily persisted to PostgreSQL)
- Client clock or version vectors for conflict detection

That means schema changes, likely a new `document_operations` table, a `document_sessions` table, and a presence channel. These are not additive to the existing REST data model. They change the ownership model for what "the document" means.

**4. Authority and session ownership**

With REST, every request is stateless. With real-time collaboration, someone must own the document session. Questions that must be answered before any line of code is written:

- Who is the session authority? (A WebSocket server process? A queue consumer?)
- What happens when the session server dies mid-edit? (Reconnect with state recovery, or data loss?)
- Can multiple WebSocket server instances serve the same document? (Not without a shared pub/sub layer like Redis Pub/Sub or a message queue.)
- How does an existing REST save interact with live collaborative state? If a user saves via the old REST API while a WebSocket session is active, which wins?

**5. Horizontal scaling and shared state**

Your existing REST app almost certainly runs stateless, meaning you can add instances freely. A WebSocket server is stateful for the lifetime of each connection. If you have two WebSocket server instances and two users on the same document end up on different instances, their edits will never merge unless there is a shared coordination layer between instances. Redis Pub/Sub or a managed real-time service (Ably, Liveblocks, Supabase Realtime) solves this, but it is a new infrastructure dependency.

**6. Auth on the WebSocket handshake**

Your REST auth (likely JWT or session cookie) must be validated at WebSocket connection time, not just at the HTTP upgrade. This is easy to forget. The risks are: unauthenticated users joining document sessions, or users retaining a WebSocket connection after their session is revoked. Token expiry and connection teardown must be explicitly handled.

**7. Cursor and presence data**

Cursor positions are high-frequency, low-durability events. Persisting them to PostgreSQL on every keystroke would destroy database performance. Cursor state belongs in an ephemeral layer: Redis (with short TTL), an in-memory store on the WebSocket server, or a dedicated presence service. This is a separate data ownership decision from document persistence.

**8. Persistence, durability, and the operation log**

You must decide what you actually commit to PostgreSQL and when. Two patterns:

- **Write-through on every operation:** Low latency recovery, high write load on Postgres.
- **Checkpoint with in-memory buffer:** Batch operations, then snapshot to Postgres periodically. Faster, but there is a durability window where data exists only in memory. If the process crashes in that window, recent edits are lost.

Neither is wrong. Both must be a deliberate decision, not an accident.

---

### Feasibility assessment

**Can this be built on your current stack? Yes, with additions.**

**What blocks naive implementation:**

| Blocker | Why it matters |
|---|---|
| REST-only transport | REST cannot push to clients. A WebSocket layer must be added before anything else. |
| Flat document storage model | The current PostgreSQL schema cannot represent operation logs, version vectors, or CRDT state without migration. Schema changes must come before collaborative logic. |
| Stateless REST auth not covering WS | The auth system must explicitly handle WebSocket connection auth and token revocation. Skipping this creates a security gap. |
| Single-process assumption | If the app runs multiple instances, a shared pub/sub layer (Redis or managed service) is required before WebSocket servers can talk to each other. |
| "Last write wins" REST save | If the existing REST save endpoint still fires during a collaborative session, it will overwrite the merged state. The REST write path must be gated or deprecated for documents under active collaboration. |

**Feasibility verdict by approach:**

- **Build entirely in-house (WebSocket server, OT/CRDT, operation log):** Feasible, but 3 to 6 months of focused backend engineering. The merge algorithm alone has edge cases that take significant time to get right.
- **Use Yjs with y-websocket:** Substantially reduces the merge-algorithm problem. Yjs is well-tested and has React bindings (y-react, TipTap, ProseMirror-yjs). You still own the persistence, auth, and scaling layers. More realistic path.
- **Use a managed real-time backend (Liveblocks, Ably, Supabase Realtime):** Delegates presence, merge, and transport to the vendor. Your PostgreSQL schema still needs the operation log and persistence model changes, but the hard coordination problems are off your plate. This is the lowest-risk path for a team that has not built this before.

---

### Safer implementation path

**Phase 1: Foundation (do this before writing any collaboration code)**

- Add WebSocket transport layer. Gate it behind a feature flag so the REST path remains the fallback.
- Validate auth at WebSocket handshake. Explicitly handle token expiry and forced disconnection.
- Migrate the PostgreSQL schema: add a `document_operations` table and a `document_sessions` table. Do not touch the existing document content column yet.
- Decide the persistence model: write-through or checkpoint. This decision affects the schema, the operation log, and the recovery behavior. Commit to one before Phase 2.
- Gate the existing REST document save endpoint: if a WebSocket session is active for a document, the REST write path must either be blocked or merged through the same operation log. Do not allow two independent write paths to the same document.

**Phase 2: Collaboration kernel (