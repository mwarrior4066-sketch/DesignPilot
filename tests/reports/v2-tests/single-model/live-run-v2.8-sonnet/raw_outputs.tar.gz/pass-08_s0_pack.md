## Accessibility Audit: Mobile App

Four structural barriers, prioritized by severity and fix order.

---

### Barrier 1: Icon-only bottom navigation (Critical)

**What fails:** Unlabeled icon buttons have no accessible name. Screen readers announce generic descriptions like "button" or nothing useful. Sighted users also lose context when icons are ambiguous.

**WCAG reference:** 1.1.1 Non-text Content (Level A), 4.1.2 Name, Role, Value (Level A)

**Fix:** Add visible text labels beneath each icon. This is the stronger solution. If stakeholders resist visible labels, add `aria-label` per button as a minimum, but visible labels reduce cognitive load for all users including those with cognitive disabilities, low vision, and situational impairment (one hand occupied, glare). The 44px minimum touch target must also be maintained after the label is added.

**Verification:** Tab through the nav bar with a screen reader (VoiceOver or TalkBack). Each button must announce a meaningful destination name, not "image" or "button."

---

### Barrier 2: Placeholder-only form inputs (Critical)

**What fails:** Placeholder text disappears on focus, leaving users with no memory cue for what the field requires. Screen readers frequently announce placeholder as the accessible name, but placeholders are not a substitute for labels under WCAG 1.3.1 Info and Relationships or 2.4.6 Headings and Labels. Users with cognitive disabilities, short-term memory impairment, or motor conditions that slow typing are disproportionately affected.

**WCAG reference:** 1.3.1 Info and Relationships (Level A), 2.4.6 Headings and Labels (Level AA), 3.3.2 Labels or Instructions (Level A)

**Fix:** Add a persistent visible label above or beside each field. Use `<label for>` association in markup. If floating labels are used, the label must remain visible in the focused state, not disappear into the placeholder position. Placeholder text may remain as supplementary hint text after the label is in place.

**Verification:** Focus each field and confirm the label is visible. Test with a screen reader: the announced field name must survive after the user begins typing.

---

### Barrier 3: Color-only error messaging (High)

**What fails:** Red text alone uses color as the sole means of conveying information. This fails users with color vision deficiency (approximately 8% of males) and fails WCAG 1.4.1 Use of Color. The red text also needs to meet the 4.5:1 contrast ratio against its background.

**WCAG reference:** 1.4.1 Use of Color (Level A), 1.4.3 Contrast Minimum (Level AA)

**Fix two things separately:**

1. Add a non-color signal: an error icon (warning or exclamation mark) before the message, or an "Error:" prefix in text. The icon needs an `aria-label` or must be accompanied by visible text, not rely on color alone to carry meaning.
2. Confirm the red text meets 4.5:1 contrast against the background. Many "error red" values fail at small text sizes, especially on white.

**Programmatic requirement:** The error message must also be associated with its field via `aria-describedby` so screen readers announce the error when the field receives focus, not only when the user navigates to the error text separately.

**Verification:** View the form in a grayscale filter. Errors must remain distinguishable from success states. Test with a screen reader: focus the errored field and confirm the error message is announced.

---

### Barrier 4: Silent loading spinner (High)

**What fails:** A spinner with no programmatic state announcement is invisible to screen reader users. They receive no feedback that the system is working, which leads to repeated interaction attempts or abandonment.

**WCAG reference:** 4.1.3 Status Messages (Level AA)

**Fix:** Add a live region to the spinner container:

```html
<div role="status" aria-live="polite" aria-label="Loading">
  <!-- spinner markup -->
</div>
```

Use `aria-live="polite"` for non-critical loading states. Use `aria-live="assertive"` only when the operation is blocking and the user cannot proceed. When loading completes, update the live region or remove it so the screen reader announces completion or the new content.

**Avoid:** Do not set `aria-busy="true"` on the entire page container unless the full page is genuinely blocked. Scoped live regions are safer and less disruptive.

**Verification:** Trigger the loading state with a screen reader active. VoiceOver and TalkBack should announce "Loading" without the user navigating to the spinner. Confirm the announcement stops when loading completes.

---

### Repair order

| Priority | Barrier | WCAG Level | Effort |
|---|---|---|---|
| 1 | Placeholder-only labels | A | Medium |
| 2 | Icon-only nav labels | A | Low to medium |
| 3 | Color-only errors + aria-describedby | A / AA | Low |
| 4 | Silent spinner live region | AA | Low |

Start with the label and nav fixes. They are Level A failures and affect the largest share of users. The error and spinner fixes are low effort and should be bundled into the same sprint.

---

### Verification stack

Test each fix with:
- **VoiceOver** (iOS) or **TalkBack** (Android) with keyboard or swipe navigation
- **Grayscale mode** for color-only failures
- **Axe or Deque mobile** for automated signal coverage
- **Manual keyboard-only pass** after each fix

Automated tools will catch some of these. The label association, live region behavior, and nav announcement quality require manual screen reader verification.

[SESSION_STATE]
{
  "route": "accessibility_feedback_audit",
  "escalation_level": "standard",
  "decisions_committed": [
    "blocked_user_action: icon-only nav has no accessible name, placeholder fields lose label on focus, color-only errors fail non-sighted and color-deficient users, spinner is silent to screen readers",
    "priority_order: label/nav fixes first (Level A), error and spinner fixes second (Level AA, low effort)",
    "behavior_rule: aria-live polite for spinner, aria-describedby for error association, label-for association for inputs, aria-label for nav icons minimum",
    "verification_step: VoiceOver/TalkBack manual pass, grayscale filter, axe automated scan, keyboard-only navigation"
  ],
  "evidence_classes_cited": [
    "standards_reference",
    "state_or_behavior_rule",
    "verification_method"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Are floating labels in use on any form fields, or are all fields placeholder-only?",
    "Is the loading spinner used in blocking contexts (full-page) or scoped contexts (inline)? This affects aria-live assertive vs polite choice."
  ],
  "turn": 1
}
[/SESSION_STATE]