## Brand Positioning Pass

### Audience and Problem

**Segment:** Independent freelancers — designers, developers, consultants, writers — who earn project income, deal with irregular cash flow, and manage their own taxes and invoicing without a finance team behind them.

**Perception gap:** Existing tools either feel built for companies (Mercury, Relay pitch to startups and funded teams) or built for transactions rather than people (Stripe is infrastructure, not a financial home). Traditional banks feel bureaucratic and indifferent to non-salaried income patterns. Freelancers are underserved not because no product exists, but because none of the existing ones treats irregular income as the normal condition rather than the edge case.

---

### Positioning Frame

**Category:** Financial tools for people who work for themselves, not financial tools for businesses that happen to have one employee.

**Frame of reference:** Not a bank. Not a payments processor. A financial operating layer built around the freelance income model — variable income, multiple clients, tax responsibility, and the psychological weight of being your own finance department.

**Wedge against the field:**

- Stripe owns infrastructure. It is the plumbing. Positioning against it directly is a category error — it is not trying to be your financial home.
- Mercury and Relay are excellent, but they are pitched at funded startups or small teams. Their language is growth-stage and investor-facing. A solo freelancer feels like a second-class citizen there.
- The open territory is: **"built for how you actually get paid."** Not for MRR, runway, or headcount — for net-30 invoices, lumpy months, retainer transitions, and quarterly tax pulls.

**Positioning claim (internal compass, not tagline):**
The only financial tool that treats irregular income as the starting assumption, not the exception.

---

### Trust and Proof Burden

**Trust signal needed:** Freelancers are suspicious of financial products because the history is bad — hidden fees, accounts frozen for "unusual activity" (which is just how freelancers operate), and UX built for salaried expectations.

The trust receipts that matter here are behavioral, not badge-based:

- Transparent, flat pricing with no "business tier" surprises
- Visible tax reserve tooling (proves the product understands the actual problem)
- No holds on common freelance transaction patterns (large one-off transfers, multiple small clients, sporadic deposit volume)
- Real human support that understands self-employment — not a bot trained on corporate account questions

**Credibility tradeoff:** Claiming "trustworthy" without behavioral proof will backfire with this audience. They are experienced enough to be skeptical. Trust is earned through product behavior and honest fee language, not through the word "trust" appearing in the tagline.

---

### Messaging Consequences

**What the brand should sound like:**
Direct, specific, and written by someone who has also sent a late-night invoice. Not warm in a corporate-wellness way. Warm in a "I actually understand your problem" way.

**Avoid:**
- "Empower your business" — too generic, implies a business structure they may not identify with
- "Bank-grade security" — leads with the thing they distrust
- "Simple banking for freelancers" — undersells the product and invites commodity comparison

**Should sound like:**
- Problem-first language: "You got paid. Here is where it goes, what you owe, and what is yours."
- Specificity over aspiration: name the actual pain (tax reserves, invoice payment lags, client payment variance) rather than abstracting it into "financial freedom"
- Peer register, not brand register: written for someone who already knows how freelance finance works, not someone who needs to be told it is complicated

**Territory to own in one phrase:**
"Built for irregular income" — it is defensible, true, and immediately legible to the audience. Mercury and Relay cannot say it without undermining their core pitch. Stripe will never say it. Banks cannot say it honestly.

---

**The one positioning decision that matters most here:** Do not try to own "approachable bank." Own the income model. The approachability follows from being the tool that finally understands how freelancers get paid — you do not have to manufacture it with soft colors and friendly copy.

[SESSION_STATE]
{
  "route": "rt_brand_positioning_pass",
  "escalation_level": "standard",
  "decisions_committed": [
    "audience_frame: independent freelancers with irregular income — not startups, not salaried workers",
    "differentiation_frame: positioned against Mercury/Relay (startup-first) and Stripe (infrastructure), not against banks directly",
    "trust_logic: behavioral proof required — transparent pricing, tax reserve tooling, no holds on freelance transaction patterns",
    "messaging_consequence: problem-first language, peer register, specificity over aspiration, own the income model not the bank category"
  ],
  "evidence_classes_cited": [
    "comparison_artifact",
    "file_backed_receipt",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the startup have any existing proof artifacts — pricing model, tax reserve feature, or early user data — that could sharpen the trust signal section?",
    "Is the primary acquisition channel community-based (freelancer forums, Slack groups) or paid? This affects how aggressive the peer-register tone should be."
  ],
  "turn": 1
}
[/SESSION_STATE]