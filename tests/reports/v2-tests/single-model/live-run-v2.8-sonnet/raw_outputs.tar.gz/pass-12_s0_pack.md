# Type System Recommendation: Fintech Product

## Reading context

Three distinct reading environments, each with different demands:

- **Marketing site** - long-form scanning, display headlines, moderate density, trust-building first impression
- **Web app dashboard** - dense tabular data, small labels, KPIs, tight line-height, high cognitive load
- **Mobile** - touch-first, reduced horizontal space, legibility at variable viewing distances, OS font fallback matters

The governing constraint is the dashboard. Tabular financial data requires a typeface with a **true monospaced or tabular numeral set** (tnum + lnum), reliable optical sizing across tight leading, and sufficient weight range to carry hierarchy without visual noise.

---

## Scale and role map

### Primary typeface: Inter (variable)

Inter is the anchor across all three surfaces. Rational humanist sans with exceptional legibility at small sizes, strong tabular figure support, and a variable axis that covers the full weight range in one file.

| Role | Size (desktop) | Size (mobile) | Weight | Features |
|---|---|---|---|---|
| Display / hero | 48–72px | 36–48px | 700–800 | `kern`, `liga` |
| Section heading | 28–36px | 22–28px | 600–700 | `kern` |
| Sub-heading | 18–22px | 16–18px | 600 | `kern` |
| Body / long-form | 16–18px | 15–16px | 400 | `kern`, `liga` |
| UI label / button | 13–14px | 13–14px | 500 | `kern` |
| Table body | 13–14px | 12–13px | 400 | `tnum`, `lnum` |
| Table header | 11–12px | 11–12px | 600 | `tnum`, `lnum`, `kern` |
| Caption / meta | 11–12px | 11px | 400 | — |
| KPI / stat callout | 24–40px | 20–28px | 700 | `tnum`, `lnum` |

The variable font (`Inter[slnt,wght]`) should be loaded once and stepped using `font-weight` tokens. Do not load discrete weight files separately.

### Secondary consideration: marketing display

If the marketing site needs stronger brand expressiveness at the hero tier, pair Inter with a single display face. **Sohne** (Klim) or **Canela** (Commercial Type) would both work for headlines-only use. This is optional and should not bleed into the app.

Keep the pairing rule strict: display face used only at 36px and above, marketing site only, no dashboard surface.

---

## Readability rules

**Line length** - 60–75 characters for body copy on the marketing site. Dashboard prose (tooltips, empty states, onboarding) should stay under 55 characters. Wide viewports need explicit `max-width` on text containers.

**Line-height**
- Body: 1.5–1.6 (24–26px for 16px base)
- Table rows: 1.3–1.4 (tight but not cramped; row height affects scan speed)
- Display headings: 1.1–1.15

**Tabular numerals** - `font-feature-settings: "tnum" 1, "lnum" 1` must be applied at the token level for every table cell, KPI figure, and currency value. This is non-negotiable. Proportional figures in financial tables cause column misalignment and increase error risk.

**Contrast** - Body text at 16px must meet WCAG 4.5:1 against the surface color. Table text at 12–14px must also meet 4.5:1 (this size is below the large-text threshold). KPI callouts at 24px+ can pass at 3:1 but should target 4.5:1 for legibility under stress.

**Tracking** - Avoid negative tracking below 14px. Inter is already optically tight at small sizes. Over-tightening at caption and label sizes increases misread risk. Light positive tracking (0.01–0.02em) is acceptable for all-caps labels.

**Emphasis discipline** - Use weight (bold) as the primary emphasis tool, not italic. Italic at small dashboard sizes degrades quickly on screen. Reserve italic for formal citations or legal fine print on the marketing site.

---

## Adoption guidance

**Phase 1 - Foundation tokens**
Define the token set first before touching any component. Tokens needed:
- `font-family-base`, `font-family-display` (if using a second face)
- `font-size-*` (use a modular scale: 11, 12, 13, 14, 16, 18, 22, 28, 36, 48, 64)
- `font-weight-*` (400, 500, 600, 700, 800)
- `line-height-body`, `line-height-tight`, `line-height-display`
- `font-feature-tnum` (applied as a CSS custom property)

**Phase 2 - Dashboard and table first**
The dashboard is the highest-risk surface. Lock table typography, KPI figures, and label hierarchy before touching marketing styles. If tabular numerals are not working consistently, that is a blocking issue.

**Phase 3 - Marketing site**
Implement the display scale and long-form body type. Introduce the second display face here if the team has agreed on it. Confirm the marketing type tokens are a superset of the app tokens, not a fork.

**Phase 4 - Mobile**
Adjust the scale for reduced horizontal space. The mobile type tokens should be a responsive variant of the same token set using a CSS clamp or breakpoint override, not a separate system.

**Variable font loading**
```css
@font-face {
  font-family: 'Inter';
  src: url('Inter.var.woff2') format('woff2 supports variations'),
       url('Inter.var.woff2') format('woff2');
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
```

Fallback stack: `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`

The `-apple-system` / `BlinkMacSystemFont` fallbacks mean iOS and macOS users get San Francisco before hitting generic sans-serif, which is acceptable for a fintech product.

---

## Tradeoffs

**Inter over a premium alternative** - Inter is open-source and highly optimized for screen, but it is also ubiquitous. If brand differentiation matters at the marketing tier, the optional display face handles that without changing the functional system.

**Single variable file vs discrete weights** - The variable font adds roughly 120–140KB (woff2 compressed) against 30–50KB per discrete weight file. For a product loading 5+ weights, the variable file wins on total weight and eliminates FOUT variation between weights.

**Tabular numerals as a required feature** - This adds a small amount of token and CSS governance overhead. The tradeoff is correct: column misalignment in financial tables is a trust and accuracy problem, not just a visual one.

**No serif on the dashboard** - Serif faces can work at display scale on marketing sites and increase perceived trustworthiness in editorial contexts. They degrade on dashboard surfaces at 12–14px and complicate the tabular figure story. Keep serif as an optional marketing-only decision if pursued.

[SESSION_STATE]
{
  "route