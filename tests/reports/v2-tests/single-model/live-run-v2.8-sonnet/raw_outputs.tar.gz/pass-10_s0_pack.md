## Poster Critique

**Communication goal:** The poster needs to establish what the event is, earn attention at a distance, and give the viewer enough context to care about the title before they read it. Right now, it does none of those in the right order.

---

### Composition failures

**Focal winner is misidentified.** The conference logo sits in the center of the frame, which is the natural focal zone for a full-bleed image, but it's rendered in white against a city skyline with unpredictable light and dark zones. That pairing creates unreliable contrast. The logo may read well in some prints and disappear in others.

**Hierarchy puts the title before the frame.** A decorative typeface at the top signals "this is important" before the viewer knows what kind of event this is. A conference title lands flat without context. The viewer needs to know the category first: design conference, not just the name.

**The date is buried.** Small gray text in a corner is the lowest-legibility position on a poster. At any distance beyond reading range, it's invisible. This is the one piece of information with genuine urgency for an interested viewer.

**The city skyline is working against the message.** Full-bleed photography competes with every text layer placed over it. Without a consistent dark or light zone, there's no reliable contrast anchor. The image is also generic unless this city is the conference location and that's part of the identity signal.

---

### Rebuild moves

**1. Establish the frame before the title.**
Add a conference type line above or below the title: a short descriptor like "annual design conference" or the edition number. This gives the decorative title something to land on.

**2. Give the logo a protected zone.**
Move the logo out of the center focal zone or give it a solid background shape, a scrim, or a high-contrast placement where the skyline isn't fighting it. White-on-photo is only reliable when you control the photo crop.

**3. Elevate the date.**
The date should be the second or third largest element, not the smallest. A viewer who is already interested will look for it immediately. Burying it in gray in a corner fails that viewer.

**4. Control the photo or replace it.**
Either crop the skyline to a dark band at the base with a clear upper field for text, or replace the photo with a flat or textured background. If the city is not part of the identity story, the photo is decoration that creates contrast problems without adding meaning.

---

### Distance and emphasis tradeoff

At poster distance, three things should survive: the event name, what kind of event it is, and when. Right now only the title has scale. The logo gets visual attention through placement but not legibility. The date is effectively invisible. The skyline gets the most visual weight because it fills the frame.

**What should dominate:** event name at scale, with the conference descriptor as immediate context.
**What can recede:** the skyline, which should serve as texture or location signal rather than the primary visual weight.
**What must move up:** the date, from decorative footnote to essential callout.

The decorative typeface is a reasonable choice for a design conference, but decorative alone does not create hierarchy. Hierarchy requires contrast in size, weight, and placement between things that matter at different levels.

[SESSION_STATE]
{
  "route": "rt_graphic_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "focal_winner: conference name with descriptor context, not logo at center",
    "distance_legibility: three elements must survive at poster distance -- event name, event type, date",
    "composition_rule: full-bleed photo without contrast anchor creates unreliable legibility for all text layers",
    "emphasis_tradeoff: skyline recedes to texture, date elevates to essential callout"
  ],
  "evidence_classes_cited": [
    "visual_structure_rule",
    "comparison_artifact",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Is the city skyline the conference location? If yes, it may earn its place as an identity signal with better contrast control."
  ],
  "turn": 1
}
[/SESSION_STATE]