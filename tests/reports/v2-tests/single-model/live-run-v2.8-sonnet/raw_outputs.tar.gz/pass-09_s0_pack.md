## Color System: Healthcare SaaS Dashboard

### Role model

A semantic role model separates colors by function so no single hue carries meaning in multiple contexts. This prevents the common failure where a brand blue ends up as both a primary action and a "normal" status signal.

**Defined roles:**

| Role family | Purpose |
|---|---|
| Surface | Page, panel, card, and overlay backgrounds |
| Text | Body, heading, label, secondary, and disabled text |
| Action | Primary buttons, links, focus rings, interactive states |
| Status | Normal, warning, critical, and informational indicators |
| Chart | Categorical data series (5 colors, order-independent) |
| Border / divider | Structural separation, input outlines |
| Overlay | Modals, tooltips, drawer backdrops |

Brand color (if any) feeds into the Action role. It does not double as a status color.

---

### Token map

Tokens use a two-tier structure: primitive tokens (raw values) and semantic tokens (role aliases). This means a single palette change flows through the whole system rather than requiring manual updates across components.

**Primitive palette (hue selection rationale):**

Status hues are chosen to remain distinct under deuteranopia and protanopia. Red/green alone fails roughly 8% of male users. The system uses red, amber, and cyan/teal as the status trio, which survives the most common deficiency simulations.

```
-- Primitives
blue-50 through blue-900
red-50 through red-900
amber-50 through amber-900
teal-50 through teal-900
neutral-0 through neutral-1000

-- Chart categorical (light mode base)
chart-violet:   #7C3AED    (violet)
chart-teal:     #0D9488    (teal)
chart-amber:    #D97706    (amber)
chart-rose:     #E11D48    (rose)
chart-sky:      #0284C7    (sky blue)
```

**Semantic token map:**

```
Light mode
--color-surface-page:        neutral-50
--color-surface-card:        neutral-0
--color-surface-overlay:     neutral-0 / 92% opacity

--color-text-primary:        neutral-900
--color-text-secondary:      neutral-600
--color-text-disabled:       neutral-400
--color-text-inverse:        neutral-0

--color-action-default:      blue-600
--color-action-hover:        blue-700
--color-action-focus-ring:   blue-600
--color-action-pressed:      blue-800

--color-status-normal:       teal-600      (text/icon)
--color-status-normal-bg:    teal-50
--color-status-warning:      amber-600     (text/icon)
--color-status-warning-bg:   amber-50
--color-status-critical:     red-600       (text/icon)
--color-status-critical-bg:  red-50

--color-border-default:      neutral-200
--color-border-input:        neutral-300
--color-border-focus:        blue-600

Dark mode
--color-surface-page:        neutral-950
--color-surface-card:        neutral-900
--color-surface-overlay:     neutral-900 / 92% opacity

--color-text-primary:        neutral-50
--color-text-secondary:      neutral-400
--color-text-disabled:       neutral-600
--color-text-inverse:        neutral-900

--color-action-default:      blue-400
--color-action-hover:        blue-300
--color-action-focus-ring:   blue-400

--color-status-normal:       teal-400
--color-status-normal-bg:    teal-950
--color-status-warning:      amber-400
--color-status-warning-bg:   amber-950
--color-status-critical:     red-400
--color-status-critical-bg:  red-950

--color-border-default:      neutral-800
--color-border-input:        neutral-700
```

**Chart tokens for dark mode:** shift each chart color one step lighter (e.g. chart-violet becomes `#8B5CF6` at violet-500) and verify contrast against the dark surface before finalizing.

---

### Contrast and state rules

**WCAG AA text thresholds (4.5:1 for normal text, 3:1 for large text and UI components):**

| Token pair | Light mode ratio | Dark mode ratio | Passes AA |
|---|---|---|---|
| text-primary on surface-page | neutral-900 / neutral-50 | neutral-50 / neutral-950 | Yes, both |
| text-secondary on surface-page | neutral-600 / neutral-50 | neutral-400 / neutral-950 | Check: neutral-400/950 needs verification at your exact values. Target >= 4.5:1 |
| text-secondary on surface-card | neutral-600 / neutral-0 | neutral-400 / neutral-900 | Check both |
| action-default as link on surface-page | blue-600 / neutral-50 | blue-400 / neutral-950 | Verify; blue-400 on dark is a common fail point |
| status-normal text on status-normal-bg | teal-600 / teal-50 | teal-400 / teal-950 | Verify at build time |
| status-warning text on status-warning-bg | amber-600 / amber-50 | amber-400 / amber-950 | Verify; amber-400 on amber-950 is often marginal |
| status-critical text on status-critical-bg | red-600 / red-50 | red-400 / red-950 | Verify at build time |

**Verification tooling:** run all pairs through the WebAIM contrast checker or Figma's built-in contrast inspector at token finalization. Lock the contrast ratio next to the token in your documentation so it does not drift during redesign.

**Non-text contrast (UI components and status icons, 3:1 minimum):**
- Status icons and badge borders must meet 3:1 against their background even when the label text is not shown.
- Input borders (`border-input` on `surface-card`) must meet 3:1.

**Color-only state rule:**
Status must never rely on color alone. Every status badge uses an icon (checkmark, warning triangle, alert diamond) plus a text label. A badge that changes from green to red while keeping the same shape is not accessible on its own.

**Chart categorical rules:**
- Chart colors must meet 3:1 against both light and dark surface backgrounds for the data marks themselves.
- Adjacent chart series should not use hues that are perceptually similar under deuteranopia. The five chosen hues (violet, teal, amber, rose, sky) are distinguishable under simulation, but verify with a tool like Coblis or Stark before shipping.
- Chart labels and axis text must meet 4.5:1 against the chart background.

---

### Migration notes

If the existing system uses a flat hex palette without semantic roles, the migration sequence is:

1. Audit current usage: map every hex value to one of the role families above. This surfaces where one color is carrying multiple roles (common: a single brand blue used for actions, links, status indicators, and chart series).
2. Create primitive tokens first: give every used hue a primitive name before creating semantic aliases. This prevents the aliases