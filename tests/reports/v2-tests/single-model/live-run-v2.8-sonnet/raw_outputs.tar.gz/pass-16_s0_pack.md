# API Reliability and Security Review: POST /exports

## Failure Semantics and Error Contract

**Current state:** The endpoint returns HTTP 200 for all responses, including failures. Clients cannot distinguish success from failure without parsing a body field, which means retry logic, circuit breakers, and monitoring all have to guess. Internal enum values leaking into error messages is a separate but compounding problem: it exposes implementation details that create both information-disclosure risk and a soft coupling between server internals and client parsing behavior.

**Required contract:**

Adopt RFC 9457 Problem Details (`application/problem+json`) for all failure responses. Every error response must carry:

```json
{
  "type": "https://api.example.com/problems/export-failed",
  "title": "Export generation failed",
  "status": 422,
  "detail": "The requested date range exceeds the maximum export window.",
  "instance": "/exports/req_01J4X"
}
```

**Status code map:**

| Condition | Status | Reason |
|---|---|---|
| Invalid request params | `400 Bad Request` | Client error, not retryable as-is |
| Unauthorized | `401 Unauthorized` | Auth failure |
| Missing permission for resource | `403 Forbidden` | BOLA/BFLA boundary (see below) |
| Accepted for async processing | `202 Accepted` | Correct long-work response |
| Validation failure | `422 Unprocessable Entity` | Semantic failure, not retryable |
| Server fault | `500 Internal Server Error` | Retryable with backoff |
| Upstream timeout | `504 Gateway Timeout` | Retryable with backoff |

Internal enum values must be scrubbed from all client-facing error messages. Map them to stable, public `type` URIs in the problem details contract. Keep internal values in server logs behind the `instance` reference so debugging is still possible without leaking them.

---

## Authorization and Resource Protection

**Current state:** Not described, which means there is no visible authorization perimeter. For an export endpoint, this is high risk. The export is almost certainly scoped to a user, tenant, or set of records. Without explicit object-level authorization, a caller can potentially request exports for resources they do not own.

**Required controls:**

POST /exports accepts a scope parameter of some kind: a report type, date range, filters, or record set. Every one of those parameters is a potential BOLA (Broken Object-Level Authorization) surface. The server must verify that the requesting identity has access to each resource referenced in the export scope before starting generation, not after.

Concrete rules:

- **Deny by default.** If the authorization check cannot be completed, reject the request with `403`. Do not fall through to generation.
- **Object-level check, not just role check.** A user with an `exporter` role still must not be able to export another tenant's records. Role (RBAC) is not sufficient alone here; the authorization model must be at least object-level or property-level.
- **Audit trail.** Log every export request with the requesting identity, the resolved scope, the authorization decision, and the `instance` ID. This is not optional for an endpoint that generates potentially sensitive documents.
- **BFLA surface.** If the endpoint accepts a parameter that changes the generation behavior (format, template, scope expansion), verify that the caller is authorized to use that capability, not just that they are authenticated.

---

## Idempotency and Async Lifecycle

This is the largest structural problem. A synchronous 3-minute blocking call is not viable for a production export endpoint.

**Why synchronous blocking fails:**

- Load balancer and reverse proxy timeouts are typically 30 to 60 seconds. The connection will be cut before the job completes.
- There is no retry safety. If the client retries a timed-out request, the server may start a second PDF generation job for the same input, creating duplicate exports, double billing events, or duplicate audit records.
- Thread or connection pool exhaustion under concurrent load is near-certain, because each request holds a resource for up to 3 minutes.
- The client has no way to poll or recover. If the connection drops, the work is lost and the client has no job reference to check.

**Required async lifecycle:**

Move to a `202 Accepted` + job-status polling pattern:

```
POST /exports
-> 202 Accepted
   Location: /exports/jobs/job_01J4X
   {
     "job_id": "job_01J4X",
     "status": "queued",
     "status_url": "https://api.example.com/exports/jobs/job_01J4X"
   }

GET /exports/jobs/job_01J4X
-> { "status": "running", "created_at": "...", "estimated_completion": "..." }

GET /exports/jobs/job_01J4X  (later)
-> {
     "status": "completed",
     "download_url": "https://...",
     "expires_at": "..."
   }

GET /exports/jobs/job_01J4X  (on failure)
-> {
     "status": "failed",
     "type": "https://api.example.com/problems/export-failed",
     "detail": "Rendering failed at page 14 of 22."
   }
```

Job status must be a closed enum of terminal and non-terminal states, exposed publicly:

| State | Terminal | Retryable |
|---|---|---|
| `queued` | No | N/A |
| `running` | No | N/A |
| `completed` | Yes | No |
| `failed` | Yes | Yes (new job) |
| `expired` | Yes | Yes (new job) |

**Idempotency key:**

Add an `Idempotency-Key` header to POST /exports. Server behavior:

- If a key is seen for the first time: create the job, store the key with a TTL (24 hours is a reasonable default for export jobs).
- If the same key arrives within the TTL: return the original `202 Accepted` response with the original `job_id`. Do not create a second job.
- If the key arrives after TTL expiry: treat as a new request.
- If the key arrives while the original job is still running: return `202 Accepted` with the existing `job_id` and current status URL.

Conflict behavior: if the same key arrives with a different request body, return `409 Conflict` with a problem details body explaining the key collision.

---

## Resilience and Observability

**Generation queue and resource protection:**

- Move PDF generation into a background worker queue. The POST /exports handler becomes thin: validate input, check authorization, enqueue the job, return `202`. Generation work happens off the request thread.
- Set an explicit timeout on the generation worker itself (for example, 5 minutes as a hard ceiling). If generation exceeds it, the job transitions to `failed` with a `generation-timeout` problem type.
- Apply a per-user and per-tenant concurrency limit on in-flight export jobs. Without this, a single client can exhaust the worker pool. A reasonable starting point is 3 to 5 concurrent jobs per tenant; adjust based on observed usage.
- Apply a rate limit on POST /exports independently of the concurrency cap. Return `429 Too Many Requests` with a `Retry-After` header when the rate limit is hit.

**Retry safety summary:**

| Operation | Safe to retry? | Why |
|---|---|---|
| POST /exports (with idempotency key) | Yes | Key deduplication prevents duplicate jobs |
| POST /exports (without