# Back-End Architecture Spec: Multi-Tenant Scheduling Platform

**Route:** `backend_architecture_spec` | **Mode:** STRUCTURE | **Phase:** strategy → specs
**Supporting skills:** back-end-systems-architect, api-reliability-security-expert, back-end-aware-planner

---

## 1. System Framing

**System:** A multi-tenant scheduling platform where customer organizations ("tenants") own team workspaces, scheduled resources, and approval workflows. External systems connect via outbound webhooks. Automation rules are a near-future capability.

**Actors:**
- `Tenant` — the subscribing organization; the top-level isolation boundary
- `Member` — a user belonging to one or more tenant workspaces
- `Admin` — a member with elevated permission within a workspace or tenant
- `Approver` — a member designated to resolve approval requests
- `Automation Agent` — a future rule executor scoped to a single tenant
- `External System` — a customer-owned endpoint receiving outbound webhooks

**Resources:**
- `Workspace` — scoped container within a tenant; owns schedules, members, and rules
- `ScheduleEntry` — the core bookable unit, owned by a workspace
- `ApprovalRequest` — a lifecycle artifact attached to a schedule entry
- `AuditEvent` — an immutable record attached to every mutation across resources
- `WebhookSubscription` — a tenant-owned delivery target for outbound events
- `AutomationRule` — future; a tenant-scoped conditional trigger-action pair

**Why architecture is needed now:** Background jobs and eventing are inconsistent. Without naming authority, consistency posture, and delivery contracts explicitly, regional residency, audit trails, and webhook reliability cannot be guaranteed. The existing REST + relational base is sound; the gaps are in event ownership, job safety, and cross-service authority.

---

## 2. Core Model and Authority Boundaries

### Tenant isolation model

Tenant is the hard isolation boundary. No resource crosses a tenant boundary at the data layer. Every table that holds tenant-scoped data carries a `tenant_id` foreign key. Queries never run without a `tenant_id` predicate.

**Regional residency** is enforced at this boundary. Each tenant's write-primary database shard is pinned to a declared region (e.g., `us-east-1`, `eu-west-1`). No tenant data leaves its declared region in transit or at rest. This is a deployment topology decision with schema consequences: `tenant_id` must resolve to a shard locator before any query executes.

Implementation constraint: a lightweight `TenantRouter` sits ahead of the data layer. It resolves `tenant_id` → `{region, shard_dsn}` from a small global control-plane database that holds only tenant metadata (region, plan, status). The control plane is the only cross-region data store.

### Source-of-truth ownership

| Resource | Write authority | Read replicas allowed |
|---|---|---|
| ScheduleEntry | Scheduling Service | Yes, bounded staleness |
| ApprovalRequest | Approval Service | Yes, read-your-writes for the approver session |
| AuditEvent | Audit Service (append-only) | Yes, but must not be writable from any other service |
| WebhookSubscription | Webhook Service | Yes |
| AutomationRule (future) | Automation Service | Yes |
| Workspace / Member | Identity Service | No; always authoritative read |

**The Audit Service is append-only.** No service may issue a DELETE or UPDATE to the audit log table. The Audit Service exposes a single `record_event(tenant_id, actor_id, resource_type, resource_id, action, diff, timestamp)` call. All other services emit to it; none own it.

### Authorization model

Use **ReBAC (relationship-based access control)** anchored at the workspace level.

```
Tenant
 └── Workspace
      ├── Member  (role: viewer | editor | admin | approver)
      └── ScheduleEntry
           └── ApprovalRequest
```

Every permission check resolves the question: *does actor X have relationship R to resource Y within workspace W of tenant T?*

Authorization is evaluated by the Identity Service. No service embeds its own permission logic. Services call `can(actor_id, action, resource_id, workspace_id)` and receive a binary decision with a reason code. This keeps permission logic auditable and prevents BFLA drift across services.

**Deny by default.** A missing relationship entry is a deny, not a configuration error.

---

## 3. Data, Consistency, and Delivery Design

### Consistency stance

| Operation | Consistency requirement | Model |
|---|---|---|
| ScheduleEntry create / update | Read-your-writes | Writer returns the committed record; client uses that as its next state |
| Approval state transition | Linearizable within the ApprovalRequest | Optimistic lock on `version` column; reject concurrent writes with `409 Conflict` |
| Audit event append | At-least-once, append-only | Idempotent on `(tenant_id, resource_id, action, timestamp)` composite key |
| Activity feed cursor reads | Bounded staleness acceptable | Feed is built from the audit log; up to 5-second lag is safe |
| Webhook delivery | At-least-once with idempotency | Consumer must be idempotent; delivery retried with exponential backoff |

**Revision tokens:** ScheduleEntry and ApprovalRequest carry an opaque `revision_token` (a base64-encoded `{resource_id, version, timestamp}`). Clients pass this token on updates. The service rejects any update where the submitted token does not match the current stored token, preventing lost-update races without distributed locking.

### Activity feed design

The activity feed is a cursor-based projection over AuditEvents, scoped per workspace.

```
GET /workspaces/{workspace_id}/activity
  ?cursor=<opaque_cursor>
  &limit=50
```

The cursor encodes `{tenant_id, workspace_id, last_audit_event_id, timestamp}` as a signed, encrypted token. The feed service decodes the cursor, queries `WHERE audit_event_id > last_id AND workspace_id = ? AND tenant_id = ?`, and returns the next page with a `next_cursor`. If no new events exist, it returns an empty page and the same cursor. This is keyset pagination on an append-only log, which is stable under insertion and requires no offset.

**Never use offset pagination on the activity feed.** Offset pagination on an append-only log produces duplicate rows under high-insertion conditions.

### Approval workflow design

The `ApprovalRequest` is a state machine:

```
PENDING → APPROVED → (done)
PENDING → REJECTED → (done)
PENDING → CANCELLED → (done)
APPROVED → REVOKED   (only within a grace period, configurable per tenant)
```

State transitions are the only mutations the Approval Service permits. The service does not expose a free-form update endpoint. Every transition:
1. validates the actor has the `approver` relationship in the workspace
2. acquires an optimistic lock via `revision_token`
3. writes the new state and emits an `ApprovalStateChanged` domain event to the internal event bus
4. the Audit Service subscribes and appends the immutable record

**REVOKED** exists because some scheduling domains require a post-approval correction window. The grace period is a tenant-level configuration, not hardcoded. After the grace period, `REVOKED` is not a valid transition.

### Internal event bus

The existing inconsistency in background jobs and eventing is the highest-risk gap