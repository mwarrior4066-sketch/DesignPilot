## PDF Remediation Plan

**Artifact:** InDesign-exported two-column report PDF
**Governing route:** `rt_pdf_remediation` — document semantics and accessibility are at risk; visual cleanup is not the primary job here.

---

### Current Failure State

The exported PDF has at least four compounding problems that together make it semantically broken:

1. **Reading order failure** — Two-column layouts exported from InDesign frequently serialize in frame-creation order, not visual reading order. This means column 2 may precede column 1, or pull quotes interrupt mid-sentence before the main text resumes.
2. **Untagged decorative images** — Images not marked as artifacts pollute the accessibility tree and force screen readers to announce placeholder filenames or empty alt text.
3. **Broken TOC hyperlinks** — Internal links exported from InDesign can break if document pages shifted during production or if the PDF export settings did not include bookmarks and hyperlinks correctly.
4. **Structural tag gaps** — Pull quotes likely exist as styled text frames, not tagged `<Quote>` or `<P>` elements with semantic placement. If they are tagged at all, they are probably inserted mid-flow where InDesign placed them on the page, not where they belong logically.

---

### Remediation Sequence

Work in this order. Do not compress steps or jump to a visual check first.

**Step 1 — Verify reading order before touching tags**

Open the PDF in Acrobat Pro. Open the Order panel (`View > Show/Hide > Navigation Panes > Order`). Do not use the Tags panel yet.

Read through the Order panel top to bottom. This is what a screen reader will announce. Flag:
- Any content that appears out of column sequence
- Pull quote frames appearing mid-paragraph
- Figure descriptions or captions appearing before their image

Document the current order before making any change. This is your baseline.

**Step 2 — Fix reading order in the Order panel**

Drag items in the Order panel to establish correct logical sequence:
- Column 1 body text flows completely before column 2 body text
- Pull quotes move to the end of the paragraph they reinforce, or are marked as artifacts if they add no unique information not already in the main text
- Captions follow their image immediately
- Sidebars appear after the body section they belong to, not interspersed

Do not reorder using the Tags panel at this stage. The Order panel controls the actual reading sequence; the Tags panel controls semantic structure. Fixing both independently and then reconciling is safer than trying to do both at once.

**Step 3 — Artifact all decorative images**

Open the Tags panel. Find any `<Figure>` tags that correspond to decorative images (borders, dividers, background textures, purely decorative photography with no informational content).

Right-click each > `Change Tag to Artifact`. Confirm the artifact type as `Background`.

For images that carry informational weight, ensure the `<Figure>` tag has an `Alt` attribute with a concise functional description. In Acrobat Pro: right-click the `<Figure>` tag > Properties > Tag tab > Alternate Text.

Do not bulk-artifact every image. Check intent first.

**Step 4 — Fix or rebuild the TOC links**

First, diagnose the break. Go to `View > Show/Hide > Toolbar Items > Find and check the Link tool`. Click each TOC entry. If the link target is showing a page number that no longer exists or is pointing to a named destination that was dropped during export, the links are dead references.

Fastest repair path if the source InDesign file is available:
- Correct any page shifts in InDesign
- Re-export with `Include Hyperlinks` and `Create PDF Bookmarks` enabled in the PDF export dialog
- Re-import the fresh export and re-apply any Acrobat-side tag fixes from Steps 1-3 (export wipes Acrobat-side remediation)

If the InDesign source is not available or re-export is not viable:
- Delete the dead links using the Link tool
- Recreate internal links manually using `Tools > Edit PDF > Link > Add or Edit`
- Set each link to go to `Page View` and navigate to the correct page before setting the destination
- Add bookmarks in the Bookmarks panel mirroring the TOC structure

Note: manual link recreation in Acrobat is tedious but does not damage the semantic layer if done correctly.

**Step 5 — Tag audit and repair**

Now use the Tags panel. Walk the tag tree against the Order panel sequence you established in Step 2. Confirm:
- Headings are tagged `<H1>`, `<H2>`, `<H3>` in correct nesting, not all `<H1>` or all `<P>`
- Body paragraphs are `<P>`
- Pull quotes are `<Quote>` if they contain unique text, or have been artifacted
- The `<Document>` root exists and the `<Story>` or `<Part>` grouping reflects column and section logic
- Lists use `<L>`, `<LI>`, `<LBody>` structure, not styled paragraphs tagged as `<P>`

Fix tag type mismatches first. Then check nesting. Then check that `<Figure>` elements have their `Alt` text from Step 3.

**Step 6 — Document properties and language**

Set the document language:
`File > Properties > Description tab > Language`

Set the document title:
`File > Properties > Description tab > Title` — match the report cover title exactly

Set the display title:
`File > Properties > Initial View tab > Window Options > Show > Document Title`

Without a language declaration, screen readers default to the OS language, which fails multilingual or non-English sections.

**Step 7 — Run the accessibility checker**

`Tools > Accessibility > Accessibility Check`

Run against all pages. Review failures in order:
- Reading order failures reopen the Order panel
- Alternate text failures mean a Figure tag still has no Alt text
- Tab order failures mean the page's tab order is not set to follow the document structure

To fix tab order: `Page Thumbnails panel > right-click any page > Page Properties > Tab Order > Use Document Structure`.

Apply this to every page, not just the ones the checker flags.

---

### Verification Checks

Run all three before calling the file done.

**Screen reader walkthrough**
Use NVDA (Windows) or VoiceOver (macOS). Navigate using the headings list first (NVDA: `H` key, VoiceOver: rotor). Confirm heading levels match the visual hierarchy. Then read straight through with the arrow keys from the top. The column content should flow without interruption or repetition.

**Copy-paste extraction test**
Select all text in the PDF (`Ctrl+A` or `Cmd+A`) and paste into a plain text editor. Read the paste output. This reflects the actual extraction order, which is what assistive tools and downstream systems see. Pull quotes should not appear mid-sentence. Column 2 content should follow column 1 content, not interleave with it.

**Link spot-check**
Click every TOC link. Confirm it lands on the correct page. If bookmarks were added, open the Bookmarks panel and confirm they match the TOC hierarchy and navigate correctly.

---

### Risk Controls

**Do not flatten the PDF.** Flattening collapses the semantic layer entirely and turns the document into a raster image. No remediation is possible after flattening.

**Do not rasterize pages to fix visual alignment problems.** If InDesign geometry looked correct but the PDF export looks off, the fix is in the export settings or the source file, not rasterization.

**Do not use OCR-first repair** unless the PDF is scanned