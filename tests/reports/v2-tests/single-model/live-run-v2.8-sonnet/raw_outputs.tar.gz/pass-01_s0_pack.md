## Pricing Page Audit

**Route:** UI Structure Critique, supported by Accessibility + Color System

---

### What this page is trying to do

A B2B SaaS pricing page has one job: move a qualified visitor to a decision. That means the CTA must be impossible to miss, the plan hierarchy must answer "which one is for me" before the visitor scrolls, and the feature comparison must validate — not create — the decision. Right now the page is doing most of this in the wrong order and with structural gaps that cost conversions before accessibility failures even enter the picture.

---

### Structural failures

**1. The hero is decorative, not directional**

"Everything your team needs" is a category statement, not a decision prompt. It tells visitors nothing they couldn't infer from landing on a pricing page at all. Combined with a CTA that is visually undersized relative to the hero, the opening frame asks visitors to appreciate the product rather than act on it. The CTA needs to be physically large enough to anchor the hero — not a button floating over a background image. A CTA buried in a hero is slower than no CTA at all because it implies the real action is elsewhere.

Structural fix: The headline should answer a comparison question — "Plans that scale with your team," or lead with the decision trigger: "Start free, upgrade when you're ready." The CTA should be the largest interactive element in the above-the-fold zone, not competing with a background image for visual weight.

**2. The pricing table hierarchy is single-tier-forward but ambiguous for B2B buyers**

Color-coding the Pro tier is a valid visual strategy — it names a winner for the solo buyer scan path. The problem is that in a B2B context, the person reading this page is often not the only decision-maker. The Pro tier being highlighted by color alone means that hierarchy collapses for anyone with color deficiency, and it also doesn't resolve the Starter vs. Pro ambiguity for teams. The table needs to earn its recommendation through copy, not just chroma.

Structural fix: Pair the visual highlight with a short one-line rationale below the tier name: "Best for teams of 5–25" or "Most chosen by ops teams." This gives the buyer something to carry into an internal conversation. Color becomes emphasis, not the sole carrier of meaning.

**3. The feature comparison table is positioned as a closer, but it reads like a persuasion wall**

Placing the feature comparison immediately below the pricing table forces every visitor through the density of the full table before they reach testimonials or a second CTA. For buyers who already have an intent signal — they came to a pricing page — the comparison table is a validation tool, not a discovery tool. Burying it between pricing and testimonials uses the highest-value real estate on the page to answer questions most buyers haven't asked yet.

Structural fix: Either gate the comparison table behind a disclosure ("See full feature comparison") for lower-intent visitors, or restructure the page as: Hero → Pricing cards → Social proof → Comparison table → Final CTA. This lets the testimonials do trust work before the detailed feature list does its validation work.

**4. No second CTA after the comparison table**

If a visitor does scroll through the full feature comparison and testimonials, they have no action surface waiting at the bottom. This is a standard conversion gap on long pricing pages. Every section that answers a doubt or builds trust should have a CTA within scroll range.

---

### Accessibility failures

**5. Pro tier color coding fails contrast and semantic redundancy requirements**

Color-only differentiation of a highlighted plan fails WCAG 2.1 SC 1.4.1 (use of color). If the only signal that Pro is the recommended tier is background color or a border color, users with color deficiency will not receive that meaning. This is not a corner case — roughly 8% of male users have some form of color vision deficiency.

The fix requires two things in parallel:

- Contrast: Any color used in the tier card — background, border, badge, or label — must meet the relevant threshold. For UI components and boundaries: 3:1 non-text contrast against adjacent surfaces (WCAG SC 1.4.11). For text on a colored background: 4.5:1 for normal text, 3:1 for large text (WCAG SC 1.4.3). If the current Pro highlight color has not been checked against these thresholds, it should be treated as failing.
- Non-color redundancy: Add a text-based "Recommended" or "Most Popular" badge to the Pro card. This carries the meaning without requiring color perception. The badge itself must meet contrast requirements against its background.

**6. CTA button contrast is unverified**

Given that the CTA is described as small relative to the hero and sits on a background image, the button's text and background combination almost certainly has not been checked against a fixed surface. Text on a photographic background is a known contrast trap because the image luminance varies across the button's position. The button needs either a solid backing element (a panel, pill, or opaque container) or a guaranteed minimum contrast calculation against the darkest plausible background region.

**7. Pricing table keyboard and focus behavior is unspecified**

If the pricing table uses interactive elements — toggles, billing cycle switches, feature tooltips — each of these must be keyboard-accessible with a visible focus indicator. B2B pricing pages commonly add monthly/annual toggles that are built with custom elements or JS-powered switches. These need full ARIA role assignment and keyboard operability.

---

### Intervention order

Fix in this sequence:

1. CTA size and hero hierarchy — a small CTA on a background image is both a conversion failure and a contrast compliance risk. Fix this first.
2. Pro tier color redundancy — add the "Recommended" badge and verify non-text contrast thresholds. This requires a designer and a contrast checker, not a development sprint.
3. Feature comparison table reposition — move it below testimonials or gate it behind a disclosure. This is a page-structure change that does not require any engineering work on the table itself.
4. Add a bottom CTA after the testimonials or comparison table.
5. Verify all interactive pricing table elements for keyboard and focus behavior.

---

### Tradeoffs

The background image in the hero is doing brand work — it likely communicates product feel or team context. Replacing it with a solid surface or a high-contrast overlay will simplify the aesthetic but substantially improve CTA legibility. Brand atmosphere should flex here; CTA clarity should not.

Moving the feature comparison table below testimonials shortens the apparent page for lower-intent visitors. The table is still present and findable — it just stops blocking the conversion path for buyers who are already close to a decision.

---

### What this page needs to do before it can be considered conversion-ready

- One unambiguous, contrast-safe CTA above the fold
- Pro tier recommended by copy and visual treatment, not color alone
- Feature comparison repositioned as a validation tool, not a persuasion wall
- A bottom CTA after the trust-building sections complete
- All interactive elements verified for keyboard operability and focus visibility

[SESSION_STATE]
{
  "route": "rt_ui_structure_critique",
  "escalation_level": "standard",
  "decisions_committed": [
    "structural_failure: hero is decorative and non-directional; CTA is undersized relative to hero",
    "hierarchy_winner: CTA and plan rationale copy must win the first scan",
    "intervention_order: CTA fix → color redundancy → table reposition → bottom CTA → keyboard audit",
    "tradeoff_resolution: brand atmosphere in hero flexes; CTA clarity does not"
  ],
  "evidence_classes_cited": [
    "state_or_behavior_rule",
    "implementation_constraint",
    "comparison_artifact",
    "visual_structure_rule"
  ],
  "validator_flags": [],
  