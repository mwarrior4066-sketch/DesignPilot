Three tiers, same decision, different explanation surfaces. The architecture call itself does not change across them.

---

## Functional tier

When you build a React app, every piece of information your app needs to display or act on has to live somewhere. That "somewhere" is called state.

**Local state** means a single component owns the information and passes it down to its children if they need it. It is simple: the component that owns the data is the component you edit when the data needs to change.

**Context** is a built-in React tool that lets you share data across many components without passing it down manually through every level. It works well for things that change rarely, like which user is logged in, or whether dark mode is on.

**Redux** (or a similar global store like Zustand or Jotai) is a separate library that creates one central place for data that many parts of the app read and write at the same time, especially when that data changes frequently and predictably.

Here is the practical problem with reaching for Redux too early: it adds real setup cost, a new mental model, and extra files before you have proven you need it. And here is the problem with local state alone: when five or six components all need the same piece of data and you keep passing it down through layers of components that do not use it themselves, the app becomes hard to follow and painful to change.

**The signal that tells you to move up:** if you find yourself passing props through three or more component levels just to get data somewhere, that is called prop drilling, and it is the sign that local state has run out of road.

A safe starting rule: begin with local state. Add context when sharing across unrelated parts of the tree. Add a global store only when shared state changes frequently and multiple parts of the app need to react to those changes at the same time.

**Governing decision:** Use local component state as the default and introduce React Context for low-frequency shared data such as auth and theme; add a dedicated global store only when two or more unrelated UI regions need to read and mutate the same frequently changing state simultaneously.

---

## Integrative tier

The question is not which tool is more powerful. It is which ownership model matches the actual data-flow shape of this app.

**Three things determine the right answer:**

**1. Update frequency.** Context re-renders every consumer when its value changes. For high-frequency updates (filter state, form fields, live data) that re-render cost compounds quickly across a large tree. A global store like Redux, Zustand, or Jotai uses subscription-based selection, so only the components that care about a specific slice re-render. If your shared state updates often and many components consume it, context becomes a performance liability, not a convenience.

**2. Write ownership.** Local state is safe because exactly one component owns the write path. Context spreads that ownership, which makes mutation logic harder to trace. Global stores enforce a single write channel through actions or setters, which makes state transitions auditable and testable in isolation. If multiple parts of the app need to mutate the same record, the write-ownership model matters as much as the read-access model.

**3. Cross-cutting concerns.** Auth state, theme, locale, and feature flags are legitimate context candidates because they change infrequently and are read-mostly. Anything that drives UI transitions, optimistic updates, or server-state synchronization (data fetched from an API) should not live in plain context, and often should not live in client state at all. Libraries like React Query or SWR are purpose-built for server-state: they handle caching, background refetching, stale-while-revalidate, and error states in ways that a general-purpose store does not.

**The practical consequence:** many apps that reach for Redux are actually solving a server-state problem with a client-state tool. Separating the two, client state in local state or a lightweight store, server state in React Query or SWR, usually produces a smaller and more maintainable system than a monolithic Redux store that tries to own everything.

**Governing decision:** Separate server state from client state at the architecture level; use React Query or SWR for server-derived data, keep true client state local or in context for low-frequency cross-cutting concerns, and introduce a global client store only when frequent shared mutations across unrelated UI regions make local ownership untenable.

---

## Strategic tier

The Redux-versus-context question is usually the wrong frame. The prior question is whether server state and client state have been separated at the architecture boundary, because conflating them is what creates the pressure that makes global stores feel necessary.

**Server state** is data that lives on the server, has a canonical remote source of truth, and requires cache invalidation, background sync, and stale-detection logic. React Query and SWR are the right primitives here. They are not state managers in the Redux sense; they are async cache layers with built-in lifecycle management.

**Client state** is UI state with no remote source of truth: selected tab, open modal, filter values, draft form input. This belongs as close to its consumption site as possible. Lifting it into a global store when it has no cross-cutting consumers is a form of premature coupling.

**The global store becomes justified** when you have frequent cross-component mutations of shared client state, where subscription-based selective re-rendering is necessary for performance, or where the mutation history needs to be serializable for debugging or undo. Those conditions are real but uncommon before a product reaches meaningful scale or complexity.

**Context re-render behavior is a hard constraint, not a style preference.** A context value triggers a full re-render of every consumer on every update. Memoization can blunt this but does not eliminate it at scale. This is why using context for anything other than low-frequency, read-mostly shared data is architecturally risky regardless of preference.

**The sequencing recommendation:** local state by default, context for auth/theme/locale, React Query or SWR for server state, a lightweight store (Zustand is the lowest-overhead option with selector-based subscriptions) only when the conditions above are genuinely met.

**Governing decision:** Resolve the server/client state boundary first; use React Query or SWR for all server-derived state, reserve a global client store for genuinely shared high-frequency client mutations, and treat Context as a low-frequency cross-cutting primitive rather than a general distribution mechanism for app state.

[SESSION_STATE]
{
  "route": "rt_frontend_implementation_review",
  "escalation_level": "compound",
  "decisions_committed": [
    "rendering_model: client-side React SPA with server-state/client-state boundary as the primary architecture decision",
    "state_ownership: local state default, context for low-frequency cross-cutting, global store only for frequent shared client mutations",
    "boundary_placement: server state isolated to React Query or SWR cache layer, client state isolated to component or lightweight store",
    "semantic_contract: state ownership model is the governing contract, not tool preference",
    "cost_or_degraded_path: context re-render cost named as hard constraint; global store adds setup and coupling cost"
  ],
  "evidence_classes_cited": [
    "rendering_boundary_rule",
    "state_or_behavior_rule",
    "implementation_constraint"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [],
  "turn": 1
}
[/SESSION_STATE]