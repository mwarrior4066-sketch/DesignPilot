# Color System for Healthcare SaaS Dashboard

## Role Model

This system organizes color around **semantic roles** rather than brand whims. Each role has a purpose; roles map to states and contexts instead of floating as a palette list.

### Core semantic roles

**Surface roles** (backgrounds and containers)
- `surface-default` — neutral background for primary content
- `surface-secondary` — recessive container for grouping or secondary content
- `surface-hover` — interactive affordance on hover (component-level, not text)
- `surface-active` — pressed or selected state container

**Text roles** (foreground for reading)
- `text-primary` — body copy, primary UI labels
- `text-secondary` — helper text, metadata, timestamps
- `text-inverted` — text on colored or dark surfaces

**Status roles** (state communication)
- `status-normal` — healthy, stable, no action needed
- `status-warning` — attention required, potential risk
- `status-critical` — immediate action required, active failure

**Semantic action roles** (intent signaling)
- `action-primary` — primary CTAs, major user intent
- `action-secondary` — less prominent actions
- `action-destructive` — delete, revoke, irreversible action

**Data visualization roles** (categorical discrimination)
- `data-cat-1` through `data-cat-5` — distinct categorical series
- `data-neutral` — baseline or "other" category

---

## Token Map: Light Mode

| Role | Token Name | Hex | WCAG AA on white | WCAG AA on `surface-secondary` | Usage |
|---|---|---|---|---|---|
| **Surface** | `surface-default` | `#FFFFFF` | — | — | Primary canvas |
| | `surface-secondary` | `#F5F7FA` | — | — | Cards, grouped content |
| | `surface-hover` | `#EEF1F6` | — | — | Hover states on containers |
| | `surface-active` | `#E0E8F5` | — | — | Selected or pressed state |
| **Text** | `text-primary` | `#1A1F36` | ✓ 14.2:1 | ✓ 10.8:1 | Body, labels, headings |
| | `text-secondary` | `#697386` | ✓ 6.1:1 | ✓ 4.8:1 | Helper, meta, timestamps |
| | `text-inverted` | `#FFFFFF` | — | — | Text on dark/colored |
| **Status** | `status-normal` | `#10873D` | ✓ 6.2:1 | ✓ 4.9:1 | Healthy, running, ok |
| | `status-warning` | `#B8860B` | ✓ 5.1:1 | ✓ 4.0:1 | Needs attention, pending |
| | `status-critical` | `#C41E3A` | ✓ 7.8:1 | ✓ 6.1:1 | Active failure, critical |
| **Action** | `action-primary` | `#0055CC` | ✓ 8.5:1 | ✓ 6.6:1 | Primary buttons, CTAs |
| | `action-secondary` | `#0055CC` at 85% | `#4D7FBF` | ✓ 4.8:1 | Secondary buttons |
| | `action-destructive` | `#C41E3A` | ✓ 7.8:1 | ✓ 6.1:1 | Delete, revoke, reset |
| **Data Viz** | `data-cat-1` | `#0055CC` | ✓ 8.5:1 | — | Categorical series 1 |
| | `data-cat-2` | `#10873D` | ✓ 6.2:1 | — | Categorical series 2 |
| | `data-cat-3` | `#8B5A2B` | ✓ 5.0:1 | — | Categorical series 3 |
| | `data-cat-4` | `#556B7F` | ✓ 5.9:1 | — | Categorical series 4 |
| | `data-cat-5` | `#7B3FF2` | ✓ 6.6:1 | — | Categorical series 5 |
| | `data-neutral` | `#B0B9C3` | ✓ 4.5:1 | — | Other, baseline |

---

## Token Map: Dark Mode

Dark mode inverts the surface logic but preserves role semantics and contrast thresholds.

| Role | Token Name | Hex | WCAG AA on `surface-default` | Usage |
|---|---|---|---|---|
| **Surface** | `surface-default` | `#0F1117` | — | Primary canvas |
| | `surface-secondary` | `#1A1F2E` | — | Cards, grouped |
| | `surface-hover` | `#252D3D` | — | Hover affordance |
| | `surface-active` | `#354063` | — | Selected/pressed |
| **Text** | `text-primary` | `#E8EAED` | ✓ 13.1:1 | Body, labels |
| | `text-secondary` | `#9CA3AF` | ✓ 6.3:1 | Helper, meta |
| | `text-inverted` | `#0F1117` | — | Text on light/colored |
| **Status** | `status-normal` | `#22C55E` | ✓ 7.2:1 | Healthy, running |
| | `status-warning` | `#FDB022` | ✓ 5.4:1 | Pending, caution |
| | `status-critical` | `#FF6B6B` | ✓ 7.1:1 | Active failure |
| **Action** | `action-primary` | `#3B82F6` | ✓ 8.8:1 | Primary buttons |
| | `action-secondary` | `#60A5FA` | ✓ 6.3:1 | Secondary buttons |
| | `action-destructive` | `#FF6B6B` | ✓ 7.1:1 | Delete, revoke |
| **Data Viz** | `data-cat-1` | `#3B82F6` | ✓ 8.8:1 | Categorical 1 |
| | `data-cat-2` | `#22C55E` | ✓ 7.2:1 | Categorical 2 |
| | `data-cat-3` | `#FBBF24` | ✓ 5.1:1 | Categorical 3 |
| | `data-cat-4` | `#A78BFA` | ✓ 6.9:1 | Categorical 4 |
| | `data-cat-5` | `#F472B6` | ✓ 6.5:1 | Categorical 5 |
| | `