# Dashboard Audit

**Mode:** AUDIT | **Phase:** structure | **Route:** rt_dashboard_audit

## Dashboard role

Operational monitoring view for daily metric review. This is built to answer "what happened today?" but structured to answer "what happened in this specific sub-segment?" — a mismatch that forces the KPI row and chart to work against each other instead of in sequence.

## Key failures

**KPI row without context.** DAU, MRR, and churn shown as isolated numbers with trend direction only. A user landing here cannot tell if 3.2% churn is acceptable, worsening, or a system failure. Trend arrows alone skip the decision threshold. The row assumes the viewer knows the target, the baseline, and why this moment matters—a load placed on memory, not on the interface.

**Chart design hides the story.** Four colored lines without the legend visible create immediate friction: the user must scroll or search to know what the lines represent. The missing Y-axis label forces readers to infer the unit (users? dollars? percentage?). The chart is legible only after two scrolls and one inference. That's three interactions before the data becomes interpretable.

**Navigation breaks task hierarchy.** Twelve ungrouped nav items suggest the user can reach any view with equal ease. In reality, one or two navigation targets support 80% of daily use. The sidebar should signal priority through grouping, visual weight, or position. Right now it's a flat list that treats "export data" the same as "revenue trend."

## Evidence and rationale

**KPI selection is correct; framing is not.** DAU, MRR, and churn are the right metrics for this dashboard role. The problem is isolation. Each number needs a reference point—yesterday's value, the 7-day average, the monthly target, or the red-line threshold below which the ops team is alerted. Without one, the trend arrow becomes decoration.

**Chart density without access pattern.** Four-segment lines are appropriate for comparative monitoring, but only if the viewer can instantly identify each line. The legend-below-fold pattern works for static reports. For a live dashboard where the first question is "which segment is this?" it creates a scanning tax. Moving the legend inline (or above the fold) reduces that tax by 50%.

**Y-axis label is a navigation gate.** "Percentage of DAU" or "USD thousands" or "count" changes how the lines are read. Without it, the user is guessing. For a dashboard that opens cold, the label is mandatory safety.

## Recommended rebuild path

**1. Add one reference point to each KPI.** Start with the one that unlocks action fastest:
   - DAU: show yesterday's value (or 7-day baseline) so the trend arrow means something
   - MRR: show the monthly target or the MoM delta (not just today's absolute)
   - Churn: show the threshold (e.g., "3.2% | target <2.8%") so the user knows whether to escalate

   This turns the KPI row from decoration into a decision surface.

**2. Move the legend into the chart.** Place it as an inline legend above or inside the top-right corner of the chart frame. Let the user see "DAU | Enterprise | SMB | Free" without scrolling. This kills the "what line is this?" friction.

**3. Add a Y-axis label and unit.** If all four lines share a unit (users, %) state it once. If they differ, label each axis. Pick one over the other; a dual-axis chart here introduces more ambiguity than it solves.

**4. Group navigation by task.** Create three nav groups at most:
   - **Monitor** (DAU, MRR, churn, engagement)
   - **Analyze** (cohorts, retention, funnel)
   - **Manage** (exports, settings, user admin)

   This signals where to look first and hides low-frequency navigation behind grouping. The sidebar goes from 12 equal items to 3 scannable groups.

**5. Check the scroll depth.** If the legend or secondary controls require scrolling on mobile or narrow viewports, that's a fragile design. The first view should contain all tools needed to answer the dashboard's opening question.

## Tradeoffs

**Inline legend vs. external legend:** The inline legend takes chart space and can occlude data if the series are dense. It wins because this is a monitoring dashboard where the first job is identification. Visual clarity over whitespace.

**Single Y-axis vs. dual-axis:** Four segments on one axis is the right choice here. They're likely percentages or user counts—same unit family. A dual-axis introduces scale games and confusion. Stay simple.

**KPI detail vs. KPI count:** Adding reference values (target, baseline) makes the row taller. The row goes from one line to two or three visual zones. That's acceptable because it turns the row from a vanity metric into an action trigger. The height cost pays for itself.

**Nav grouping vs. flattening:** Grouping costs one extra click to reach a hidden item. But most daily tasks live in the top group, so the cost is paid once per session. Flattening costs cognitive scan time every time the user looks at the sidebar. Grouping wins.