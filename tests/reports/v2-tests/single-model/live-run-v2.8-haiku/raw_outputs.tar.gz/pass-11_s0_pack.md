# Layout Reconstruction from Brand Guidelines

I'm treating this as a **layout reconstruction task** grounded in a legacy PDF artifact. Let me break down what to extract and how to translate it safely.

## What to extract and preserve

### Grid and structural specifications
- **Column count and gutter width** – the core logic, not just visual spacing
- **Margin hierarchy** – outer margins, section margins, and internal padding rules
- **Baseline or leading increment** – if present, this constrains type and rhythm decisions
- **Breakpoint or medium-specific variants** – desktop, tablet, mobile variants if the PDF shows them
- **Aspect ratios or frame proportions** – any fixed-ratio sections or modules

### Confidence mapping
Mark each as:
- **observed** – directly visible in the grid diagrams or labeled
- **inferred** – reverse-engineered from alignment and spacing in the examples
- **assumption** – estimated when PDFs lack precision or the spec is ambiguous

### Example inventory
Document which example shows which pattern:
- "Page 3 shows a 12-column layout at desktop with 24px gutters"
- "Page 7 shows a 4-column tablet variant; margins are estimated at ~16px based on visual proportion"
- "Baseline increment is unlabeled; inferred as 8px from the height ratios in the type examples"

---

## How to translate into a modern layout system

### 1. Normalize the grid first

**Extract the canonical grid logic:**
- If the PDF specifies "12 columns with 24px gutters and 40px margins," that's your baseline.
- If it only shows examples, measure the column width and gutter from a full-width layout example and reverse-engineer the count.
- Create a simple token or specification:
  ```yaml
  Grid:
    desktop:
      columns: 12
      gutter: 24px
      margin: 40px
    tablet:
      columns: 8
      gutter: 20px
      margin: 24px
    mobile:
      columns: 4
      gutter: 16px
      margin: 16px
  ```

### 2. Decide what stays locked, what flexes

**Preservation rules:**
- **Locked:** column count, gutter ratio, margin logic (these define the system identity)
- **Flexible:** absolute pixel values (these scale for modern viewports)
- **Revisit:** aspect ratios or fixed heights (modern responsive design prefers content-driven sizing)

**Example decision:**
- "The 2018 grid uses 12 columns on desktop and 24px gutters. We preserve the column count and the ratio (gutter = 1 : column ≈ 1:3). We adjust margin from 40px to 48px for modern 16:9 screens."

### 3. Create a migration map for the examples

Go through each example layout in the PDF and document:
- **What it shows:** e.g., "hero with 2-column text + sidebar"
- **How it uses the grid:** e.g., "text spans 8 columns, sidebar spans 4"
- **What translates directly:** most grid-based layouts do
- **What needs rethinking:** fixed heights, outdated breakpoints, layouts that break on modern mobile widths

**Example:**
```markdown
Page 5 – Article layout
- Hero image: full-width (12 columns)
- Body text: 8 columns, margin-right: 24px
- Sidebar: 4 columns
- Locked for modern use: column and margin logic
- Adjust: hero height from fixed 400px to aspect ratio 16:9 or content-driven
```

### 4. Extract and verify type and color references

**If the PDF shows type scales:**
- Note the role (display, heading, body, caption)
- Record size, weight, and line-height if labeled
- Mark confidence on the leading (often inferred from visual space)

**If the PDF shows color:**
- Map colors to roles (primary action, background, text, etc.)
- Check contrast (2018 guidelines may not meet modern WCAG thresholds)
- Plan a dark-mode or theme strategy if the guidelines don't specify

### 5. Build the modern output structure

Create a living layout system that references the 2018 grid logic but speaks current implementation language:

```markdown
# Layout System – Reconstructed from 2018 Guidelines

## Grid Origin
Reconstructed from brand guidelines PDF (2018). Column count, gutter ratio, 
and margin philosophy preserved; pixel values normalized for modern viewports.

## Desktop (1024px+)
- Columns: 12
- Gutter: 24px
- Margin: 48px (adjusted from 2018: 40px)
- Max-width container: 1296px
- Confidence: high (directly observed in PDF grid diagrams)

## Tablet (768–1023px)
- Columns: 8
- Gutter: 20px
- Margin: 32px
- Confidence: medium (inferred from tablet example on page 12; no explicit spec)

## Mobile (< 768px)
- Columns: 4
- Gutter: 16px
- Margin: 16px
- Confidence: low (not shown in 2018 PDF; designed to maintain rhythm)

## Preserved logic
- Column count is identity
- Gutter ratio (1:3 column-to-gutter) maintained
- Margin as fraction of gutter

## Layout patterns from 2018 guidelines
[Map each example to modern usage with preservation notes]
```

---

## Risk controls and verification

### Beware of
- **Assumption creep** – mark inferred values clearly so future work doesn't treat them as law
- **Outdated breakpoints** – 2018 may have targeted older device sizes; check if the breakpoint thresholds still fit your user device distribution
- **Hidden accessibility debt** – old guidelines rarely document focus, keyboard navigation, or reading order; add those separately
- **Color contrast regression** – old brand colors may not meet WCAG AA on new backgrounds; test before locking

### Verification checkpoints
1. **Overlay test** – place a new template over the 2018 examples; the grid should align
2. **Breakpoint test** – does the responsive behavior match the content flow intent, or does it just fit narrower screens?
3. **Density test** – if margins and gutters were designed for print-era viewing, test whether they still feel right on modern fast-scroll interfaces

---

## Output recommendation

**Deliver as:**
- A grid token specification (YAML or JSON) with confidence levels
- A visual layout diagram showing each breakpoint with measurements labeled
- A migration guide mapping 2018 examples to modern template patterns
- A living note about what was inferred vs. observed, so future maintainers know the boundary

This keeps the historical logic alive, makes the system buildable, and flags assumptions clearly so they can be tested or refined as the product evolves.

[SESSION_STATE]
{
  "route": "layout_reconstruction_plan",
  "escalation_level": "standard",
  "decisions_committed": ["preserved_elements: grid logic and margin ratio", "inference_boundary: marked confidence on all reverse-engineered measurements", "verification_method: overlay test and breakpoint validation"],
  "evidence_classes_cited": ["implementation_constraint", "comparison_artifact"],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": ["Do you have specific template examples you want to test against the reconstructed grid?", "Is the 2018 PDF digital or scanned?"],
  "turn": 1
}
[/SESSION_STATE]