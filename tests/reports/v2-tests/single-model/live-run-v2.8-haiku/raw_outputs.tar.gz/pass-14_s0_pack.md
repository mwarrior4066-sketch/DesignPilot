# Front-End Implementation Review: Scheduling Dashboard

**Route:** `frontend_implementation_review` | **Mode:** AUDIT | **Escalation:** standard

---

## Architectural Framing

The current proposal moves all visibility, loading, mutation state, and filter logic into the client without naming the server/client boundary or making state ownership explicit. This creates three compounding risks:

1. **State explosion** – separate loading and error booleans multiply into inconsistent states (loading + error both true, neither true at error time, stale data still visible during refetch)
2. **Accessibility blindness** – custom div buttons for filters lose semantic role contracts, focus management, and keyboard affordances that table interactions depend on
3. **Permission drift** – role-based visibility decided at render time on the client will diverge from the server's source of truth when optimistic updates land before permission checks complete

The safer path: **Server-driven table shell with client-side mutation handling**, explicit state machines for async lifecycle, and native form + button semantics for filters.

---

## Boundary and State Model

### Server/Client Boundary (Proposed → Safer)

| Aspect | Current | Safer |
|---|---|---|
| **What renders first** | Client fetches everything then renders | Server renders table skeleton + metadata with initial rows |
| **Filter state ownership** | Client useState | Form field values in a `<form>` + server redirects to preserve URL |
| **Permission checks** | Client-side render gates | Server enforces in query; client never hides a row it shouldn't see |
| **Optimistic updates** | Update local state immediately | Use `useActionState` bound to a server action for mutation; let the server decide if the change is valid before UI commits |

### Typed State Machine (Not Separate Booleans)

Replace:
```javascript
const [loading, setLoading] = useState(false);
const [error, setError] = useState(null);
const [data, setData] = useState([]);
```

With a single state union:
```typescript
type DataState =
  | { status: 'idle' }
  | { status: 'loading'; previousData?: EventRow[] }
  | { status: 'success'; data: EventRow[] }
  | { status: 'error'; message: string; previousData?: EventRow[] };

const [state, dispatch] = useReducer(dataStateReducer, { status: 'idle' });
```

**Why:** A single state variable prevents `loading: true, error: "message"` collisions. Stale data is explicitly preserved during refetch so the UI doesn't blank. Error states hold the previous data, not an empty table.

### Mutation Lifecycle (Server Action + Usecase Pattern)

```typescript
// Server action with permission check baked in
async function updateEventRecurrence(eventId: string, rule: RecurrenceRule) {
  const session = await getSession(); // throws if unauthenticated
  const event = await db.events.findUnique({ where: { id: eventId } });
  
  // Permission check on server
  if (event.createdBy !== session.userId && !hasAdminRole(session)) {
    throw new Error('Permission denied');
  }
  
  const updated = await db.events.update({
    where: { id: eventId },
    data: { recurrenceRule: rule },
  });
  
  revalidatePath('/dashboard/schedule'); // ISR
  return updated;
}

// Client-side mutation hook
const [state, formAction, isPending] = useActionState(
  updateEventRecurrence,
  { status: 'idle' }
);

// Form owns the pending state, not useState
<form action={formAction}>
  <select name="frequency" defaultValue={event.frequency} required>
    <option value="daily">Daily</option>
    <option value="weekly">Weekly</option>
  </select>
  <button type="submit" disabled={isPending}>
    Save Recurrence
  </button>
</form>
```

**Why:** The server decides if the change is valid **before** the client commits it. If the user's role changed between render and submission, the server rejects it. No optimistic update outlives the permission boundary.

---

## Rendering and Mutation Strategy

### 1. Initial Table Render: Server-Side + Streaming

Use React Server Components or Server-Side Rendering to return table skeleton + initial rows on first load:

```typescript
// app/dashboard/schedule/page.tsx (Server Component)
export default async function SchedulePage({ searchParams }) {
  const session = await getSession();
  if (!session) redirect('/login');
  
  const filters = {
    dateRange: searchParams.dateRange || 'week',
    roleFilter: searchParams.role || null, // server enforces visible roles
  };
  
  // Query only rows the user can see
  const rows = await db.events.findMany({
    where: getRoleBasedWhereClause(session.roles, filters),
    take: 50,
  });
  
  return (
    <ScheduleTable 
      initialRows={rows} 
      filters={filters} 
      serverFilterUrl="/dashboard/schedule"
    />
  );
}
```

**Benefit:** The page is interactive in ~1s instead of waiting for client JS to fetch and parse. Permission checks run server-side, so the user never fetches rows they shouldn't see.

### 2. Filters: Native Form + Server Redirect

```typescript
// Client Component wrapping the filter form
'use client';

export function FilterForm({ filters, serverFilterUrl }) {
  return (
    <form 
      method="GET" 
      action={serverFilterUrl}
      className="filter-controls"
    >
      {/* Date range filter */}
      <fieldset>
        <legend>Date Range</legend>
        <select name="dateRange" defaultValue={filters.dateRange}>
          <option value="week">This week</option>
          <option value="month">This month</option>
          <option value="all">All time</option>
        </select>
      </fieldset>

      {/* Role filter – server enforces visibility */}
      <fieldset>
        <legend>Show roles</legend>
        {userVisibleRoles.map(role => (
          <label key={role}>
            <input 
              type="checkbox" 
              name="role" 
              value={role}
              defaultChecked={filters.role?.includes(role)}
            />
            {role}
          </label>
        ))}
      </fieldset>

      <button type="submit">Apply Filters</button>
      <a href={serverFilterUrl}>Clear all</a>
    </form>
  );
}
```

**Why:** 
- Native form preserves the URL state, so refresh doesn't lose filters
- Server redirects with filtered rows already queried
- No custom div buttons; checkboxes and selects are keyboard-accessible by default
- Screen readers announce the fieldset legend and option values

### 3. Row-Level Mutations: Server Actions + Pending UI

For recurring-event edits, use server actions bound to each row:

```typescript
// Client Component for a single event row
'use client';

function EventRow({ event, onUpdateOptimistic }) {
  const [state, formAction, isPending] = useActionState(
    async (prevState, formData) => {
      const result = await updateEventRecurrence(
        event.id,
        formData.get('frequency')
      );
      return { success: true, data: result