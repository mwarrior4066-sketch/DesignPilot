# Backend Feasibility Review: Real-Time Collaboration Feature

## Requested Capability
Add simultaneous multi-user editing to a React app with visible cursor positions, live conflict resolution, and persistent state. Users must see each other's edits and cursors in real time.

## Hidden System Requirements

Your REST + PostgreSQL stack requires substantial additions:

**Data ownership and consistency**
- Current state: Individual users own documents; you decide read/write boundaries per document
- Collaboration adds: Versioning requirement (every keystroke creates potential conflict), atomic write ordering (preventing silent data loss when two users edit simultaneously), and revision-history model (you must store not just current state, but the edit log)
- Risk: Without explicit versioning, concurrent edits will silently overwrite each other even with optimistic locking

**Real-time delivery and state sync**
- Current state: REST request/response; clients pull state on demand
- Collaboration adds: Bidirectional messaging (server must push edits to all clients instantly, not wait for polls), connection state management (when a user disconnects mid-edit, their in-flight changes must either commit or roll back), and broadcast ordering (all clients must apply edits in the same sequence or they diverge)
- Risk: Polling defeats real-time; you must add WebSocket or Server-Sent Events (SSE)

**Conflict resolution semantics**
- Current state: Last write wins (or you block concurrent writes per document)
- Collaboration adds: Operational Transformation (OT) or CRDT (Conflict-free Replicated Data Type) logic to merge simultaneous edits. Visible cursors mean you track not just document state but active user sessions and their positions
- Risk: Cursor positions are ephemeral; if a user deletes text before another user's cursor, you must rebase the cursor position correctly or it will jump to wrong locations

**Async job and notification surface**
- Current state: Synchronous REST; if a write fails, the client knows immediately
- Collaboration adds: Acknowledgment model (client sends edit, server confirms it applied, other clients are notified). If the server crashes mid-broadcast, you need to replay or deduplicate
- Risk: Without idempotency keys, resent edits create duplicate text

**Session and presence model**
- Current state: User authentication at request time
- Collaboration adds: Live session tracking (who is editing right now), presence broadcast (showing other users' cursors and selections), and graceful exit (when a user closes the tab, remove their cursor after a timeout, not instantly)
- Risk: Stale session data (user session marked active but connection dropped) confuses other collaborators

## Feasibility Assessment

### Blocking constraints

**1. You cannot use REST polling for real-time edits**
REST request/response is fundamentally pull-based. Polling every 100ms for changes scales to ~10 concurrent users before database load becomes severe. Google Docs uses push: every keystroke triggers a WebSocket message to the server, which broadcasts immediately. You must add WebSocket or SSE.

**2. Your current write model (single document record) breaks under concurrent edits**
If two users edit the same document simultaneously:
- User A sends `PUT /documents/{id}` with full text
- User B sends `PUT /documents/{id}` with full text
- Last write wins; User A's edits are lost silently

You need either:
- Operational Transformation (OT): track edit operations (insert at position 5, delete 3 chars) instead of full text; merge them semantically
- CRDT: use a data structure that guarantees convergence without central coordination

Both require schema changes and significant logic.

**3. PostgreSQL is the wrong place to store edit operations at scale**
You can store the final document state in PostgreSQL. But the edit log (every keystroke) needs to be:
- Queryable by timestamp for history and undo
- Replayable for new collaborators joining mid-session
- Distributed to all connected clients within ~100ms

PostgreSQL can do this, but you'll need an event log table and a way to stream changes out of it faster than HTTP polling. This often means adding Redis Pub/Sub or a message queue (RabbitMQ, Kafka) as a buffer.

**4. Cursor positions are not document state; they are ephemeral session state**
Storing cursor positions in PostgreSQL wastes writes and creates stale data. Cursor positions should live in memory (Redis, in-process map) and broadcast via WebSocket. When the user disconnects, delete the position immediately.

### Safer assumptions first
- Start with 2–5 concurrent editors per document
- Accept 200–500ms latency for edits to propagate (not <100ms like Google Docs)
- Use text-only documents first; skip rich text, nested objects, and comments for phase 1
- Assume one document per session (no cross-document undo or branching)

## Recommended Rebuild Path

### Phase 1: WebSocket foundation (1–2 weeks)
**Goal:** Real-time messaging without conflict resolution.

- Add Socket.IO or ws library to Node.js/Express
- On `/documents/{id}/join`, open a WebSocket connection; send full document state to client
- Client sends `edit` messages: `{position: 5, insert: "hello"}` or `{position: 5, delete: 3}`
- Server broadcasts to all connected clients in the same room
- **No persistence yet:** edits live in memory; refresh loses unsaved work
- **Testing:** Two browsers, one document, type in both. Edits appear in both.
- **Risk**: This is a prototype. Do not ship without phase 2.

**Why this order:** You need working real-time messaging before adding persistence and conflict resolution. If you add complexity now, you'll debug both simultaneously.

### Phase 2: Operational Transformation or CRDT (2–4 weeks)
**Goal:** Handle simultaneous edits without data loss.

**Option A: Operational Transformation (OT)**
- Requires a central server that applies every edit in order and acknowledges it
- Client sends edit; server applies it, increments a version number, broadcasts the **server-transformed** edit to all other clients
- If client A and B both send edits simultaneously, server orders them (A then B), transforms B's position based on A's insertion, and broadcasts the correct result
- Libraries: `Quill.js` (client) with custom OT server, or `ShareDB` (full OT framework)
- Easier to understand; harder to scale if you later need offline-capable clients

**Option B: CRDT (Conflict-free Replicated Data Type)**
- Each client generates a unique ID for each character insertion; merge logic is deterministic
- No central server needed for conflict resolution (useful for offline-first or p2p scenarios later)
- Clients can apply edits in any order and converge to the same state
- Libraries: `Automerge`, `Yjs` (well-tested, used by Figma alternatives)
- More complex to understand; scales better to offline and peer-based scenarios

**Recommendation: Start with OT via ShareDB** (lower friction for your REST-to-real-time transition). Automerge/Yjs if you anticipate offline or later peer-to-peer editing.

- Add an edit-operations table to PostgreSQL: `(id, doc_id, version, user_id, op_type, position, content, created_at)`
- Server logic: on each edit, query the highest version, apply OT transformation, persist the new operation, broadcast
- Client receives only the transformed operation (not the full document again)

### Phase 3: Persistence and history (1–2 weeks)
**Goal:** Survive server restart; enable undo/revision history.

- Snapshot the current document state every 60 seconds (