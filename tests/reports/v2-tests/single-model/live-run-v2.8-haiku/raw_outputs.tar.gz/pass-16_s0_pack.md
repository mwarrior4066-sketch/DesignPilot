# API Reliability and Security Review: POST /exports

## Failure Semantics

**Current state:** HTTP 200 for all responses, including failures, with internal enum values leaked in error messages.

**Hard failure:** A 200 success envelope masks error states. The client has no way to distinguish success from failure, and error parsing relies on inspecting message text rather than a structured contract. This violates RFC 9457 and creates silent failures in retry logic, monitoring, and client state machines.

**Required contract:**
Use structured problem details (RFC 9457) with distinct HTTP status codes:

```json
{
  "type": "urn:api:exports:invalid-parameters",
  "title": "Invalid export parameters",
  "status": 400,
  "detail": "The report_id does not exist in your workspace.",
  "instance": "/exports"
}
```

- `400 Bad Request` - malformed input, missing required fields, or invalid parameter values
- `401 Unauthorized` - missing or invalid credentials
- `403 Forbidden` - user lacks permission to access the report or workspace
- `409 Conflict` - resource state prevents export (e.g., report locked for editing)
- `422 Unprocessable Entity` - semantically valid input but cannot be processed (e.g., report too large to export as PDF)
- `429 Too Many Requests` - rate limit exceeded
- `500 Internal Server Error` - transient server failure (retriable)
- `503 Service Unavailable` - service degraded or overloaded (retriable)

**Why it matters:** The client needs to know whether to retry (5xx), backoff (429), fix input (4xx), or fail open. Enum leakage in error messages creates a coupling between server implementation and client parsing logic.

---

## Authorization and Resource Protection

**Current state:** No visible authorization layer described; assume unprotected or insufficiently scoped.

**Risk: BOLA/BFLA.** A user could POST `/exports` with another user's `report_id` and retrieve their PDF if authorization is missing or checked only at the API surface without object-level verification.

**Required decisions:**

1. **Object-level authorization:** Every export must verify that the authenticated user owns or has read access to the target report. Do not trust the client to send only valid IDs.
   ```
   GET /exports/:export_id → verify user_id matches the export owner or workspace membership
   ```

2. **Workspace scoping:** If multi-tenant, verify the report belongs to the user's workspace.
   ```
   SELECT report.* FROM reports 
   WHERE report.id = ? AND report.workspace_id = (
     SELECT workspace_id FROM workspace_members WHERE user_id = ?
   )
   ```

3. **Permission model:** Define who can export what.
   - Can only workspace members export reports?
   - Can read-only members export?
   - Can only report authors export?

4. **Resource limits:** Protect against denial-of-service by capping concurrent exports per user or workspace.
   ```
   SELECT COUNT(*) FROM exports 
   WHERE user_id = ? AND status = 'processing' AND created_at > NOW() - INTERVAL '1 hour'
   -- Reject if count > 5
   ```

---

## Idempotency and Async Lifecycle

**Current state:** Synchronous (blocks for up to 3 minutes), no idempotency key, no async job tracking.

**Critical problem:** A client that times out after 2:50 does not know whether the export succeeded. Retrying will trigger the PDF generation again, wasting compute and potentially creating duplicate files or consuming quota twice.

**Safer async contract:**

**Request:**
```http
POST /exports HTTP/1.1
Content-Type: application/json
Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000

{
  "report_id": "rpt_123",
  "format": "pdf"
}
```

**Immediate response (202 Accepted):**
```json
{
  "export_id": "exp_456",
  "status": "queued",
  "status_url": "https://api.example.com/exports/exp_456",
  "eta_seconds": 45
}
```

**Poll the status URL:**
```http
GET /exports/exp_456 HTTP/1.1
```

**Response (while processing):**
```json
{
  "export_id": "exp_456",
  "status": "running",
  "progress_percent": 65,
  "eta_seconds": 20
}
```

**Response (on success):**
```json
{
  "export_id": "exp_456",
  "status": "succeeded",
  "download_url": "https://s3.example.com/exports/exp_456/report.pdf",
  "expires_at": "2025-01-20T14:30:00Z",
  "size_bytes": 2048576
}
```

**Response (on failure):**
```json
{
  "type": "urn:api:exports:report-too-large",
  "title": "Report too large to export",
  "status": 422,
  "detail": "The report contains 50,000 rows and exceeds the 10,000-row export limit.",
  "instance": "/exports/exp_456",
  "export_id": "exp_456",
  "status": "failed"
}
```

**Idempotency contract:**
- The `Idempotency-Key` header is a client-generated UUID or request fingerprint.
- Store it with the job record and set a 24-hour TTL.
- If the same `Idempotency-Key` arrives within the TTL, return the cached response (same HTTP status and body).
- If the key is absent, reject with `400 Bad Request` and `type: urn:api:exports:idempotency-key-required`.

**Terminal states:**
- `succeeded` – download is ready
- `failed` – see error details
- `cancelled` – user or quota limit stopped it

**Why it matters:** The client can retry without duplicating work, network timeouts are safe, and quota tracking is deterministic.

---

## Resilience and Observability

**Current state:** Synchronous 3-minute wall-clock blocking; no queue, no backpressure, no observable signals.

**Risks:**
- If PDF generation takes longer than expected, the client hangs and the connection consumes a thread.
- No way to know if the service is degraded or overloaded until a request times out.
- No trace ID linking the request to logs, making debugging hard.

**Required design:**

### Queuing and Backpressure
- Enqueue jobs in a durable job queue (e.g., Postgres FIFO table, RabbitMQ, Redis queue, or managed service like GCP Tasks).
- Return `202 Accepted` immediately; do not block the HTTP request.
- Worker processes pull from the queue and generate PDFs asynchronously.
- If the queue depth exceeds a threshold (e.g., 100 jobs), reject new requests with `503 Service Unavailable` and `Retry-After: 60` header.

### Rate Limiting and Quotas
- Per-user quota: max 50 exports per day, max 5 concurrent exports.
- Per-workspace quota: max 500 exports per day.
- Return `429 Too Many Requests` when quota is exceeded:
  ```json
  {
    "