# API Reliability and Security Review

**Route:** `api_reliability_security_review` | **Mode:** AUDIT

## Failure Semantics

**Governing Decision: Adopt RFC 9457 problem details for all error responses.**

The current error envelope (plain string) leaves the client unable to distinguish transient failures from permanent ones, permission issues from validation failures, or retry-safe operations from destructive ones. A client cannot reason about whether to retry, whether to show the error to the user, or whether the operation partially succeeded.

Replace the plain-string error with a structured problem details object:

```json
{
  "type": "https://api.example.com/errors/project-not-found",
  "title": "Project Not Found",
  "status": 404,
  "detail": "Project with ID abc123 does not exist or has been deleted.",
  "instance": "/api/v1/projects/abc123/members"
}
```

This lets clients:
- Parse the `type` to decide if retry is safe
- Route 400 (malformed request) separately from 403 (permission) separately from 409 (conflict)
- Surface 422 (validation failure) to the user instead of retrying

## Authorization and Resource Protection

**Governing Decision: Implement object-level authorization. Deny by default. Require both project membership and admin role.**

The current check (logged-in only) allows any authenticated user to add members to any project. This is a **Broken Object Level Authorization (BOLA)** vulnerability.

The fix has three layers:

1. **Does the project exist?** Return 404 if not (or 403 if the caller should not know it exists).

2. **Is the caller a member of the project?** Return 403 if not. This prevents users from adding members to projects they know about but shouldn't touch.

3. **Is the caller a project admin?** Check the caller's role within the project membership. Return 403 if not. This allows members to view and possibly edit their own profiles without adding new members.

The order matters: check existence first (in case the project is soft-deleted), then membership, then admin role.

```
if project not found:
  return 404
if caller not in project members:
  return 403
if caller's project_role != "admin":
  return 403
// proceed with add
```

## Idempotency and Async Lifecycle

**Governing Decision: Require and validate an `Idempotency-Key` header. Map duplicate requests to the original response without re-executing the add.**

The endpoint currently has no way to handle network retries safely. If a client sends the same add-member request twice (due to timeout or flaky connection), the user is added twice, or a 500 is returned on the second attempt because the member already exists.

Idempotency key behavior:

- Client sends: `POST /api/v1/projects/{id}/members` with header `Idempotency-Key: abc-def-123`
- Server stores the key with the response for 24 hours (or your SLA).
- If the same key arrives again within the window, return the cached response.
- If a different key arrives for the same resource, proceed normally.

Decide the success response:
- **201 Created** with the new member object is clearer than 200 with a list.
- If you return 200, it should contain *only the newly added member*, not the entire list (which scales badly).

For the duplicate case, return 409 Conflict if the user is already in the project:

```json
{
  "type": "https://api.example.com/errors/member-already-exists",
  "title": "Member Already Exists",
  "status": 409,
  "detail": "User user123 is already a member of this project."
}
```

A 409 tells the client: "Your request is valid, but the state is already what you wanted." The client can treat it as success.

## Resilience and Observability

**Governing Decision: Add `trace_id` to all error responses. Implement quota limits on member adds. Define degraded behavior when member invitations are slow.**

Three concerns:

1. **Tracing.** When a user hits an error, they need a `trace_id` to hand to support. Include it in the error response:
   ```json
   {
     "type": "...",
     "status": 403,
     "trace_id": "550e8400-e29b-41d4-a716-446655440000"
   }
   ```

2. **Quota.** Without rate limits, an admin can be tricked into adding thousands of members in rapid succession, burning CPU and storage. Add a per-project quota (e.g., 100 member adds per minute, or per-user quota like 1000 per day). Return 429 Too Many Requests when exceeded:
   ```json
   {
     "type": "https://api.example.com/errors/rate-limit-exceeded",
     "status": 429,
     "title": "Rate Limit Exceeded",
     "detail": "You have exceeded the quota of 100 member additions per minute.",
     "retry_after": 42
   }
   ```

3. **Degraded mode.** If member notifications or indexing is slow, the response may take 5+ seconds. Define a timeout: if the member add itself succeeds but notifications fail, return 202 Accepted with a status URL instead of blocking:
   ```
   202 Accepted
   Location: /api/v1/projects/{id}/members/{userId}/status
   ```
   The client can poll or webhook for notification status without blocking.

## Summary of Decisions and Risks

| Decision | Safer than current state | Implementation cost | Blocking risk |
|---|---|---|---|
| RFC 9457 error envelope | Enables client retry logic, removes guessing | Low: one new schema | None if backwards-compatible |
| Object-level authorization (project admin check) | Closes BOLA vulnerability | Low: one role lookup | Yes: may break existing integrations that assume logged-in = can add |
| Idempotency key + 201/409 response | Prevents duplicate members on retry | Medium: cache layer, key validation | Low: cache backend required |
| Quota (429) + trace_id + degraded mode (202) | Prevents resource exhaustion, enables debugging | Medium: quota tracking, timeout logic | Low: adds operational complexity |

The **highest-risk change** is the authorization fix, because it will reject requests that currently succeed. This must come with a migration path: log which requests would fail with the new rule for one sprint, warn affected integrations, then enforce.