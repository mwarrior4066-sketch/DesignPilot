# Graphic Critique

## Communication goal
This poster needs to sell a design conference to designers in a glance. The first read should answer "what is this?" and "is it for me?" before the title's decorative treatment can matter.

## Composition failures

**The hierarchy problem is real.**
You're leading with typographic ornament instead of event clarity. A designer walking past this sees "pretty letters" before understanding it's a conference announcement. The logo center-stage doesn't clarify what the event is either—it's a brand mark without context.

**The photo competes for dominance.**
A full-bleed skyline is atmospheric but offers no focal signal. It's landscape backdrop, not communication. The eye lands on title decoration, then bounces between logo and photo with no clear reading order.

**The date is functionally invisible.**
Gray text in a bottom corner is information burial, not design. For a time-dependent event, this is a missed primary action.

## Rebuild moves

**Lead with the event name and conference identity together.**
Move the logo and conference name (or "Design Conference") into the upper third so it answers "what is this?" immediately. Pair it with a subheading that says who it's for: "For Design Leaders" or "The Annual Conference for Product Designers." This gives the decorative title context to live in.

**Anchor the date and call-to-action in the visual hierarchy.**
The date should be visible at normal viewing distance—bottom-right or bottom-center, large enough to read from across a room. If there's a website or ticket link, it belongs here too, in a clear secondary role.

**Use the photo strategically, not as wallpaper.**
Crop or scale the skyline so it occupies the lower half or right edge, not the whole surface. Let it frame the event information rather than compete with it. Or reserve the photo for background texture and put the conference identity in a clear zone (a semi-transparent overlay, a solid sidebar, or white space).

**Treat the decorative typeface as emphasis, not the lead.**
The fancy title can work—but only after the audience knows what they're looking at. Move it to a secondary position or use it for a tagline instead of the event name.

## Distance and emphasis tradeoff

**What should dominate:** Event name + date. These survive at poster distance and on social media thumbnails.

**What can recede:** The decorative title treatment. It's beautiful at close reading, but it's sacrificing scanability for ornament. If you keep it, use it as a subtitle or campaign slogan, not the main signpost.

**Preservation tradeoff:** You lose some visual polish if you make the layout clearer. A centered decorative treatment is more "designed." A grid-based hierarchy with clear information zones is more functional. For a conference poster, function wins—the poster's job is to drive attendance, not to win a type award.