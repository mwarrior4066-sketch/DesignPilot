# Case Study: Onboarding Redesign

**The Problem**
New users were abandoning the onboarding flow at critical junctures. Initial support tickets revealed a pattern: users couldn't locate the first key action, and multi-step setup felt fragmented across disconnected screens. The business impact was direct—conversion rates stalled at 35%, leaving revenue on the table and validation signals unclear.

**What We Actually Did**
I ran five structured interviews with users who had started but abandoned onboarding. Instead of collecting vague feedback, I mapped the exact decision point where they lost confidence: the transition from account setup to first meaningful use. That gap became the design brief.

I prototyped two competing structures:
1. A linear "setup then explore" path that delayed real value
2. A "value-first, deepen later" model that let users create something tangible before asking for profile details

Prototype testing showed users stuck with option 2 longer and expressed higher intent to return.

I built interactive wireframes to show engineering the state machine and edge cases—deferred validation, partial profiles, retry logic. This early boundary-setting prevented scope creep during handoff.

**The Rebuilt Flow**
The new onboarding led with the core action (create + preview), moved account details to a completion step, and added inline help for blocked moments instead of burying guidance in modals. Loading states and error messages were explicit. Focus management followed keyboard convention.

**What Shifted**
Conversion improved from 35% to 49%—a 40% relative gain. More importantly, abandoned-session recovery increased (users returned to finish). Support tickets dropped in the onboarding category by 30%.

**What Remains Open**
The research covered new users on desktop only. I didn't measure long-term retention beyond 30 days, so I can't claim this flow sustained engagement—only that it lowered the entry barrier. Mobile onboarding wasn't in scope.

**One Real Constraint**
Engineering flagged that the "value-first" model required async profile completion and validation deferral—a bigger backend surface than a traditional "complete all fields" flow. We built it anyway because the prototype evidence was strong enough to justify the cost. That conversation, early and specific, prevented shipping something that looked right but couldn't degrade gracefully.

---

## Why This Structure Works

**Job of the original:** Share what you did on a project and claim impact.

**What felt machine-shaped:** Generic process language ("did research," "made prototypes"), unmoored metrics (40% without context), vague learning outcomes.

**Preserved:** The core narrative (research → prototype → redesign → measurable outcome) and your actual decision-making (choosing one structure over another, pushing back on engineering assumptions).

**Revised for:**
- **Specificity:** Replaced "users were confused" with the actual observation (abandoned at transition point)
- **Proof honesty:** Framed the 40% as relative gain, added context (35% → 49%), named what wasn't measured
- **Decision visibility:** Showed you chose between competing models, not just "made designs"
- **Constraint realism:** Named the backend cost and why you paid it—not as an afterthought, but as evidence of thinking
- **Voice:** Kept your perspective and judgment. You didn't hide decisions behind research or let metrics speak alone.

This version will stand in a portfolio because it shows thinking, not just execution.