# UX Research Gap Map

## Known evidence
You have three validated friction points: stakeholder context (n=3), current-product usability issues (n=2), and a quantified abandonment signal (60% drop-off at project creation). This is real but incomplete evidence. You can see *that* users leave; you cannot yet see *why* or what alternatives they're comparing you against.

## Critical gaps (ranked by decision impact)

### 1. Abandonment reason map — blocks sequencing and scope
**Why it matters:** A 60% drop-off could signal any of five different problems: confusing mental model, missing required fields, performance friction, permission/access anxiety, or comparison-shopping mid-flow. Each requires a different fix, and fixing the wrong one wastes the redesign.

**What to study:**
- Moderated remote usability test (n=8–12 new-user participants) with a think-aloud protocol during project creation
- Instrument: capture where they hesitate, re-read, click back, or express doubt
- Decision it unlocks: whether to fix information architecture, reduce required fields, add progressive disclosure, clarify permissions upfront, or restructure the entire entry flow

**Output:** task-completion map with abandonment reason tagged to each drop-off point

---

### 2. Power-user workflow and feature leverage — blocks prioritization
**Why it matters:** Your stakeholders and new users are not your daily drivers. Power users (teams that ship 20+ projects/month or multi-team coordination) likely have workarounds, feature wishes, and mental models your current research does not surface. Without this, the redesign may optimize for onboarding while breaking power-user speed or automation.

**What to study:**
- Contextual inquiry or diary study (n=6–8 power users over 1–2 weeks)
- Instrument: observe actual project workflows, not reconstructed workflows; capture shortcuts, pain points, and what they wish existed
- Decision it unlocks: whether to optimize for speed (templates, bulk actions, keyboard shortcuts), coordination (roles, approvals, visibility), or integration (Slack, calendar, other tools)

**Output:** feature-usage heat map and workflow sequence map with power-user priorities ranked

---

### 3. Competitive context and category conventions — blocks positioning and feature scope
**Why it matters:** B2B project management is crowded (Asana, Monday.com, Linear, Jira, etc.). Users choose tools based on category fit (engineering vs. creative vs. ops), not absolute feature count. Without this map, you risk designing a tool that is *good* but not *different* or *fit* for your segment.

**What to study:**
- Heuristic competitive audit (4–5 close competitors) on: project creation flow, information architecture, power-user features, permissions model
- User-informed competitive preference study (n=8–12) asking users why they chose, stayed with, or abandoned tools
- Decision it unlocks: what category or user segment you're strongest in; what features are table-stakes vs. differentiators; what mental model mismatches hurt you most

**Output:** competitive positioning matrix and feature-fit map

---

### 4. Team-size and role-based mental models — blocks information architecture
**Why it matters:** A solo freelancer's project creation flow should not match a 50-person agency's. Permission models, approval workflows, and template defaults differ radically. Your 3 stakeholder interviews may have been biased toward one team size or role type. Without segmentation, the redesign optimizes for an average user that does not exist.

**What to study:**
- Follow-up structured interviews (n=6–8) across team sizes (1-person, 5–10, 20+) and roles (PM, engineer, designer, executive sponsor)
- Instrument: show wireframe or current-product fragments and ask "What would you expect to happen here?" to surface mental-model gaps
- Decision it unlocks: whether to gate features by role/team size or surface everything with progressive disclosure; what defaults matter most to each segment

**Output:** role/team-size mental-model map

---

### 5. Abandonment timing and device/context — supports sequencing
**Why it matters:** Is the 60% drop-off on mobile? On first use? During permission setup? On retry after a failure? Timing and context matter for whether to fix UX, performance, error messaging, or async job handling.

**What to study:**
- Analytics deep-dive: segment the 60% by device, session length, time-to-drop, prior product experience, and team size
- Qualitative follow-up (n=4–6) with users who started but abandoned
- Decision it unlocks: quick wins (messaging, error clarity) vs. architectural fixes (permissions model, multi-step flow redesign)

**Output:** drop-off segmentation report

---

## Research plan

| Gap | Method | Sample | Timeline | Owner | Output |
|---|---|---|---|---|---|
| Abandonment reasons | Moderated usability test (think-aloud) | 10 new users | 2 weeks | UX research | task-completion map with drop-off reasons |
| Power-user workflows | Contextual inquiry + diary study | 6 power users | 3 weeks | UX research + PM | feature-usage heat map; workflow prioritization |
| Competitive context | Audit + user preference study | 4 competitors; 10 users | 2 weeks | PM + UX research | positioning matrix; feature-fit scorecard |
| Mental models by segment | Segmented interviews + wireframe testing | 6 users (mixed roles/sizes) | 2 weeks | UX research | role/team-size decision matrix |
| Abandonment context | Analytics segmentation + followup interviews | 4–6 abandoners | 1 week | Analytics + UX research | drop-off segmentation report |

---

## Decision impact and sequencing

**Run immediately (week 1–2):**
- Abandonment reason usability test (highest leverage; blocks redesign scope)
- Analytics deep-dive (quick; informs usability test design and prioritization)

**Run in parallel (week 2–3):**
- Power-user contextual inquiry (informs feature scope and defaults)
- Competitive audit (informs positioning; can run without primary research)

**Run after findings (week 4):**
- Segmented mental-model interviews (validate redesign assumptions for different user types)

**Defer until redesign has a direction:**
- Full competitive preference study (useful once you know what to compare)

---

## Evidence gaps this closes
After this research, you will know:
- **Why** the 60% abandon (not just that they do)
- **What features** power users actually rely on vs. wish for
- **Which segment** your tool is strongest in and where you compete
- **What mental model** your IA should assume for each user type
- **What to prioritize** in the redesign (onboarding clarity, power-user speed, role-based defaults, or integration surface)

You will still not have:
- Quantified conversion lift from the redesign (that's post-launch measurement)
- Detailed interaction patterns for every edge case (that's iteration and QA)
- Market-size validation or pricing assumptions (that's a different research scope)

---

[SESSION_STATE]
{
  "route": "ux_research_gap_map",
  "escalation_level": "standard",
  "decisions_committed": ["gap_priority: abandonment_reasons first", "method_mapping: usability_test + contextual_inquiry + audit", "decision_linkage: each study unlocks a redesign decision"],
  "evidence_classes_cited": ["research_artifact", "comparison_artifact", "narrative_proof_boundary"],
  "validator_flags": [],
  "weak_patterns