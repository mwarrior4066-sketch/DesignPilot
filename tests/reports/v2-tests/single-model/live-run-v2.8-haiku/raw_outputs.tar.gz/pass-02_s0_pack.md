# Split Button Component Specification

## Purpose and Scope

A split button combines a primary action with a dropdown menu of secondary actions in a single compound control. The primary action triggers immediately on click; the dropdown arrow opens a menu of alternatives. The component owns the button layout, state machine, and keyboard behavior. It does not own the menu implementation (use a separate Menu component) or the actions themselves (those belong to the consuming form or container).

## Anatomy

```
┌─────────────────┬──┐
│ Save            │▼ │  Primary button + dropdown trigger
└─────────────────┴──┘
     48px (min)    32px (trigger)
```

**Parts:**
- **Primary button** — the main action label and hit target
- **Divider** — visual separation between primary and dropdown (1px, semantic color)
- **Dropdown trigger** — chevron icon or arrow, right-aligned, owns the menu open/close
- **Focus ring** — wraps both parts as one logical button (not separate focus stops)
- **Loading spinner** — optional, replaces or overlays the trigger when in loading state

## State Matrix

| State | Primary button | Trigger | Behavior | Keyboard | Notes |
|---|---|---|---|---|---|
| **default** | text + icon | chevron, pointer cursor | Clicking primary fires action immediately. Clicking trigger opens menu. | Tab into component, Space/Enter fires primary, ArrowDown/Alt+Down opens menu. | Ready to interact. |
| **hover** | text + icon, elevated or bg color | chevron, darker | Background or shadow change signals interactive state. Both areas respond to hover. | N/A | Touch platforms skip hover. |
| **focus** | text + icon | chevron | Focus ring wraps both parts; 2px outline at 8px offset or per design tokens. | Focus ring visible. Tab moves to next control. | Single focus stop for both. |
| **active/pressed** | text + icon, darker/depressed appearance | chevron | User is actively clicking or interacting. Menu may be open. | Space/Enter held down or in active menu interaction. | Visual feedback that interaction is happening. |
| **disabled** | text + icon, reduced opacity (50%), no cursor | chevron, reduced opacity | Both parts are unclickable and unfocusable. Form submission ignores the button. | Not in tab order. No keyboard events fire. | All interactive states suspended. |
| **loading** | text fades or dims, spinner appears in trigger area | spinner icon replaces chevron | Primary action is disabled (mutation in flight). Dropdown is disabled. Spinner animates. | Not in tab order during loading. Focus moves to next control or returns to form. | User cannot interact while async work completes. |
| **error** | text + icon, error color or icon change | trigger may show error state or remain default | Primary button may be disabled or re-enabled based on error type. Menu remains available if retry is an option. | Focusable if re-enablement is possible. | Error messaging lives outside the component (in a live region or error summary). |

## Accessibility and Implementation Notes

### Keyboard Behavior

- **Tab** — moves focus into the split button as a single logical control, not two separate stops
- **Space / Enter** — fires the primary action (same as clicking the primary button)
- **ArrowDown / Alt+ArrowDown** — opens the dropdown menu; focus moves to the first menu item
- **Escape** — closes the menu and returns focus to the trigger
- **ArrowUp** — in open menu, moves focus to previous menu item (managed by Menu component, not this component)
- **ArrowDown** — in open menu, moves focus to next menu item (managed by Menu component)

### ARIA and Semantics

```html
<div role="group" aria-label="Save options">
  <button
    type="button"
    aria-label="Save"
    aria-controls="save-menu"
    aria-expanded="false"
    aria-haspopup="menu"
  >
    Save
  </button>
  
  <button
    type="button"
    aria-label="More save options"
    aria-controls="save-menu"
    aria-expanded="false"
    aria-haspopup="menu"
  >
    <ChevronDownIcon aria-hidden="true" />
  </button>

  <Menu id="save-menu" role="menu">
    <MenuItem role="menuitem">Save as draft</MenuItem>
    <MenuItem role="menuitem">Save and close</MenuItem>
  </Menu>
</div>
```

**Why this structure:**
- `role="group"` wraps both buttons as a single compound control
- Both buttons control the same menu (same `aria-controls` id)
- `aria-expanded="false"` → `"true"` when menu opens
- `aria-haspopup="menu"` signals to assistive tech that a menu will open
- Trigger button gets `aria-label="More save options"` since the icon alone is not descriptive
- Primary button label is its text content ("Save")

### Focus Management

- **Initial focus:** Split button receives focus as a unit; focus ring wraps both parts visually
- **Menu open:** Focus moves to the first menu item (Menu component owns this)
- **Menu close:** Focus returns to the dropdown trigger
- **During loading:** Focus may be moved away or the button may become inert; communicate this with `aria-busy="true"` and `disabled` attribute
- **Touch devices:** Focus and hover states coexist; use sufficient touch target sizing (48px min height, 44px min width per WCAG touch guidance)

### Touch and Mobile

- **Minimum target size:** 48px height × 44px width for the entire split button (primary + trigger combined)
- **Padding:** At least 8px around the icon to ensure comfortable touch spacing
- **No hover states on touch:** All state changes must work via focus, active, disabled, and loading states
- **Trigger button spacing:** Ensure the dropdown trigger is at least 32px wide to avoid accidental activation while touching the primary button

### Motion and Reduced Motion

- **Loading spinner animation:** Should respect `prefers-reduced-motion`
  - If reduced motion is enabled, replace spinning animation with a pulsing opacity change or a static icon
  - Duration minimum 200ms for any animation
- **Menu open/close transitions:** Keep the Menu component responsible; the split button should not animate independently

### States to Avoid

- Do not make the primary button and trigger separately focusable (breaks keyboard UX)
- Do not use color alone to indicate disabled state (use opacity + cursor change)
- Do not disable the dropdown while the primary button is active (state confusion)
- Do not animate the chevron icon rotation (handle this in the Menu component for consistency)

## Component Boundary

**The split button owns:**
- Button layout and visual pairing (primary + trigger)
- Single focus stop and keyboard routing
- Disabled, loading, and enabled states
- Aria labels and menu control attributes
- Touch target sizing and spacing

**The Menu component owns:**
- Menu open/close animation
- Menu item rendering and selection
- Keyboard navigation within the menu (ArrowUp, ArrowDown, Home, End)
- Menu item focus management
- Submenu behavior if needed

**The consuming component (Form, Action Bar) owns:**
- What happens when the primary action fires
- What secondary actions are available in the menu
- Error messaging and retry logic
- Loading state coordination (when to show loading spinner)
- Disabled state logic based on form validity

## Implementation Boundary

Do not hardcode:
- Action labels ("Save", "Save as draft") — pass as props
- Menu items — accept a `menuItems` prop