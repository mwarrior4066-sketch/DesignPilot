# Backend Architecture Spec: Multi-Tenant Scheduling Platform

**Route:** `backend_architecture_spec`  
**Mode:** STRUCTURE  
**Phase:** strategy, specs  
**Escalation:** standard

---

## System Framing

**Actors & Resources**

The system orchestrates work across three core actor classes:

- **Workspace Owner** – creates, configures, deletes workspaces; manages members and webhooks; views audit logs.
- **Team Member** – creates, edits, approves schedule items; posts to activity feeds; receives notifications.
- **End Customer** (via webhook) – receives event payloads; may eventually trigger automation rules via inbound webhook or API gateway.

The core resources are:

- **Workspace** – multi-tenant container, owns members, schedules, webhooks, automation rules, audit trail, and regional residency policy.
- **Schedule Item** – belongs to exactly one workspace; has creator, approver, state transitions (draft → pending approval → approved → executed), and audit events.
- **Activity Feed** – per-workspace cursor-based log of schedule changes, approvals, audit events, and system events.
- **Webhook Subscription** – defines URL, event types, retry policy, and delivery state for a specific workspace.
- **Audit Trail** – immutable log of all mutations and permission checks; used for compliance, debugging, and automation triggers.

Why architecture is necessary:

1. **Multi-tenancy failure**: Without explicit tenant isolation, regional residency policies, and permission scoping, data will leak across workspace boundaries during activity feed pagination, webhook dispatch, and automation-rule evaluation.
2. **Event ordering and delivery**: Without a canonical event model and outbox pattern, webhooks will be delivered out of order, duplicated on retry, or lost on failure. Automation rules will not have ordered, idempotent semantics.
3. **Consistency under concurrency**: Schedule approvals, state transitions, and audit events must maintain causal order and atomicity. Cursor-based pagination across activity feeds must not stall or return duplicate records under concurrent mutations.
4. **Operational blindness**: Without explicit trace propagation and observability hooks, failures in webhook delivery, approval workflows, and automation-rule evaluation will be silent.

---

## Core Model and Authority Boundaries

### Source-of-Truth and Ownership

**Workspace Authority**

The Workspace record is the source of truth for:
- Membership roster and role assignments (owner, member, restricted viewer)
- Regional residency policy (determines which database replicas and event queue regions handle this workspace's data)
- Webhook subscriptions and retry configuration
- Automation-rule definitions and enablement state

No service may override or shadow workspace configuration. All mutations to workspace membership or webhook subscriptions must be written to the Workspace record first; only then may derived state (e.g., permission caches, webhook event queue assignments) be populated.

**Schedule Item Authority**

The Schedule Item record is the source of truth for:
- Creator identity and creation timestamp
- Current state (draft, pending_approval, approved, executed, rejected, cancelled)
- Approver identity (nullable until approval is granted)
- Approval timestamp and decision rationale (optional)

State transitions must be atomic and ordered. The Schedule Item record itself is the atomic unit; there is no separate state-transition table. The audit trail records the *event* of transition, but the Schedule Item carries the *current state*.

**Audit Trail Authority**

The Audit Trail is the source of truth for:
- All mutations to Workspace, Schedule Item, Webhook Subscription, and Automation Rule records
- All permission checks (who tried to do what, with what result)
- All webhook dispatch attempts (event id, delivery timestamp, HTTP status, retry count)
- Automation-rule evaluations and state changes they triggered

Audit records are immutable. Once written, they may be read for compliance, debugging, and automation triggers, but never mutated or deleted.

**Activity Feed Authority**

The Activity Feed is a *read model*. It is derived from the Audit Trail and Schedule Item mutations. It is not the source of truth for any state; it is a convenience view for clients to scan recent changes without replaying the entire audit log.

---

### Tenant Isolation and Permission Boundaries

**Tenant Scoping Rule**

Every query and mutation must include the workspace ID (derived from the request's authentication token). Queries without an explicit workspace scope are rejected. This applies to:
- `SELECT` queries: all must have `WHERE workspace_id = ?`
- `INSERT` queries: all must include the workspace_id
- `DELETE` queries: all must include `WHERE workspace_id = ?`

No shared tables. All tables have a `workspace_id` column and a composite primary key of `(workspace_id, resource_id)`.

**Permission Model: Role-Based Access Control (RBAC) with Object-Level Overrides**

Workspace membership is the root permission boundary. The three roles are:

| Role | Workspace Config | Members | Schedules (Read) | Schedules (Create) | Schedules (Approve) | Webhooks | Audit Trail | Automation Rules |
|---|---|---|---|---|---|---|---|---|
| **Owner** | Write | Write (add/remove) | Read all | Create | Approve any | Write | Read all | Write |
| **Member** | Read | Read (list only) | Read all | Create own | Approve (not own) | Read | Read own + audit events | Read |
| **Restricted Viewer** | None | None | Read only | None | None | None | Read (filtered) | None |

Permission checks happen *before* the query is issued. A member who creates a schedule item should not be able to approve their own item; this is enforced at the application layer, not at the database layer. The audit trail records the permission check result (allowed or denied).

---

### Authorization and Consistency Boundaries

**Source-of-Truth Consistency Model: Read-Your-Writes + Bounded Staleness**

The system uses a **linearizable write model** for the primary database (Workspace, Schedule Item, Webhook Subscription, Audit Trail) with a **bounded-staleness read model** for activity feeds and audit summaries.

- **Writes**: Schedule state transitions, webhook deliveries, audit events, and permission checks are linearizable. A write completes only after it has been committed to the primary database and the write has been acknowledged by at least one replica.
- **Reads**: Workspace and member reads are linearizable. Schedule item reads are linearizable. Activity feed reads are eventually consistent with a bounded staleness of ≤ 2 seconds (time for the activity feed read model to catch up to the primary database).
- **Permission Checks**: Permission checks are linearizable. A user's role and workspace membership are fetched from the primary database before any query is issued.

This prevents data leaks across tenants (tenant isolation is strict) and prevents approval workflows from racing with state transitions (approver cannot approve a schedule that has been executed concurrently).

---

## Data, Consistency, and Delivery Design

### Data Model and Entity Relationships

**Workspace Table**

```
CREATE TABLE workspaces (
  workspace_id UUID PRIMARY KEY,
  name VARCHAR NOT NULL,
  owner_user_id UUID NOT NULL,
  regional_residency ENUM ('us-east', 'eu-west', 'ap-south') NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);
```

Regional residency determines which database region owns this workspace's data, which message queue region handles its events, and which webhook delivery service delivers its webhooks.

**Members Table**

```
CREATE TABLE workspace_members (
  workspace_id UUID NOT NULL,
  user_id UUID NOT NULL,
  role ENUM ('owner', 'member', 'restricted_viewer') NOT NULL,
  added_at TIMESTAMP NOT