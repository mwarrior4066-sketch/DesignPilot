# Brand Positioning Pass

## Audience and problem

Freelancers need a financial operating system that moves as fast as they do—reliable enough for real money, flexible enough for irregular income, and transparent enough that they're not fighting settlement delays and hidden fees. Traditional banks feel slow and untrusting; competitor platforms feel designed for scale, not for the individual person managing their own runway.

The perception gap is real: fintech feels *smart but cold*, banking feels *safe but slow*. Freelancers are caught between needing both safety and speed without the overhead or opacity.

## Positioning frame

**Positioning against:** The fintech-as-infrastructure play (Stripe, Mercury). These are powerful but anonymous—built to move money, not to understand the freelancer's actual financial life.

**Category:** Not "fintech for freelancers" (too crowded). **Financial clarity for self-employed professionals.**

**Wedge:** Own the frame that freelance income and expenses are fundamentally different from employment or business-as-usual. Your competitor platforms treat freelance cash flow as a solved problem; you're positioning them as tools *for* freelancers, not *with* them.

**The actual claim:** You're the first platform designed around the freelancer's actual decision-making rhythm—not transaction speed, but *confidence in cash position*. 

- Stripe moves money fast. You help freelancers *understand* what that money means *right now*.
- Mercury handles volume. You handle uncertainty—the part that keeps freelancers awake.
- Relay offers features. You offer clarity on the numbers that actually matter to someone with irregular income.

## Trust and proof burden

Trust in fintech is *not* built by sounding like a bank. It's built by:
- **Radical transparency on what's actually happening.** No settlement surprises. No "processing" as a black box. Show real-time data about what's pending, what's posted, what's being held. This is your proof—make it visible in the product and your writing.
- **Acknowledging the specific fears.** Freelancers worry about: late invoices delaying deposits, tax implications they don't fully understand, cash flow gaps around project cycles, not knowing which money is "safe to spend." Don't pretend these don't exist. Name them and show how you're different.
- **Evidence that you built this *for* them, not *at* them.** This is a design and narrative choice, not a feature list. Your case studies, writing, and product UX should show freelancer scenarios, not generic fintech benchmarks.

Proof artifacts you'll need:
- Real freelancer quotes about what they feared and why your clarity helped.
- Transparent explanation of how settlement actually works (compare this directly to what competitors hide).
- A specific, named problem you solved for a real freelancer (not "improved cash flow" but "helped Maya see that her Q3 payment from her biggest client was going to arrive 12 days late, so she could plan the gap").

## Messaging consequences

**What you should sound like:**
- **Honest about constraints.** "We can't make your client pay faster, but we can make sure you see exactly when the money will land."
- **Freelancer-fluent, not fintech-jargon.** Talk about projects and income gaps, not ACH windows and rails.
- **Specific about what's different.** Not "better for freelancers" but "we built this around your project cycle, not corporate payroll."
- **Proactive about the emotional part.** Acknowledge that cash flow stress is real. You're not dismissing it as solved by speed alone.

**What you should NOT sound like:**
- Neutral infrastructure. (You'd blend with Stripe.)
- A bank cosplaying as modern. (You'd blend with traditional options.)
- Cheerful optimism about "finally, freelancing is easy!" (It's not. Be real.)
- Feature-obsessed. (Your competitors already dumped features.)

**Tone territory:**
Clear, direct, and acknowledging the actual weight of financial independence. Not apologetic, not corporate-friendly. Freelancers trust people who understand the trade-offs, not people who pretend there aren't any.

---

## Next moves

1. **Interview 5–8 of your actual early users.** Ask: What were you afraid of before you signed up? What's the one number you check first now? What do you still worry about? Use their language in your positioning and case studies.

2. **Name your competitor repositioning clearly.** Write out: "Stripe is ___. Mercury is ___. We are ___." Don't be vague about the frame—be specific so your team and early users understand the wedge.

3. **Build one strong proof artifact:** a single freelancer case study that shows the actual problem (not "needs a financial system" but "couldn't see when her retainer payment would settle, so she was over-committing new work"), how your clarity changed her decision-making, and what shifted. This becomes your north star.

4. **Audit your website and copy for neutral-sounding language.** Search for "seamless," "integrated," "innovative," "easy." Replace with freelancer-specific scenarios and honest explanations of how your clarity works differently.