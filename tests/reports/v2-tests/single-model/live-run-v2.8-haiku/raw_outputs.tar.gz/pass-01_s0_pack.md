# Pricing Page Audit

**Mode:** AUDIT | **Phase:** UI | **Route:** UI Structure Critique + Accessibility Feedback Audit

---

## Problem Framing

The pricing page has three distinct structural failures that compound into a weak conversion surface:

1. **Hero CTA is visually buried** — the button is undersized relative to the hero's visual weight, making the primary conversion action feel optional
2. **Pro tier color-coding fails accessibility** — the highlight colors likely do not meet WCAG contrast thresholds, hiding the product's recommended option from low-vision and color-blind users
3. **Feature comparison comes *after* pricing**, adding cognitive friction — users cannot evaluate fit before deciding tier

The page asks users to commit to a tier before understanding what each tier includes.

---

## Findings

### Hero CTA is undersized
The button is small relative to the headline and background image. In B2B SaaS pricing, the CTA must be one of the heaviest visual elements — it should feel like the natural next action, not a secondary detail. A large hero with a small button creates a hierarchy failure: the background image wins the first scan, the headline wins the second, and the button is buried third.

**Visual confidence:** High (direct observation from description).

### Pro tier color-coding is not accessible
Color alone cannot convey the "recommended" status. Users with color blindness (roughly 8% of males, 0.5% of females) cannot see the difference. Even users with low vision may not perceive the distinction. A WCAG AA contrast ratio of 4.5:1 requires significant luminance separation; soft pastels or brand colors often fail this test.

**Visual confidence:** Medium (inferred from "colors are not accessible" in the brief; needs verification against the actual palette).

### Feature comparison is positioned *after* tier selection
Users see pricing ($29, $79, custom) before understanding what each tier unlocks. This breaks the B2B buying journey: feature fit must come *before* price commitment in high-consideration categories. Putting the comparison table below the pricing table forces users to scroll, re-examine, and potentially restart their decision.

**Visual confidence:** High (structural observation).

### Testimonials placement is inert
A testimonials strip at the bottom does not reinforce the pricing decision. In B2B, social proof should anchor the conversion moment — ideally near or *within* the pricing table (e.g., "Recommended by XYZ" or customer logos on the Pro tier).

**Visual confidence:** Medium (inferred structural weakness).

---

## Recommendations

### 1. Enlarge and weight the hero CTA (first intervention)
- Make the button at least 48–56px tall and at least 200px wide
- Use a solid, saturated primary color with strong contrast to the background (WCAG AAA preferred: 7:1)
- If the background is an image, add a semi-transparent dark overlay behind the button to guarantee contrast
- Position it below the headline and above the fold
- Test: the button should feel like the natural "next" action after reading the headline

**Why first:** This is the single highest-leverage fix. A buried CTA compounds all downstream friction.

### 2. Fix color-coding to use redundant signals (second intervention)
Replace color-only highlighting with:
- **Checkmark icons** on features included in the Pro tier
- **"Recommended" badge** above the Pro tier heading (text, not color)
- **Subtle border or background change** — increase luminance contrast to at least WCAG AA (4.5:1 for text), or use a high-contrast border (e.g., dark gray at 3px) instead of pastels
- Keep the color, but ensure it also has a luminance difference, not just hue

**Accessibility test:** Use a color-blindness simulator (e.g., Coblis) to verify the tier is still identifiable without relying on hue alone.

### 3. Move the feature comparison table *above* the pricing table (third intervention)
Reorder the page:
1. Hero + CTA
2. **Feature comparison table** (narrow to 3 columns, labeled Starter / Pro / Enterprise)
3. Pricing table with redundant "Recommended" signals
4. Testimonials (repositioned near the Pro tier, not at the bottom)

**Why this order:** Users answer "What do I need?" before "What does it cost?" The comparison becomes a decision scaffold, not a footnote.

### 4. Integrate testimonials into the pricing section (optional, high-impact)
- Add a small quote or customer logo inside or next to the Pro tier card
- Use one short testimonial that reinforces the Pro tier value (e.g., "Most popular with teams of 10–50")
- This anchors social proof to the purchase moment instead of burying it

---

## Tradeoffs

| Preserve | Sacrifice | Flex first |
|---|---|---|
| Hero image and headline | Visual polish and soft color palette | Luminance contrast requirements must win |
| Three-tier pricing structure | Aesthetic "elegance" of color-only coding | Accessibility must not be compromised |
| Testimonials (content) | Their current position and prominence | Move them into the pricing section where they actually influence the decision |

**Clarity should win:** The page's job is to move high-consideration buyers from "What do I get?" to "I'll start with Pro." Every element must serve that job. Color as the only tier indicator fails this test.

---

## Implementation order

1. **CTA size** (1–2 hours): Enlarge button, adjust padding, test contrast.
2. **Redundant accessibility signals** (2–4 hours): Add badge text, icons, luminance contrast; remove color-only coding.
3. **Reorder content** (4–8 hours): Move comparison table above pricing; integrate testimonials.
4. **Verify accessibility** (1–2 hours): Test with color-blindness simulator, screen reader, WCAG validator.

---

## Verification checklist

- [ ] CTA button is 48–56px tall and clearly visible above the fold
- [ ] Pro tier is distinguishable without color (e.g., by badge, border, or text label)
- [ ] All color contrasts meet WCAG AA (4.5:1 for text; 3:1 for UI components)
- [ ] Feature comparison table precedes pricing table
- [ ] Screen reader announces "Recommended" for Pro tier
- [ ] Testimonials appear within or adjacent to the pricing section
- [ ] Mobile: CTA remains prominent; columns stack clearly; features remain scannable