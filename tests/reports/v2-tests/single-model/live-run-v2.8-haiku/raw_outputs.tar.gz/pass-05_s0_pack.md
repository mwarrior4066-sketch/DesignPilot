# PDF Remediation Plan

## Current failure state

The PDF has three blocking accessibility failures:

1. **Semantic structure is broken.** Two-column layout content lacks proper reading-order tagging. Pull quotes and decorative images have no artifact markers, so screen readers treat them as main content, fragmenting the narrative.
2. **Extraction and export fidelity is at risk.** Broken ToC links and untagged images will corrupt copy-paste, text extraction, and downstream republishing.
3. **Document integrity cannot be verified.** Without explicit artifact and tag repair, you risk silent data loss when users extract or re-export the PDF.

## Remediation sequence

### Phase 1: Structure and artifact tagging (do first)
1. Open the PDF in Acrobat Pro and run **Tools > Accessibility > Add Tags to Document** to generate the initial tag tree.
2. Inspect the tag tree (View > Show Tag Panel). You should see a structure tree with artifacts, paragraphs, images, and table markers.
3. **Mark decorative images as artifacts.** Select each decorative image in the tag tree, right-click, and change its tag to `<Artifact>`. Do not delete—artifact-tag status preserves the visual rendering but removes it from the reading order and extraction.
4. **Mark pull quotes as asides or blockquotes.** For each pull quote:
   - If it is a direct excerpt, wrap it in `<BlockQuote>` tags.
   - If it is a standalone commentary, wrap it in `<Sect>` tags and assign it a role label (e.g., "pull quote").
   - Move it *after* the paragraph it interrupts in the tag tree so reading order matches narrative flow.

### Phase 2: Reading order repair (do second)
1. **Reorder the two-column layout.** The auto-tagger often preserves InDesign's column order (left column, then right column, then left column again). Instead:
   - Use **Tools > Accessibility > Reading Order** to open the reading order dialog.
   - Click on each content block in the PDF in the order it should be read (top to bottom, left to right within each row).
   - The order panel will rewrite the tag tree to match your clicks.
2. **Verify the order by testing.** Open **File > Properties > Content** and enable "Reading order" in the Accessibility section. Tab through the PDF with a screen reader (NVDA or JAWS) or use Acrobat's Read Aloud feature to confirm flow.

### Phase 3: Hyperlink and reference repair (do third)
1. **Rebuild ToC links.** The broken links are likely orphaned reference anchors. In Acrobat:
   - Select the ToC entry text in the PDF.
   - Right-click > **Create Link**.
   - Set the link type to **Go to a page in this document** or **Go to a named destination**.
   - If named destinations exist but are orphaned, use **Tools > Edit PDF > Link** to retarget the link to the correct page or create a new destination if needed.
2. **Test each link** by clicking it in the PDF viewer and confirming it lands on the right page.

### Phase 4: Verification checks (do last)
1. **Run the Accessibility Checker.** In Acrobat, go to **Tools > Accessibility > Full Check**. Fix any remaining issues:
   - Missing alt text (add it; do not leave blank if the image is meaningful).
   - Unmarked lists or tables.
   - Missing language specification (set document language under **File > Properties > Advanced**).
2. **Extract text to confirm reading order.** In Acrobat, select all content (**Ctrl+A**) and copy it. Paste into a text editor and verify the narrative flows without fragments or repeated columns.
3. **Test with a screen reader.** Use NVDA (Windows) or VoiceOver (Mac) to navigate the PDF. The reading order should match the visual narrative—no jumps, no artifact repetition, no missing content.

## Risk controls

- **Do not flatten or rasterize the document.** Flattening destroys all tagging and makes the PDF unrecoverable.
- **Do not use OCR as a shortcut.** OCR will regenerate text but loses all original tagging and semantic structure.
- **Preserve the InDesign source.** Keep the .indd file so you can re-export if the remediation fails. Tag changes in Acrobat do not feed back to the source.
- **Use a backup.** Save the original PDF before starting remediation.

---

## Why this sequence works

**Structure first** ensures the tag tree is machine-readable before you move content. **Reading order second** fixes the narrative flow without losing semantic markers. **Links third** restores the reference contract. **Verification last** catches silent failures before the PDF ships.

The two-column layout will collapse into a single reading order when exported to text, which is correct—columns are a visual structure, not a logical one. Pull quotes, once tagged as asides or blockquotes, will be skippable by assistive-tech users and will not corrupt extraction. Decorative images, once artifact-tagged, will vanish from screen-reader output and text exports, preserving clarity.

[SESSION_STATE]
{
  "route": "pdf_remediation_plan",
  "escalation_level": "standard",
  "decisions_committed": [
    "semantic_failure: two-column layout and untagged images fragmenting reading order",
    "reading_order_or_extraction: pull quotes and decorative images interrupting narrative; broken ToC links blocking reference integrity",
    "verification_method: screen reader navigation, text extraction test, accessibility checker",
    "destructive_shortcut_rejected: no flatten, no rasterize, no OCR-first approach"
  ],
  "evidence_classes_cited": [
    "standards_reference: PDF/UA tagging, artifact markers, reading order semantics",
    "verification_method: screen reader, text extraction, accessibility checker, link test",
    "implementation_constraint: preserve InDesign source, backup original, protect tag structure"
  ],
  "validator_flags": [],
  "weak_patterns_seen": [],
  "open_questions": [
    "Does the original InDesign file still exist for re-export if needed?",
    "Are there any complex table structures or embedded graphics that need special tagging?"
  ],
  "turn": 1
}
[/SESSION_STATE]