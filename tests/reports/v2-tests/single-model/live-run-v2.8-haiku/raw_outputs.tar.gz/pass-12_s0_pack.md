# Type System Recommendation for Fintech

## Reading context
Fintech products read across three distinct contexts with different density, device constraints, and confidence requirements:
- marketing site: narrative and proof-heavy, longer-form blocks, variable viewport sizes
- web app dashboard: dense tabular data, rapid scanning, precise numeric alignment, small-to-medium text
- mobile: constrained viewport, touch-friendly target sizes, high scan efficiency

Each context has different readability demands. The system must preserve hierarchy and contrast across all three without requiring three separate type stacks.

## Scale and role map

### Display roles (marketing + top-level hierarchy)
- **Display XL** (48px / 56px line-height): marketing hero, major section headers
- **Display L** (36px / 44px): featured claims, marketing subheads
- **Display M** (28px / 36px): card titles, dashboard section headers, feature callouts

### Heading roles (hierarchy within content)
- **Heading L** (24px / 32px): page titles, form section labels, primary navigation labels
- **Heading M** (20px / 28px): subsection headers, modal titles, card headers
- **Heading S** (16px / 24px): component labels, secondary navigation, toggle labels

### Body roles (reading and data)
- **Body Regular** (16px / 24px): marketing paragraphs, table descriptions, default UI text
- **Body Compact** (14px / 20px): dashboard context text, secondary descriptions, help text
- **Body Dense** (13px / 18px): table cell data, chart labels, small UI labels (mobile-safe minimum)

### Numeric and code roles
- **Mono** (14px / 20px for dashboard, 13px / 18px for tables): all numeric cell data, hash values, transaction IDs, code snippets
- **Mono Label** (12px / 16px): metadata, timestamps, currency codes

## Font selection and stack

### Recommended typeface pairing
- **Sans-serif (primary)**: Inter (variable font with opsz axis when available)
  - Why: Excellent optical sizing support across all point sizes. Open-source. Free variable-weight options. Proven in fintech dashboards (Stripe, Wise, Square). High x-height supports small size legibility. Neutral, trustworthy voice.
  
- **Mono (tabular data)**: IBM Plex Mono (or Roboto Mono as fallback)
  - Why: Excellent alignment in tables. Fintech-standard. Clear distinction between similar glyphs (0/O, 1/l/I). Tabular figures by default. Licensed and fallback-available.

### Fallback stack
If variable fonts are unavailable or performance-critical:
```
Body: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif
Mono: "IBM Plex Mono", "Courier New", monospace
```

Avoid generic system stacks for display roles; use a controlled fallback like "Trebuchet MS" or accept a shift to the next available sans-serif.

## Readability rules

### Line length and density
- **Marketing site**: 45–75 characters per line (use max-width: 90ch on paragraphs)
- **Dashboard tables**: 13–14px mono, 18–20px line-height, allows dense grid without crowding
- **Mobile**: 30–50 characters (naturally constrained by viewport at 16px body on mobile)

### Line-height (leading)
- **Display**: 1.1–1.2 ratio (tighter, more confident)
- **Heading**: 1.3–1.4 ratio (breathing room for hierarchy)
- **Body**: 1.5 ratio (standard readable prose)
- **Mono data**: 1.4–1.5 ratio (tight enough to stack multiple rows, loose enough for clarity)

### Letter spacing (tracking)
- **Display**: −0.02em (confidence, modernity)
- **Heading**: −0.01em to 0em (neutral)
- **Body**: 0em (default)
- **Mono**: 0em to +0.01em (ensures glyphs don't blur in small sizes)

### Weight distribution
- **Regular** (400): all body text, navigation, default UI labels
- **Medium** (500): subsection headers, form labels, secondary actions, emphasis within body
- **Semibold** (600): heading hierarchy, primary navigation, dashboard section headers, CTA labels
- **Bold** (700): display roles, major claims, critical alerts or status badges

Do not use weight alone for semantics. Always pair with size change or role position.

## Token-based adoption guidance

### Phase 1: Display and heading scale (low risk, high impact)
Map existing display and heading styles to the new scale. This establishes the new system's "voice" without touching data or forms.
- Time: 1–2 sprints
- Test: Check contrast, mobile reflow, and visual hierarchy match across web, dashboard, mobile

### Phase 2: Body and UI text roles
Replace body text styles with the new stack. Keep existing functional text roles (labels, placeholders, hints) at their current sizes during this phase.
- Time: 2–3 sprints
- Test: Paragraph readability at 16px body. Label legibility at 14px. Help text at 13px on mobile.

### Phase 3: Tabular data and numeric roles
Migrate all table, list, and data-grid cell text to mono roles. This is fintech-critical; test alignment and readability first.
- Time: 1–2 sprints
- Critical test: Numbers, currency codes, and IDs align vertically. Rows remain scannable at 13px without eyestrain.

### Phase 4: Marketing site prose (longer lift, isolated risk)
Apply new heading and body stack to marketing site. Adjust max-widths and leading if the new font rendering changes line-breaking behavior.
- Time: 2–3 sprints
- Test: Proof-reading for text reflow, headline scan legibility, CTA clarity.

Avoid attempting all four phases at once. Each phase allows QA and user feedback loops.

## Accessibility and cross-platform notes

- **Minimum size**: 13px on mobile, 14px on desktop. Anything smaller fails WCAG AA for normal text and risks eye strain on financial data.
- **Contrast**: Use Weight 600+ for smaller sizes (13–14px) and lighter weight for sizes 18px+. This maintains perceptual contrast and prevents spindly rendering on light backgrounds.
- **Dark mode**: Test the mono stack at 13px on both light and dark backgrounds. Fintech often runs dark dashboards; verify digit clarity without haloing or blur.
- **Variable font performance**: Inter opsz axis reduces token payload when used with `font-optical-sizing: auto`, but test on slower networks (mobile LTE) before relying on dynamic sizing.
- **Multilingual**: Inter and IBM Plex Mono both support Latin, Cyrillic, Greek, and extended character sets. Verify CJK support separately if your user base extends to Asia.

## Migration notes

### Current to new
If you have an existing stack, map roles by visual size and function, not by name. A "small heading" in your current system (14px, semibold) should map to **Heading S**, not stay at 14px.

### Token naming
Use descriptive role names (`heading-l`, `body-regular`, `mono-dense`) rather than size-only names (`h3`, `text-sm`). This survives design changes and makes hierarchy explicit for developers.